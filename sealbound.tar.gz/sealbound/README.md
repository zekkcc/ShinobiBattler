# Sealbound — Shinobi Battler Online

[![CI](https://github.com/OWNER/sealbound/actions/workflows/ci.yml/badge.svg)](https://github.com/OWNER/sealbound/actions/workflows/ci.yml)

A turn-based, server-authoritative PvP battler, with a meta-game of territory,
politics, crafting and trade sitting on top of it.

Combat is meant to read as chess rather than as a damage race: three chakra
reserves with asymmetric regeneration, hand seals that can be interrupted,
substitutions you have to choose rather than have happen to you, and elemental
combos that reward setting something up a turn early. Between matches, players
gather and craft, run a market, hold ground in weekly clan wars, elect a village
government with bounded powers, and teach each other.

One rule runs through all of it: **nothing purchasable affects combat power.**
That is enforced by the build, not by good intentions — `pnpm validate:content`
fails if an item grows a combat field, and `pnpm drift` fails if any path opens
from the economy into combat resolution.

> **On the setting.** This is a fan project using names from the *Naruto*
> franchise. The MIT licence covers the code only. See [`NOTICE.md`](NOTICE.md),
> which also explains how to reskin it — every name lives in content JSON, so
> swapping the setting changes no code and no balance number.

## Run it locally

```
pnpm install
pnpm dev              # game server on :3000 + web client on :5173
```

Then open **http://localhost:5173** and enrol — pick a name, a password, and a
village. Open a second window (or an incognito one), enrol a second shinobi, put
both in the queue, and you have a match against yourself.

Vite proxies `/api` and `/ws` to the game server, so the browser stays on one
origin and there is no CORS setup to do.

To run them separately: `pnpm dev:server` and `pnpm dev:web`.

## Deploy it

The API and the built client are served from one process on one origin, so a
deployment is a single container.

```
docker compose up --build      # app on :3000, Postgres alongside it
```

Or without Docker:

```
pnpm install
pnpm build                     # builds the web client into apps/web/dist
DATABASE_URL=postgres://... MIGRATE_ON_BOOT=1 pnpm start
```

With no `DATABASE_URL` the server runs in memory and everything resets on
restart — fine for local play, useless for anything else. Copy `.env.example`
for the full list of settings. `MIGRATE_ON_BOOT=1` applies `schema.sql`; it is
meant for a fresh database, and there is no migration path yet for one that
already holds players.

## Checks

```
pnpm check           # everything below, in one command — this is what CI runs

pnpm test            # 109 engine tests
pnpm test:server     # 346 tests: auth, trust model, progression, squads, clans,
                     #            rogue-nin, titles and legendaries, the meta-game,
                     #            and a store contract run against both backends
pnpm lint            # engine-purity rules (CLAUDE.md §4)
pnpm validate:content
pnpm parity          # archetype fixture fairness
pnpm sim -- --matches 20000
pnpm sim:economy     # 48 players over a season: faucets, sinks, prices, roles
pnpm tune            # automated balance search
pnpm qa              # adversarial fuzzer + 20 combat exploit probes
pnpm qa:meta         # 33 meta-game exploit probes (economy, trade, ground, elections)
pnpm drift           # design-direction conformance — 70 properties
pnpm check           # all of the above, in one command
```

## Layout

```
packages/shared     Zod DTOs and the shared type model. No business logic.
packages/engine     Pure combat resolution. resolveTurn(state, actions, rng).
packages/content    267 jutsu, 24 statuses, 21 bloodlines, 6 combos, 17 missions,
                    training locations, clans, villages, reputation tiers,
                    promotion gates, and every balance constant. Plus the
                    meta-game: seasons, 10 regions, 18 items and 8 recipes,
                    village politics, 3 dungeons, mentorship, 24 cosmetics.
apps/server         Fastify + WebSocket. Accounts, matchmaking, match rooms,
                    training, missions, squads, reputation, teachers, rank exams,
                    clans, defection and bounties, titles and legendaries,
                    rating, replays — and the meta-game: territory and clan wars,
                    the escrowed market and crafting, elections and office
                    powers, dungeons, mentorship, cosmetics.
apps/web            React + Vite + Zustand client. Renders server state and
                    submits intent; it calculates nothing itself.
tools/balance       Simulator, fixture parity check, automated tuner.
tools/qa            Invariant fuzzer, exploit probes, drift check.
tools/lint          Engine-purity rules enforced in CI.
.claude/agents      Sub-agents for review, tuning, and QA passes.
```

## Server

The transport is deliberately thin: it resolves a connection to an authenticated
player id and hands the raw payload to `GameService`, which makes every game
decision. There is exactly one place the trust model can be got wrong.

### Accounts

One account is one shinobi, which is what makes reputation and rank mean anything.
Passwords are scrypt-hashed with a per-user salt and a self-describing digest, so
the cost parameters can be raised later without invalidating anyone. Session tokens
are 256 bits of randomness and only their SHA-256 is stored, so a database dump does
not hand over live sessions. Login answers identically for a wrong name and a wrong
password, and does the hashing work either way, so it cannot be used to find out who
plays here.

`SEED_DEV_ACCOUNTS=1` creates two local accounts and prints their tokens. It is off
by default so it cannot fire in production.

### Storage

Two implementations behind one `Store` interface, and the same contract suite runs
against both — that is what makes them interchangeable rather than merely similar.

```
DATABASE_URL=postgres://…  MIGRATE_ON_BOOT=1  pnpm dev:server
```

Without `DATABASE_URL` the server runs in memory and everything resets on restart.
`PostgresStore` is written against a two-line driver interface, so production runs
it on `pg.Pool` and the tests run it on an in-process Postgres.

Note what `schema.sql` does NOT have: no elapsed or progress column on training
(time is always derived from `started_at` against the server clock) and no
state-snapshot column on replays (they are `(seed, actions[])` only). Those
absences are the guarantee, and there are tests asserting the columns stay absent.

## The meta-game

Seven systems sit on top of combat, and one rule runs through all of them: none
of them can affect combat power. Territory pays in war score and resources, an
office pays in bounded village-wide effects, the market pays in materials that
make training and gathering faster, and cosmetics pay in nothing at all. There is
no code path from any of it into `resolveTurn`, and `pnpm drift` fails the build
if one appears.

Players may trade and gift directly. Transfers are therefore free, and no attempt
is made to pretend otherwise: what the server guarantees instead is that a trade
settles atomically, that the `tradable` flag is honoured by gifts as well as
sales, and that every completed transfer is written to an append-only log with
both ends and the exact contents. Prevention was traded for attribution
deliberately — see `docs/OVERRIDES.md`. The market keeps its fee and its tax,
because the reference price band is built on what people actually pay there.

Four invariants are held by database constraints rather than application checks,
because an application check is the part that loses a race: one war per region
per period, one vote per player per office per cycle, one active mentor per
student, and one buyer per listing.

## Not yet built

`apps/web` covers the meta-game across six screens, but a few controls are still
missing: proposing a full item-for-item trade, enacting laws, commissioning public
works, and declaring war on another village. The black market in `economy.json` has no handler yet. Anything
else outstanding is at the bottom of `docs/OVERRIDES.md`.
