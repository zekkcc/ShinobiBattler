/**
 * `pnpm validate:content` — schema validation plus the checks that a Zod schema
 * cannot express: economic sanity, effect-kind budget, and the IP scan.
 *
 * Invalid records fail the build (CLAUDE.md §8).
 */
import { EFFECT_KINDS, ZJutsu } from '@shinobi/shared';
import {
  BLOODLINES, CLANS, COMBOS, JUTSU, STATUSES, STATUS_BY_ID, TUNING, VILLAGES, BASELINE_ACTIONS, rollBloodline,
  COSMETICS, DUNGEONS, ECONOMY, ITEM_BY_ID, LEGACY, MENTORSHIP, MISSIONS, POLITICS, SEASONS, TERRITORY, TRAINING, currentSeason,
} from './index.js';

const problems: string[] = [];
const warnings: string[] = [];

/* ── 1. Schema ────────────────────────────────────────────────────────── */
for (const j of JUTSU) {
  const parsed = ZJutsu.safeParse(j);
  if (!parsed.success) problems.push(`${j.id}: ${parsed.error.issues.map((i) => i.path.join('.') + ' ' + i.message).join('; ')}`);
}

/* ── 2. Referential integrity ─────────────────────────────────────────── */
const seen = new Set<string>();
for (const j of JUTSU) {
  if (seen.has(j.id)) problems.push(`duplicate id: ${j.id}`);
  seen.add(j.id);

  const walk = (effects: readonly unknown[]): void => {
    for (const e of effects as { kind: string; status?: string; statuses?: string[]; effects?: unknown[]; bonusVs?: { status: string } }[]) {
      if (!(EFFECT_KINDS as readonly string[]).includes(e.kind)) problems.push(`${j.id}: unknown effect kind "${e.kind}"`);
      if (e.status && !STATUS_BY_ID.has(e.status as never)) problems.push(`${j.id}: unknown status "${e.status}"`);
      if (e.bonusVs && !STATUS_BY_ID.has(e.bonusVs.status as never)) problems.push(`${j.id}: unknown bonusVs status`);
      for (const s of e.statuses ?? []) if (!STATUS_BY_ID.has(s as never)) problems.push(`${j.id}: unknown cleanse status "${s}"`);
      if (e.effects) walk(e.effects);
    }
  };
  walk(j.effects);
}

for (const id of BASELINE_ACTIONS) {
  if (!seen.has(id)) problems.push(`baseline action "${id}" is not in the library`);
  const j = JUTSU.find((x) => x.id === id);
  if (j) {
    const total = j.cost.physical + j.cost.mental + j.cost.natural;
    if (total > 0) problems.push(`baseline action "${id}" must be free, costs ${total} across pools`);
  }
}

/* ── 3. Effect-kind budget (CLAUDE.md §6: the set is meant to stay small) ── */
if (EFFECT_KINDS.length > 16) {
  problems.push(`effect kinds have grown to ${EFFECT_KINDS.length}; §6 asks that this set stay small — get sign-off before adding more`);
}
const used = new Set<string>();
for (const j of JUTSU) {
  const walk = (effects: readonly { kind: string; effects?: { kind: string }[] }[]): void => {
    for (const e of effects) { used.add(e.kind); if (e.effects) walk(e.effects); }
  };
  walk(j.effects as never);
}
for (const kind of EFFECT_KINDS) {
  if (!used.has(kind)) warnings.push(`effect kind "${kind}" is defined but unused by any jutsu`);
}

/* ── 4. Economic sanity ───────────────────────────────────────────────── */
const RANK_ORDER = ['E', 'D', 'C', 'B', 'A', 'S'];
for (const j of JUTSU) {
  if (j.cost.physical > 240 || j.cost.mental > 240) problems.push(`${j.id}: single-pool cost is unreachable`);
  if (j.cost.natural > 0 && j.rank !== 'S' && j.id !== 'sage-mode') {
    warnings.push(`${j.id}: costs natural energy but is not S-rank — natural energy cannot be regenerated`);
  }
  if (j.seals === 0 && j.sealDifficulty > 0) problems.push(`${j.id}: sealDifficulty on a seal-less technique`);
  if (j.seals > 0 && j.sealDifficulty === 0) problems.push(`${j.id}: sealed technique with no difficulty — its accuracy roll can never fail`);
  if (j.seals > 0 && j.interruptThreshold > 400) problems.push(`${j.id}: interruptThreshold makes the weave uninterruptible`);
  const rankIdx = RANK_ORDER.indexOf(j.rank);
  if (rankIdx >= 4 && j.cooldown === 0) warnings.push(`${j.id}: ${j.rank}-rank with no cooldown`);
  if (j.requires && j.requires.min > 200) problems.push(`${j.id}: stat requirement above the stat ceiling`);
}

/* ── 5. Statuses ──────────────────────────────────────────────────────── */
for (const s of STATUSES) {
  if (s.control === 'skipChance' && s.controlChance === undefined) problems.push(`status ${s.id}: skipChance without controlChance`);
  if (s.dotPctMaxHp !== undefined && s.hotPctMaxHp !== undefined) problems.push(`status ${s.id}: both damages and heals`);
}
const referenced = new Set<string>();
for (const j of JUTSU) {
  const walk = (effects: readonly { status?: string; statuses?: string[]; effects?: unknown[] }[]): void => {
    for (const e of effects) {
      if (e.status) referenced.add(e.status);
      for (const s of e.statuses ?? []) referenced.add(s);
      if (e.effects) walk(e.effects as never);
    }
  };
  walk(j.effects as never);
}
for (const s of STATUSES) {
  if (!referenced.has(s.id) && s.id !== 'exhaustion') warnings.push(`status "${s.id}" is never applied by any jutsu`);
}

/* ── 6. Bloodlines, clans, villages ───────────────────────────────────── */
for (const b of BLOODLINES) {
  for (const g of b.grants) {
    if (!seen.has(g)) problems.push(`bloodline ${b.id}: grants unknown jutsu "${g}"`);
  }
  if (b.clan && !CLANS.some((c) => c.id === b.clan)) problems.push(`bloodline ${b.id}: unknown clan "${b.clan}"`);
  if (b.grants.length === 0) warnings.push(`bloodline ${b.id} grants no techniques`);
}
for (const c of CLANS) {
  if (!VILLAGES.some((v) => v.id === c.village)) problems.push(`clan ${c.id}: unknown village "${c.village}"`);
  for (const bl of c.bloodlines) {
    if (!BLOODLINES.some((b) => b.id === bl)) problems.push(`clan ${c.id}: unknown bloodline "${bl}"`);
  }
}
for (const v of VILLAGES) {
  for (const c of v.clans) {
    if (!CLANS.some((x) => x.id === c)) problems.push(`village ${v.id}: unknown clan "${c}"`);
    else if (CLANS.find((x) => x.id === c)!.village !== v.id) {
      problems.push(`village ${v.id}: clan "${c}" does not point back to this village`);
    }
  }
}

/* Every bloodline-granted technique must be reachable ONLY via a bloodline or a
   loadout — a grant that duplicates a freely-buyable jutsu is a dead perk. */
const grantedIds = new Set(BLOODLINES.flatMap((b) => b.grants));
const overlap = [...grantedIds].filter((g) => (BASELINE_ACTIONS as readonly string[]).includes(g));
for (const o of overlap) problems.push(`bloodline grant "${o}" is also a free baseline action`);

/* ── 7. Combos ────────────────────────────────────────────────────────── */
for (const c of COMBOS) {
  if (!STATUS_BY_ID.has(c.setup)) problems.push(`combo ${c.id}: unknown setup status "${c.setup}"`);
  const setupExists = JUTSU.some((j) => j.effects.some((e) => e.kind === 'applyStatus' && e.status === c.setup));
  if (!setupExists) problems.push(`combo ${c.id}: no jutsu can apply the setup status "${c.setup}" — the combo is unreachable`);
  const triggerExists = JUTSU.some((j) => j.nature === c.trigger && j.effects.some((e) => e.kind === 'damage'));
  if (!triggerExists) problems.push(`combo ${c.id}: no damaging ${c.trigger} technique exists to trigger it`);
}
const comboKeys = new Set<string>();
for (const c of COMBOS) {
  const k = `${c.setup}|${c.trigger}`;
  if (comboKeys.has(k)) problems.push(`combo ${c.id}: duplicate setup+trigger pair "${k}" — only one would ever fire`);
  comboKeys.add(k);
}

/* ── 8. Bloodline rarity (direction doc: ~20% of players, lore-weighted) ── */
{
  const total = BLOODLINES.reduce((n, b) => n + b.rarity, 0);
  const commonest = BLOODLINES.reduce((a, b) => (b.rarity > a.rarity ? b : a));
  const rarest = BLOODLINES.reduce((a, b) => (b.rarity < a.rarity ? b : a));
  if (rarest.rarity * 10 > commonest.rarity) {
    warnings.push(`bloodline rarity spread is flat (${rarest.id}=${rarest.rarity} vs ${commonest.id}=${commonest.rarity}) — lore scarcity should be pronounced`);
  }
  let granted = 0;
  const N = 20000;
  for (let i = 0; i < N; i++) if (rollBloodline((i * 0.61803398875) % 1, ((i * 0.31830988618) % 1)) !== null) granted++;
  const pct = granted / N;
  if (Math.abs(pct - TUNING.bloodlines.grantChance) > 0.02) {
    problems.push(`rollBloodline grants ${(pct * 100).toFixed(1)}% of characters a bloodline, expected ${(TUNING.bloodlines.grantChance * 100).toFixed(0)}%`);
  }
  void total;
}


/* ── 9. Seasons ───────────────────────────────────────────────────────── */
{
  const weatherIds = new Set(TRAINING.weather.map((w) => w.id));
  const covered = new Set<string>();
  for (const s of SEASONS.seasons) {
    for (const w of s.weather) {
      if (!weatherIds.has(w)) problems.push(`season ${s.id}: unknown weather "${w}"`);
      covered.add(w);
    }
    if (new Set(s.weather).size !== s.weather.length) problems.push(`season ${s.id}: repeats a weather id, which flattens the rotation`);
  }
  for (const w of weatherIds) if (!covered.has(w)) warnings.push(`weather "${w}" never occurs in any season`);
  if (SEASONS.cycleDays % SEASONS.seasons.length !== 0) {
    problems.push(`seasons do not divide the year evenly (${SEASONS.cycleDays} days / ${SEASONS.seasons.length})`);
  }
  // The rotation must actually move: four seasons across a year, each reachable.
  const dayMs = 24 * 60 * 60 * 1000;
  const seen9 = new Set<string>();
  for (let d = 0; d < SEASONS.cycleDays; d++) seen9.add(currentSeason(d * dayMs).id);
  if (seen9.size !== SEASONS.seasons.length) problems.push(`only ${seen9.size} of ${SEASONS.seasons.length} seasons occur within a cycle`);
}

/* ── 10. Territory ────────────────────────────────────────────────────── */
{
  const regionIds = new Set(TERRITORY.regions.map((r) => r.id));
  const itemIds = new Set(ECONOMY.items.map((i) => i.id));
  for (const r of TERRITORY.regions) {
    if (!VILLAGES.some((v) => v.id === r.homeVillage)) problems.push(`region ${r.id}: unknown home village "${r.homeVillage}"`);
    for (const a of r.adjacent) {
      if (!regionIds.has(a)) { problems.push(`region ${r.id}: unknown neighbour "${a}"`); continue; }
      const back = TERRITORY.regions.find((x) => x.id === a)!;
      if (!back.adjacent.includes(r.id)) problems.push(`region ${r.id}: adjacency to "${a}" is not mutual`);
    }
    if (r.adjacent.includes(r.id)) problems.push(`region ${r.id}: adjacent to itself`);
    for (const res of r.resources) {
      if (!itemIds.has(res)) problems.push(`region ${r.id}: unknown resource "${res}"`);
      else if (ECONOMY.items.find((i) => i.id === res)!.kind !== 'resource') {
        problems.push(`region ${r.id}: "${res}" is gatherable but is not a resource`);
      }
    }
  }
  // A disconnected region can never be reached by a front line, so it can never
  // change hands — it would be permanent territory for whoever starts with it.
  const reach = new Set<string>([TERRITORY.regions[0]!.id]);
  const stack = [TERRITORY.regions[0]!.id];
  while (stack.length) {
    const id = stack.pop()!;
    const cur = TERRITORY.regions.find((r) => r.id === id);
    if (!cur) continue;
    for (const a of cur.adjacent) if (!reach.has(a) && regionIds.has(a)) { reach.add(a); stack.push(a); }
  }
  if (reach.size !== TERRITORY.regions.length) {
    problems.push(`territory graph is disconnected: ${TERRITORY.regions.length - reach.size} region(s) unreachable`);
  }
  for (const item of ECONOMY.items) {
    if (item.kind === 'resource' && !TERRITORY.regions.some((r) => r.resources.includes(item.id))) {
      problems.push(`resource "${item.id}" is not gatherable in any region`);
    }
    if (item.kind === 'resource' && item.seasons.length === 0) {
      problems.push(`resource "${item.id}" has no season, so it can never be gathered`);
    }
  }
  if (TERRITORY.war.spoils.winnerBankShareOfStake >= 1) {
    problems.push('war spoils return the whole stake — two clans could trade a region back and forth at no cost');
  }
}

/* ── 11. Economy ──────────────────────────────────────────────────────── */
{
  const itemIds = new Set(ECONOMY.items.map((i) => i.id));
  const jutsuIds = new Set(JUTSU.map((j) => j.id));
  const stationIds = new Set(ECONOMY.stations.map((s) => s.id));
  const dupes = new Set<string>();
  for (const i of ECONOMY.items) {
    if (dupes.has(i.id)) problems.push(`duplicate item id: ${i.id}`);
    dupes.add(i.id);
    if (jutsuIds.has(i.id)) problems.push(`item "${i.id}" collides with a jutsu id`);
    if (i.kind !== 'consumable' && i.use) problems.push(`item "${i.id}" is a ${i.kind} but carries a use block`);
  }
  for (const r of ECONOMY.recipes) {
    if (!stationIds.has(r.station)) problems.push(`recipe ${r.id}: unknown station "${r.station}"`);
    if (!itemIds.has(r.output.item)) problems.push(`recipe ${r.id}: unknown output "${r.output.item}"`);
    for (const inp of r.inputs) {
      if (!itemIds.has(inp.item)) problems.push(`recipe ${r.id}: unknown input "${inp.item}"`);
      if (inp.item === r.output.item) problems.push(`recipe ${r.id}: consumes and produces "${inp.item}" — a one-step duplication loop`);
    }
  }
  /* A recipe whose output is worth less than its inputs is a recipe no informed
     player will ever run, and an uninformed one loses money by trying. The
     economy simulator found three of these shipped at once — all of them the
     ENTRY-LEVEL recipes, so every new crafter's first experience was going
     broke. This is a hard error rather than a warning because there is no
     legitimate reason for it: if a step is meant to be a sink, make it a sink
     explicitly, not an accident of two numbers drifting apart. */
  for (const r of ECONOMY.recipes) {
    const inputValue = r.inputs.reduce((n, i) => n + (ITEM_BY_ID.get(i.item)?.baseValue ?? 0) * i.qty, 0);
    const outputValue = (ITEM_BY_ID.get(r.output.item)?.baseValue ?? 0) * r.output.qty;
    if (outputValue <= inputValue) {
      problems.push(
        `recipe ${r.id}: inputs are worth ${inputValue} and the output ${outputValue} — `
        + 'crafting it destroys value, so nobody should ever run it',
      );
      continue;
    }
    /* And it has to be worth the TIME, not merely non-negative. The comparison
       is against what the same hours pay doing D-rank missions, because that is
       the alternative a player actually has. */
    const perHour = (outputValue - inputValue) / (r.minutes / 60);
    const missionWage = Math.max(...MISSIONS.missions.filter((m) => m.party === 1).map((m) => m.ryo / (m.minutes / 60)));
    if (perHour < missionWage * 0.25) {
      warnings.push(
        `recipe ${r.id} pays ${perHour.toFixed(0)} ryo/hour against a mission wage of ${missionWage.toFixed(0)} — `
        + 'few players will choose it',
      );
    }
  }

  /* A cycle in the recipe graph is a material duplication bug waiting to happen:
     if A makes B and B makes A, the only question is which direction is profitable. */
  const producedBy = new Map<string, string[]>();
  for (const r of ECONOMY.recipes) producedBy.set(r.output.item, r.inputs.map((i) => i.item));
  const state = new Map<string, number>();
  const cyclic = (item: string): boolean => {
    if (state.get(item) === 1) return true;
    if (state.get(item) === 2) return false;
    state.set(item, 1);
    for (const dep of producedBy.get(item) ?? []) if (cyclic(dep)) return true;
    state.set(item, 2);
    return false;
  };
  for (const item of itemIds) if (cyclic(item)) { problems.push(`recipe graph contains a cycle involving "${item}"`); break; }

  const m = ECONOMY.market;
  /* The sale tax is NOT set here — it is the seller's village tax rate, which
     politics.json bands above zero. So the wash-trade-is-lossy property is
     (listing fee + village tax floor) > 0, and both halves have to be checked
     where they actually live. An earlier version of this checked a
     `saleTaxFraction` field in this file that no runtime code ever read. */
  if (m.listingFeeFraction + POLITICS.tax.min <= 0) {
    problems.push('the market charges nothing, so wash trading between two accounts is free — the fee is what makes collusion lossy');
  }
  if (m.priceFloorFraction >= m.priceCeilingFraction) problems.push('market price floor is at or above the ceiling');
  for (const i of ECONOMY.items) {
    if (i.kind !== 'regalia' && i.baseValue <= 0) problems.push(`item "${i.id}" has no base value, so its price band collapses to zero`);
  }
  /* Nothing bought or crafted may reach a match. The absence is the guarantee,
     so it is asserted rather than assumed. */
  const rawItems = JSON.stringify(ECONOMY.items);
  if (/"(damage|power|scaling|effects|combat|hp|maxHp|statMods|multiplier)"\s*:/.test(rawItems)) {
    problems.push('an item carries a combat-shaped field — crafted goods must never reach resolveTurn');
  }
  /* A recipe may gate on a stat (you must be strong enough to fold steel); it may
     never grant one. The `requires` block is the only place a stat may appear. */
  for (const r of ECONOMY.recipes) {
    const allowed = new Set(['id', 'name', 'station', 'inputs', 'output', 'minutes', 'requires', 'unlockRank']);
    const stray = Object.keys(r).filter((k) => !allowed.has(k));
    if (stray.length) problems.push(`recipe ${r.id}: unexpected field(s) ${stray.join(', ')} — a recipe may gate on a stat but never grant one`);
  }
}

/* ── 12. Politics ─────────────────────────────────────────────────────── */
{
  const p = POLITICS;
  if (p.nominationDays + p.votingDays >= p.cycleDays) {
    problems.push('nomination and voting fill the whole cycle, leaving no time in office');
  }
  if (p.tax.default < p.tax.min || p.tax.default > p.tax.max) problems.push('default tax rate sits outside its own band');
  if (p.tax.min <= 0) problems.push('the tax floor is zero — the market would have no sink at all under a populist Kage');
  if (p.tax.max >= 1) problems.push('the tax ceiling would let an office holder confiscate every sale');
  if (p.maxActiveLaws > p.laws.length) warnings.push('more law slots than laws');
  const officeIds = new Set(p.offices.map((o) => o.id));
  if (!officeIds.has(p.war.declareRequiresOffice)) problems.push(`village war requires office "${p.war.declareRequiresOffice}", which does not exist`);
  const lawIds = new Set<string>();
  for (const l of p.laws) { if (lawIds.has(l.id)) problems.push(`duplicate law id: ${l.id}`); lawIds.add(l.id); }
  for (const c of p.treasury.commissions) {
    if (Object.keys(c.effect).length === 0) problems.push(`commission ${c.id} buys nothing`);
  }
  if (p.suffrage.minMissionsCompleted <= 0 && p.suffrage.minAccountAgeMinutes <= 0) {
    problems.push('suffrage has no proof-of-play requirement at all — an election could be decided by fresh accounts');
  }
  /* No power may move village money to a person. If a payout field ever appears
     here, the office becomes worth buying and the whole system inverts. */
  if (/"(payout|salary|stipendTo|toPlayer|withdraw)"\s*:/.test(JSON.stringify(p))) {
    problems.push('a political power pays a player directly — there must be no path from the treasury to a wallet');
  }
}

/* ── 13. Dungeons ─────────────────────────────────────────────────────── */
{
  const regionIds = new Set(TERRITORY.regions.map((r) => r.id));
  const itemIds = new Set(ECONOMY.items.map((i) => i.id));
  const cosmeticIds = new Set(COSMETICS.items.map((c) => c.id));
  const legendaryIds = new Set(LEGACY.legendaries.map((l) => l.id));
  const salts = new Set<string>();
  const raw = JSON.stringify(DUNGEONS.dungeons);
  if (/"answer"\s*:/.test(raw) || /"solution"\s*:/.test(raw)) {
    problems.push('a dungeon room stores a plaintext answer — only salted digests may be stored');
  }
  for (const d of DUNGEONS.dungeons) {
    if (!regionIds.has(d.regionId)) problems.push(`dungeon ${d.id}: unknown region "${d.regionId}"`);
    if (d.keyItem) {
      if (!itemIds.has(d.keyItem)) problems.push(`dungeon ${d.id}: unknown key item "${d.keyItem}"`);
      else if (ECONOMY.items.find((i) => i.id === d.keyItem)!.kind !== 'key') {
        problems.push(`dungeon ${d.id}: "${d.keyItem}" is used as a key but is not a key`);
      }
    }
    for (const r of d.rooms) {
      if (salts.has(r.salt)) problems.push(`dungeon ${d.id} room ${r.id}: reuses a salt — one solved room would weaken another`);
      salts.add(r.salt);
    }
    if (d.rewards.jutsu && !JUTSU.some((j) => j.id === d.rewards.jutsu)) {
      problems.push(`dungeon ${d.id}: rewards unknown technique "${d.rewards.jutsu}"`);
    }
    if (d.rewards.cosmetic && !cosmeticIds.has(d.rewards.cosmetic)) {
      problems.push(`dungeon ${d.id}: rewards unknown cosmetic "${d.rewards.cosmetic}"`);
    }
    if (d.rewards.legendary && !legendaryIds.has(d.rewards.legendary)) {
      problems.push(`dungeon ${d.id}: rewards unknown legendary "${d.rewards.legendary}"`);
    }
    for (const it of d.rewards.items) if (!itemIds.has(it.item)) problems.push(`dungeon ${d.id}: rewards unknown item "${it.item}"`);
    if (d.seasons.length > 0 && d.keyItem === null && d.rooms.length === 0) problems.push(`dungeon ${d.id}: no rooms`);
  }
}

/* ── 14. Cosmetics ────────────────────────────────────────────────────── */
{
  const slotIds = new Set(COSMETICS.slots.map((s) => s.id));
  const recipeIds = new Set(ECONOMY.recipes.map((r) => r.id));
  const titleIds = new Set(LEGACY.titles.map((t) => t.id));
  const dungeonCosmetics = new Set(DUNGEONS.dungeons.map((d) => d.rewards.cosmetic).filter(Boolean) as string[]);
  const defaults = new Set<string>();
  const ids = new Set<string>();
  for (const c of COSMETICS.items) {
    if (ids.has(c.id)) problems.push(`duplicate cosmetic id: ${c.id}`);
    ids.add(c.id);
    if (!slotIds.has(c.slot)) problems.push(`cosmetic ${c.id}: unknown slot "${c.slot}"`);
    if (c.source === 'default') defaults.add(c.slot);
    if (c.source === 'purchase' && !c.price) problems.push(`cosmetic ${c.id}: purchasable with no price`);
    if (c.source === 'default' && c.price) problems.push(`cosmetic ${c.id}: a default cannot also be priced`);
    if (c.source === 'title' && (!c.title || !titleIds.has(c.title))) problems.push(`cosmetic ${c.id}: unknown or missing title gate`);
    if (c.source === 'craft' && (!c.recipe || !recipeIds.has(c.recipe))) problems.push(`cosmetic ${c.id}: unknown or missing recipe`);
    if (c.source === 'season' && !c.season) problems.push(`cosmetic ${c.id}: seasonal with no season`);
    if (c.source === 'dungeon' && !dungeonCosmetics.has(c.id)) problems.push(`cosmetic ${c.id}: sourced from a dungeon that never awards it`);
  }
  for (const s of slotIds) if (!defaults.has(s)) warnings.push(`slot "${s}" has no default, so a new character has nothing in it`);
  if (COSMETICS.rules.affectsCombat !== false || COSMETICS.rules.affectsProgression !== false) {
    problems.push('cosmetics claim to affect combat or progression — that is the one thing they may never do');
  }
  if (/"(stat|stats|power|bonus|mult|multiplier|effect|effects|damage)"\s*:/.test(JSON.stringify(COSMETICS))) {
    problems.push('a cosmetic record carries a stat or effect field');
  }
}

/* ── 15. Mentorship ───────────────────────────────────────────────────── */
{
  const m = MENTORSHIP;
  const gift = ECONOMY.items.find((i) => i.id === m.mentor.graduationGift);
  if (!gift) problems.push(`mentorship: unknown graduation gift "${m.mentor.graduationGift}"`);
  else if (gift.tradable) problems.push('the graduation gift is tradable, which turns mentoring into a way to mint sellable goods');
  if (/"ryo"\s*:/.test(JSON.stringify(m.mentor.rewardPerMilestone))) {
    problems.push('mentors are paid in currency — the reward must stay unsellable or alt-farming becomes profitable');
  }
  if (m.pairing.minDurationMinutesBeforeRewards <= 0) {
    problems.push('a pairing pays out immediately, so a mentor could form and dissolve pairings in a loop');
  }
  if (m.pairing.levelGapMin <= 0) warnings.push('no level gap required between mentor and mentee');
  if (!m.mentee.mentoredOnce) warnings.push('a player may be mentored repeatedly — the bonus becomes permanent rather than a start');
  for (const ms of m.milestones) {
    if (ms.criterion !== 'rank' && ms.threshold === undefined) problems.push(`milestone ${ms.id}: countable criterion with no threshold`);
  }
}

/* ── Report ───────────────────────────────────────────────────────────── */
console.log(`content: ${JUTSU.length} jutsu, ${STATUSES.length} statuses, ${EFFECT_KINDS.length} effect kinds, `
  + `${BLOODLINES.length} bloodlines, ${COMBOS.length} combos, ${CLANS.length} clans, ${VILLAGES.length} villages`);
for (const w of warnings) console.log(`  ! ${w}`);
if (problems.length) {
  for (const p of problems) console.error(`  ✗ ${p}`);
  console.error(`\nvalidate:content: ${problems.length} problem(s)`);
  process.exit(1);
}
console.log('validate:content: clean');
