/**
 * `pnpm validate:content` — schema validation plus the checks that a Zod schema
 * cannot express: economic sanity, effect-kind budget, and the IP scan.
 *
 * Invalid records fail the build (CLAUDE.md §8).
 */
import { EFFECT_KINDS, ZJutsu } from '@shinobi/shared';
import { BLOODLINES, CLANS, COMBOS, JUTSU, STATUSES, STATUS_BY_ID, TUNING, VILLAGES, BASELINE_ACTIONS, rollBloodline } from './index.js';

const problems: string[] = [];
const warnings: string[] = [];

/* ── 1. Schema ────────────────────────────────────────────────────────── */
for (const j of JUTSU) {
  const parsed = ZJutsu.safeParse(j);
  if (!parsed.success) problems.push(`${j.id}: ${parsed.error.issues.map((i) => i.path.join('.') + ' ' + i.message).join('; ')}`);
}

/* ── 2. Referential integrity ─────────────────────────────────────────── */
const seen = new Set<string>();
for (const j of JUTSU) {
  if (seen.has(j.id)) problems.push(`duplicate id: ${j.id}`);
  seen.add(j.id);

  const walk = (effects: readonly unknown[]): void => {
    for (const e of effects as { kind: string; status?: string; statuses?: string[]; effects?: unknown[]; bonusVs?: { status: string } }[]) {
      if (!(EFFECT_KINDS as readonly string[]).includes(e.kind)) problems.push(`${j.id}: unknown effect kind "${e.kind}"`);
      if (e.status && !STATUS_BY_ID.has(e.status as never)) problems.push(`${j.id}: unknown status "${e.status}"`);
      if (e.bonusVs && !STATUS_BY_ID.has(e.bonusVs.status as never)) problems.push(`${j.id}: unknown bonusVs status`);
      for (const s of e.statuses ?? []) if (!STATUS_BY_ID.has(s as never)) problems.push(`${j.id}: unknown cleanse status "${s}"`);
      if (e.effects) walk(e.effects);
    }
  };
  walk(j.effects);
}

for (const id of BASELINE_ACTIONS) {
  if (!seen.has(id)) problems.push(`baseline action "${id}" is not in the library`);
  const j = JUTSU.find((x) => x.id === id);
  if (j) {
    const total = j.cost.physical + j.cost.mental + j.cost.natural;
    if (total > 0) problems.push(`baseline action "${id}" must be free, costs ${total} across pools`);
  }
}

/* ── 3. Effect-kind budget (CLAUDE.md §6: the set is meant to stay small) ── */
if (EFFECT_KINDS.length > 16) {
  problems.push(`effect kinds have grown to ${EFFECT_KINDS.length}; §6 asks that this set stay small — get sign-off before adding more`);
}
const used = new Set<string>();
for (const j of JUTSU) {
  const walk = (effects: readonly { kind: string; effects?: { kind: string }[] }[]): void => {
    for (const e of effects) { used.add(e.kind); if (e.effects) walk(e.effects); }
  };
  walk(j.effects as never);
}
for (const kind of EFFECT_KINDS) {
  if (!used.has(kind)) warnings.push(`effect kind "${kind}" is defined but unused by any jutsu`);
}

/* ── 4. Economic sanity ───────────────────────────────────────────────── */
const RANK_ORDER = ['E', 'D', 'C', 'B', 'A', 'S'];
for (const j of JUTSU) {
  if (j.cost.physical > 240 || j.cost.mental > 240) problems.push(`${j.id}: single-pool cost is unreachable`);
  if (j.cost.natural > 0 && j.rank !== 'S' && j.id !== 'sage-mode') {
    warnings.push(`${j.id}: costs natural energy but is not S-rank — natural energy cannot be regenerated`);
  }
  if (j.seals === 0 && j.sealDifficulty > 0) problems.push(`${j.id}: sealDifficulty on a seal-less technique`);
  if (j.seals > 0 && j.sealDifficulty === 0) problems.push(`${j.id}: sealed technique with no difficulty — its accuracy roll can never fail`);
  if (j.seals > 0 && j.interruptThreshold > 400) problems.push(`${j.id}: interruptThreshold makes the weave uninterruptible`);
  const rankIdx = RANK_ORDER.indexOf(j.rank);
  if (rankIdx >= 4 && j.cooldown === 0) warnings.push(`${j.id}: ${j.rank}-rank with no cooldown`);
  if (j.requires && j.requires.min > 200) problems.push(`${j.id}: stat requirement above the stat ceiling`);
}

/* ── 5. Statuses ──────────────────────────────────────────────────────── */
for (const s of STATUSES) {
  if (s.control === 'skipChance' && s.controlChance === undefined) problems.push(`status ${s.id}: skipChance without controlChance`);
  if (s.dotPctMaxHp !== undefined && s.hotPctMaxHp !== undefined) problems.push(`status ${s.id}: both damages and heals`);
}
const referenced = new Set<string>();
for (const j of JUTSU) {
  const walk = (effects: readonly { status?: string; statuses?: string[]; effects?: unknown[] }[]): void => {
    for (const e of effects) {
      if (e.status) referenced.add(e.status);
      for (const s of e.statuses ?? []) referenced.add(s);
      if (e.effects) walk(e.effects as never);
    }
  };
  walk(j.effects as never);
}
for (const s of STATUSES) {
  if (!referenced.has(s.id) && s.id !== 'exhaustion') warnings.push(`status "${s.id}" is never applied by any jutsu`);
}

/* ── 6. Bloodlines, clans, villages ───────────────────────────────────── */
for (const b of BLOODLINES) {
  for (const g of b.grants) {
    if (!seen.has(g)) problems.push(`bloodline ${b.id}: grants unknown jutsu "${g}"`);
  }
  if (b.clan && !CLANS.some((c) => c.id === b.clan)) problems.push(`bloodline ${b.id}: unknown clan "${b.clan}"`);
  if (b.grants.length === 0) warnings.push(`bloodline ${b.id} grants no techniques`);
}
for (const c of CLANS) {
  if (!VILLAGES.some((v) => v.id === c.village)) problems.push(`clan ${c.id}: unknown village "${c.village}"`);
  for (const bl of c.bloodlines) {
    if (!BLOODLINES.some((b) => b.id === bl)) problems.push(`clan ${c.id}: unknown bloodline "${bl}"`);
  }
}
for (const v of VILLAGES) {
  for (const c of v.clans) {
    if (!CLANS.some((x) => x.id === c)) problems.push(`village ${v.id}: unknown clan "${c}"`);
    else if (CLANS.find((x) => x.id === c)!.village !== v.id) {
      problems.push(`village ${v.id}: clan "${c}" does not point back to this village`);
    }
  }
}

/* Every bloodline-granted technique must be reachable ONLY via a bloodline or a
   loadout — a grant that duplicates a freely-buyable jutsu is a dead perk. */
const grantedIds = new Set(BLOODLINES.flatMap((b) => b.grants));
const overlap = [...grantedIds].filter((g) => (BASELINE_ACTIONS as readonly string[]).includes(g));
for (const o of overlap) problems.push(`bloodline grant "${o}" is also a free baseline action`);

/* ── 7. Combos ────────────────────────────────────────────────────────── */
for (const c of COMBOS) {
  if (!STATUS_BY_ID.has(c.setup)) problems.push(`combo ${c.id}: unknown setup status "${c.setup}"`);
  const setupExists = JUTSU.some((j) => j.effects.some((e) => e.kind === 'applyStatus' && e.status === c.setup));
  if (!setupExists) problems.push(`combo ${c.id}: no jutsu can apply the setup status "${c.setup}" — the combo is unreachable`);
  const triggerExists = JUTSU.some((j) => j.nature === c.trigger && j.effects.some((e) => e.kind === 'damage'));
  if (!triggerExists) problems.push(`combo ${c.id}: no damaging ${c.trigger} technique exists to trigger it`);
}
const comboKeys = new Set<string>();
for (const c of COMBOS) {
  const k = `${c.setup}|${c.trigger}`;
  if (comboKeys.has(k)) problems.push(`combo ${c.id}: duplicate setup+trigger pair "${k}" — only one would ever fire`);
  comboKeys.add(k);
}

/* ── 8. Bloodline rarity (direction doc: ~20% of players, lore-weighted) ── */
{
  const total = BLOODLINES.reduce((n, b) => n + b.rarity, 0);
  const commonest = BLOODLINES.reduce((a, b) => (b.rarity > a.rarity ? b : a));
  const rarest = BLOODLINES.reduce((a, b) => (b.rarity < a.rarity ? b : a));
  if (rarest.rarity * 10 > commonest.rarity) {
    warnings.push(`bloodline rarity spread is flat (${rarest.id}=${rarest.rarity} vs ${commonest.id}=${commonest.rarity}) — lore scarcity should be pronounced`);
  }
  let granted = 0;
  const N = 20000;
  for (let i = 0; i < N; i++) if (rollBloodline((i * 0.61803398875) % 1, ((i * 0.31830988618) % 1)) !== null) granted++;
  const pct = granted / N;
  if (Math.abs(pct - TUNING.bloodlines.grantChance) > 0.02) {
    problems.push(`rollBloodline grants ${(pct * 100).toFixed(1)}% of characters a bloodline, expected ${(TUNING.bloodlines.grantChance * 100).toFixed(0)}%`);
  }
  void total;
}

/* ── Report ───────────────────────────────────────────────────────────── */
console.log(`content: ${JUTSU.length} jutsu, ${STATUSES.length} statuses, ${EFFECT_KINDS.length} effect kinds, `
  + `${BLOODLINES.length} bloodlines, ${COMBOS.length} combos, ${CLANS.length} clans, ${VILLAGES.length} villages`);
for (const w of warnings) console.log(`  ! ${w}`);
if (problems.length) {
  for (const p of problems) console.error(`  ✗ ${p}`);
  console.error(`\nvalidate:content: ${problems.length} problem(s)`);
  process.exit(1);
}
console.log('validate:content: clean');
