import { z } from 'zod';
import { ZEffect, ZJutsu, ZJutsuRank, ZNature, ZStatKey, ZStatusId, type Effect, type Jutsu, type Nature, type StatKey, type StatusId } from '@shinobi/shared';
import jutsuData from '../data/jutsu.json' with { type: 'json' };
import statusData from '../data/statuses.json' with { type: 'json' };
import tuningData from '../data/tuning.json' with { type: 'json' };
import bloodlineData from '../data/bloodlines.json' with { type: 'json' };
import clanData from '../data/clans.json' with { type: 'json' };
import villageData from '../data/villages.json' with { type: 'json' };
import comboData from '../data/combos.json' with { type: 'json' };
import trainingData from '../data/training.json' with { type: 'json' };
import missionData from '../data/missions.json' with { type: 'json' };
import rogueData from '../data/rogue.json' with { type: 'json' };
import clanRuleData from '../data/clan-rules.json' with { type: 'json' };
import legacyData from '../data/legacy.json' with { type: 'json' };
import seasonData from '../data/seasons.json' with { type: 'json' };
import territoryData from '../data/territory.json' with { type: 'json' };
import economyData from '../data/economy.json' with { type: 'json' };
import politicsData from '../data/politics.json' with { type: 'json' };
import dungeonData from '../data/dungeons.json' with { type: 'json' };
import cosmeticData from '../data/cosmetics.json' with { type: 'json' };
import mentorshipData from '../data/mentorship.json' with { type: 'json' };

/* ── Status schema ────────────────────────────────────────────────────── */

export const ZStatusDef = z.object({
  id: ZStatusId,
  name: z.string().min(2).max(32),
  control: z.enum(['skip', 'skipChance']).optional(),
  controlChance: z.number().min(0).max(1).optional(),
  dotPctMaxHp: z.number().min(0).max(0.25).optional(),
  hotPctMaxHp: z.number().min(0).max(0.25).optional(),
  rampPerTurn: z.number().min(0).max(0.1).optional(),
  chakraPerTurn: z.number().min(-60).max(60).optional(),
  outgoingMult: z.number().min(0.1).max(3).optional(),
  /** scales the hand-seal accuracy roll — eye injuries make seals unreliable */
  accuracyMult: z.number().min(0.1).max(2).optional(),
  incomingMult: z.number().min(0.1).max(3).optional(),
  defenseMult: z.number().min(0.1).max(3).optional(),
  statMults: z.record(ZStatKey, z.number().min(0.1).max(3)).optional(),
  incomingNatureMult: z.record(ZNature, z.number().min(0.1).max(3)).optional(),
  blocksSealedJutsu: z.boolean().optional(),
  breaksWeave: z.boolean().optional(),
  breaksOnDamage: z.boolean().optional(),
  tags: z.array(z.string().max(24)).max(6),
});
export type StatusDef = z.infer<typeof ZStatusDef>;

/* ── Tuning schema ────────────────────────────────────────────────────── */

export const ZTuning = z.object({
  mitigationK: z.number().positive(),
  natureAdvantage: z.number().positive(),
  natureDisadvantage: z.number().positive(),
  disciplineAdvantage: z.number().positive(),
  disciplineDisadvantage: z.number().positive(),
  suddenDeathRound: z.number().int().positive(),
  suddenDeathDamageMultiplier: z.number().min(1),
  hardCapRound: z.number().int().positive(),
  hp: z.object({ base: z.number(), perStamina: z.number(), perLevel: z.number() }),
  energy: z.object({
    physical: z.object({ base: z.number(), perStamina: z.number(), perStrength: z.number(), regenBase: z.number(), regenPerStamina: z.number() }),
    mental: z.object({ base: z.number(), perIntelligence: z.number(), perStamina: z.number(), regenBase: z.number(), regenPerStamina: z.number() }),
    natural: z.object({ base: z.number(), perIntelligence: z.number(), perStamina: z.number(), regenBase: z.number(), regenPerStamina: z.number() }),
  }),
  sealAccuracy: z.object({
    base: z.number(), perHandSeals: z.number(), perDifficulty: z.number(),
    min: z.number().min(0).max(1), max: z.number().min(0).max(1), burnFraction: z.number().min(0).max(1),
  }),
  injuries: z.object({ duration: z.number().int().positive(), chanceOnHeavyHit: z.number().min(0).max(1), heavyHitFraction: z.number().min(0).max(1) }),
  bloodlines: z.object({ grantChance: z.number().min(0).max(1) }),
  roles: z.record(z.string(), z.number().min(0).max(3)),
  /** scales every gate tier's HP drain at once, so the ladder is one lever */
  gateDrainScale: z.number().min(0.1).max(3),
  stances: z.object({
    substituteBaseChance: z.number().min(0).max(1),
    counterFraction: z.number().min(0).max(1),
    counterReduction: z.number().min(0).max(1),
    prepareDamageMult: z.number().min(1).max(4),
    prepareSealBonus: z.number().int().min(0).max(6),
  }),
  guard: z.object({ base: z.number(), perTaijutsu: z.number(), perSpeed: z.number(), perStamina: z.number() }),
  ward: z.object({ base: z.number(), perIntelligence: z.number(), perSpeed: z.number(), perStamina: z.number() }),
  sealsPerTurn: z.object({ base: z.number(), perHandSeals: z.number(), max: z.number() }),
  overdraw: z.object({ selfDamagePerPoint: z.number(), maxOverdrawFraction: z.number() }),
  substitution: z.object({
    startCharges: z.number().int().min(0),
    damageThresholdFraction: z.number().min(0).max(1),
    baseChance: z.number().min(0).max(1),
    speedWeight: z.number().min(0).max(1),
    minChance: z.number().min(0).max(1),
    maxChance: z.number().min(0).max(1),
  }),
  control: z.object({ hardImmunityTurns: z.number().int().min(0).max(10) }),
  clones: z.object({
    maxActive: z.number().int().min(1),
    outgoingDamageMultiplier: z.number().min(0).max(2),
    returnChakraOnRecall: z.boolean(),
    returnChakraOnDispel: z.boolean(),
    returnChakraOnDeath: z.boolean(),
  }),
  gates: z.array(z.object({
    tier: z.number().int().min(1).max(8),
    name: z.string(),
    strengthMult: z.number().min(1),
    speedMult: z.number().min(1),
    hpDrainPct: z.number().min(0).max(0.5),
  })).length(8),
  skillGain: z.object({
    perChakraSpentDivisor: z.number().positive(),
    perDamageDealtDivisor: z.number().positive(),
    perDamageTakenDivisor: z.number().positive(),
    winBonus: z.number().positive(),
    lossBonus: z.number().positive(),
    maxPerStatPerMatch: z.number().positive(),
    maxTotalPerMatch: z.number().positive(),
    levelDifferenceSoftCap: z.number().positive(),
    minRoundsForFullCredit: z.number().int().positive(),
  }),
});
export type Tuning = z.infer<typeof ZTuning>;

/* ── Bloodlines, clans, villages ──────────────────────────────────────── */

export const ZBloodline = z.object({
  id: z.string().regex(/^[a-z0-9-]+$/),
  name: z.string().min(2).max(48),
  clan: z.string().regex(/^[a-z0-9-]+$/).nullable(),
  tier: z.number().int().min(1).max(3),
  statMults: z.record(ZStatKey, z.number().min(0.5).max(1.5)),
  extraSubstitutions: z.number().int().min(0).max(3),
  sealsPerTurnBonus: z.number().int().min(0).max(3),
  grants: z.array(z.string().regex(/^[a-z0-9-]+$/)).max(12),
  /** relative draw weight — lower is rarer, following lore scarcity */
  rarity: z.number().int().min(1).max(100),
});
export type Bloodline = z.infer<typeof ZBloodline>;

export const ZClan = z.object({
  id: z.string().regex(/^[a-z0-9-]+$/),
  name: z.string().min(2).max(48),
  village: z.string().regex(/^[a-z0-9-]+$/),
  bloodlines: z.array(z.string().regex(/^[a-z0-9-]+$/)).max(6),
});
export type Clan = z.infer<typeof ZClan>;

export const ZVillage = z.object({
  id: z.string().regex(/^[a-z0-9-]+$/),
  name: z.string().min(2).max(48),
  country: z.string().min(2).max(48),
  affinityBias: ZNature,
  clans: z.array(z.string().regex(/^[a-z0-9-]+$/)).max(20),
});
export type Village = z.infer<typeof ZVillage>;

/* ── Combos ───────────────────────────────────────────────────────────── */

/**
 * A setup status plus a payoff nature. When damage of the trigger nature lands on
 * a target carrying the setup status, the combo fires. Oil then fire is an
 * explosion; water then lightning electrocutes.
 */
export const ZCombo = z.object({
  id: z.string().regex(/^[a-z0-9-]+$/),
  name: z.string().min(2).max(48),
  setup: ZStatusId,
  trigger: ZNature,
  consumesSetup: z.boolean(),
  effects: z.array(ZEffect).min(1).max(4),
});
export type Combo = z.infer<typeof ZCombo>;

/* ── Training (design direction: dynamic training, weather, locations) ─── */

export const ZTraining = z.object({
  locations: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(48),
    activity: z.string().min(2).max(64),
    primary: ZStatKey,
    secondary: ZStatKey,
    rate: z.number().min(0.5).max(2),
    unlockRank: z.enum(['academy', 'genin', 'chunin', 'jonin', 'anbu', 'kage']),
  })).min(1),
  weather: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(32),
    statBonus: z.record(ZStatKey, z.number().min(0).max(1)),
    natureBonus: z.record(ZNature, z.number().min(0).max(1)),
  })).min(1),
  tiers: z.array(z.object({
    tier: z.number().int().min(1).max(5),
    name: z.string().min(2).max(32),
    minutes: z.number().int().positive(),
    multiplier: z.number().min(1).max(3),
  })).length(5),
  gainPerMinute: z.number().positive(),
  diminishingAbove: z.number().positive(),
  diminishingFactor: z.number().min(0).max(1),
  primaryShare: z.number().min(0).max(1),
  secondaryShare: z.number().min(0).max(1),
});
export type Training = z.infer<typeof ZTraining>;

/* ── Missions, reputation, promotion ──────────────────────────────────── */

const ZRankName = z.enum(['academy', 'genin', 'chunin', 'jonin', 'anbu', 'kage']);

export const ZMissions = z.object({
  missions: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(64),
    rank: ZJutsuRank.exclude(['E']),
    requiredRank: ZRankName,
    minutes: z.number().int().positive(),
    stat: ZStatKey,
    difficulty: z.number().int().positive(),
    ryo: z.number().int().nonnegative(),
    xp: z.number().int().nonnegative(),
    reputation: z.number().int(),
    party: z.number().int().min(1).max(4),
    brief: z.string().max(200),
  })).min(1),
  successCurve: z.object({
    base: z.number().min(0).max(1),
    perStatPoint: z.number().positive(),
    min: z.number().min(0).max(1),
    max: z.number().min(0).max(1),
  }),
  failure: z.object({
    ryoShare: z.number().min(0).max(1),
    xpShare: z.number().min(0).max(1),
    reputationLoss: z.number().int().nonnegative(),
    injuryChance: z.number().min(0).max(1),
  }),
  reputationTiers: z.array(z.object({
    id: z.string(),
    atOrBelow: z.number().int(),
    priceMultiplier: z.number().positive(),
    missionAccess: z.boolean(),
    note: z.string().max(160),
  })).min(2),
  promotions: z.array(z.object({
    from: ZRankName, to: ZRankName,
    level: z.number().int().nonnegative(),
    reputation: z.number().int(),
    rating: z.number().int().nonnegative(),
    missionsAtRank: z.number().int().nonnegative(),
    note: z.string().max(160),
  })).min(1),
  levelCurve: z.object({ base: z.number().positive(), exponent: z.number().positive() }),
  jutsuPrices: z.record(ZJutsuRank, z.number().int().nonnegative()),
  teacherRankRequired: z.record(ZJutsuRank, ZRankName),
});
export type MissionData = z.infer<typeof ZMissions>;
export type Mission = MissionData['missions'][number];

/* ── Defection, notoriety, bounties ───────────────────────────────────── */

export const ZRogue = z.object({
  defection: z.object({ reputationFloor: z.number().int(), note: z.string().max(240) }),
  amnesty: z.object({
    baseCost: z.number().int().nonnegative(),
    perNotoriety: z.number().nonnegative(),
    cooldownMinutes: z.number().int().nonnegative(),
    reputationOnReturn: z.number().int(),
    note: z.string().max(240),
  }),
  notoriety: z.object({
    perBlackMarketMission: z.number().nonnegative(),
    perPvpWin: z.number().nonnegative(),
    max: z.number().positive(),
    note: z.string().max(240),
  }),
  bounty: z.object({
    base: z.number().nonnegative(),
    perNotoriety: z.number().nonnegative(),
    perLevel: z.number().nonnegative(),
    /** strictly below 1: the shortfall is what makes collusion lose money */
    hunterShare: z.number().min(0).max(0.95),
    note: z.string().max(240),
  }),
  blackMarket: z.object({
    priceMultiplier: z.number().min(1),
    ignoresRankGate: z.boolean(),
    missionPayMultiplier: z.number().min(1),
    note: z.string().max(240),
  }),
  contract: z.object({
    durationMinutes: z.number().int().positive(),
    cooldownMinutesSamePair: z.number().int().nonnegative(),
    maxActivePerHunter: z.number().int().positive(),
    minNotorietyToPost: z.number().nonnegative(),
  }),
});
export type RogueRules = z.infer<typeof ZRogue>;

/* ── Player clans (guilds) ────────────────────────────────────────────────
   Distinct from the lore clans in clans.json, which are bloodline families and
   are derived from a player's bloodline rather than joined. */

export const ZClanRules = z.object({
  founding: z.object({
    ryoCost: z.number().int().nonnegative(),
    minRank: ZRankName,
    minReputation: z.number().int(),
    note: z.string().max(240),
  }),
  size: z.object({ max: z.number().int().positive(), officersMax: z.number().int().positive() }),
  bank: z.object({
    withdrawRequiresOfficer: z.boolean(),
    memberTenureMinutesToWithdraw: z.number().int().nonnegative(),
    withdrawFractionPerDay: z.number().min(0).max(1),
    note: z.string().max(240),
  }),
  contribution: z.object({
    perRyoDeposited: z.number().nonnegative(),
    perMissionCompleted: z.number().nonnegative(),
    perPvpWin: z.number().nonnegative(),
    note: z.string().max(240),
  }),
  ranks: z.array(z.enum(['member', 'officer', 'leader'])).length(3),
});
export type ClanRules = z.infer<typeof ZClanRules>;

/* ── Legacy: titles and legendary items ───────────────────────────────── */

const ZCriterion = z.enum([
  'missionsCompleted', 'pvpWins', 'rating', 'bountiesClaimed',
  'notoriety', 'reputation', 'rank', 'sRankCompleted', 'clanFounded',
]);
export type LegacyCriterion = z.infer<typeof ZCriterion>;

export const ZLegacy = z.object({
  titles: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(48),
    criterion: ZCriterion,
    threshold: z.number().int().nonnegative(),
    blurb: z.string().max(160),
  })).min(1),
  legendaries: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(64),
    claim: ZCriterion,
    threshold: z.number().int().positive(),
    lore: z.string().max(240),
  })).min(1),
  rules: z.object({
    uniquePerServer: z.literal(true),
    /** must stay false: see the note in the data file */
    grantsCombatPower: z.literal(false),
    purchasable: z.literal(false),
    note: z.string().max(400),
  }),
});
export type Legacy = z.infer<typeof ZLegacy>;

/* ── Seasons ──────────────────────────────────────────────────────────────
   Derived from the clock exactly as weather is. Nothing about a season is
   stored, so there is nothing for a client to influence or a server to lose. */

export const ZSeasonId = z.enum(['spring', 'summer', 'autumn', 'winter']);
export type SeasonId = z.infer<typeof ZSeasonId>;

export const ZSeasons = z.object({
  cycleDays: z.number().int().positive(),
  note: z.string().max(400),
  seasons: z.array(z.object({
    id: ZSeasonId,
    name: z.string().min(2).max(24),
    /** training only — a season never touches a combat number */
    statBonus: z.record(ZStatKey, z.number().min(0).max(0.2)),
    /** weather ids drawn from training.json; four so the hourly rotation stays visible */
    weather: z.array(z.string().regex(/^[a-z0-9-]+$/)).min(4).max(8),
    flavor: z.string().max(200),
  })).length(4),
});
export type Seasons = z.infer<typeof ZSeasons>;

/* ── Territory ────────────────────────────────────────────────────────── */

export const ZTerritory = z.object({
  regions: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(48),
    country: z.string().min(2).max(48),
    homeVillage: z.string().regex(/^[a-z0-9-]+$/),
    adjacent: z.array(z.string().regex(/^[a-z0-9-]+$/)).min(1).max(8),
    resources: z.array(z.string().regex(/^[a-z0-9-]+$/)).min(1).max(6),
    trainingBonus: z.number().min(0).max(0.25),
    taxPerDay: z.number().int().nonnegative(),
    blurb: z.string().max(200),
  })).min(2),
  war: z.object({
    periodDays: z.number().int().positive(),
    declareWindowDays: z.number().int().positive(),
    declareCost: z.number().int().nonnegative(),
    minMembersToDeclare: z.number().int().positive(),
    maxRegionsPerClan: z.number().int().positive(),
    maxDeclarationsPerPeriodPerClan: z.number().int().positive(),
    minTenureMinutesToScore: z.number().int().nonnegative(),
    /** applies to WAR SCORE, never to a combat statistic — see the note in the data */
    defenderScoreMultiplier: z.number().min(1).max(2),
    score: z.object({
      pvpWin: z.number().nonnegative(),
      missionCompleted: z.number().nonnegative(),
      sRankCompleted: z.number().nonnegative(),
      bountyClaimed: z.number().nonnegative(),
      maxPerMemberPerPeriod: z.number().positive(),
    }),
    spoils: z.object({
      /** strictly below 1: the shortfall is what makes trading a region back and forth lossy */
      winnerBankShareOfStake: z.number().min(0).max(0.95),
      note: z.string().max(400),
    }),
    note: z.string().max(600),
  }),
  yield: z.object({
    gatherMinutes: z.number().int().positive(),
    baseUnits: z.number().int().positive(),
    controllingVillageBonus: z.number().min(0).max(2),
    garrisonClanBonus: z.number().min(0).max(2),
    outsiderPenalty: z.number().min(0).max(1),
    outsiderTollFraction: z.number().min(0).max(1),
    seasonalMissMultiplier: z.number().min(0).max(1),
    note: z.string().max(400),
  }),
});
export type Territory = z.infer<typeof ZTerritory>;
export type Region = Territory['regions'][number];

/* ── Economy ──────────────────────────────────────────────────────────── */

export const ZItemKind = z.enum(['resource', 'component', 'consumable', 'key', 'regalia']);

/**
 * An item's `use` block is the whole surface an item is allowed to have, and
 * every field in it is out-of-combat by construction. There is no route from a
 * crafted good into `resolveTurn` — that is what keeps a market from becoming
 * pay-to-win.
 */
export const ZItemUse = z.object({
  trainingRateBonus: z.number().min(0).max(1).optional(),
  gatherYieldBonus: z.number().min(0).max(1).optional(),
  dungeonAttempts: z.number().int().min(0).max(3).optional(),
  uses: z.number().int().min(1).max(10),
}).strict();

export const ZEconomy = z.object({
  items: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(48),
    kind: ZItemKind,
    seasons: z.array(ZSeasonId).max(4),
    baseValue: z.number().int().nonnegative(),
    stackMax: z.number().int().positive(),
    tradable: z.boolean(),
    use: ZItemUse.optional(),
    blurb: z.string().max(200),
  })).min(1),
  recipes: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(48),
    station: z.string().regex(/^[a-z0-9-]+$/),
    inputs: z.array(z.object({ item: z.string().regex(/^[a-z0-9-]+$/), qty: z.number().int().positive().max(99) })).min(1).max(4),
    output: z.object({ item: z.string().regex(/^[a-z0-9-]+$/), qty: z.number().int().positive().max(10) }),
    minutes: z.number().int().positive(),
    requires: z.object({ stat: ZStatKey, min: z.number().int().nonnegative().max(200) }),
    unlockRank: ZRankName,
  })).min(1),
  stations: z.array(z.object({ id: z.string().regex(/^[a-z0-9-]+$/), name: z.string().min(2).max(48) })).min(1),
  market: z.object({
    listingFeeFraction: z.number().min(0).max(0.5),
    maxActiveListingsPerPlayer: z.number().int().positive(),
    minRankToTrade: ZRankName,
    priceFloorFraction: z.number().min(0).max(1),
    priceCeilingFraction: z.number().min(1).max(20),
    referenceAdjustPerSale: z.number().min(0).max(0.5),
    referenceReturnPerDay: z.number().min(0).max(1),
    listingDurationHours: z.number().int().positive(),
    note: z.string().max(600),
  }),
  blackMarket: z.object({
    priceMultiplier: z.number().min(1).max(5),
    sellsKeys: z.boolean(),
    taxFree: z.boolean(),
    note: z.string().max(400),
  }),
});
export type Economy = z.infer<typeof ZEconomy>;
export type Item = Economy['items'][number];
export type Recipe = Economy['recipes'][number];

/* ── Politics ─────────────────────────────────────────────────────────── */

export const ZOfficeId = z.enum(['kage', 'council', 'anbu-captain', 'jonin-commander']);
export type OfficeId = z.infer<typeof ZOfficeId>;

export const ZPolitics = z.object({
  cycleDays: z.number().int().positive(),
  nominationDays: z.number().int().positive(),
  votingDays: z.number().int().positive(),
  note: z.string().max(600),
  offices: z.array(z.object({
    id: ZOfficeId,
    name: z.string().min(2).max(32),
    seats: z.number().int().positive().max(9),
    minRank: ZRankName,
    minReputation: z.number().int(),
    powers: z.array(z.enum(['setTax', 'enactLaw', 'commissionWork', 'declareVillageWar', 'postBounty'])).min(1),
    blurb: z.string().max(200),
  })).min(1),
  suffrage: z.object({
    minRank: ZRankName,
    minMissionsCompleted: z.number().int().nonnegative(),
    minAccountAgeMinutes: z.number().int().nonnegative(),
    roguesMayVote: z.boolean(),
    note: z.string().max(600),
  }),
  tax: z.object({
    min: z.number().min(0).max(1),
    max: z.number().min(0).max(1),
    default: z.number().min(0).max(1),
    changePerCycleMax: z.number().min(0).max(1),
    note: z.string().max(400),
  }),
  treasury: z.object({
    commissions: z.array(z.object({
      id: z.string().regex(/^[a-z0-9-]+$/),
      name: z.string().min(2).max(48),
      cost: z.number().int().positive(),
      effect: z.object({
        trainingBonusVillage: z.number().min(0).max(0.5).optional(),
        gatherBonusVillage: z.number().min(0).max(0.5).optional(),
        defenceScoreBonus: z.number().min(0).max(0.5).optional(),
        missionInjuryReduction: z.number().min(0).max(0.5).optional(),
      }).strict(),
      durationDays: z.number().int().positive(),
      blurb: z.string().max(200),
    })).min(1),
    maxActiveCommissions: z.number().int().positive(),
    note: z.string().max(600),
  }),
  laws: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(32),
    effect: z.object({
      outsiderPenaltyWaived: z.boolean().optional(),
      warScoreBonus: z.number().min(0).max(0.5).optional(),
      outsiderTollFraction: z.number().min(0).max(1).optional(),
      menteeBonus: z.number().min(0).max(0.5).optional(),
    }).strict(),
    blurb: z.string().max(200),
  })).min(1),
  maxActiveLaws: z.number().int().positive(),
  war: z.object({
    declareRequiresOffice: ZOfficeId,
    cooldownDays: z.number().int().nonnegative(),
    note: z.string().max(400),
  }),
});
export type Politics = z.infer<typeof ZPolitics>;

/* ── Dungeons ─────────────────────────────────────────────────────────── */

export const ZDungeons = z.object({
  note: z.string().max(600),
  rules: z.object({
    maxRunsPerDay: z.number().int().positive(),
    wrongAnswerCooldownMinutes: z.number().int().nonnegative(),
    runExpiryMinutes: z.number().int().positive(),
    attemptsFloor: z.number().int().positive(),
  }),
  dungeons: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(48),
    regionId: z.string().regex(/^[a-z0-9-]+$/),
    seasons: z.array(ZSeasonId).max(4),
    keyItem: z.string().regex(/^[a-z0-9-]+$/).nullable(),
    minRank: ZRankName,
    cooldownHours: z.number().int().positive(),
    blurb: z.string().max(200),
    rooms: z.array(z.object({
      id: z.string().regex(/^[a-z0-9-]+$/),
      prompt: z.string().min(10).max(300),
      hint: z.string().max(160),
      salt: z.string().regex(/^[0-9a-f]{16}$/),
      /** salted sha256 of the normalised answer — never the answer itself */
      answerHash: z.string().regex(/^[0-9a-f]{64}$/),
      attempts: z.number().int().positive().max(10),
    })).min(1).max(8),
    rewards: z.object({
      ryo: z.number().int().nonnegative(),
      items: z.array(z.object({ item: z.string().regex(/^[a-z0-9-]+$/), qty: z.number().int().positive() })).max(4),
      jutsu: z.string().regex(/^[a-z0-9-]+$/).optional(),
      cosmetic: z.string().regex(/^[a-z0-9-]+$/).optional(),
      legendary: z.string().regex(/^[a-z0-9-]+$/).optional(),
    }),
  })).min(1),
});
export type Dungeons = z.infer<typeof ZDungeons>;
export type Dungeon = Dungeons['dungeons'][number];

/* ── Cosmetics ────────────────────────────────────────────────────────── */

export const ZCosmetics = z.object({
  rules: z.object({
    /** all three literals: the type system refuses a cosmetic that does anything */
    affectsCombat: z.literal(false),
    affectsProgression: z.literal(false),
    tradable: z.literal(false),
    note: z.string().max(600),
  }),
  slots: z.array(z.object({ id: z.string().regex(/^[a-z0-9-]+$/), name: z.string().min(2).max(32) })).min(1),
  items: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(48),
    slot: z.string().regex(/^[a-z0-9-]+$/),
    source: z.enum(['default', 'purchase', 'craft', 'dungeon', 'title', 'season', 'mentor']),
    price: z.number().int().positive().optional(),
    season: ZSeasonId.optional(),
    title: z.string().regex(/^[a-z0-9-]+$/).optional(),
    recipe: z.string().regex(/^[a-z0-9-]+$/).optional(),
    blurb: z.string().max(200),
  }).strict()).min(1),
});
export type Cosmetics = z.infer<typeof ZCosmetics>;

/* ── Mentorship ───────────────────────────────────────────────────────── */

export const ZMentorship = z.object({
  mentor: z.object({
    minRank: ZRankName,
    minReputation: z.number().int(),
    maxConcurrentMentees: z.number().int().positive().max(10),
    /** never ryo and never anything sellable — see the note in the data file */
    rewardPerMilestone: z.object({
      reputation: z.number().int().nonnegative(),
      clanContribution: z.number().int().nonnegative(),
    }).strict(),
    maxRewardedMilestonesPerMenteePerWeek: z.number().int().positive(),
    graduationGift: z.string().regex(/^[a-z0-9-]+$/),
    note: z.string().max(600),
  }),
  mentee: z.object({
    maxRank: ZRankName,
    trainingBonus: z.number().min(0).max(0.5),
    missionBonus: z.number().min(0).max(0.5),
    mentoredOnce: z.boolean(),
    note: z.string().max(600),
  }),
  pairing: z.object({
    minDurationMinutesBeforeRewards: z.number().int().nonnegative(),
    maxDurationDays: z.number().int().positive(),
    sameVillageRequired: z.boolean(),
    roguesExcluded: z.boolean(),
    levelGapMin: z.number().int().nonnegative(),
    cooldownMinutesBetweenPairings: z.number().int().nonnegative(),
    note: z.string().max(600),
  }),
  milestones: z.array(z.object({
    id: z.string().regex(/^[a-z0-9-]+$/),
    name: z.string().min(2).max(48),
    criterion: z.enum(['rank', 'missionsCompleted', 'pvpWins']),
    threshold: z.number().int().nonnegative().optional(),
    blurb: z.string().max(200),
  })).min(1),
});
export type Mentorship = z.infer<typeof ZMentorship>;

/* ── Validated exports ────────────────────────────────────────────────── */

export const TUNING: Tuning = ZTuning.parse(tuningData);
export const STATUSES: StatusDef[] = z.array(ZStatusDef).parse(statusData);
export const JUTSU: Jutsu[] = z.array(ZJutsu).parse(jutsuData);
export const BLOODLINES: Bloodline[] = z.array(ZBloodline).parse(bloodlineData);
export const CLANS: Clan[] = z.array(ZClan).parse(clanData);
export const VILLAGES: Village[] = z.array(ZVillage).parse(villageData);
export const COMBOS: Combo[] = z.array(ZCombo).parse(comboData);
export const TRAINING: Training = ZTraining.parse(trainingData);
export const MISSIONS: MissionData = ZMissions.parse(missionData);
export const ROGUE: RogueRules = ZRogue.parse(rogueData);
export const CLAN_RULES: ClanRules = ZClanRules.parse(clanRuleData);
export const LEGACY: Legacy = ZLegacy.parse(legacyData);
export const SEASONS: Seasons = ZSeasons.parse(seasonData);
export const TERRITORY: Territory = ZTerritory.parse(territoryData);
export const ECONOMY: Economy = ZEconomy.parse(economyData);
export const POLITICS: Politics = ZPolitics.parse(politicsData);
export const DUNGEONS: Dungeons = ZDungeons.parse(dungeonData);
export const COSMETICS: Cosmetics = ZCosmetics.parse(cosmeticData);
export const MENTORSHIP: Mentorship = ZMentorship.parse(mentorshipData);
export const MISSION_BY_ID: ReadonlyMap<string, Mission> = new Map(MISSIONS.missions.map((m) => [m.id, m]));

/** Indexed by `${setup}|${trigger}` for a single lookup per damage instance. */
export const COMBO_INDEX: ReadonlyMap<string, Combo> = new Map(COMBOS.map((c) => [`${c.setup}|${c.trigger}`, c]));

export const BLOODLINE_BY_ID: ReadonlyMap<string, Bloodline> = new Map(BLOODLINES.map((b) => [b.id, b]));
export const CLAN_BY_ID: ReadonlyMap<string, Clan> = new Map(CLANS.map((c) => [c.id, c]));
export const VILLAGE_BY_ID: ReadonlyMap<string, Village> = new Map(VILLAGES.map((v) => [v.id, v]));

export function getBloodline(id: string): Bloodline | undefined { return BLOODLINE_BY_ID.get(id); }

export const STATUS_BY_ID: ReadonlyMap<StatusId, StatusDef> = new Map(STATUSES.map((s) => [s.id, s]));
export const JUTSU_BY_ID: ReadonlyMap<string, Jutsu> = new Map(JUTSU.map((j) => [j.id, j]));

/** Zero-cost actions every fighter may use whether or not they are in the loadout. */
export const BASELINE_ACTIONS = [
  'basic-strike', 'throw-weapon', 'chakra-focus', 'guard-stance',
  'substitute', 'counter-stance-basic', 'prepare-seals', 'gather-natural-energy',
] as const;

/**
 * Rolls a bloodline for a new character. Only ~20% of characters get one, and the
 * draw is weighted by lore scarcity — a Rinnegan is not a Nara shadow.
 * Deterministic given the roll value, so character creation stays replayable.
 */
export function rollBloodline(roll01: number, pick01: number): string | null {
  if (roll01 >= TUNING.bloodlines.grantChance) return null;
  const total = BLOODLINES.reduce((n, b) => n + b.rarity, 0);
  let cursor = Math.min(0.999999, Math.max(0, pick01)) * total;
  for (const b of BLOODLINES) {
    cursor -= b.rarity;
    if (cursor < 0) return b.id;
  }
  return BLOODLINES[BLOODLINES.length - 1]?.id ?? null;
}

/** fire → wind → lightning → earth → water → fire (CLAUDE.md §7) */
export const NATURE_CYCLE: Record<string, Nature> = {
  fire: 'wind', wind: 'lightning', lightning: 'earth', earth: 'water', water: 'fire',
};

/** taijutsu → genjutsu → ninjutsu → taijutsu (CLAUDE.md §7) */
export const DISCIPLINE_CYCLE = {
  taijutsu: 'genjutsu', genjutsu: 'ninjutsu', ninjutsu: 'taijutsu',
} as const;

export const REGION_BY_ID: ReadonlyMap<string, Region> = new Map(TERRITORY.regions.map((r) => [r.id, r]));
export const ITEM_BY_ID: ReadonlyMap<string, Item> = new Map(ECONOMY.items.map((i) => [i.id, i]));
export const RECIPE_BY_ID: ReadonlyMap<string, Recipe> = new Map(ECONOMY.recipes.map((r) => [r.id, r]));
export const DUNGEON_BY_ID: ReadonlyMap<string, Dungeon> = new Map(DUNGEONS.dungeons.map((d) => [d.id, d]));
export const COSMETIC_BY_ID: ReadonlyMap<string, Cosmetics['items'][number]> = new Map(COSMETICS.items.map((c) => [c.id, c]));

/**
 * Season and weather are both pure functions of the server clock. Nothing is
 * stored, so there is no state to desynchronise and nothing a client can reroll
 * by reconnecting.
 */
export function currentSeason(nowMs: number): Seasons['seasons'][number] {
  const dayLength = 24 * 60 * 60 * 1000;
  const seasonDays = SEASONS.cycleDays / SEASONS.seasons.length;
  const index = Math.floor(nowMs / (dayLength * seasonDays)) % SEASONS.seasons.length;
  return SEASONS.seasons[index]!;
}

export function getJutsu(id: string): Jutsu | undefined { return JUTSU_BY_ID.get(id); }
export function getStatus(id: StatusId): StatusDef | undefined { return STATUS_BY_ID.get(id); }

export type { Jutsu, StatKey, StatusId, Nature, Effect };
