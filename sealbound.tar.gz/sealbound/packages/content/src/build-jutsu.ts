/**
 * Builds data/jutsu.json from a compact spec table.
 *
 * The emitted JSON is the artifact of record — the engine reads JSON, never this
 * file. This exists so 200+ records stay internally consistent: rank determines
 * cost/power/seal curves in exactly one place.
 *
 * ALL PROPER NOUNS HERE ARE ORIGINAL TO THIS PROJECT (CLAUDE.md §2).
 */
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import type { Discipline, Effect, Jutsu, JutsuRank, Nature, StatKey, StatusId } from '@shinobi/shared';
import tuning from '../data/tuning.json' with { type: 'json' };

/** Role power multipliers are balance constants, so they live in content data. */
const R: Record<string, number> = tuning.roles;

type Role =
  | 'strike' | 'pierce' | 'multi' | 'dot' | 'control' | 'debuff' | 'buff' | 'heal'
  | 'regen' | 'shield' | 'clone' | 'dispel' | 'reflect' | 'trap' | 'drain'
  | 'chakra' | 'gate' | 'haste' | 'execute' | 'guardbreak' | 'nuke' | 'sub' | 'cleanse'
  | 'interrupt' | 'focus' | 'stance' | 'oil' | 'natural';

/** [id, Name, nature, discipline, rank, role, arg?] */
type Spec = [string, string, Nature | null, Discipline, JutsuRank, Role, (string | number)?];

const CURVE: Record<JutsuRank, { power: number; cost: number; seals: number; interrupt: number; cd: number }> = {
  E: { power: 30, cost: 6, seals: 0, interrupt: 400, cd: 0 },
  D: { power: 48, cost: 18, seals: 1, interrupt: 58, cd: 0 },
  C: { power: 70, cost: 34, seals: 2, interrupt: 50, cd: 1 },
  B: { power: 98, cost: 54, seals: 3, interrupt: 44, cd: 2 },
  A: { power: 132, cost: 78, seals: 4, interrupt: 38, cd: 3 },
  S: { power: 178, cost: 112, seals: 6, interrupt: 32, cd: 5 },
};

const SCALE: Record<Discipline, StatKey> = { ninjutsu: 'ninjutsu', genjutsu: 'genjutsu', taijutsu: 'strength' };

const r = (n: number) => Math.round(n);

const RANK_INDEX: Record<JutsuRank, number> = { E: 0, D: 1, C: 2, B: 3, A: 4, S: 5 };

/** Always available, always free — must match BASELINE_ACTIONS in the loader. */
const BASELINE_IDS = ['basic-strike', 'chakra-focus', 'guard-stance', 'throw-weapon',
  'substitute', 'counter-stance-basic', 'prepare-seals', 'gather-natural-energy'] as const;

function effectsFor(role: Role, rank: JutsuRank, disc: Discipline, arg?: string | number): Effect[] {
  const c = CURVE[rank];
  const s = SCALE[disc];
  const p = c.power;
  switch (role) {
    case 'strike': return [{ kind: 'damage', power: r(p * R.strike!), scaling: s }];
    case 'pierce': return [{ kind: 'damage', power: r(p * R.pierce!), scaling: s, pierce: 0.4 }];
    case 'multi': return [{ kind: 'damage', power: r(p * R.multi!), scaling: s, hits: 3 }];
    case 'nuke': return [{ kind: 'damage', power: r(p * R.nuke!), scaling: s }];
    case 'dot': return [
      { kind: 'damage', power: r(p * R.dot!), scaling: s },
      { kind: 'applyStatus', status: (arg as StatusId) ?? 'burn', duration: 4, potency: r(p * 0.12), chance: 0.85, target: 'opponent' },
    ];
    case 'control': return [
      { kind: 'damage', power: r(p * R.control!), scaling: s },
      { kind: 'applyStatus', status: (arg as StatusId) ?? 'stun', duration: rank === 'S' ? 3 : rank === 'A' ? 2 : 1, chance: rank === 'S' ? 0.8 : 0.65, target: 'opponent' },
    ];
    case 'debuff': return [
      { kind: 'damage', power: r(p * R.debuff!), scaling: s },
      { kind: 'applyStatus', status: (arg as StatusId) ?? 'mark', duration: 4, potency: r(p * 0.1), chance: 0.9, target: 'opponent' },
    ];
    case 'guardbreak': return [
      { kind: 'damage', power: r(p * R.guardbreak!), scaling: s },
      { kind: 'applyStatus', status: 'guardbreak', duration: 3, chance: 0.9, target: 'opponent' },
    ];
    case 'execute': return [{ kind: 'damage', power: r(p * R.execute!), scaling: s, bonusVs: { status: (arg as StatusId) ?? 'bleed', mult: 1.45 } }];
    case 'drain': return [{ kind: 'damage', power: r(p * R.drain!), scaling: s, leech: 0.28 }];
    case 'buff': return [{ kind: 'statModifier', stat: (arg as StatKey) ?? s, mult: 1 + p / 420, duration: 4, target: 'self' }];
    case 'haste': return [
      { kind: 'statModifier', stat: 'speed', mult: 1 + p / 500, duration: 3, target: 'self' },
      { kind: 'applyStatus', status: 'haste', duration: 3, target: 'self' },
    ];
    case 'heal': return [{ kind: 'heal', power: r(p * R.heal!), scaling: 'stamina' }];
    case 'regen': return [
      { kind: 'heal', power: r(p * R.regen!), scaling: 'stamina' },
      { kind: 'applyStatus', status: 'regen', duration: 4, potency: r(p * 0.08), target: 'self' },
    ];
    case 'shield': return [{ kind: 'shield', power: r(p * R.shield!), scaling: 'stamina', duration: 3 }];
    case 'clone': {
      const count = Number(arg ?? 2);
      return [{ kind: 'cloneSplit', count, duration: count >= 3 ? 2 : 3 }];
    }
    case 'dispel': return [{ kind: 'dispel', clones: true, buffs: true, shields: true, target: 'opponent' }];
    case 'reflect': return [{ kind: 'reflectStance', fraction: Math.min(0.6, 0.2 + p / 600), duration: 2 }];
    case 'trap': return [{ kind: 'delayed', delay: 2, effects: [{ kind: 'damage', power: r(p * 1.15), scaling: s }, { kind: 'applyStatus', status: 'daze', duration: 2, chance: 0.7, target: 'opponent' }] }];
    case 'chakra': return [
      { kind: 'chakraDelta', amount: -r(p * 0.4), pool: 'all', target: 'opponent' },
      { kind: 'chakraDelta', amount: r(p * 0.25), pool: 'all', target: 'self' },
    ];
    case 'gate': return [{ kind: 'gateOpen', tiers: Number(arg ?? 1) }];
    case 'sub': return [{ kind: 'substitutionCharge', amount: Number(arg ?? 1) }];
    case 'cleanse': return [{ kind: 'cleanseStatus', count: Number(arg ?? 2), target: 'self' }];
    case 'interrupt': return [{ kind: 'damage', power: r(p * R.interrupt!), scaling: s }, { kind: 'interrupt' }];
    case 'focus': return [{ kind: 'applyStatus', status: 'focus', duration: 3, target: 'self' }];
    case 'stance': return [{ kind: 'stance', stance: arg as 'substitute' | 'counter' | 'prepare' }];
    case 'oil': return [
      { kind: 'damage', power: r(p * R.oil!), scaling: s },
      { kind: 'applyStatus', status: 'oiled', duration: 4, chance: 0.95, target: 'opponent' },
    ];
    case 'natural': return [{ kind: 'chakraDelta', amount: r(p * 0.35), pool: 'natural', target: 'self' }];
    default: {
      const never: never = role;
      throw new Error(`unhandled role ${String(never)}`);
    }
  }
}

/** Roles whose value is not damage get discounted cost / no seals penalty. */
const COST_MOD: Partial<Record<Role, number>> = {
  buff: 0.7, haste: 0.7, heal: 0.85, regen: 0.85, shield: 0.8, cleanse: 0.6,
  sub: 0.7, dispel: 0.75, reflect: 0.8, chakra: 0.5, gate: 0.35, clone: 3.0, focus: 0.6,
  stance: 0, natural: 0, oil: 0.6,
  nuke: 1.3, trap: 0.9,
};

const COOLDOWN_MOD: Partial<Record<Role, number>> = {
  control: 2, nuke: 3, gate: 4, clone: 2, sub: 3, dispel: 2, reflect: 2, trap: 2, execute: 1,
  interrupt: 2, focus: 2,
};

/** Scales the numeric magnitude of an effect list without changing its shape. */
function scalePower(effects: Effect[], mult: number): Effect[] {
  if (mult === 1) return effects;
  return effects.map((e): Effect => {
    switch (e.kind) {
      case 'damage': return { ...e, power: r(e.power * mult) };
      case 'heal': return { ...e, power: r(e.power * mult) };
      case 'shield': return { ...e, power: r(e.power * mult) };
      case 'delayed': return { ...e, effects: scalePower(e.effects, mult) as typeof e.effects };
      default: return e;
    }
  });
}

function build(spec: Spec): Jutsu {
  const [id, name, nature, discipline, rank, role, arg] = spec;
  const c = CURVE[rank];
  const isBaseline = (BASELINE_IDS as readonly string[]).includes(id);

  /* Taijutsu is body technique: it costs no hand seals, so it never weaves and
     never gets interrupted. It pays for that tempo with lower power per hit and
     a lower ceiling. Ninjutsu and genjutsu buy burst with setup time. */
  const bodyTechnique = discipline === 'taijutsu';
  const throughput = bodyTechnique ? R.bodyTechnique! : 1;

  const raw = isBaseline
    ? 0
    : Math.max(0, Math.round(c.cost * (COST_MOD[role] ?? 1) * (bodyTechnique ? 1.25 : 1)));

  /* Chakra is physical energy plus spiritual energy, so ninjutsu draws on both.
     Body technique is purely physical; illusion is purely mental. Forbidden and
     sage-tier work additionally demands natural energy, which cannot be
     regenerated — it has to be gathered first. */
  const cost =
    discipline === 'taijutsu' ? { physical: raw, mental: 0, natural: 0 }
    : discipline === 'genjutsu' ? { physical: 0, mental: raw, natural: 0 }
    : { physical: Math.round(raw * 0.65), mental: Math.round(raw * 0.65), natural: 0 };
  if (rank === 'S' && !isBaseline) cost.natural = Math.max(1, Math.round(raw * 0.22));
  const seals = bodyTechnique ? 0
    : role === 'gate' || rank === 'E' ? Math.max(0, c.seals - 1)
    : c.seals;
  const cooldown = c.cd + (COOLDOWN_MOD[role] ?? 0);
  const reqStat: StatKey = discipline === 'taijutsu' ? 'taijutsu' : discipline === 'genjutsu' ? 'genjutsu' : 'ninjutsu';
  const reqMin = { E: 0, D: 8, C: 20, B: 38, A: 60, S: 85 }[rank];
  const j: Jutsu = {
    id, name, discipline, nature, rank,
    // effectsFor returns the shared Effect union; ZJutsu re-derives a structurally
    // identical (but nominally distinct) union, so widen through the schema.
    cost,
    seals,
    sealDifficulty: seals === 0 ? 0 : Math.round(seals * 6 + RANK_INDEX[rank] * 5),
    cooldown,
    interruptThreshold: c.interrupt,
    effects: scalePower(effectsFor(role, rank, discipline, arg), throughput) as Jutsu['effects'],
    ...(reqMin > 0 ? { requires: { stat: reqStat, min: reqMin } } : {}),
  };
  return j;
}

/* ── The library ──────────────────────────────────────────────────────── */

const SPECS: Spec[] = [
  /* Baseline — always available, zero cost (see project decisions) */
  ['basic-strike', 'Basic Strike', null, 'taijutsu', 'E', 'strike'],
  ['chakra-focus', 'Chakra Focus', null, 'ninjutsu', 'E', 'chakra'],
  ['guard-stance', 'Guard Stance', null, 'taijutsu', 'E', 'shield'],
  ['throw-weapon', 'Throw Weapon', null, 'taijutsu', 'E', 'strike'],
  ['substitute', 'Substitution', null, 'ninjutsu', 'E', 'stance', 'substitute'],
  ['counter-stance-basic', 'Counter', null, 'taijutsu', 'E', 'stance', 'counter'],
  ['prepare-seals', 'Prepare', null, 'ninjutsu', 'E', 'stance', 'prepare'],
  ['gather-natural-energy', 'Gather Natural Energy', null, 'ninjutsu', 'E', 'natural'],

  /* ── Fire ── */
  ['fireball-jutsu', 'Fireball Jutsu', 'fire', 'ninjutsu', 'E', 'strike'],
  ['flame-fist', 'Flame Fist', 'fire', 'taijutsu', 'E', 'strike'],
  ['ash-pile-burning', 'Ash Pile Burning', 'fire', 'ninjutsu', 'D', 'dot', 'burn'],
  ['flame-cloak', 'Flame Cloak', 'fire', 'taijutsu', 'D', 'haste'],
  ['exploding-flame-tag', 'Exploding Flame Tag', 'fire', 'ninjutsu', 'D', 'trap'],
  ['flame-brand', 'Flame Brand', 'fire', 'ninjutsu', 'D', 'debuff', 'mark'],
  ['phoenix-flower-jutsu', 'Phoenix Flower Jutsu', 'fire', 'ninjutsu', 'C', 'strike'],
  ['ash-cloud-veil', 'Ash Cloud Veil', 'fire', 'ninjutsu', 'C', 'debuff', 'blind'],
  ['phoenix-nail-crimson', 'Phoenix Nail Crimson', 'fire', 'ninjutsu', 'C', 'multi'],
  ['flame-dash', 'Flame Dash', 'fire', 'taijutsu', 'C', 'haste'],
  ['cauterizing-flame', 'Cauterizing Flame', 'fire', 'ninjutsu', 'C', 'heal'],
  ['dragon-flame-volley', 'Dragon Flame Volley', 'fire', 'ninjutsu', 'C', 'multi'],
  ['fire-sealing-chain', 'Fire Sealing Chain', 'fire', 'ninjutsu', 'B', 'control', 'bind'],
  ['dragon-flame-bomb', 'Dragon Flame Bomb', 'fire', 'ninjutsu', 'B', 'multi'],
  ['great-fire-annihilation', 'Great Fire Annihilation', 'fire', 'ninjutsu', 'B', 'dot', 'burn'],
  ['flame-body', 'Flame Body', 'fire', 'ninjutsu', 'B', 'buff'],
  ['fire-encampment-wall', 'Fire Encampment Wall', 'fire', 'ninjutsu', 'B', 'shield'],
  ['flame-mirror', 'Flame Mirror', 'fire', 'ninjutsu', 'B', 'reflect'],
  ['fire-dragon-flame-bullet', 'Fire Dragon Flame Bullet', 'fire', 'ninjutsu', 'A', 'pierce'],
  ['blaze-devouring-flame', 'Blaze Devouring Flame', 'fire', 'ninjutsu', 'A', 'drain'],
  ['great-flame-flower', 'Great Flame Flower', 'fire', 'ninjutsu', 'A', 'dot', 'burn'],
  ['hell-ring', 'Hell Ring', 'fire', 'ninjutsu', 'A', 'control', 'snare'],
  ['amaterasu', 'Amaterasu', 'fire', 'ninjutsu', 'S', 'nuke'],
  ['blaze-release-kagutsuchi', 'Blaze Release: Kagutsuchi', 'fire', 'ninjutsu', 'S', 'drain'],

  /* ── Wind ── */
  ['gale-palm', 'Gale Palm', 'wind', 'ninjutsu', 'E', 'strike'],
  ['whirlwind-fist', 'Whirlwind Fist', 'wind', 'taijutsu', 'E', 'strike'],
  ['wind-scythe-jutsu', 'Wind Scythe Jutsu', 'wind', 'ninjutsu', 'D', 'multi'],
  ['vacuum-blade', 'Vacuum Blade', 'wind', 'ninjutsu', 'D', 'pierce'],
  ['pressure-damage', 'Pressure Damage', 'wind', 'ninjutsu', 'D', 'debuff', 'chakraleak'],
  ['dust-wind-technique', 'Dust Wind Technique', 'wind', 'ninjutsu', 'D', 'dispel'],
  ['vacuum-sphere', 'Vacuum Sphere', 'wind', 'ninjutsu', 'C', 'strike'],
  ['wind-cloak', 'Wind Cloak', 'wind', 'taijutsu', 'C', 'haste'],
  ['vacuum-serial-waves', 'Vacuum Serial Waves', 'wind', 'ninjutsu', 'C', 'multi'],
  ['rising-twister', 'Rising Twister', 'wind', 'taijutsu', 'C', 'haste'],
  ['devouring-gale', 'Devouring Gale', 'wind', 'ninjutsu', 'C', 'drain'],
  ['wind-binding', 'Wind Binding', 'wind', 'ninjutsu', 'C', 'control', 'snare'],
  ['wind-clone', 'Wind Clone', 'wind', 'ninjutsu', 'C', 'clone', 2],
  ['great-breakthrough', 'Great Breakthrough', 'wind', 'ninjutsu', 'B', 'strike'],
  ['vacuum-void', 'Vacuum Void', 'wind', 'ninjutsu', 'B', 'debuff', 'chakraleak'],
  ['drilling-air-bullet', 'Drilling Air Bullet', 'wind', 'ninjutsu', 'B', 'pierce'],
  ['silencing-gale', 'Silencing Gale', 'wind', 'ninjutsu', 'B', 'control', 'silence'],
  ['wind-armour', 'Wind Armour', 'wind', 'ninjutsu', 'B', 'shield'],
  ['vacuum-great-sphere', 'Vacuum Great Sphere', 'wind', 'ninjutsu', 'A', 'pierce'],
  ['wind-barrier', 'Wind Barrier', 'wind', 'ninjutsu', 'A', 'shield'],
  ['divine-cross-cut-storm', 'Divine Cross Cut Storm', 'wind', 'ninjutsu', 'A', 'multi'],
  ['wind-cutter', 'Wind Cutter', 'wind', 'ninjutsu', 'A', 'strike'],
  ['rasenshuriken', 'Wind Release: Rasenshuriken', 'wind', 'ninjutsu', 'S', 'multi'],
  ['vacuum-devastation', 'Vacuum Devastation', 'wind', 'ninjutsu', 'S', 'nuke'],

  /* ── Lightning ── */
  ['lightning-strike', 'Lightning Strike', 'lightning', 'ninjutsu', 'E', 'strike'],
  ['static-drain', 'Static Drain', 'lightning', 'ninjutsu', 'E', 'drain'],
  ['lightning-senbon', 'Lightning Senbon', 'lightning', 'ninjutsu', 'D', 'pierce'],
  ['lightning-release-armour', 'Lightning Release Armour', 'lightning', 'ninjutsu', 'D', 'buff'],
  ['flash-pillar', 'Flash Pillar', 'lightning', 'ninjutsu', 'D', 'debuff', 'blind'],
  ['conductive-mark', 'Conductive Mark', 'lightning', 'ninjutsu', 'D', 'debuff', 'conduct'],
  ['grounding-seal', 'Grounding Seal', 'lightning', 'ninjutsu', 'D', 'dispel'],
  ['chain-lightning', 'Chain Lightning', 'lightning', 'ninjutsu', 'C', 'multi'],
  ['lightning-nail', 'Lightning Nail', 'lightning', 'ninjutsu', 'C', 'pierce'],
  ['lightning-step', 'Lightning Step', 'lightning', 'taijutsu', 'C', 'haste'],
  ['electromagnetic-murder', 'Electromagnetic Murder', 'lightning', 'ninjutsu', 'C', 'debuff', 'conduct'],
  ['lightning-clone', 'Lightning Clone', 'lightning', 'ninjutsu', 'C', 'clone', 2],
  ['thunderclap-guard', 'Thunderclap Guard', 'lightning', 'ninjutsu', 'C', 'shield'],
  ['lightning-paralysis', 'Lightning Paralysis', 'lightning', 'ninjutsu', 'B', 'control', 'stun'],
  ['chidori', 'Chidori', 'lightning', 'ninjutsu', 'B', 'strike'],
  ['thunder-volley', 'Thunder Volley', 'lightning', 'ninjutsu', 'B', 'multi'],
  ['lightning-drain', 'Lightning Drain', 'lightning', 'ninjutsu', 'B', 'drain'],
  ['lightning-net', 'Lightning Net', 'lightning', 'ninjutsu', 'B', 'control', 'bind'],
  ['lightning-fang', 'Lightning Fang', 'lightning', 'ninjutsu', 'A', 'drain'],
  ['false-darkness', 'False Darkness', 'lightning', 'ninjutsu', 'A', 'strike'],
  ['lightning-execution', 'Lightning Execution', 'lightning', 'ninjutsu', 'A', 'execute', 'conduct'],
  ['thousand-lightning-needles', 'Thousand Lightning Needles', 'lightning', 'ninjutsu', 'A', 'multi'],
  ['kirin', 'Kirin', 'lightning', 'ninjutsu', 'S', 'nuke'],
  ['lightning-overload', 'Lightning Overload', 'lightning', 'ninjutsu', 'S', 'buff', 'speed'],

  /* ── Earth ── */
  ['earth-fist', 'Earth Fist', 'earth', 'taijutsu', 'E', 'strike'],
  ['earth-skin', 'Earth Skin', 'earth', 'ninjutsu', 'E', 'buff'],
  ['earth-shot', 'Earth Shot', 'earth', 'ninjutsu', 'D', 'multi'],
  ['earth-style-wall', 'Earth Style Wall', 'earth', 'ninjutsu', 'D', 'shield'],
  ['earth-grip', 'Earth Grip', 'earth', 'ninjutsu', 'D', 'debuff', 'slow'],
  ['stone-trap-seal', 'Stone Trap Seal', 'earth', 'ninjutsu', 'D', 'trap'],
  ['earth-pillar', 'Earth Pillar', 'earth', 'ninjutsu', 'C', 'strike'],
  ['swamp-of-the-underworld', 'Swamp of the Underworld', 'earth', 'ninjutsu', 'C', 'control', 'snare'],
  ['headhunter-jutsu', 'Headhunter Jutsu', 'earth', 'ninjutsu', 'C', 'pierce'],
  ['iron-skin', 'Iron Skin', 'earth', 'ninjutsu', 'C', 'buff', 'stamina'],
  ['stone-devouring', 'Stone Devouring', 'earth', 'ninjutsu', 'C', 'drain'],
  ['earth-clone', 'Earth Clone', 'earth', 'ninjutsu', 'C', 'clone', 2],
  ['earth-mending', 'Earth Mending', 'earth', 'ninjutsu', 'C', 'heal'],
  ['earth-dragon-bullet', 'Earth Dragon Bullet', 'earth', 'ninjutsu', 'B', 'strike'],
  ['earth-binding-prison', 'Earth Binding Prison', 'earth', 'ninjutsu', 'B', 'control', 'bind'],
  ['mud-wall', 'Mud Wall', 'earth', 'ninjutsu', 'B', 'shield'],
  ['deep-root-snare', 'Deep Root Snare', 'earth', 'ninjutsu', 'B', 'control', 'snare'],
  ['earth-dome', 'Earth Dome', 'earth', 'ninjutsu', 'B', 'shield'],
  ['earth-shaking-palm', 'Earth Shaking Palm', 'earth', 'ninjutsu', 'A', 'strike'],
  ['stone-armour', 'Stone Armour', 'earth', 'ninjutsu', 'A', 'buff', 'stamina'],
  ['stone-shatter-fist', 'Stone Shatter Fist', 'earth', 'taijutsu', 'A', 'guardbreak'],
  ['rock-pillar-hammer', 'Rock Pillar Hammer', 'earth', 'taijutsu', 'A', 'pierce'],
  ['earth-style-tomb', 'Earth Style Tomb', 'earth', 'ninjutsu', 'S', 'control', 'bind'],
  ['mountain-crusher', 'Mountain Crusher', 'earth', 'ninjutsu', 'S', 'nuke'],

  /* ── Water ── */
  ['water-bullet', 'Water Bullet', 'water', 'ninjutsu', 'E', 'strike'],
  ['water-healing', 'Water Healing', 'water', 'ninjutsu', 'E', 'heal'],
  ['hidden-mist-jutsu', 'Hidden Mist Jutsu', 'water', 'ninjutsu', 'D', 'buff'],
  ['water-needle-rain', 'Water Needle Rain', 'water', 'ninjutsu', 'D', 'multi'],
  ['water-soak', 'Water Soak', 'water', 'ninjutsu', 'D', 'debuff', 'drench'],
  ['water-mark', 'Water Mark', 'water', 'ninjutsu', 'D', 'debuff', 'drench'],
  ['wild-water-wave', 'Wild Water Wave', 'water', 'ninjutsu', 'C', 'strike'],
  ['water-prison-jutsu', 'Water Prison Jutsu', 'water', 'ninjutsu', 'C', 'control', 'bind'],
  ['mist-step', 'Mist Step', 'water', 'taijutsu', 'C', 'haste'],
  ['still-water-mending', 'Still Water Mending', 'water', 'ninjutsu', 'C', 'heal'],
  ['water-wall', 'Water Wall', 'water', 'ninjutsu', 'C', 'shield'],
  ['water-clone-jutsu', 'Water Clone Jutsu', 'water', 'ninjutsu', 'C', 'clone', 2],
  ['water-whip', 'Water Whip', 'water', 'ninjutsu', 'C', 'multi'],
  ['whirlpool-drag', 'Whirlpool Drag', 'water', 'ninjutsu', 'B', 'control', 'snare'],
  ['water-shark-bomb', 'Water Shark Bomb', 'water', 'ninjutsu', 'B', 'strike'],
  ['frozen-brine', 'Frozen Brine', 'water', 'ninjutsu', 'B', 'debuff', 'slow'],
  ['spring-of-renewal', 'Spring of Renewal', 'water', 'ninjutsu', 'B', 'regen'],
  ['water-binding', 'Water Binding', 'water', 'ninjutsu', 'B', 'control', 'bind'],
  ['riptide-barrage', 'Riptide Barrage', 'water', 'ninjutsu', 'A', 'multi'],
  ['abyssal-drain', 'Abyssal Drain', 'water', 'ninjutsu', 'A', 'drain'],
  ['water-fang-lance', 'Water Fang Lance', 'water', 'ninjutsu', 'A', 'pierce'],
  ['whirlpool-prison', 'Whirlpool Prison', 'water', 'ninjutsu', 'A', 'control', 'bind'],
  ['great-waterfall-technique', 'Great Waterfall Technique', 'water', 'ninjutsu', 'S', 'nuke'],
  ['water-dragon-bullet', 'Water Dragon Bullet', 'water', 'ninjutsu', 'S', 'strike'],

  /* ── Yin — illusion, mind, unmaking ── */
  ['false-surroundings', 'False Surroundings', 'yin', 'genjutsu', 'E', 'strike'],
  ['feather-illusion-jutsu', 'Feather Illusion Jutsu', 'yin', 'genjutsu', 'E', 'debuff', 'slow'],
  ['demonic-illusion-hell-viewing', 'Demonic Illusion: Hell Viewing', 'yin', 'genjutsu', 'D', 'control', 'illusionlock'],
  ['illusion-doubt', 'Illusion: Doubt', 'yin', 'genjutsu', 'D', 'debuff', 'guardbreak'],
  ['mirage-clone', 'Mirage Clone', 'yin', 'genjutsu', 'D', 'clone', 2],
  ['illusion-weeping-seal', 'Illusion: Weeping Seal', 'yin', 'genjutsu', 'D', 'dot', 'poison'],
  ['blinding-illusion', 'Blinding Illusion', 'yin', 'genjutsu', 'D', 'debuff', 'blind'],
  ['demonic-illusion-false-dusk', 'Demonic Illusion: False Dusk', 'yin', 'genjutsu', 'C', 'control', 'daze'],
  ['bell-ringing-illusion', 'Bell Ringing Illusion', 'yin', 'genjutsu', 'C', 'control', 'silence'],
  ['mind-shatter', 'Mind Shatter', 'yin', 'genjutsu', 'C', 'strike'],
  ['illusion-doubling-shadows', 'Illusion: Doubling Shadows', 'yin', 'genjutsu', 'C', 'clone', 3],
  ['demonic-illusion-lullaby', 'Demonic Illusion: Lullaby', 'yin', 'genjutsu', 'C', 'control', 'daze'],
  ['phantom-pain', 'Phantom Pain', 'yin', 'genjutsu', 'C', 'debuff', 'mark'],
  ['memory-disruption', 'Memory Disruption', 'yin', 'genjutsu', 'C', 'debuff', 'chakraleak'],
  ['transformation-jutsu', 'Transformation Jutsu', 'yin', 'genjutsu', 'C', 'clone', 2],
  ['temple-of-nirvana', 'Temple of Nirvana', 'yin', 'genjutsu', 'B', 'control', 'illusionlock'],
  ['nightmare-bloom', 'Nightmare Bloom', 'yin', 'genjutsu', 'B', 'dot', 'poison'],
  ['binding-illusion', 'Binding Illusion', 'yin', 'genjutsu', 'B', 'control', 'snare'],
  ['mind-sever', 'Mind Sever', 'yin', 'genjutsu', 'B', 'guardbreak'],
  ['illusion-false-wound', 'Illusion: False Wound', 'yin', 'genjutsu', 'B', 'strike'],
  ['bringer-of-darkness', 'Bringer of Darkness', 'yin', 'genjutsu', 'B', 'reflect'],
  ['demonic-illusion-mourning', 'Demonic Illusion: Mourning', 'yin', 'genjutsu', 'A', 'control', 'illusionlock'],
  ['mind-destruction', 'Mind Destruction', 'yin', 'genjutsu', 'A', 'strike'],
  ['mind-leech', 'Mind Leech', 'yin', 'genjutsu', 'A', 'drain'],
  ['inner-collapse', 'Inner Collapse', 'yin', 'genjutsu', 'A', 'execute', 'illusionlock'],
  ['recursive-illusion', 'Recursive Illusion', 'yin', 'genjutsu', 'A', 'control', 'daze'],
  ['tsukuyomi', 'Tsukuyomi', 'yin', 'genjutsu', 'S', 'control', 'illusionlock'],
  ['kotoamatsukami', 'Kotoamatsukami', 'yin', 'genjutsu', 'S', 'control', 'bind'],
  ['mind-annihilation', 'Mind Annihilation', 'yin', 'genjutsu', 'S', 'nuke'],

  /* ── Yang — healing, body, endurance ── */
  ['mystical-palm-technique', 'Mystical Palm Technique', 'yang', 'ninjutsu', 'E', 'heal'],
  ['chakra-enhanced-strength', 'Chakra Enhanced Strength', 'yang', 'taijutsu', 'E', 'buff', 'stamina'],
  ['healing-ward', 'Healing Ward', 'yang', 'ninjutsu', 'D', 'shield'],
  ['antibody-activation', 'Antibody Activation', 'yang', 'ninjutsu', 'D', 'cleanse', 2],
  ['cell-regeneration', 'Cell Regeneration', 'yang', 'ninjutsu', 'D', 'heal'],
  ['chakra-transfer', 'Chakra Transfer', 'yang', 'ninjutsu', 'D', 'cleanse', 1],
  ['healing-pulse', 'Healing Pulse', 'yang', 'ninjutsu', 'C', 'heal'],
  ['muscle-reinforcement', 'Muscle Reinforcement', 'yang', 'taijutsu', 'C', 'buff', 'strength'],
  ['regeneration-ability', 'Regeneration Ability', 'yang', 'ninjutsu', 'C', 'regen'],
  ['body-anchor', 'Body Anchor', 'yang', 'ninjutsu', 'C', 'shield'],
  ['adrenaline-pulse', 'Adrenaline Pulse', 'yang', 'taijutsu', 'C', 'haste'],
  ['poison-extraction', 'Poison Extraction', 'yang', 'ninjutsu', 'C', 'cleanse', 3],
  ['adrenaline-surge', 'Adrenaline Surge', 'yang', 'taijutsu', 'C', 'haste'],
  ['chakra-scalpel', 'Chakra Scalpel', 'yang', 'ninjutsu', 'C', 'debuff', 'mark'],
  ['healing-resonance', 'Healing Resonance', 'yang', 'ninjutsu', 'B', 'heal'],
  ['marrow-reinforcement', 'Marrow Reinforcement', 'yang', 'ninjutsu', 'B', 'buff', 'stamina'],
  ['yin-healing-wound-destruction', 'Yin Healing Wound Destruction', 'yang', 'ninjutsu', 'B', 'cleanse', 4],
  ['life-leech', 'Life Leech', 'yang', 'ninjutsu', 'B', 'drain'],
  ['bone-mending', 'Bone Mending', 'yang', 'ninjutsu', 'B', 'regen'],
  ['strength-of-a-hundred-seal', 'Strength of a Hundred Seal', 'yang', 'ninjutsu', 'A', 'buff', 'strength'],
  ['healing-tide', 'Healing Tide', 'yang', 'ninjutsu', 'A', 'heal'],
  ['unbreakable-stance', 'Unbreakable Stance', 'yang', 'taijutsu', 'A', 'shield'],
  ['blood-pact', 'Blood Pact', 'yang', 'ninjutsu', 'A', 'buff', 'stamina'],
  ['creation-rebirth', 'Creation Rebirth', 'yang', 'ninjutsu', 'S', 'heal'],
  ['final-lantern', 'Final Lantern', 'yang', 'ninjutsu', 'S', 'buff', 'stamina'],
  ['resurgent-heart', 'Resurgent Heart', 'yang', 'ninjutsu', 'S', 'cleanse', 8],

  /* ── Pure taijutsu — no nature ── */
  ['palm-strike', 'Palm Strike', null, 'taijutsu', 'E', 'strike'],
  ['leaf-rising-wind', 'Leaf Rising Wind', null, 'taijutsu', 'D', 'strike'],
  ['leaf-whirlwind', 'Leaf Whirlwind', null, 'taijutsu', 'D', 'multi'],
  ['shadow-of-the-dancing-leaf', 'Shadow of the Dancing Leaf', null, 'taijutsu', 'D', 'haste'],
  ['dynamic-entry', 'Dynamic Entry', null, 'taijutsu', 'C', 'pierce'],
  ['leaf-strong-whirlwind', 'Leaf Strong Whirlwind', null, 'taijutsu', 'C', 'guardbreak'],
  ['pinning-throw', 'Pinning Throw', null, 'taijutsu', 'C', 'control', 'bind'],
  ['leaf-gale', 'Leaf Gale', null, 'taijutsu', 'C', 'dot', 'bleed'],
  ['iron-guard', 'Iron Guard', null, 'taijutsu', 'C', 'shield'],
  ['front-lotus', 'Front Lotus', null, 'taijutsu', 'B', 'multi'],
  ['falling-heel-drop', 'Falling Heel Drop', null, 'taijutsu', 'B', 'strike'],
  ['leaf-hurricane', 'Leaf Hurricane', null, 'taijutsu', 'B', 'multi'],
  ['tendon-sever', 'Tendon Sever', null, 'taijutsu', 'B', 'debuff', 'snare'],
  ['counter-stance', 'Counter Stance', null, 'taijutsu', 'B', 'reflect'],
  ['hidden-lotus', 'Hidden Lotus', null, 'taijutsu', 'A', 'strike'],
  ['morning-peacock', 'Morning Peacock', null, 'taijutsu', 'A', 'multi'],
  ['piercing-fang', 'Piercing Fang', null, 'taijutsu', 'A', 'pierce'],
  ['daytime-tiger', 'Daytime Tiger', null, 'taijutsu', 'S', 'execute', 'bleed'],

  /* ── Utility: clones, seals, gates ── */
  ['shadow-clone-jutsu', 'Shadow Clone Jutsu', null, 'ninjutsu', 'C', 'clone', 2],
  ['multi-shadow-clone-jutsu', 'Multi Shadow Clone Jutsu', null, 'ninjutsu', 'B', 'clone', 3],
  ['multiple-shadow-clone-jutsu', 'Multiple Shadow Clone Jutsu', null, 'ninjutsu', 'A', 'clone', 5],
  ['substitution-jutsu', 'Substitution Jutsu', null, 'ninjutsu', 'D', 'sub', 1],
  ['substitution-cache', 'Substitution Cache', null, 'ninjutsu', 'C', 'sub', 2],
  ['dispelling-sign', 'Dispelling Sign', null, 'ninjutsu', 'C', 'dispel'],
  ['seal-breaking-palm', 'Seal Breaking Palm', null, 'taijutsu', 'B', 'dispel'],
  ['chakra-absorption-seal', 'Chakra Absorption Seal', null, 'ninjutsu', 'B', 'chakra'],
  ['mind-clearing', 'Mind Clearing', null, 'ninjutsu', 'D', 'cleanse', 2],
  ['exploding-tag', 'Exploding Tag', 'lightning', 'ninjutsu', 'C', 'trap'],
  ['gate-of-opening', 'Gate of Opening', null, 'taijutsu', 'C', 'gate', 1],
  ['gate-of-life', 'Gate of Life', null, 'taijutsu', 'B', 'gate', 3],
  ['gate-of-limit', 'Gate of Limit', null, 'taijutsu', 'A', 'gate', 5],
  ['gate-of-death', 'Gate of Death', null, 'taijutsu', 'S', 'gate', 8],
  ['sealing-snap', 'Sealing Snap', null, 'taijutsu', 'C', 'interrupt'],
  ['thunderclap', 'Thunderclap', 'lightning', 'ninjutsu', 'B', 'interrupt'],
  ['centering-breath', 'Centering Breath', 'yang', 'ninjutsu', 'D', 'focus'],
  ['killing-intent', 'Killing Intent', 'yin', 'genjutsu', 'C', 'focus'],

  /* ── Bloodline-granted techniques ──────────────────────────────────
     These are unlocked by a kekkei genkai or clan trait rather than bought
     with a loadout slot. See data/bloodlines.json for who gets what. */

  // Sharingan / Mangekyo
  ['susanoo', 'Susanoo', 'yin', 'genjutsu', 'S', 'shield'],
  ['izanagi', 'Izanagi', 'yin', 'genjutsu', 'S', 'cleanse', 8],

  // Byakugan
  ['gentle-fist', 'Gentle Fist', null, 'taijutsu', 'C', 'pierce'],
  ['eight-trigrams-palm-rotation', 'Eight Trigrams Palm Rotation', null, 'taijutsu', 'B', 'reflect'],
  ['eight-trigrams-sixty-four-palms', 'Eight Trigrams Sixty-Four Palms', null, 'taijutsu', 'S', 'multi'],

  // Rinnegan
  ['shinra-tensei', 'Shinra Tensei', null, 'ninjutsu', 'S', 'nuke'],
  ['universal-pull', 'Universal Pull', null, 'ninjutsu', 'B', 'control', 'bind'],
  ['chibaku-tensei', 'Chibaku Tensei', 'earth', 'ninjutsu', 'S', 'control', 'bind'],

  // Wood Release
  ['wood-release-binding', 'Wood Release: Binding', 'earth', 'ninjutsu', 'B', 'control', 'bind'],
  ['wood-clone', 'Wood Clone', 'earth', 'ninjutsu', 'C', 'clone', 2],
  ['deep-forest-emergence', 'Deep Forest Emergence', 'earth', 'ninjutsu', 'A', 'strike'],

  // Ice Release
  ['demonic-ice-mirrors', 'Demonic Ice Mirrors', 'water', 'ninjutsu', 'A', 'reflect'],
  ['ice-prison', 'Ice Prison', 'water', 'ninjutsu', 'B', 'control', 'bind'],
  ['thousand-ice-needles', 'Thousand Ice Needles', 'water', 'ninjutsu', 'B', 'multi'],

  // Lava Release
  ['lava-globs', 'Lava Globs', 'fire', 'ninjutsu', 'B', 'dot', 'burn'],
  ['quicklime-congealing', 'Quicklime Congealing', 'earth', 'ninjutsu', 'A', 'control', 'snare'],

  // Boil Release
  ['corrosive-mist', 'Corrosive Mist', 'water', 'ninjutsu', 'B', 'dot', 'poison'],
  ['skilled-mist', 'Skilled Mist', 'water', 'ninjutsu', 'C', 'guardbreak'],

  // Storm Release
  ['laser-circus', 'Laser Circus', 'lightning', 'ninjutsu', 'A', 'multi'],

  // Explosion Release
  ['landmine-fist', 'Landmine Fist', 'earth', 'taijutsu', 'B', 'strike'],
  ['c4-detonation', 'C4 Detonation', 'fire', 'ninjutsu', 'S', 'nuke'],

  // Scorch Release
  ['steaming-danger-tyranny', 'Steaming Danger Tyranny', 'fire', 'ninjutsu', 'A', 'dot', 'burn'],

  // Magnet Release
  ['iron-sand-drizzle', 'Iron Sand Drizzle', 'earth', 'ninjutsu', 'A', 'multi'],
  ['gold-dust-wave', 'Gold Dust Wave', 'earth', 'ninjutsu', 'B', 'control', 'snare'],

  // Dust Release
  ['detachment-of-primitive-world', 'Detachment of the Primitive World', null, 'ninjutsu', 'S', 'nuke'],

  // Shikotsumyaku
  ['dance-of-the-camellia', 'Dance of the Camellia', null, 'taijutsu', 'C', 'strike'],
  ['dance-of-the-willow', 'Dance of the Willow', null, 'taijutsu', 'B', 'multi'],
  ['dead-bone-pulse', 'Dead Bone Pulse', null, 'taijutsu', 'A', 'pierce'],

  // Nara
  ['shadow-possession-jutsu', 'Shadow Possession Jutsu', 'yin', 'genjutsu', 'C', 'control', 'bind'],
  ['shadow-strangle', 'Shadow Strangle', 'yin', 'genjutsu', 'B', 'dot', 'bleed'],

  // Yamanaka
  ['mind-transfer-jutsu', 'Mind Transfer Jutsu', 'yin', 'genjutsu', 'B', 'control', 'illusionlock'],
  ['mind-body-disturbance', 'Mind Body Disturbance', 'yin', 'genjutsu', 'C', 'debuff', 'daze'],

  // Akimichi
  ['expansion-jutsu', 'Expansion Jutsu', null, 'taijutsu', 'C', 'buff', 'strength'],
  ['human-boulder', 'Human Boulder', null, 'taijutsu', 'B', 'multi'],

  // Aburame
  ['insect-swarm', 'Insect Swarm', null, 'ninjutsu', 'C', 'dot', 'poison'],
  ['chakra-drain-insects', 'Chakra Drain Insects', null, 'ninjutsu', 'B', 'chakra'],

  // Inuzuka
  ['fang-over-fang', 'Fang Over Fang', null, 'taijutsu', 'B', 'multi'],
  ['beast-human-clone', 'Beast Human Clone', null, 'ninjutsu', 'C', 'clone', 2],

  // Sand manipulation
  ['sand-coffin', 'Sand Coffin', 'earth', 'ninjutsu', 'B', 'control', 'bind'],
  ['sand-shield', 'Sand Shield', 'earth', 'ninjutsu', 'C', 'shield'],
  ['sand-burial', 'Sand Burial', 'earth', 'ninjutsu', 'S', 'nuke'],

  // Uzumaki
  ['adamantine-sealing-chains', 'Adamantine Sealing Chains', null, 'ninjutsu', 'A', 'control', 'bind'],

  // Signature spiralling-chakra line
  ['rasengan', 'Rasengan', null, 'ninjutsu', 'A', 'strike'],
  ['big-ball-rasengan', 'Big Ball Rasengan', null, 'ninjutsu', 'S', 'nuke'],
  ['raikiri', 'Raikiri', 'lightning', 'ninjutsu', 'S', 'pierce'],

  // Combo setup lines (see data/combos.json)
  ['toad-oil-bullet', 'Toad Oil Bullet', null, 'ninjutsu', 'C', 'oil'],
  ['oil-slick-seal', 'Oil Slick Seal', null, 'ninjutsu', 'D', 'oil'],
  ['sage-mode', 'Sage Mode', null, 'ninjutsu', 'C', 'natural'],
];

const jutsu = SPECS.map(build);

const ids = new Set<string>();
for (const j of jutsu) {
  if (ids.has(j.id)) throw new Error(`duplicate jutsu id: ${j.id}`);
  ids.add(j.id);
}

const here = dirname(fileURLToPath(import.meta.url));
writeFileSync(join(here, '..', 'data', 'jutsu.json'), JSON.stringify(jutsu, null, 2) + '\n');
// eslint-disable-next-line no-console
console.log(`wrote ${jutsu.length} jutsu`);
