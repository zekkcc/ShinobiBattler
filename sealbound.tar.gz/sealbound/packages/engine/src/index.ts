import { TUNING, getBloodline } from '@shinobi/content';
import type { FighterState, MatchState, Nature, StatKey, Stats, SubmittedAction } from '@shinobi/shared';
import { STAT_KEYS } from '@shinobi/shared';
import { maxEnergyFor, maxHpFor, primaryDisciplineFor, startingEnergyFor } from './derive.js';

export { resolveTurn } from './resolve.js';

/**
 * Stamps every action with the authenticated sender and drops anything
 * addressed to a body that sender does not own. apps/server calls this on the
 * WebSocket boundary; resolveTurn then enforces it a second time.
 */
export function sanitizeActions(
  state: MatchState,
  senderFighterId: string,
  actions: SubmittedAction[],
): SubmittedAction[] {
  const self = state.fighters.find((f) => f.id === senderFighterId);
  if (!self) return [];
  const ownBodies = new Set<string>([self.id, ...self.clones.map((c) => c.id)]);
  /* Rebuild each action from known fields only. Spreading the client's object
     would carry attacker-controlled junk (claimed damage, rolls, cooldowns) into
     the action log and the stored replay — the engine ignores it, but nothing
     downstream should ever see it. */
  return actions
    .filter((a) => ownBodies.has(a.fighterId))
    .map((a) => ({
      fighterId: a.fighterId,
      actionId: a.actionId,
      targetId: a.targetId,
      submittedBy: senderFighterId,
    }));
}
export { makeRng, type Rng } from './rng.js';
export {
  defenseAgainst, effStat, energyRegenFor, guardOf, maxEnergyFor, maxHpFor,
  primaryDisciplineFor, sealAccuracy, sealsPerTurn, startingEnergyFor, wardOf,
} from './derive.js';
export { computeDamage, disciplineMultiplier, natureMultiplier } from './damage.js';

export interface FighterSpec {
  id: string;
  name: string;
  level: number;
  stats: Stats;
  affinity: Nature;
  loadout: string[];
  /** kekkei genkai or clan trait; passives are baked in at construction */
  bloodlineId?: string | null;
}

export function createFighter(spec: FighterSpec): FighterState {
  const bloodline = spec.bloodlineId ? getBloodline(spec.bloodlineId) : undefined;

  /* Bloodline passives are baked into the stat line rather than applied as
     timed modifiers: they are innate, so dispel must not be able to strip them. */
  const stats: Stats = { ...spec.stats };
  if (bloodline) {
    for (const [key, mult] of Object.entries(bloodline.statMults)) {
      const k = key as keyof Stats;
      stats[k] = Math.max(1, Math.round(stats[k] * mult));
    }
  }

  const maxHp = maxHpFor(stats, spec.level);
  const maxChakra = maxEnergyFor(stats);
  return {
    id: spec.id,
    name: spec.name,
    level: spec.level,
    stats,
    affinity: spec.affinity,
    primaryDiscipline: primaryDisciplineFor(stats),
    hp: maxHp,
    maxHp,
    chakra: startingEnergyFor(stats),
    maxChakra,
    loadout: [...spec.loadout],
    bloodlineId: bloodline?.id ?? null,
    granted: bloodline ? [...bloodline.grants] : [],
    sealBonus: bloodline?.sealsPerTurnBonus ?? 0,
    cooldowns: {},
    statuses: [],
    modifiers: [],
    shields: [],
    clones: [],
    weave: null,
    pending: [],
    substitutions: TUNING.substitution.startCharges + (bloodline?.extraSubstitutions ?? 0),
    gateTier: 0,
    stance: 'none',
    controlImmunity: 0,
    reflect: null,
    skillLedger: {},
    defeated: false,
  };
}

export function createMatch(matchId: string, seed: string, a: FighterSpec, b: FighterSpec): MatchState {
  return {
    matchId,
    seed,
    round: 1,
    timeMs: 0,
    phase: 'awaitingActions',
    suddenDeath: false,
    fighters: [createFighter(a), createFighter(b)],
    winnerId: null,
    outcome: 'pending',
  };
}

/* ── PvP skill gain ──────────────────────────────────────────────────── */

export interface SkillAward { fighterId: string; gains: Partial<Record<StatKey, number>>; total: number }

/**
 * Settles the in-match skill ledger into stat gains.
 *
 * Pure: takes a finished MatchState, returns awards. The server writes them.
 * The ledger accrues from what a fighter actually *did* — chakra spent, damage
 * dealt, damage absorbed — so a stalled or conceded match pays almost nothing.
 */
export function settleSkillGain(state: MatchState): SkillAward[] {
  const cfg = TUNING.skillGain;
  const [a, b] = state.fighters;
  const roundsPlayed = Math.max(1, state.round - 1);
  const roundFactor = Math.min(1, roundsPlayed / cfg.minRoundsForFullCredit);

  return state.fighters.map((f) => {
    const other = f.id === a.id ? b : a;
    const won = state.winnerId === f.id;
    const outcomeMult = won ? cfg.winBonus : cfg.lossBonus;

    // Beating someone far above you pays more; farming someone far below pays less.
    const levelDelta = other.level - f.level;
    const levelMult = clamp(1 + levelDelta / cfg.levelDifferenceSoftCap, 0.25, 1.75);

    const gains: Partial<Record<StatKey, number>> = {};
    let total = 0;
    for (const key of STAT_KEYS) {
      const raw = (f.skillLedger[key] ?? 0) * outcomeMult * levelMult * roundFactor;
      const capped = Math.min(cfg.maxPerStatPerMatch, round2(raw));
      if (capped > 0) { gains[key] = capped; total += capped; }
    }

    if (total > cfg.maxTotalPerMatch) {
      const scale = cfg.maxTotalPerMatch / total;
      total = 0;
      for (const key of Object.keys(gains) as StatKey[]) {
        const v = round2((gains[key] ?? 0) * scale);
        gains[key] = v;
        total += v;
      }
    }

    return { fighterId: f.id, gains, total: round2(total) };
  });
}

const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));
const round2 = (v: number) => Math.round(v * 100) / 100;
