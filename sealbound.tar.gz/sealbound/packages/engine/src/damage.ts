import { DISCIPLINE_CYCLE, NATURE_CYCLE, STATUS_BY_ID, TUNING } from '@shinobi/content';
import type { Discipline, FighterState, MatchEvent, Nature, StatusId } from '@shinobi/shared';
import { defenseAgainst, effStat, incomingMultOf, outgoingMultOf } from './derive.js';
import type { Rng } from './rng.js';

/** fire → wind → lightning → earth → water → fire. yin/yang sit off-cycle. */
export function natureMultiplier(attack: Nature | null, defend: Nature): number {
  if (attack === null) return 1;
  if (attack === 'yin' || attack === 'yang') return 1;
  if (defend === 'yin' || defend === 'yang') return 1;
  if (NATURE_CYCLE[attack] === defend) return TUNING.natureAdvantage;
  if (NATURE_CYCLE[defend] === attack) return TUNING.natureDisadvantage;
  return 1;
}

/** taijutsu → genjutsu → ninjutsu → taijutsu, applied after the nature multiplier. */
export function disciplineMultiplier(attack: Discipline, defend: Discipline): number {
  if (DISCIPLINE_CYCLE[attack] === defend) return TUNING.disciplineAdvantage;
  if (DISCIPLINE_CYCLE[defend] === attack) return TUNING.disciplineDisadvantage;
  return 1;
}

function natureStatusMultOf(target: FighterState, nature: Nature | null): number {
  if (nature === null) return 1;
  let m = 1;
  for (const s of target.statuses) {
    const def = STATUS_BY_ID.get(s.status);
    const v = def?.incomingNatureMult?.[nature];
    if (v !== undefined) m *= v;
  }
  return m;
}

/** Injuries land on heavy hits and outlast the exchange that caused them. */
export const INJURIES: StatusId[] = ['broken-arm', 'leg-injury', 'eye-injury'];

export function maybeInjure(defender: FighterState, toHp: number, rng: Rng): StatusId | null {
  const cfg = TUNING.injuries;
  if (toHp < defender.maxHp * cfg.heavyHitFraction) return null;
  if (!rng.chance(cfg.chanceOnHeavyHit)) return null;
  const pick = INJURIES[rng.int(INJURIES.length)]!;
  if (defender.statuses.some((s) => s.status === pick)) return null;
  defender.statuses.push({ status: pick, remaining: cfg.duration, potency: 0 });
  return pick;
}

export interface DamageSpec {
  power: number;
  scalingValue: number;
  nature: Nature | null;
  discipline: Discipline;
  pierce: number;
  bonusMult: number;
}

/** Raw → mitigated. Ratio mitigation `K / (K + defense)`; no hard floor, no cap. */
export function computeDamage(
  attacker: FighterState,
  defender: FighterState,
  spec: DamageSpec,
  suddenDeath: boolean,
): { amount: number; natureMult: number; disciplineMult: number } {
  const base = spec.power * (1 + spec.scalingValue / 100);

  const natureMult = natureMultiplier(spec.nature, defender.affinity);
  const disciplineMult = disciplineMultiplier(spec.discipline, defender.primaryDiscipline);

  let raw = base
    * natureMult
    * disciplineMult
    * outgoingMultOf(attacker)
    * incomingMultOf(defender)
    * natureStatusMultOf(defender, spec.nature)
    * spec.bonusMult;

  if (suddenDeath) raw *= TUNING.suddenDeathDamageMultiplier;

  const pierce = Math.max(0, Math.min(1, spec.pierce));
  const defense = defenseAgainst(defender, spec.discipline) * (1 - pierce);
  const mitigated = raw * (TUNING.mitigationK / (TUNING.mitigationK + defense));

  return { amount: Math.max(0, Math.round(mitigated)), natureMult, disciplineMult };
}

export interface ApplyDamageResult {
  /** damage that reached HP */
  toHp: number;
  /** damage soaked by shields */
  shielded: number;
  /** clone that ate the hit, if any */
  cloneId: string | null;
  /** true if a substitution nullified the hit */
  substituted: boolean;
  events: MatchEvent[];
}

/**
 * Absorption chain, in order:
 *   substitution → clone body → shields → HP
 *
 * Substitution is checked first because it is a dodge, not a soak: the hit never
 * lands, so it should not consume a clone body.
 */
export function applyDamage(
  attacker: FighterState,
  defender: FighterState,
  amountIn: number,
  meta: { natureMult: number; disciplineMult: number },
  rng: Rng,
): ApplyDamageResult {
  const events: MatchEvent[] = [];
  let amount = amountIn;
  if (amount <= 0) {
    return { toHp: 0, shielded: 0, cloneId: null, substituted: false, events };
  }

  /* ── Substitution ──────────────────────────────────────────────────
     Substitution is a declared move, not a passive safety net: the defender must
     have spent their action on the Substitute stance this round. That is a direct
     override of the earlier auto-trigger design — see docs/OVERRIDES.md #2. */
  const sub = TUNING.substitution;
  const threshold = defender.maxHp * sub.damageThresholdFraction;
  if (defender.stance === 'substitute' && amount >= threshold && defender.substitutions > 0) {
    const atkSpeed = effStat(attacker, 'speed');
    const defSpeed = effStat(defender, 'speed');
    const ratio = defSpeed / (defSpeed + atkSpeed);
    const chance = Math.max(
      sub.minChance,
      Math.min(sub.maxChance, TUNING.stances.substituteBaseChance + (ratio - 0.5) * 2 * sub.speedWeight),
    );
    /* The charge is spent only when the swap actually lands (QA probe X5). */
    const success = rng.chance(chance);
    if (success) defender.substitutions -= 1;
    events.push({ t: 'substitution', fighterId: defender.id, success, remaining: defender.substitutions });
    if (success) {
      return { toHp: 0, shielded: 0, cloneId: null, substituted: true, events };
    }
  }

  /* ── Counter stance blocks part of the hit ──────────────────────────
     Reflect alone never justified the turn it cost: returning a fraction of a
     hit you still took is strictly worse than attacking. Counter now prevents
     damage as well, which is what makes reading an incoming attack pay. */
  if (defender.stance === 'counter') {
    const blocked = Math.round(amount * TUNING.stances.counterReduction);
    if (blocked > 0) {
      amount -= blocked;
      events.push({ t: 'counter', fighterId: defender.id, blocked });
    }
  }

  // ── Clone body absorbs one qualifying hit ───────────────────────────
  if (defender.clones.length > 0) {
    const clone = defender.clones.shift()!;
    // Chakra held by a destroyed clone is lost (tuning.clones.returnChakraOnDeath).
    if (TUNING.clones.returnChakraOnDeath) {
      for (const pool of ['physical', 'mental', 'natural'] as const) {
        defender.chakra[pool] = Math.min(defender.maxChakra[pool], defender.chakra[pool] + clone.chakra[pool]);
      }
    }
    events.push({ t: 'cloneDestroyed', fighterId: defender.id, cloneId: clone.id });
    return { toHp: 0, shielded: 0, cloneId: clone.id, substituted: false, events };
  }

  // ── Shields ─────────────────────────────────────────────────────────
  let remaining = amount;
  let shielded = 0;
  while (remaining > 0 && defender.shields.length > 0) {
    const s = defender.shields[0]!;
    const soak = Math.min(s.amount, remaining);
    s.amount -= soak;
    remaining -= soak;
    shielded += soak;
    if (s.amount <= 0) defender.shields.shift();
  }

  // ── HP ──────────────────────────────────────────────────────────────
  const toHp = Math.min(defender.hp, remaining);
  defender.hp -= toHp;

  events.push({
    t: 'damage',
    sourceId: attacker.id,
    targetId: defender.id,
    amount: toHp + shielded,
    natureMult: meta.natureMult,
    disciplineMult: meta.disciplineMult,
    shielded,
    cloneId: null,
  });

  return { toHp, shielded, cloneId: null, substituted: false, events };
}
