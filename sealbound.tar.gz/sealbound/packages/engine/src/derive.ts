import { STATUS_BY_ID, TUNING } from '@shinobi/content';
import type { Discipline, Energy, FighterState, Stats, StatKey } from '@shinobi/shared';

export function maxHpFor(stats: Stats, level: number): number {
  const { base, perStamina, perLevel } = TUNING.hp;
  return Math.round(base + stats.stamina * perStamina + level * perLevel);
}

/**
 * Three reserves, not one pool. Physical energy comes from the body, mental from
 * the mind, and natural energy has no natural ceiling contribution from either —
 * it is gathered from the world and never regenerates on its own.
 */
export function maxEnergyFor(stats: Stats): Energy {
  const e = TUNING.energy;
  return {
    physical: Math.round(e.physical.base + stats.stamina * e.physical.perStamina + stats.strength * e.physical.perStrength),
    mental: Math.round(e.mental.base + stats.intelligence * e.mental.perIntelligence + stats.stamina * e.mental.perStamina),
    natural: Math.round(e.natural.base + stats.intelligence * e.natural.perIntelligence + stats.stamina * e.natural.perStamina),
  };
}

/** Starting reserves: physical and mental full, natural empty — it must be gathered. */
export function startingEnergyFor(stats: Stats): Energy {
  const max = maxEnergyFor(stats);
  return { physical: max.physical, mental: max.mental, natural: 0 };
}

export function energyRegenFor(stats: Stats): Energy {
  const e = TUNING.energy;
  return {
    physical: Math.round(e.physical.regenBase + stats.stamina * e.physical.regenPerStamina),
    mental: Math.round(e.mental.regenBase + stats.stamina * e.mental.regenPerStamina),
    natural: Math.round(e.natural.regenBase + stats.stamina * e.natural.regenPerStamina),
  };
}

/**
 * Chance that a hand-seal sequence is performed cleanly. Fast, practised hands
 * beat difficult seals; an eye injury makes every sequence unreliable.
 */
export function sealAccuracy(f: FighterState, difficulty: number): number {
  const a = TUNING.sealAccuracy;
  let p = a.base + effStat(f, 'handSeals') * a.perHandSeals + difficulty * a.perDifficulty;
  for (const st of f.statuses) {
    const mult = STATUS_BY_ID.get(st.status)?.accuracyMult;
    if (mult !== undefined) p *= mult;
  }
  return Math.max(a.min, Math.min(a.max, p));
}

/** Highest of the three discipline stats; ties broken by a fixed order so it stays deterministic. */
export function primaryDisciplineFor(stats: Stats): Discipline {
  const order: Discipline[] = ['taijutsu', 'genjutsu', 'ninjutsu'];
  let best = order[0]!;
  for (const d of order) if (stats[d] > stats[best]) best = d;
  return best;
}

/**
 * Seals resolved per turn. Deliberately NOT floored: an integer rate turns this
 * into a step function, and crossing a threshold then doubles a caster's
 * throughput. That cliff made Hand Seals a super-stat — whoever sat just above
 * the step got double value for one point of investment.
 */
export function sealsPerTurn(handSeals: number, bonus = 0): number {
  const { base, perHandSeals, max } = TUNING.sealsPerTurn;
  return Math.max(1, Math.min(max + bonus, base + handSeals * perHandSeals + bonus));
}

/**
 * Effective value of a stat after modifiers, status stat-multipliers, and gates.
 * Pure: reads the fighter, writes nothing.
 */
export function effStat(f: FighterState, key: StatKey): number {
  let v = f.stats[key];

  for (const m of f.modifiers) if (m.stat === key) v *= m.mult;

  for (const s of f.statuses) {
    const def = STATUS_BY_ID.get(s.status);
    const mult = def?.statMults?.[key];
    if (mult !== undefined) v *= mult;
  }

  if (f.gateTier > 0) {
    const gate = TUNING.gates[f.gateTier - 1];
    if (gate) {
      if (key === 'strength') v *= gate.strengthMult;
      if (key === 'speed') v *= gate.speedMult;
    }
  }

  return Math.max(1, v);
}

/** Physical defense — used against taijutsu. */
export function guardOf(f: FighterState): number {
  const g = TUNING.guard;
  let d = g.base + effStat(f, 'taijutsu') * g.perTaijutsu + effStat(f, 'speed') * g.perSpeed + effStat(f, 'stamina') * g.perStamina;
  d *= defenseMultOf(f);
  return Math.max(1, d);
}

/** Chakra defense — used against ninjutsu and genjutsu. */
export function wardOf(f: FighterState): number {
  const w = TUNING.ward;
  let d = w.base + effStat(f, 'intelligence') * w.perIntelligence + effStat(f, 'speed') * w.perSpeed + effStat(f, 'stamina') * w.perStamina;
  d *= defenseMultOf(f);
  return Math.max(1, d);
}

function defenseMultOf(f: FighterState): number {
  let m = 1;
  for (const s of f.statuses) {
    const def = STATUS_BY_ID.get(s.status);
    if (def?.defenseMult !== undefined) m *= def.defenseMult;
  }
  return m;
}

export function defenseAgainst(f: FighterState, discipline: Discipline): number {
  return discipline === 'taijutsu' ? guardOf(f) : wardOf(f);
}

export function outgoingMultOf(f: FighterState): number {
  let m = 1;
  for (const s of f.statuses) {
    const def = STATUS_BY_ID.get(s.status);
    if (def?.outgoingMult !== undefined) m *= def.outgoingMult;
  }
  return m;
}

export function incomingMultOf(f: FighterState): number {
  let m = 1;
  for (const s of f.statuses) {
    const def = STATUS_BY_ID.get(s.status);
    if (def?.incomingMult !== undefined) m *= def.incomingMult;
  }
  return m;
}

export function hasStatus(f: FighterState, id: string): boolean {
  return f.statuses.some((s) => s.status === id);
}
