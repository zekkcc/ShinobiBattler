/**
 * Seeded, counter-based PRNG. The engine never calls Math.random (CLAUDE.md §4.1);
 * every roll comes from an Rng injected by the caller.
 *
 * Counter-based rather than state-chained so a replay can be resumed at any turn
 * by reconstructing (seed, cursor) instead of replaying every prior draw.
 */
export interface Rng {
  readonly seed: string;
  /** current draw index — part of the replay record */
  cursor: number;
  next(): number;
  int(maxExclusive: number): number;
  chance(p: number): boolean;
  fork(label: string): Rng;
}

/** FNV-1a over the seed string → 32-bit base. */
function hashSeed(seed: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

/** splitmix32 — fast, well-distributed, and pure given (base, counter). */
function splitmix32(base: number, counter: number): number {
  let z = (base + Math.imul(counter, 0x9e3779b9)) >>> 0;
  z = Math.imul(z ^ (z >>> 16), 0x21f0aaad) >>> 0;
  z = Math.imul(z ^ (z >>> 15), 0x735a2d97) >>> 0;
  z = (z ^ (z >>> 15)) >>> 0;
  return z;
}

export function makeRng(seed: string, cursor = 0): Rng {
  const base = hashSeed(seed);
  return {
    seed,
    cursor,
    next(): number {
      const v = splitmix32(base, this.cursor++);
      return v / 4294967296;
    },
    int(maxExclusive: number): number {
      if (!Number.isFinite(maxExclusive) || maxExclusive <= 0) return 0;
      return Math.floor(this.next() * maxExclusive) % maxExclusive;
    },
    chance(p: number): boolean {
      // Always consume a draw, even for degenerate probabilities, so that
      // changing a chance value never desynchronises an existing replay.
      const roll = this.next();
      if (p <= 0) return false;
      if (p >= 1) return true;
      return roll < p;
    },
    fork(label: string): Rng {
      return makeRng(`${seed}:${label}`, 0);
    },
  };
}
