import { COMBO_INDEX, STATUS_BY_ID, TUNING, getJutsu } from '@shinobi/content';
import type {
  CloneState, Effect, Energy, EnergyPool, FighterState, MatchEvent, MatchState, StatKey,
} from '@shinobi/shared';
import { applyDamage, computeDamage, maybeInjure } from './damage.js';
import { effStat } from './derive.js';
import type { Rng } from './rng.js';

export interface Ctx {
  state: MatchState;
  events: MatchEvent[];
  rng: Rng;
  /** monotonically increasing id source; derived from state so it stays deterministic */
  nextId: () => string;
}

export function opponentOf(state: MatchState, fighterId: string): FighterState {
  const [a, b] = state.fighters;
  return a.id === fighterId ? b : a;
}

export function fighterById(state: MatchState, fighterId: string): FighterState {
  const [a, b] = state.fighters;
  return a.id === fighterId ? a : b;
}

function creditSkill(f: FighterState, stat: StatKey, amount: number): void {
  if (amount <= 0) return;
  f.skillLedger[stat] = (f.skillLedger[stat] ?? 0) + amount;
}

/**
 * Applies one jutsu's effects. `bodyChakra` lets a clone pay from its own pool.
 * Returns total HP damage dealt so callers can drive interrupts and skill credit.
 */
export function applyEffects(
  ctx: Ctx,
  actor: FighterState,
  target: FighterState,
  effects: readonly Effect[],
  opts: { nature: Parameters<typeof computeDamage>[2]['nature']; discipline: Parameters<typeof computeDamage>[2]['discipline']; sourceMult?: number; comboDepth?: number },
): number {
  let hpDamageDealt = 0;
  for (const eff of effects) {
    hpDamageDealt += applyOne(ctx, actor, target, eff, opts);
    if (target.hp <= 0 || actor.hp <= 0) break;
  }
  return hpDamageDealt;
}

function applyOne(
  ctx: Ctx,
  actor: FighterState,
  target: FighterState,
  eff: Effect,
  opts: { nature: Parameters<typeof computeDamage>[2]['nature']; discipline: Parameters<typeof computeDamage>[2]['discipline']; sourceMult?: number; comboDepth?: number },
): number {
  const { state, events, rng } = ctx;

  switch (eff.kind) {
    case 'damage': {
      const hits = eff.hits ?? 1;
      let total = 0;
      for (let i = 0; i < hits; i++) {
        if (target.hp <= 0) break;
        let bonusMult = 1;
        if (eff.bonusVs && target.statuses.some((s) => s.status === eff.bonusVs!.status)) {
          bonusMult *= eff.bonusVs.mult;
        }
        const { amount, natureMult, disciplineMult } = computeDamage(
          actor, target,
          {
            power: eff.power,
            scalingValue: effStat(actor, eff.scaling),
            nature: opts.nature,
            discipline: opts.discipline,
            pierce: eff.pierce ?? 0,
            bonusMult: bonusMult * (opts.sourceMult ?? 1),
          },
          state.suddenDeath,
        );
        const res = applyDamage(actor, target, amount, { natureMult, disciplineMult }, rng);
        events.push(...res.events);
        total += res.toHp;

        if (res.toHp > 0 || res.shielded > 0) {
          onDamageLanded(ctx, actor, target, res.toHp + res.shielded, res.toHp);
          fireCombo(ctx, actor, target, opts);
        }
        if (res.toHp > 0) {
          const injury = maybeInjure(target, res.toHp, rng);
          if (injury) events.push({ t: 'injury', fighterId: target.id, status: injury });
        }
        if (eff.leech && res.toHp > 0) {
          const healed = Math.min(actor.maxHp - actor.hp, Math.round(res.toHp * eff.leech));
          if (healed > 0) {
            actor.hp += healed;
            events.push({ t: 'heal', fighterId: actor.id, amount: healed });
          }
        }
      }
      creditSkill(actor, opts.discipline === 'taijutsu' ? 'taijutsu' : opts.discipline === 'genjutsu' ? 'genjutsu' : 'ninjutsu', total / TUNING.skillGain.perDamageDealtDivisor);
      creditSkill(target, 'stamina', total / TUNING.skillGain.perDamageTakenDivisor);
      return total;
    }

    case 'heal': {
      const power = eff.power * (1 + effStat(actor, eff.scaling) / 100);
      const healed = Math.min(actor.maxHp - actor.hp, Math.round(power));
      if (healed > 0) {
        actor.hp += healed;
        events.push({ t: 'heal', fighterId: actor.id, amount: healed });
      }
      return 0;
    }

    case 'chakraDelta': {
      const who = eff.target === 'self' ? actor : target;
      const pools: EnergyPool[] = eff.pool === 'all' ? ['physical', 'mental'] : [eff.pool];
      for (const pool of pools) {
        const before = who.chakra[pool];
        who.chakra[pool] = Math.max(0, Math.min(who.maxChakra[pool], before + eff.amount));
        const delta = who.chakra[pool] - before;
        if (delta !== 0) events.push({ t: 'chakra', fighterId: who.id, pool, delta });
      }
      return 0;
    }

    case 'applyStatus': {
      const who = eff.target === 'self' ? actor : target;
      const def0 = STATUS_BY_ID.get(eff.status);
      const isHardControl = def0?.tags.includes('hard') ?? false;
      // Diminishing returns: you cannot be chain-locked out of the match.
      if (isHardControl && eff.target === 'opponent' && who.controlImmunity > 0) {
        events.push({ t: 'status', fighterId: who.id, status: eff.status, applied: false, duration: 0 });
        return 0;
      }
      const chance = eff.chance ?? 1;
      const applied = rng.chance(chance);
      events.push({ t: 'status', fighterId: who.id, status: eff.status, applied, duration: eff.duration });
      if (!applied) return 0;

      const def = STATUS_BY_ID.get(eff.status);
      const existing = who.statuses.find((s) => s.status === eff.status);
      if (existing) {
        existing.remaining = Math.max(existing.remaining, eff.duration);
        existing.potency = Math.max(existing.potency, eff.potency ?? 0);
      } else {
        who.statuses.push({ status: eff.status, remaining: eff.duration, potency: eff.potency ?? 0 });
      }
      // A stun cancels a weave in progress (CLAUDE.md §7).
      if (def?.breaksWeave) breakWeave(ctx, who, 'stun');
      return 0;
    }

    case 'cleanseStatus': {
      const who = eff.target === 'self' ? actor : target;
      const wanted = eff.statuses;
      const limit = eff.count ?? 99;
      const removed: typeof who.statuses[number]['status'][] = [];
      const kept: typeof who.statuses = [];
      for (const s of who.statuses) {
        const matches = wanted ? wanted.includes(s.status) : true;
        // Self-cleanse never strips the caster's own buffs.
        const isBuff = STATUS_BY_ID.get(s.status)?.tags.includes('buff') ?? false;
        if (matches && removed.length < limit && !(eff.target === 'self' && isBuff)) {
          removed.push(s.status);
        } else {
          kept.push(s);
        }
      }
      who.statuses = kept;
      if (removed.length) events.push({ t: 'cleanse', fighterId: who.id, removed });
      return 0;
    }

    case 'statModifier': {
      const who = eff.target === 'self' ? actor : target;
      const existing = who.modifiers.find((m) => m.stat === eff.stat && m.source === 'jutsu' && m.mult === eff.mult);
      if (existing) {
        // Refresh rather than stack: prevents an unbounded self-buff loop.
        existing.remaining = Math.max(existing.remaining, eff.duration);
      } else {
        who.modifiers.push({ stat: eff.stat, mult: eff.mult, remaining: eff.duration, source: 'jutsu' });
      }
      events.push({ t: 'modifier', fighterId: who.id, stat: eff.stat, mult: eff.mult, duration: eff.duration });
      return 0;
    }

    case 'shield': {
      const amount = Math.round(eff.power * (1 + effStat(actor, eff.scaling) / 100));
      actor.shields.push({ amount, remaining: eff.duration });
      events.push({ t: 'shield', fighterId: actor.id, amount });
      return 0;
    }

    case 'cloneSplit': {
      const room = TUNING.clones.maxActive - actor.clones.length;
      const count = Math.max(0, Math.min(eff.count, room));
      if (count === 0) return 0;
      // The caster's current chakra is divided evenly across caster + clones.
      const each: Energy = { physical: 0, mental: 0, natural: 0 };
      for (const pool of ['physical', 'mental', 'natural'] as const) {
        each[pool] = Math.floor(actor.chakra[pool] / (count + 1));
        actor.chakra[pool] -= each[pool] * count;
      }
      for (let i = 0; i < count; i++) {
        const clone: CloneState = {
          id: ctx.nextId(),
          chakra: { ...each },
          remaining: eff.duration,
          weave: null,
          cooldowns: {},
        };
        actor.clones.push(clone);
      }
      events.push({ t: 'clonesSplit', fighterId: actor.id, count, chakraEach: each });
      return 0;
    }

    case 'substitutionCharge': {
      actor.substitutions = Math.max(0, Math.min(TUNING.substitution.startCharges, actor.substitutions + eff.amount));
      events.push({ t: 'substitution', fighterId: actor.id, success: true, remaining: actor.substitutions });
      return 0;
    }

    case 'gateOpen': {
      const tier = Math.max(actor.gateTier, Math.min(8, eff.tiers));
      actor.gateTier = tier;
      events.push({ t: 'gate', fighterId: actor.id, tier });
      creditSkill(actor, 'strength', 0.2);
      return 0;
    }

    case 'dispel': {
      const who = eff.target === 'self' ? actor : target;
      let clones = 0, buffs = 0, shields = 0;
      if (eff.clones) {
        clones = who.clones.length;
        if (TUNING.clones.returnChakraOnDispel) {
          for (const c of who.clones) {
            const back: Energy = { physical: 0, mental: 0, natural: 0 };
            for (const pool of ['physical', 'mental', 'natural'] as const) {
              back[pool] = Math.min(who.maxChakra[pool] - who.chakra[pool], c.chakra[pool]);
              who.chakra[pool] += back[pool];
            }
            events.push({ t: 'cloneRecalled', fighterId: who.id, cloneId: c.id, chakraReturned: back });
          }
        }
        who.clones = [];
      }
      if (eff.buffs) {
        const before = who.modifiers.length;
        who.modifiers = who.modifiers.filter((m) => m.mult < 1);
        buffs = before - who.modifiers.length;
        const beforeS = who.statuses.length;
        who.statuses = who.statuses.filter((s) => !(STATUS_BY_ID.get(s.status)?.tags.includes('buff') ?? false));
        buffs += beforeS - who.statuses.length;
      }
      if (eff.shields) {
        shields = who.shields.length;
        who.shields = [];
      }
      events.push({ t: 'dispel', fighterId: who.id, clones, buffs, shields });
      return 0;
    }

    case 'reflectStance': {
      actor.reflect = { fraction: eff.fraction, remaining: eff.duration };
      return 0;
    }

    case 'stance': {
      actor.stance = eff.stance;
      events.push({ t: 'stance', fighterId: actor.id, stance: eff.stance });
      if (eff.stance === 'counter') {
        actor.reflect = { fraction: TUNING.stances.counterFraction, remaining: 1 };
      }
      return 0;
    }

    case 'interrupt': {
      breakWeave(ctx, target, 'dispel');
      return 0;
    }

    case 'delayed': {
      const id = ctx.nextId();
      actor.pending.push({
        id, effects: eff.effects, remaining: eff.delay,
        ownerId: actor.id, targetId: target.id,
        nature: opts.nature, discipline: opts.discipline,
      });
      events.push({ t: 'delayedArmed', fighterId: actor.id, id, delay: eff.delay });
      return 0;
    }

    default: {
      const never: never = eff;
      throw new Error(`unhandled effect kind: ${JSON.stringify(never)}`);
    }
  }
}

/**
 * Setup status + payoff nature = combo (oil then fire, water then lightning).
 * Bounded by comboDepth so a combo's own damage cannot chain indefinitely.
 */
function fireCombo(
  ctx: Ctx, actor: FighterState, target: FighterState,
  opts: { nature: Parameters<typeof computeDamage>[2]['nature']; discipline: Parameters<typeof computeDamage>[2]['discipline']; sourceMult?: number; comboDepth?: number },
): void {
  if (opts.nature === null) return;
  if ((opts.comboDepth ?? 0) >= 1) return;
  for (const st of [...target.statuses]) {
    const combo = COMBO_INDEX.get(`${st.status}|${opts.nature}`);
    if (!combo) continue;
    if (combo.consumesSetup) target.statuses = target.statuses.filter((x) => x.status !== st.status);
    const before = target.hp;
    applyEffects(ctx, actor, target, combo.effects, {
      nature: opts.nature, discipline: opts.discipline,
      sourceMult: opts.sourceMult, comboDepth: (opts.comboDepth ?? 0) + 1,
    });
    ctx.events.push({ t: 'combo', fighterId: actor.id, targetId: target.id, comboId: combo.id, amount: before - target.hp });
    return; // at most one combo per landed hit
  }
}

/** Reflect, illusion break, and weave interrupt all key off "damage actually landed". */
function onDamageLanded(ctx: Ctx, attacker: FighterState, defender: FighterState, landed: number, toHp: number): void {
  const { events } = ctx;

  // Reflect a fraction back at the attacker. Reflected damage cannot itself reflect.
  if (defender.reflect && defender.reflect.remaining > 0 && landed > 0) {
    const back = Math.round(landed * defender.reflect.fraction);
    if (back > 0) {
      const dealt = Math.min(attacker.hp, back);
      attacker.hp -= dealt;
      events.push({ t: 'reflect', fighterId: defender.id, amount: dealt });
    }
  }

  if (toHp <= 0) return;

  // Illusions that break when the victim takes real damage.
  const survivors = defender.statuses.filter((s) => !(STATUS_BY_ID.get(s.status)?.breaksOnDamage ?? false));
  if (survivors.length !== defender.statuses.length) {
    for (const s of defender.statuses) {
      if (STATUS_BY_ID.get(s.status)?.breaksOnDamage) {
        events.push({ t: 'statusExpired', fighterId: defender.id, status: s.status });
      }
    }
    defender.statuses = survivors;
  }

  // Damage above the woven jutsu's interruptThreshold cancels it.
  if (defender.weave) {
    const j = getJutsu(defender.weave.jutsuId);
    if (j && toHp > j.interruptThreshold) breakWeave(ctx, defender, 'damage');
  }
  for (const clone of defender.clones) {
    if (!clone.weave) continue;
    const j = getJutsu(clone.weave.jutsuId);
    if (j && toHp > j.interruptThreshold) clone.weave = null;
  }
}

/** Cancels a weave and refunds half the chakra paid (CLAUDE.md §7). */
export function breakWeave(ctx: Ctx, f: FighterState, cause: 'damage' | 'stun' | 'dispel'): void {
  if (!f.weave) return;
  const jutsuId = f.weave.jutsuId;
  let refund = 0;
  for (const pool of ['physical', 'mental', 'natural'] as const) {
    const back = Math.floor(f.weave.chakraPaid[pool] / 2);
    const before = f.chakra[pool];
    f.chakra[pool] = Math.min(f.maxChakra[pool], before + back);
    refund += f.chakra[pool] - before;
  }
  f.weave = null;
  ctx.events.push({ t: 'weaveBroken', fighterId: f.id, jutsuId, refund, cause });
}
