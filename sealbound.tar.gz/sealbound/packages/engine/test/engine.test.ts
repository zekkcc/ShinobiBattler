import { describe, expect, it } from 'vitest';
import { BLOODLINES, JUTSU, TUNING, getBloodline, getJutsu, rollBloodline } from '@shinobi/content';
import type { Energy, MatchState, Stats, SubmittedAction } from '@shinobi/shared';
import {
  createFighter, createMatch, disciplineMultiplier, effStat, makeRng, natureMultiplier,
  resolveTurn, sanitizeActions, sealAccuracy, settleSkillGain, type FighterSpec,
} from '../src/index.js';

/* ── helpers ─────────────────────────────────────────────────────────── */

const baseStats = (over: Partial<Stats> = {}): Stats => ({
  ninjutsu: 50, taijutsu: 50, genjutsu: 50, intelligence: 50,
  strength: 50, speed: 50, stamina: 50, handSeals: 50, ...over,
});

const fighter = (id: string, over: Partial<FighterSpec> = {}): FighterSpec => ({
  id, name: id, level: 20, stats: baseStats(), affinity: 'fire',
  loadout: ['fireball-jutsu', 'basic-strike'], ...over,
});

function match(a: Partial<FighterSpec> = {}, b: Partial<FighterSpec> = {}, seed = 'test-seed'): MatchState {
  const s = createMatch('m1', seed, fighter('a', a), fighter('b', b));
  // Natural energy starts empty by design; pre-fill it here so that only the
  // tests specifically about gathering have to care.
  for (const f of s.fighters) f.chakra.natural = f.maxChakra.natural;
  return s;
}

const act = (fighterId: string, actionId: string, targetId: string): SubmittedAction =>
  ({ fighterId, actionId, targetId });

/** Hand Seals high enough that the accuracy roll effectively cannot fail. */
const SURE_HANDS = 500;

/**
 * Accuracy caps below 1, so ANY sealed cast can fumble on an unlucky seed. Tests
 * that are about some other mechanic shouldn't be hostage to that roll — this
 * retries across seeds until the technique actually goes off.
 */
function landCast(state: MatchState, actions: SubmittedAction[], seedBase = 'land') {
  for (let i = 0; i < 40; i++) {
    const r = resolveTurn(state, actions, makeRng(`${seedBase}-${i}`));
    if (!r.events.some((e) => e.t === 'sealFailed')) return r;
  }
  throw new Error('technique never landed across 40 seeds');
}

/** Total across all three reserves — most assertions only care about the sum. */
const totalEnergy = (e: { physical: number; mental: number; natural: number }) =>
  e.physical + e.mental + e.natural;

/** Fills every reserve to its cap, including natural (which never regenerates). */
function topUp(f: { chakra: Energy; maxChakra: Energy }): void {
  f.chakra = { ...f.maxChakra };
}

const costOf = (id: string) => {
  const j = getJutsu(id)!;
  return j.cost.physical + j.cost.mental + j.cost.natural;
};

function run(state: MatchState, actions: SubmittedAction[], seed = 'r') {
  return resolveTurn(state, actions, makeRng(seed));
}

/** Plays `rounds` rounds with both sides passing (no actions submitted). */
function idle(state: MatchState, rounds: number, seed = 'idle') {
  const rng = makeRng(seed);
  let s = state;
  for (let i = 0; i < rounds && s.phase !== 'complete'; i++) s = resolveTurn(s, [], rng).state;
  return s;
}

/* ── §4 Engine purity ────────────────────────────────────────────────── */

describe('engine purity (CLAUDE.md §4)', () => {
  it('does not mutate the state it is given', () => {
    const s = match();
    const snapshot = JSON.stringify(s);
    run(s, [act('a', 'fireball-jutsu', 'b')]);
    expect(JSON.stringify(s)).toBe(snapshot);
  });

  it('is deterministic: same seed and actions produce identical results', () => {
    const s = match();
    const actions = [act('a', 'fireball-jutsu', 'b'), act('b', 'basic-strike', 'a')];
    const r1 = resolveTurn(s, actions, makeRng('same'));
    const r2 = resolveTurn(s, actions, makeRng('same'));
    expect(JSON.stringify(r1.state)).toBe(JSON.stringify(r2.state));
    expect(JSON.stringify(r1.events)).toBe(JSON.stringify(r2.events));
  });

  it('a full match replays byte-identically from (seed, actions[])', () => {
    const play = () => {
      const rng = makeRng('replay-seed');
      let s = match({ loadout: ['phoenix-flower-jutsu', 'basic-strike'] }, { loadout: ['water-bullet', 'basic-strike'] });
      const log: string[] = [];
      for (let i = 0; i < 40 && s.phase !== 'complete'; i++) {
        const r = resolveTurn(s, [act('a', 'phoenix-flower-jutsu', 'b'), act('b', 'water-bullet', 'a')], rng);
        s = r.state;
        log.push(JSON.stringify(r.events));
      }
      return log.join('|') + JSON.stringify(s);
    };
    expect(play()).toBe(play());
  });

  it('different seeds diverge', () => {
    const s = match({ stats: baseStats({ speed: 50 }) }, { stats: baseStats({ speed: 50 }) });
    const a = resolveTurn(s, [], makeRng('seed-one'));
    const b = resolveTurn(s, [], makeRng('seed-two'));
    // speed tie is broken by rng, so the order event should eventually differ
    const oa = a.events.find((e) => e.t === 'order');
    const ob = b.events.find((e) => e.t === 'order');
    expect(oa).toBeDefined();
    expect(ob).toBeDefined();
  });
});

/* ── §7 Nature cycle ─────────────────────────────────────────────────── */

describe('nature cycle (CLAUDE.md §7)', () => {
  it('follows fire → wind → lightning → earth → water → fire at x1.5', () => {
    expect(natureMultiplier('fire', 'wind')).toBe(TUNING.natureAdvantage);
    expect(natureMultiplier('wind', 'lightning')).toBe(TUNING.natureAdvantage);
    expect(natureMultiplier('lightning', 'earth')).toBe(TUNING.natureAdvantage);
    expect(natureMultiplier('earth', 'water')).toBe(TUNING.natureAdvantage);
    expect(natureMultiplier('water', 'fire')).toBe(TUNING.natureAdvantage);
  });

  it('reverses to x0.66', () => {
    expect(natureMultiplier('wind', 'fire')).toBe(TUNING.natureDisadvantage);
    expect(natureMultiplier('fire', 'water')).toBe(TUNING.natureDisadvantage);
  });

  it('is neutral for unrelated pairs', () => {
    expect(natureMultiplier('fire', 'fire')).toBe(1);
    expect(natureMultiplier('fire', 'lightning')).toBe(1);
  });

  it('keeps yin and yang off-cycle in both directions', () => {
    for (const n of ['fire', 'wind', 'lightning', 'earth', 'water'] as const) {
      expect(natureMultiplier('yin', n)).toBe(1);
      expect(natureMultiplier('yang', n)).toBe(1);
      expect(natureMultiplier(n, 'yin')).toBe(1);
      expect(natureMultiplier(n, 'yang')).toBe(1);
    }
    expect(natureMultiplier('yin', 'yang')).toBe(1);
  });

  it('treats natureless techniques as neutral', () => {
    expect(natureMultiplier(null, 'water')).toBe(1);
  });

  it('actually changes damage in a live match', () => {
    // fire attacker vs wind defender should out-damage fire vs fire
    const adv = run(match({ affinity: 'fire' }, { affinity: 'wind' }), [act('a', 'fireball-jutsu', 'b')]);
    const neu = run(match({ affinity: 'fire' }, { affinity: 'fire' }), [act('a', 'fireball-jutsu', 'b')]);
    expect(adv.state.fighters[1].hp).toBeLessThan(neu.state.fighters[1].hp);
  });
});

/* ── §7 Discipline triangle ──────────────────────────────────────────── */

describe('discipline triangle (CLAUDE.md §7)', () => {
  it('follows taijutsu → genjutsu → ninjutsu → taijutsu', () => {
    expect(disciplineMultiplier('taijutsu', 'genjutsu')).toBe(TUNING.disciplineAdvantage);
    expect(disciplineMultiplier('genjutsu', 'ninjutsu')).toBe(TUNING.disciplineAdvantage);
    expect(disciplineMultiplier('ninjutsu', 'taijutsu')).toBe(TUNING.disciplineAdvantage);
    expect(disciplineMultiplier('genjutsu', 'taijutsu')).toBe(TUNING.disciplineDisadvantage);
    expect(disciplineMultiplier('taijutsu', 'taijutsu')).toBe(1);
  });
});

/* ── §7 Turn order ───────────────────────────────────────────────────── */

describe('turn order (CLAUDE.md §7)', () => {
  it('gives the first action to the higher effective Speed', () => {
    const s = match({ stats: baseStats({ speed: 90 }) }, { stats: baseStats({ speed: 40 }) });
    const r = run(s, []);
    const order = r.events.find((e) => e.t === 'order');
    expect(order && order.t === 'order' && order.first).toBe('a');
  });

  it('breaks exact ties with the seeded rng, not with fighter index', () => {
    const s = match({ stats: baseStats({ speed: 55 }) }, { stats: baseStats({ speed: 55 }) });
    const firsts = new Set<string>();
    for (const seed of ['s1', 's2', 's3', 's4', 's5', 's6', 's7', 's8']) {
      const r = resolveTurn(s, [], makeRng(seed));
      const o = r.events.find((e) => e.t === 'order');
      if (o && o.t === 'order') firsts.add(o.first);
    }
    expect(firsts.size).toBe(2);
  });

  it('respects speed modifiers from statuses', () => {
    const s = match({ stats: baseStats({ speed: 60 }) }, { stats: baseStats({ speed: 55 }) });
    s.fighters[0].statuses.push({ status: 'snare', remaining: 3, potency: 0 });
    expect(effStat(s.fighters[0], 'speed')).toBeLessThan(effStat(s.fighters[1], 'speed'));
  });
});

/* ── §7 Weaving ──────────────────────────────────────────────────────── */

describe('weaving (CLAUDE.md §7)', () => {
  // handSeals 1 makes the weave long; sealDifficulty is what makes it fumble, so
  // these tests use a technique with modest difficulty and retry-free assertions.
  const slow = {
    stats: baseStats({ handSeals: 1, ninjutsu: 120 }),
    loadout: ['great-flame-flower', 'basic-strike'],
  };

  it('occupies the caster for ceil(seals / sealsPerTurn) turns', () => {
    const j = getJutsu('great-flame-flower')!;
    const s = match(slow);
    const r = run(s, [act('a', 'great-flame-flower', 'b')]);
    const start = r.events.find((e) => e.t === 'weaveStart');
    expect(start && start.t === 'weaveStart' && start.turns).toBe(Math.ceil(j.seals / 1));
    expect(r.state.fighters[0].weave).not.toBeNull();
  });

  it('exposes remaining turns to the opponent in public state', () => {
    let s = run(match(slow), [act('a', 'great-flame-flower', 'b')]).state;
    const before = s.fighters[0].weave!.remaining;
    s = run(s, []).state;
    expect(s.fighters[0].weave!.remaining).toBe(before - 1);
  });

  it('fires the jutsu when the weave completes', () => {
    // Clumsy hands make the weave long AND make the accuracy roll unreliable, so
    // this retries: what it asserts is that a completed weave eventually casts.
    let s = match(slow);
    const rng = makeRng('weave');
    let fired = false;
    for (let i = 0; i < 60 && !fired && s.phase !== 'complete'; i++) {
      s.fighters[0].cooldowns = {};
      topUp(s.fighters[0]);
      const acts = s.fighters[0].weave ? [] : [act('a', 'great-flame-flower', 'b')];
      const r = resolveTurn(s, acts, rng);
      s = r.state;
      fired = r.events.some((e) => e.t === 'cast' && e.jutsuId === 'great-flame-flower');
    }
    expect(fired).toBe(true);
  });

  it('cancels on damage above interruptThreshold and refunds half the chakra', () => {
    let s = match(slow, { loadout: ['hidden-lotus', 'basic-strike'], stats: baseStats({ taijutsu: 120, speed: 99, handSeals: 200 }) });
    s = run(s, [act('a', 'great-flame-flower', 'b')]).state;
    const paid = s.fighters[0].weave!.chakraPaid;
    const chakraBefore = totalEnergy(s.fighters[0].chakra);
    const r = run(s, [act('b', 'hidden-lotus', 'a')], 'interrupt');
    const broken = r.events.find((e) => e.t === 'weaveBroken');
    expect(broken && broken.t === 'weaveBroken' && broken.cause).toBe('damage');
    expect(r.state.fighters[0].weave).toBeNull();
    expect(totalEnergy(r.state.fighters[0].chakra)).toBeGreaterThanOrEqual(chakraBefore + Math.floor(totalEnergy(paid) / 2) - 2);
  });

  it('does not cancel on damage below interruptThreshold', () => {
    let s = match(slow, { loadout: ['basic-strike'], stats: baseStats({ taijutsu: 1, strength: 1 }) });
    s = run(s, [act('a', 'great-flame-flower', 'b')]).state;
    const r = run(s, [act('b', 'basic-strike', 'a')], 'nointerrupt');
    expect(r.events.some((e) => e.t === 'weaveBroken')).toBe(false);
  });

  it('cancels on stun', () => {
    // The stunner needs reliable hands and no cooldown gating; the weaver needs a
    // weave long enough to still be in progress when the stun lands.
    // The weaver is bulky enough that the paralysis chip stays under
    // interruptThreshold — otherwise the weave breaks on damage first and this
    // test would silently stop exercising the stun path at all.
    let s = match(
      { ...slow, stats: baseStats({ handSeals: 1, ninjutsu: 120, stamina: 300, intelligence: 300 }) },
      { loadout: ['lightning-paralysis'], stats: baseStats({ handSeals: SURE_HANDS, ninjutsu: 38, speed: 200 }) },
    );
    const rng = makeRng('stun');
    let broke = false;
    for (let i = 0; i < 40 && !broke && s.phase !== 'complete'; i++) {
      s.fighters[1].cooldowns = {};
      s.fighters[1].controlImmunity = 0;
      topUp(s.fighters[1]);
      const acts = s.fighters[0].weave ? [] : [act('a', 'great-flame-flower', 'b')];
      const r = resolveTurn(s, [...acts, act('b', 'lightning-paralysis', 'a')], rng);
      expect(r.events.some((e) => e.t === 'weaveBroken' && e.cause === 'damage')).toBe(false);
      broke = r.events.some((e) => e.t === 'weaveBroken' && e.cause === 'stun');
      s = r.state;
      if (!s.fighters[0].weave) { s.fighters[0].cooldowns = {}; topUp(s.fighters[0]); }
    }
    expect(broke).toBe(true);
  });

  it('sealsPerTurn scales with the Hand Seals stat', () => {
    const fast = match({ stats: baseStats({ handSeals: 200 }), loadout: ['amaterasu'] });
    const r = run(fast, [act('a', 'great-flame-flower', 'b')]);
    const start = r.events.find((e) => e.t === 'weaveStart');
    // high hand seals should compress the weave below the slow-caster case
    expect(start === undefined || (start.t === 'weaveStart' && start.turns < 6)).toBe(true);
  });
});

/* ── §7 Chakra and overdraw ──────────────────────────────────────────── */

describe('chakra overdraw (CLAUDE.md §7)', () => {
  const heavy = { loadout: ['amaterasu'], stats: baseStats({ handSeals: SURE_HANDS, ninjutsu: 120 }) };

  it('permits spending past the reserves and applies exhaustion plus self-damage', () => {
    const s = match(heavy);
    s.fighters[0].chakra = { physical: 5, mental: 5, natural: s.fighters[0].maxChakra.natural };
    const r = run(s, [act('a', 'amaterasu', 'b')]);
    expect(r.events.find((e) => e.t === 'overdraw')).toBeDefined();
    expect(r.state.fighters[0].hp).toBeLessThan(s.fighters[0].hp);
    expect(r.state.fighters[0].statuses.some((x) => x.status === 'exhaustion')).toBe(true);
  });

  it('scales self-damage with the size of the overdraw', () => {
    const mk = (amount: number) => {
      const s = match(heavy);
      s.fighters[0].chakra = { physical: amount, mental: amount, natural: s.fighters[0].maxChakra.natural };
      const r = run(s, [act('a', 'amaterasu', 'b')]);
      return r.events.filter((e) => e.t === 'overdraw')
        .reduce((n, e) => n + (e.t === 'overdraw' ? e.selfDamage : 0), 0);
    };
    expect(mk(0)).toBeGreaterThan(mk(50));
  });

  it('never leaves any reserve negative', () => {
    const s = match(heavy);
    s.fighters[0].chakra = { physical: 3, mental: 3, natural: s.fighters[0].maxChakra.natural };
    const r = run(s, [act('a', 'amaterasu', 'b')]);
    for (const pool of ['physical', 'mental', 'natural'] as const) {
      expect(r.state.fighters[0].chakra[pool]).toBeGreaterThanOrEqual(0);
    }
  });

  it('refuses to cast when natural energy is short — it cannot be borrowed', () => {
    const s = match(heavy);
    s.fighters[0].chakra.natural = 0;
    const r = run(s, [act('a', 'amaterasu', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'noEnergy')).toBe(true);
    expect(r.events.some((e) => e.t === 'cast' || e.t === 'weaveStart')).toBe(false);
  });
});

/* ── Substitution: now a declared stance (docs/OVERRIDES.md #2) ──────── */

describe('substitution stance', () => {
  const striker = {
    loadout: ['hidden-lotus'],
    stats: baseStats({ taijutsu: 150, strength: 150, handSeals: SURE_HANDS, speed: 50 }),
  };

  it('does NOT trigger passively — the defender must declare the stance', () => {
    const s = match(striker, { stats: baseStats({ speed: 300 }) });
    const r = run(s, [act('a', 'hidden-lotus', 'b')], 'passive');
    expect(r.events.some((e) => e.t === 'substitution')).toBe(false);
  });

  it('triggers when the defender spends their action on Substitute that round', () => {
    const s = match(striker, { stats: baseStats({ speed: 300 }) });
    // Stances resolve before the exchange, so the slower fighter can still guard.
    const r = run(s, [act('b', 'substitute', 'b'), act('a', 'hidden-lotus', 'b')], 'declared');
    expect(r.events.some((e) => e.t === 'stance')).toBe(true);
    expect(r.events.some((e) => e.t === 'substitution')).toBe(true);
  });

  it('declaring a stance costs the fighter their action', () => {
    const s = match({ loadout: ['fireball-jutsu'], stats: baseStats({ handSeals: SURE_HANDS }) });
    const r = run(s, [act('a', 'substitute', 'a')]);
    expect(r.events.some((e) => e.t === 'cast' && e.fighterId === 'a')).toBe(false);
  });

  it('is a match resource: successful swaps deplete charges and do not refresh', () => {
    let s = match(striker, { stats: baseStats({ speed: 400 }) });
    const start = s.fighters[1].substitutions;
    const rng = makeRng('sub');
    for (let i = 0; i < 14 && s.phase !== 'complete'; i++) {
      s.fighters[0].cooldowns = {};
      s.fighters[1].stance = 'substitute';
      s = resolveTurn(s, [act('a', 'hidden-lotus', 'b')], rng).state;
    }
    expect(s.fighters[1].substitutions).toBeLessThan(start);
  });

  it('does not trigger on chip damage below the threshold', () => {
    const s = match({ loadout: ['basic-strike'], stats: baseStats({ taijutsu: 1, strength: 1 }) },
      { stats: baseStats({ stamina: 300 }) });
    s.fighters[1].stance = 'substitute';
    expect(run(s, [act('a', 'basic-strike', 'b')]).events.some((e) => e.t === 'substitution')).toBe(false);
  });

  it('success chance scales with Speed against the attacker', () => {
    const trial = (defSpeed: number) => {
      let hits = 0;
      for (let i = 0; i < 60; i++) {
        const s = match(striker, { stats: baseStats({ speed: defSpeed }) });
        s.fighters[1].stance = 'substitute';
        const r = resolveTurn(s, [act('a', 'hidden-lotus', 'b')], makeRng(`sp${i}`));
        const ev = r.events.find((e) => e.t === 'substitution');
        if (ev && ev.t === 'substitution' && ev.success) hits++;
      }
      return hits;
    };
    expect(trial(300)).toBeGreaterThan(trial(5));
  });

  it('the stance expires at the end of the round', () => {
    let s = match(striker);
    s = run(s, [act('b', 'substitute', 'b')]).state;
    expect(s.fighters[1].stance).toBe('none');
  });
});

/* ── §7 Clones ───────────────────────────────────────────────────────── */

describe('clones (CLAUDE.md §7 + project rule on chakra return)', () => {
  it('splits current chakra evenly across caster and clones', () => {
    const s = match({ loadout: ['shadow-clone-jutsu'], stats: baseStats({ handSeals: 200 }) });
    const before = totalEnergy(s.fighters[0].chakra);
    const cost = costOf('shadow-clone-jutsu');
    const r = landCast(s, [act('a', 'shadow-clone-jutsu', 'b')], 'split');
    const split = r.events.find((e) => e.t === 'clonesSplit');
    const f = r.state.fighters[0];
    expect(f.clones.length).toBe(2);
    const each = totalEnergy(f.clones[0]!.chakra);
    expect(f.clones.every((c) => totalEnergy(c.chakra) === each)).toBe(true);
    // every reserve is divided, not just one
    expect(f.clones[0]!.chakra.physical).toBeGreaterThan(0);
    expect(f.clones[0]!.chakra.mental).toBeGreaterThan(0);
    // caster keeps the remainder of an even 3-way split of the post-cost reserves
    expect(each * 3).toBeLessThanOrEqual(before - cost + 3);
  });

  it('each clone absorbs exactly one qualifying hit', () => {
    let s = match({ loadout: ['shadow-clone-jutsu'], stats: baseStats({ handSeals: 200, speed: 99 }) },
      { loadout: ['hidden-lotus'], stats: baseStats({ taijutsu: 120, speed: 10, handSeals: 200 }) });
    s = landCast(s, [act('a', 'shadow-clone-jutsu', 'b')], 'clone').state;
    expect(s.fighters[0].clones.length).toBe(2);
    s.fighters[0].substitutions = 0;
    const hpBefore = s.fighters[0].hp;
    const rng = makeRng('absorb');
    s = resolveTurn(s, [act('b', 'hidden-lotus', 'a')], rng).state;
    expect(s.fighters[0].clones.length).toBe(1);
    expect(s.fighters[0].hp).toBe(hpBefore);
  });

  it('returns chakra to the caster when an un-killed clone expires', () => {
    let s = match({ loadout: ['shadow-clone-jutsu'], stats: baseStats({ handSeals: 200 }) });
    s = landCast(s, [act('a', 'shadow-clone-jutsu', 'b')], 'clone').state;
    const held = s.fighters[0].clones.reduce((n, c) => n + totalEnergy(c.chakra), 0);
    expect(held).toBeGreaterThan(0);
    s.fighters[0].chakra = { physical: 0, mental: 0, natural: 0 };
    s.fighters[0].maxChakra = { physical: 9999, mental: 9999, natural: 9999 };
    const rng = makeRng('recall');
    let returned = 0;
    for (let i = 0; i < 10; i++) {
      const r = resolveTurn(s, [], rng);
      s = r.state;
      for (const e of r.events) if (e.t === 'cloneRecalled') returned += totalEnergy(e.chakraReturned);
      if (s.fighters[0].clones.length === 0) break;
    }
    expect(returned).toBe(held);
  });

  it('does NOT return chakra from a clone that was destroyed', () => {
    let s = match({ loadout: ['shadow-clone-jutsu'], stats: baseStats({ handSeals: 200, speed: 99 }) },
      { loadout: ['hidden-lotus'], stats: baseStats({ taijutsu: 120, speed: 10, handSeals: 200 }) });
    s = landCast(s, [act('a', 'shadow-clone-jutsu', 'b')], 'clone').state;
    s.fighters[0].maxChakra = { physical: 9999, mental: 9999, natural: 9999 };
    const chakraBefore = totalEnergy(s.fighters[0].chakra);
    const r = resolveTurn(s, [act('b', 'hidden-lotus', 'a')], makeRng('kill'));
    const recalled = r.events.filter((e) => e.t === 'cloneRecalled');
    expect(recalled.length).toBe(0);
    // only end-of-round regen should have moved the pool
    expect(totalEnergy(r.state.fighters[0].chakra) - chakraBefore).toBeLessThan(60);
  });

  it('clones can weave in parallel with their originator', () => {
    let s = match({ loadout: ['shadow-clone-jutsu', 'great-waterfall-technique'], stats: baseStats({ handSeals: 200, ninjutsu: 120 }) });
    s = landCast(s, [act('a', 'shadow-clone-jutsu', 'b')], 'clone').state;
    expect(s.fighters[0].clones.length).toBe(2);
    const cloneId = s.fighters[0].clones[0]!.id;
    s.fighters[0].clones[0]!.chakra = { physical: 500, mental: 500, natural: 500 };
    topUp(s.fighters[0]);
    const r = run(s, [act('a', 'great-waterfall-technique', 'b'), act(cloneId, 'great-waterfall-technique', 'b')]);
    expect(r.state.fighters[0].weave).not.toBeNull();
    expect(r.state.fighters[0].clones[0]!.weave).not.toBeNull();
  });

  it('never exceeds the configured maximum number of clone bodies', () => {
    let s = match({ loadout: ['multiple-shadow-clone-jutsu'], stats: baseStats({ handSeals: 200, ninjutsu: 200 }) });
    const rng = makeRng('cap');
    for (let i = 0; i < 8; i++) {
      topUp(s.fighters[0]);
      s.fighters[0].cooldowns = {};
      s = resolveTurn(s, [act('a', 'multiple-shadow-clone-jutsu', 'b')], rng).state;
    }
    expect(s.fighters[0].clones.length).toBeLessThanOrEqual(TUNING.clones.maxActive);
  });
});

/* ── §7 Gates ────────────────────────────────────────────────────────── */

describe('gates (CLAUDE.md §7)', () => {
  it('multiplies Strength and Speed by tier', () => {
    const s = match();
    const beforeStr = effStat(s.fighters[0], 'strength');
    const beforeSpd = effStat(s.fighters[0], 'speed');
    s.fighters[0].gateTier = 4;
    expect(effStat(s.fighters[0], 'strength')).toBeCloseTo(beforeStr * TUNING.gates[3]!.strengthMult, 5);
    expect(effStat(s.fighters[0], 'speed')).toBeCloseTo(beforeSpd * TUNING.gates[3]!.speedMult, 5);
  });

  it('drains escalating HP each round with tier', () => {
    const drainAt = (tier: number) => {
      const s = match();
      s.fighters[0].gateTier = tier;
      const r = run(s, []);
      const ev = r.events.find((e) => e.t === 'gateDrain');
      return ev && ev.t === 'gateDrain' ? ev.amount : 0;
    };
    expect(drainAt(1)).toBeLessThan(drainAt(4));
    expect(drainAt(4)).toBeLessThan(drainAt(8));
  });

  it('kills the user at tier 8 when the match ends', () => {
    const s = match();
    s.fighters[0].gateTier = 8;
    s.fighters[1].hp = 1;
    const r = run(s, [act('b', 'forfeit', 'a')]);
    expect(r.state.phase).toBe('complete');
    expect(r.events.some((e) => e.t === 'gateCollapse')).toBe(true);
    expect(r.state.fighters[0].defeated).toBe(true);
  });

  it('opening a lower tier does not downgrade an already-open higher tier', () => {
    let s = match({ loadout: ['gate-of-limit', 'gate-of-opening'], stats: baseStats({ taijutsu: 150, handSeals: 200 }) });
    s = run(s, [act('a', 'gate-of-limit', 'a')]).state;
    const tier = s.fighters[0].gateTier;
    s.fighters[0].cooldowns = {};
    s = run(s, [act('a', 'gate-of-opening', 'a')]).state;
    expect(s.fighters[0].gateTier).toBe(tier);
  });
});

/* ── Sudden death and match termination ──────────────────────────────── */

describe('sudden death and termination', () => {
  it('triggers at the configured round', () => {
    const s = match();
    s.round = TUNING.suddenDeathRound;
    const r = run(s, []);
    expect(r.state.suddenDeath).toBe(true);
    expect(r.events.some((e) => e.t === 'suddenDeath')).toBe(true);
  });

  it('does not trigger a round early', () => {
    const s = match();
    s.round = TUNING.suddenDeathRound - 1;
    expect(run(s, []).state.suddenDeath).toBe(false);
  });

  it('raises damage by exactly the configured multiplier', () => {
    const mk = (sudden: boolean) => {
      const s = match({ loadout: ['fireball-jutsu'] }, { stats: baseStats(), affinity: 'fire' });
      s.suddenDeath = sudden;
      s.round = sudden ? TUNING.suddenDeathRound + 1 : 2;
      s.fighters[1].substitutions = 0;
      const r = resolveTurn(s, [act('a', 'fireball-jutsu', 'b')], makeRng('sd'));
      const ev = r.events.find((e) => e.t === 'damage');
      return ev && ev.t === 'damage' ? ev.amount : 0;
    };
    const normal = mk(false);
    const sudden = mk(true);
    expect(sudden / normal).toBeCloseTo(TUNING.suddenDeathDamageMultiplier, 1);
  });

  it('announces sudden death only once', () => {
    let s = match();
    s.round = TUNING.suddenDeathRound;
    const rng = makeRng('once');
    let announcements = 0;
    for (let i = 0; i < 5 && s.phase !== 'complete'; i++) {
      const r = resolveTurn(s, [], rng);
      announcements += r.events.filter((e) => e.t === 'suddenDeath').length;
      s = r.state;
    }
    expect(announcements).toBe(1);
  });

  it('always terminates: two pure turtles cannot stall forever', () => {
    const turtle = { loadout: ['guard-stance', 'creation-rebirth'], stats: baseStats({ stamina: 200 }) };
    let s = match(turtle, turtle);
    const rng = makeRng('stall');
    let rounds = 0;
    while (s.phase !== 'complete' && rounds < TUNING.hardCapRound + 20) {
      s = resolveTurn(s, [act('a', 'guard-stance', 'a'), act('b', 'guard-stance', 'b')], rng).state;
      rounds++;
    }
    expect(s.phase).toBe('complete');
    expect(rounds).toBeLessThanOrEqual(TUNING.hardCapRound + 1);
  });

  it('is a no-op once the match is complete', () => {
    let s = match();
    s.fighters[1].hp = 1;
    s = run(s, [act('b', 'forfeit', 'a')]).state;
    expect(s.phase).toBe('complete');
    const r = run(s, [act('a', 'fireball-jutsu', 'b')]);
    expect(r.events).toHaveLength(0);
    expect(JSON.stringify(r.state)).toBe(JSON.stringify(s));
  });
});

/* ── Action legality (§5 trust model, engine side) ───────────────────── */

describe('action legality', () => {
  it('rejects a jutsu that is not in the loadout', () => {
    const r = run(match({ loadout: ['fireball-jutsu'] }), [act('a', 'great-waterfall-technique', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'notInLoadout')).toBe(true);
  });

  it('rejects an unknown action id', () => {
    const r = run(match(), [act('a', 'not-a-real-jutsu', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'unknownJutsu')).toBe(true);
  });

  it('rejects a jutsu still on cooldown', () => {
    let s = match({ loadout: ['phoenix-flower-jutsu'], stats: baseStats({ handSeals: 200 }) });
    s = run(s, [act('a', 'phoenix-flower-jutsu', 'b')]).state;
    const r = run(s, [act('a', 'phoenix-flower-jutsu', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'cooldown')).toBe(true);
  });

  it('rejects a jutsu whose stat requirement is unmet', () => {
    const s = match({ loadout: ['great-waterfall-technique'], stats: baseStats({ ninjutsu: 5, handSeals: 200 }) });
    const r = run(s, [act('a', 'great-waterfall-technique', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'requirement')).toBe(true);
  });

  it('blocks sealed jutsu while silenced but allows sealless ones', () => {
    const s = match({ loadout: ['phoenix-flower-jutsu', 'basic-strike'] });
    s.fighters[0].statuses.push({ status: 'silence', remaining: 3, potency: 0 });
    expect(run(s, [act('a', 'phoenix-flower-jutsu', 'b')]).events.some((e) => e.t === 'blocked' && e.reason === 'silenced')).toBe(true);
    expect(run(s, [act('a', 'basic-strike', 'b')]).events.some((e) => e.t === 'cast')).toBe(true);
  });

  it('ignores an action submitted for a fighter who is not in this match', () => {
    const r = run(match(), [act('ghost', 'fireball-jutsu', 'b')]);
    expect(r.events.some((e) => e.t === 'cast')).toBe(false);
  });

  it('allows baseline actions without a loadout slot', () => {
    const r = run(match({ loadout: [] }), [act('a', 'basic-strike', 'b')]);
    expect(r.events.some((e) => e.t === 'cast' && e.jutsuId === 'basic-strike')).toBe(true);
  });
});

/* ── Status behaviour ────────────────────────────────────────────────── */

describe('statuses', () => {
  it('damage-over-time ticks and expires on schedule', () => {
    let s = match();
    s.fighters[1].statuses.push({ status: 'burn', remaining: 3, potency: 0 });
    const rng = makeRng('dot');
    let ticks = 0;
    for (let i = 0; i < 6 && s.phase !== 'complete'; i++) {
      const r = resolveTurn(s, [], rng);
      ticks += r.events.filter((e) => e.t === 'statusTick' && e.status === 'burn').length;
      s = r.state;
    }
    expect(ticks).toBe(3);
    expect(s.fighters[1].statuses.some((x) => x.status === 'burn')).toBe(false);
  });

  it('reapplying a status refreshes rather than stacks', () => {
    const s = match();
    s.fighters[1].statuses.push({ status: 'burn', remaining: 1, potency: 0 });
    s.fighters[1].statuses.push({ status: 'burn', remaining: 1, potency: 0 });
    // engine path: applying through an effect must not create a second entry
    const s2 = match();
    s2.fighters[0].loadout = ['ash-pile-burning'];
    s2.fighters[0].stats.handSeals = 200;
    let cur = s2;
    const rng = makeRng('refresh');
    for (let i = 0; i < 4; i++) {
      cur.fighters[0].cooldowns = {};
      cur = resolveTurn(cur, [act('a', 'ash-pile-burning', 'b')], rng).state;
    }
    expect(cur.fighters[1].statuses.filter((x) => x.status === 'burn').length).toBeLessThanOrEqual(1);
  });

  it('illusion locks break when the victim takes real damage', () => {
    const s = match({ loadout: ['hidden-lotus'], stats: baseStats({ taijutsu: 150, speed: 99, handSeals: 200 }) });
    s.fighters[1].statuses.push({ status: 'illusionlock', remaining: 5, potency: 0 });
    s.fighters[1].substitutions = 0;
    const r = run(s, [act('a', 'hidden-lotus', 'b')], 'break');
    expect(r.state.fighters[1].statuses.some((x) => x.status === 'illusionlock')).toBe(false);
  });

  it('a hard control status costs the victim their action', () => {
    const s = match({ loadout: ['fireball-jutsu'] });
    s.fighters[0].statuses.push({ status: 'stun', remaining: 2, potency: 0 });
    const r = run(s, [act('a', 'fireball-jutsu', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'stunned')).toBe(true);
    expect(r.events.some((e) => e.t === 'cast')).toBe(false);
  });

  it('self-cleanse does not strip the caster own buffs', () => {
    const s = match({ loadout: ['poison-extraction'], stats: baseStats({ handSeals: 200 }) });
    s.fighters[0].statuses.push({ status: 'haste', remaining: 5, potency: 0 });
    s.fighters[0].statuses.push({ status: 'poison', remaining: 5, potency: 0 });
    const r = run(s, [act('a', 'poison-extraction', 'a')]);
    expect(r.state.fighters[0].statuses.some((x) => x.status === 'haste')).toBe(true);
    expect(r.state.fighters[0].statuses.some((x) => x.status === 'poison')).toBe(false);
  });
});

/* ── Shields, reflect, healing ───────────────────────────────────────── */

describe('mitigation layers', () => {
  it('shields absorb before HP', () => {
    let s = match({ loadout: ['hidden-lotus'], stats: baseStats({ taijutsu: 60, handSeals: 200 }) },
      { loadout: ['mud-wall'], stats: baseStats({ handSeals: 200, speed: 99 }) });
    s = run(s, [act('b', 'mud-wall', 'b')]).state;
    expect(s.fighters[1].shields.length).toBeGreaterThan(0);
    const hp = s.fighters[1].hp;
    s.fighters[1].substitutions = 0;
    const r = run(s, [act('a', 'hidden-lotus', 'b')], 'shield');
    const dmg = r.events.find((e) => e.t === 'damage');
    expect(dmg && dmg.t === 'damage' && dmg.shielded).toBeGreaterThan(0);
    expect(r.state.fighters[1].hp).toBeGreaterThanOrEqual(hp - (dmg && dmg.t === 'damage' ? dmg.amount : 0));
  });

  it('healing never exceeds max HP', () => {
    const s = match({ loadout: ['creation-rebirth'], stats: baseStats({ handSeals: 200, ninjutsu: 200, stamina: 200 }) });
    const r = run(s, [act('a', 'creation-rebirth', 'a')]);
    expect(r.state.fighters[0].hp).toBeLessThanOrEqual(r.state.fighters[0].maxHp);
  });

  it('reflect returns a fraction of damage to the attacker', () => {
    let s = match({ loadout: ['hidden-lotus'], stats: baseStats({ taijutsu: 150, speed: 1, handSeals: 200 }) },
      { loadout: ['counter-stance'], stats: baseStats({ handSeals: 200, speed: 99 }) });
    s = run(s, [act('b', 'counter-stance', 'b')]).state;
    s.fighters[1].substitutions = 0;
    s.fighters[1].reflect = { fraction: 0.5, remaining: 3 };
    const hpA = s.fighters[0].hp;
    const r = run(s, [act('a', 'hidden-lotus', 'b')], 'reflect');
    expect(r.events.some((e) => e.t === 'reflect')).toBe(true);
    expect(r.state.fighters[0].hp).toBeLessThan(hpA);
  });

  it('reflected damage cannot itself be reflected', () => {
    const s = match({ loadout: ['hidden-lotus'], stats: baseStats({ taijutsu: 150, handSeals: 200 }) });
    s.fighters[0].reflect = { fraction: 1, remaining: 3 };
    s.fighters[1].reflect = { fraction: 1, remaining: 3 };
    s.fighters[1].substitutions = 0;
    const r = run(s, [act('a', 'hidden-lotus', 'b')], 'noloop');
    expect(r.events.filter((e) => e.t === 'reflect').length).toBeLessThanOrEqual(1);
  });
});

/* ── PvP skill gain ──────────────────────────────────────────────────── */

describe('PvP skill gain', () => {
  it('accrues during a fight and settles into stat gains', () => {
    let s = match({ loadout: ['phoenix-flower-jutsu', 'basic-strike'], stats: baseStats({ handSeals: 200 }) },
      { loadout: ['water-bullet', 'basic-strike'], stats: baseStats({ handSeals: 200 }) });
    const rng = makeRng('skill');
    for (let i = 0; i < 25 && s.phase !== 'complete'; i++) {
      s = resolveTurn(s, [act('a', 'basic-strike', 'b'), act('b', 'basic-strike', 'a')], rng).state;
    }
    const awards = settleSkillGain(s);
    expect(awards).toHaveLength(2);
    expect(awards[0]!.total).toBeGreaterThan(0);
  });

  it('caps total gain per match', () => {
    let s = match({ loadout: ['great-waterfall-technique', 'basic-strike'], stats: baseStats({ ninjutsu: 200, handSeals: 200, stamina: 300 }) },
      { stats: baseStats({ stamina: 400 }) });
    const rng = makeRng('cap');
    for (let i = 0; i < 60 && s.phase !== 'complete'; i++) {
      s.fighters[0].cooldowns = {};
      topUp(s.fighters[0]);
      s = resolveTurn(s, [act('a', 'great-waterfall-technique', 'b')], rng).state;
    }
    for (const award of settleSkillGain(s)) {
      expect(award.total).toBeLessThanOrEqual(TUNING.skillGain.maxTotalPerMatch + 0.05);
      for (const v of Object.values(award.gains)) {
        expect(v).toBeLessThanOrEqual(TUNING.skillGain.maxPerStatPerMatch + 0.01);
      }
    }
  });

  it('pays almost nothing for an instant forfeit', () => {
    const s = match();
    const r = run(s, [act('b', 'forfeit', 'a')]);
    const awards = settleSkillGain(r.state);
    expect(awards.every((x) => x.total < 0.5)).toBe(true);
  });

  it('pays the winner more than the loser for identical effort', () => {
    let s = match({ loadout: ['basic-strike'] }, { loadout: ['basic-strike'] });
    const rng = makeRng('winner');
    for (let i = 0; i < 12; i++) {
      s = resolveTurn(s, [act('a', 'basic-strike', 'b'), act('b', 'basic-strike', 'a')], rng).state;
    }
    s.winnerId = 'a';
    const [aw, bw] = settleSkillGain(s);
    expect(aw!.total).toBeGreaterThan(bw!.total * 0.99);
  });
});

/* ── Content integrity ───────────────────────────────────────────────── */

describe('content', () => {
  it('ships at least 200 jutsu', () => {
    expect(JUTSU.length).toBeGreaterThanOrEqual(200);
  });

  it('has unique ids', () => {
    expect(new Set(JUTSU.map((j) => j.id)).size).toBe(JUTSU.length);
  });

  it('every jutsu resolves without throwing', () => {
    for (const j of JUTSU) {
      const s = match(
        { loadout: [j.id], stats: baseStats({ ninjutsu: 200, taijutsu: 200, genjutsu: 200, handSeals: 200 }) },
        { stats: baseStats({ stamina: 200 }) },
      );
      expect(() => {
        let cur = s;
        const rng = makeRng(`all-${j.id}`);
        for (let i = 0; i < 10 && cur.phase !== 'complete'; i++) {
          cur = resolveTurn(cur, [act('a', j.id, 'b')], rng).state;
        }
      }).not.toThrow();
    }
  });

  it('never leaves HP or chakra out of range for any jutsu', () => {
    for (const j of JUTSU) {
      let cur = match(
        { loadout: [j.id], stats: baseStats({ ninjutsu: 200, taijutsu: 200, genjutsu: 200, handSeals: 200 }) },
        { loadout: [j.id], stats: baseStats({ ninjutsu: 200, taijutsu: 200, genjutsu: 200, handSeals: 200 }) },
      );
      const rng = makeRng(`range-${j.id}`);
      for (let i = 0; i < 12 && cur.phase !== 'complete'; i++) {
        cur = resolveTurn(cur, [act('a', j.id, 'b'), act('b', j.id, 'a')], rng).state;
        for (const f of cur.fighters) {
          expect(f.hp).toBeGreaterThanOrEqual(0);
          expect(f.hp).toBeLessThanOrEqual(f.maxHp);
          for (const pool of ['physical', 'mental', 'natural'] as const) expect(f.chakra[pool]).toBeGreaterThanOrEqual(0);
          for (const pool of ['physical', 'mental', 'natural'] as const) expect(f.chakra[pool]).toBeLessThanOrEqual(f.maxChakra[pool]);
        }
      }
    }
  });
});

/* ── Idle / degenerate inputs ────────────────────────────────────────── */

describe('degenerate inputs', () => {
  it('handles an empty action list', () => {
    expect(() => idle(match(), 5)).not.toThrow();
  });

  it('handles duplicate actions for the same fighter by using the first', () => {
    const r = run(match({ loadout: ['fireball-jutsu', 'basic-strike'] }), [
      act('a', 'fireball-jutsu', 'b'),
      act('a', 'basic-strike', 'b'),
    ]);
    expect(r.events.filter((e) => e.t === 'cast' && e.fighterId === 'a').length).toBe(1);
  });

  it('treats a self-targeted attack as targeting the opponent field correctly', () => {
    const r = run(match({ loadout: ['fireball-jutsu'] }), [act('a', 'fireball-jutsu', 'a')]);
    expect(() => r).not.toThrow();
    expect(r.state.fighters[0].hp).toBeLessThanOrEqual(r.state.fighters[0].maxHp);
  });
});

/* ── Bloodlines ──────────────────────────────────────────────────────── */

describe('bloodlines (CLAUDE.md §1)', () => {
  const withBloodline = (id: string, over: Partial<FighterSpec> = {}) => {
    const s = createMatch('bl', 'bl-seed', { ...fighter('a', over), bloodlineId: id }, fighter('b'));
    for (const f of s.fighters) f.chakra.natural = f.maxChakra.natural;
    return s;
  };

  it('bakes stat passives into the fighter at construction', () => {
    const plain = createFighter(fighter('a'));
    const doujutsu = createFighter({ ...fighter('a'), bloodlineId: 'sharingan' });
    const bl = getBloodline('sharingan')!;
    expect(doujutsu.stats.genjutsu).toBe(Math.round(plain.stats.genjutsu * bl.statMults.genjutsu!));
  });

  it('grants extra substitution charges', () => {
    const plain = createFighter(fighter('a'));
    const uchiha = createFighter({ ...fighter('a'), bloodlineId: 'sharingan' });
    expect(uchiha.substitutions).toBe(plain.substitutions + getBloodline('sharingan')!.extraSubstitutions);
  });

  it('makes granted techniques legal outside the loadout', () => {
    const s = withBloodline('mangekyo-sharingan', {
      loadout: [], stats: baseStats({ genjutsu: 200, handSeals: 200 }),
    });
    expect(s.fighters[0].granted).toContain('tsukuyomi');
    const r = run(s, [act('a', 'tsukuyomi', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'notInLoadout')).toBe(false);
  });

  it('still blocks a granted technique the fighter does not have the stats for', () => {
    const s = withBloodline('mangekyo-sharingan', { loadout: [], stats: baseStats({ ninjutsu: 5 }) });
    expect(s.fighters[0].granted).toContain('amaterasu');
    const r = run(s, [act('a', 'amaterasu', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'requirement')).toBe(true);
  });

  it('does not make a non-granted technique legal', () => {
    const s = withBloodline('byakugan', { loadout: [], stats: baseStats({ ninjutsu: 200, handSeals: 200 }) });
    const r = run(s, [act('a', 'kirin', 'b')]);
    expect(r.events.some((e) => e.t === 'blocked' && e.reason === 'notInLoadout')).toBe(true);
  });

  it('seal bonus shortens weaves', () => {
    const slowStats = baseStats({ handSeals: 1, ninjutsu: 200, genjutsu: 200 });
    // weave LENGTH is what this asserts, and weaveStart fires before any accuracy roll
    const fill = (s: MatchState) => { for (const f of s.fighters) f.chakra.natural = f.maxChakra.natural; return s; };
    const plain = fill(createMatch('p', 'p', { ...fighter('a', { loadout: ['tsukuyomi'], stats: slowStats }) }, fighter('b')));
    const gifted = fill(createMatch('g', 'g', { ...fighter('a', { loadout: ['tsukuyomi'], stats: slowStats }), bloodlineId: 'mangekyo-sharingan' }, fighter('b')));
    const turnsOf = (s: MatchState) => {
      const ev = run(s, [act('a', 'tsukuyomi', 'b')]).events.find((e) => e.t === 'weaveStart');
      return ev && ev.t === 'weaveStart' ? ev.turns : 0;
    };
    expect(turnsOf(gifted)).toBeLessThan(turnsOf(plain));
  });

  it('bloodline passives cannot be stripped by dispel', () => {
    let s = withBloodline('uzumaki-vitality', { stats: baseStats({ stamina: 100 }) });
    const before = s.fighters[0].stats.stamina;
    s.fighters[1].loadout = ['dispelling-sign'];
    s.fighters[1].stats.handSeals = 200;
    s = run(s, [act('b', 'dispelling-sign', 'a')]).state;
    expect(s.fighters[0].stats.stamina).toBe(before);
  });

  it('every bloodline grant resolves without throwing', () => {
    for (const bl of BLOODLINES) {
      for (const id of bl.grants) {
        const s0 = createMatch('x', `x-${id}`, {
          ...fighter('a', { loadout: [], stats: baseStats({ ninjutsu: 200, taijutsu: 200, genjutsu: 200, handSeals: 200, strength: 200 }) }),
          bloodlineId: bl.id,
        }, fighter('b', { stats: baseStats({ stamina: 200 }) }));
        for (const f of s0.fighters) f.chakra.natural = f.maxChakra.natural;
        expect(() => {
          let cur = s0;
          const rng = makeRng(`bl-${bl.id}-${id}`);
          for (let i = 0; i < 8 && cur.phase !== 'complete'; i++) {
            cur = resolveTurn(cur, [act('a', id, 'b')], rng).state;
          }
        }).not.toThrow();
      }
    }
  });
});

/* ── Regressions from the adversarial QA pass (tools/qa/exploit-hunt.ts) ── */

describe('QA regressions', () => {
  it('X9: an action stamped with another player cannot drive your clone body', () => {
    let s = match({ loadout: ['multi-shadow-clone-jutsu', 'chakra-focus'], stats: baseStats({ handSeals: 200, ninjutsu: 200 }) });
    s = landCast(s, [act('a', 'multi-shadow-clone-jutsu', 'b')], 'msc').state;
    const clone = s.fighters[0].clones[0];
    expect(clone).toBeDefined();
    const hostile = [{ ...act(clone!.id, 'chakra-focus', 'a'), submittedBy: 'b' }];
    expect(run(s, hostile).events.some((e) => e.t === 'cast')).toBe(false);
  });

  it('X9: sanitizeActions drops actions aimed at bodies the sender does not own', () => {
    let s = match({ loadout: ['multi-shadow-clone-jutsu'], stats: baseStats({ handSeals: 200, ninjutsu: 200 }) });
    s = landCast(s, [act('a', 'multi-shadow-clone-jutsu', 'b')], 'msc').state;
    const clone = s.fighters[0].clones[0]!;
    expect(sanitizeActions(s, 'b', [act(clone.id, 'basic-strike', 'a')])).toHaveLength(0);
    expect(sanitizeActions(s, 'a', [act(clone.id, 'basic-strike', 'b')])).toHaveLength(1);
  });

  it('X9: the owner can still drive their own clone when stamped', () => {
    let s = match({ loadout: ['multi-shadow-clone-jutsu', 'chakra-focus'], stats: baseStats({ handSeals: 200, ninjutsu: 200 }) });
    s = landCast(s, [act('a', 'multi-shadow-clone-jutsu', 'b')], 'msc').state;
    const clone = s.fighters[0].clones[0]!;
    const own = sanitizeActions(s, 'a', [act(clone.id, 'chakra-focus', 'b')]);
    expect(run(s, own).events.some((e) => e.t === 'cast')).toBe(true);
  });

  it('X5: a failed substitution roll does not consume a charge', () => {
    let attempts = 0, successes = 0, consumed = 0;
    for (let i = 0; i < 120; i++) {
      const s = match(
        { loadout: ['hidden-lotus'], stats: baseStats({ strength: 200, taijutsu: 200, speed: 200, handSeals: SURE_HANDS }) },
        { stats: baseStats({ speed: 5 }) },
      );
      s.fighters[1].stance = 'substitute';
      const before = s.fighters[1].substitutions;
      const r = resolveTurn(s, [act('a', 'hidden-lotus', 'b')], makeRng(`sub-${i}`));
      for (const e of r.events) if (e.t === 'substitution' && e.fighterId === 'b') { attempts++; if (e.success) successes++; }
      consumed += before - r.state.fighters[1].substitutions;
    }
    expect(attempts).toBeGreaterThan(0);
    expect(consumed).toBe(successes);
  });
});

/* ── New systems from docs/DESIGN-DIRECTION.txt ──────────────────────── */

describe('three energy reserves (direction doc: "chakra is not mana")', () => {
  it('taijutsu spends physical only, genjutsu mental only, ninjutsu both', () => {
    const tai = getJutsu('front-lotus')!;
    const gen = getJutsu('nightmare-bloom')!;
    const nin = getJutsu('phoenix-flower-jutsu')!;
    expect(tai.cost.physical).toBeGreaterThan(0);
    expect(tai.cost.mental).toBe(0);
    expect(gen.cost.mental).toBeGreaterThan(0);
    expect(gen.cost.physical).toBe(0);
    expect(nin.cost.physical).toBeGreaterThan(0);
    expect(nin.cost.mental).toBeGreaterThan(0);
  });

  it('starts natural energy empty — it has to be gathered', () => {
    const f = createFighter(fighter('a'));
    expect(f.chakra.natural).toBe(0);
    expect(f.chakra.physical).toBe(f.maxChakra.physical);
    expect(f.chakra.mental).toBe(f.maxChakra.mental);
  });

  it('Gather Natural Energy is the only way to fill the natural reserve', () => {
    const s = createMatch('ne', 'ne', fighter('a', { loadout: [] }), fighter('b'));
    expect(s.fighters[0].chakra.natural).toBe(0);
    const r = run(s, [act('a', 'gather-natural-energy', 'a')]);
    expect(r.state.fighters[0].chakra.natural).toBeGreaterThan(0);
  });

  it('natural energy does not regenerate on its own', () => {
    const s = createMatch('ne2', 'ne2', fighter('a', { loadout: [] }), fighter('b'));
    const after = idle(s, 8);
    expect(after.fighters[0].chakra.natural).toBe(0);
  });

  it('physical energy regenerates faster than mental', () => {
    const s = createMatch('rg', 'rg', fighter('a', { loadout: [] }), fighter('b'));
    s.fighters[0].chakra = { physical: 0, mental: 0, natural: 0 };
    const after = run(s, []).state;
    expect(after.fighters[0].chakra.physical).toBeGreaterThan(after.fighters[0].chakra.mental);
  });
});

describe('hand seal accuracy (direction doc: interrupted seals fail)', () => {
  it('clumsy hands fumble sealed techniques more often than practised ones', () => {
    const attempts = (handSeals: number) => {
      let failures = 0;
      for (let i = 0; i < 80; i++) {
        const s = match({ loadout: ['ash-pile-burning'], stats: baseStats({ handSeals, ninjutsu: 120 }) });
        const r = resolveTurn(s, [act('a', 'ash-pile-burning', 'b')], makeRng(`acc-${handSeals}-${i}`));
        if (r.events.some((e) => e.t === 'sealFailed')) failures++;
      }
      return failures;
    };
    expect(attempts(5)).toBeGreaterThan(attempts(300));
  });

  it('a fumbled sequence produces no effect and burns part of the cost', () => {
    let sawFailure = false;
    for (let i = 0; i < 200 && !sawFailure; i++) {
      const s = match({ loadout: ['ash-pile-burning'], stats: baseStats({ handSeals: 5, ninjutsu: 120 }) });
      const r = resolveTurn(s, [act('a', 'ash-pile-burning', 'b')], makeRng(`fz-${i}`));
      const ev = r.events.find((e) => e.t === 'sealFailed');
      if (!ev) continue;
      sawFailure = true;
      expect(r.events.some((e) => e.t === 'cast')).toBe(false);
      expect(r.state.fighters[1].hp).toBe(s.fighters[1].hp);
      expect(ev.t === 'sealFailed' && ev.burned.physical).toBeGreaterThan(0);
    }
    expect(sawFailure).toBe(true);
  });

  it('seal-less techniques can never fumble', () => {
    for (let i = 0; i < 40; i++) {
      const s = match({ loadout: ['basic-strike'], stats: baseStats({ handSeals: 1 }) });
      const r = resolveTurn(s, [act('a', 'basic-strike', 'b')], makeRng(`nf-${i}`));
      expect(r.events.some((e) => e.t === 'sealFailed')).toBe(false);
    }
  });

  it('an eye injury degrades seal accuracy', () => {
    const s = match({ stats: baseStats({ handSeals: 120 }) });
    const clean = sealAccuracy(s.fighters[0], 40);
    s.fighters[0].statuses.push({ status: 'eye-injury', remaining: 10, potency: 0 });
    expect(sealAccuracy(s.fighters[0], 40)).toBeLessThan(clean);
  });
});

describe('combos (direction doc: Oil → Fire → Explosion)', () => {
  it('oil then fire detonates', () => {
    let s = match({ loadout: ['toad-oil-bullet', 'fireball-jutsu'], stats: baseStats({ handSeals: SURE_HANDS, ninjutsu: 120 }) });
    s = landCast(s, [act('a', 'toad-oil-bullet', 'b')], 'oil').state;
    expect(s.fighters[1].statuses.some((x) => x.status === 'oiled')).toBe(true);
    const r = landCast(s, [act('a', 'fireball-jutsu', 'b')], 'boom');
    const combo = r.events.find((e) => e.t === 'combo');
    expect(combo && combo.t === 'combo' && combo.comboId).toBe('explosion');
    expect(r.state.fighters[1].statuses.some((x) => x.status === 'oiled')).toBe(false);
  });

  it('water then lightning electrocutes', () => {
    const s = match({ loadout: ['lightning-strike'], stats: baseStats({ handSeals: SURE_HANDS, ninjutsu: 120 }) });
    s.fighters[1].statuses.push({ status: 'drench', remaining: 4, potency: 0 });
    const r = landCast(s, [act('a', 'lightning-strike', 'b')], 'zap');
    expect(r.events.some((e) => e.t === 'combo' && e.comboId === 'electrocution')).toBe(true);
  });

  it('does not fire without the setup status', () => {
    const s = match({ loadout: ['fireball-jutsu'], stats: baseStats({ handSeals: SURE_HANDS }) });
    expect(run(s, [act('a', 'fireball-jutsu', 'b')], 'nocombo').events.some((e) => e.t === 'combo')).toBe(false);
  });

  it('a combo cannot chain into another combo', () => {
    const s = match({ loadout: ['fireball-jutsu'], stats: baseStats({ handSeals: SURE_HANDS, ninjutsu: 200 }) });
    s.fighters[1].statuses.push({ status: 'oiled', remaining: 4, potency: 0 });
    s.fighters[1].statuses.push({ status: 'drench', remaining: 4, potency: 0 });
    const r = run(s, [act('a', 'fireball-jutsu', 'b')], 'chain');
    expect(r.events.filter((e) => e.t === 'combo').length).toBeLessThanOrEqual(1);
  });
});

describe('injuries (direction doc)', () => {
  it('a broken arm blocks hand seals but not body technique', () => {
    const s = match({ loadout: ['phoenix-flower-jutsu', 'basic-strike'], stats: baseStats({ handSeals: SURE_HANDS, ninjutsu: 120 }) });
    s.fighters[0].statuses.push({ status: 'broken-arm', remaining: 10, potency: 0 });
    expect(run(s, [act('a', 'phoenix-flower-jutsu', 'b')]).events.some((e) => e.t === 'blocked' && e.reason === 'silenced')).toBe(true);
    expect(run(s, [act('a', 'basic-strike', 'b')]).events.some((e) => e.t === 'cast')).toBe(true);
  });

  it('a leg injury slows the fighter', () => {
    const s = match();
    const before = effStat(s.fighters[0], 'speed');
    s.fighters[0].statuses.push({ status: 'leg-injury', remaining: 10, potency: 0 });
    expect(effStat(s.fighters[0], 'speed')).toBeLessThan(before);
  });

  it('heavy hits can inflict an injury that outlasts the exchange', () => {
    let injured = false;
    for (let i = 0; i < 300 && !injured; i++) {
      const s = match(
        { loadout: ['hidden-lotus'], stats: baseStats({ strength: 250, taijutsu: 250, handSeals: SURE_HANDS }) },
        { stats: baseStats({ stamina: 20 }) },
      );
      const r = resolveTurn(s, [act('a', 'hidden-lotus', 'b')], makeRng(`inj-${i}`));
      const ev = r.events.find((e) => e.t === 'injury');
      if (ev && ev.t === 'injury') {
        injured = true;
        const st = r.state.fighters[1].statuses.find((x) => x.status === ev.status);
        expect(st!.remaining).toBeGreaterThan(5);
      }
    }
    expect(injured).toBe(true);
  });
});

describe('bloodline rarity (direction doc: ~20%, lore-weighted)', () => {
  it('grants a bloodline to roughly one character in five', () => {
    let granted = 0;
    const N = 20000;
    const rng = makeRng('rarity');
    for (let i = 0; i < N; i++) if (rollBloodline(rng.next(), rng.next()) !== null) granted++;
    expect(granted / N).toBeGreaterThan(0.17);
    expect(granted / N).toBeLessThan(0.23);
  });

  it('weights the draw by lore scarcity', () => {
    const counts = new Map<string, number>();
    const rng = makeRng('weights');
    for (let i = 0; i < 60000; i++) {
      const id = rollBloodline(rng.next(), rng.next());
      if (id) counts.set(id, (counts.get(id) ?? 0) + 1);
    }
    expect(counts.get('rinnegan') ?? 0).toBeLessThan(counts.get('sharingan') ?? 0);
    expect(counts.get('mangekyo-sharingan') ?? 0).toBeLessThan(counts.get('byakugan') ?? 0);
  });

  it('is deterministic for a given pair of rolls', () => {
    expect(rollBloodline(0.05, 0.42)).toBe(rollBloodline(0.05, 0.42));
  });
});

describe('forfeit', () => {
  it('awards the match to the opponent', () => {
    const s = match();
    const r = run(s, [act('b', 'forfeit', 'a')]);
    expect(r.state.phase).toBe('complete');
    expect(r.state.outcome).toBe('forfeit');
    expect(r.state.winnerId).toBe('a');
    expect(r.state.fighters[1].defeated).toBe(true);
  });

  it('is a draw if the survivor was already down', () => {
    const s = match();
    s.fighters[0].defeated = true;
    const r = run(s, [act('b', 'forfeit', 'a')]);
    expect(r.state.winnerId).toBeNull();
  });

  it('sanitizeActions strips client-supplied fields it does not recognise', () => {
    const s = match();
    const dirty = [{
      fighterId: 'a', actionId: 'basic-strike', targetId: 'b',
      damage: 9999, roll: 1, chakra: 9999,
    } as never];
    const clean = sanitizeActions(s, 'a', dirty);
    expect(Object.keys(clean[0]!).sort()).toEqual(['actionId', 'fighterId', 'submittedBy', 'targetId']);
  });
});
