# Contributing

## Before anything else

Read `CLAUDE.md`. It holds the invariants this project is built on, and most of
them are not negotiable by a pull request:

- `packages/engine` is pure. No `Math.random`, no `Date.now`, no I/O, no mutation
  of its inputs. `pnpm lint` enforces this and CI runs it first.
- The server is the only authority. The client submits intent and renders what it
  is told; it calculates nothing.
- Content is data. Balance changes go in JSON, never in engine code.
- Nothing purchasable, craftable, or elected may affect combat power.

## The one command

```bash
pnpm check
```

That is lint, content validation, every test, the drift check, and both exploit
probe suites. CI runs the same thing. If it passes locally it will pass there.

## What a good change looks like

**Balance.** Edit the JSON, then run `pnpm parity` (combat) or `pnpm sim:economy`
(economy) and put the before-and-after numbers in the PR description. A balance
change without a measurement is a guess.

**A new system.** Content schema and data first, then the store, then the domain
module, then the service handler, then tests, then a probe in
`tools/qa/meta-exploit-hunt.ts`. Add the design property to
`tools/qa/drift-check.ts` so it cannot silently regress.

**A new probe.** Break the guard it is meant to catch and confirm the probe
fires, then put it back. A probe that has never failed is not evidence of
anything — two of the probes in this repository passed for the wrong reason until
they were tested that way.

**A concurrency invariant.** Enforce it with a database constraint, not with an
`if` in a handler. Application checks lose races; that is what they do. There are
four already: one war per region per period, one vote per player per office per
cycle, one active mentor per student, one buyer per listing.

## Decisions get written down

`docs/OVERRIDES.md` is the change ledger. When you make a call that a future
reader might mistake for an oversight — or reverse one that is already there —
say what you did and why. Several entries in it exist because somebody would
otherwise have "fixed" a deliberate choice.

## Style

Comments explain *why*, not *what*. If a line needs a comment to say what it
does, rewrite the line.
