# Notice on names and setting

The MIT licence in `LICENSE` covers the **code** in this repository.

It does not, and cannot, grant any rights in third-party intellectual property.
The content files under `packages/content/data/` use character, village, clan,
and technique names drawn from the *Naruto* franchise, which is the property of
its rights holders. Nothing here is endorsed by or affiliated with them.

This is a fan project. If you fork it, publish it, or put it in front of players,
that exposure is yours to weigh — particularly if money is involved anywhere in
the arrangement.

## Swapping the setting

The names were kept in data rather than in code specifically so this stays cheap.
Nothing in `packages/engine`, `apps/server`, or `apps/web` refers to a name from
the franchise; every one of them lives in a JSON file, and the engine reads them
as opaque ids.

To reskin, edit the `name` and `blurb` fields in:

```
packages/content/data/villages.json     village names
packages/content/data/clans.json        clan names
packages/content/data/bloodlines.json   bloodline names
packages/content/data/jutsu.json        technique names
packages/content/data/territory.json    region and country names
packages/content/data/missions.json     mission text
```

Leave the `id` fields alone — they are referenced across content files and by
saved player rows, and `pnpm validate:content` will tell you immediately if a
reference breaks. Balance is unaffected: no number changes.
