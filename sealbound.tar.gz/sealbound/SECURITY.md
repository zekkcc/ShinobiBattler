# Security

## Reporting

Please report vulnerabilities privately through GitHub's "Report a vulnerability"
button on the Security tab rather than opening a public issue. Include what you
did, what happened, and what you expected.

## What counts

This is a competitive game, so the interesting bugs are the ones that let a
player gain something they did not earn. All of these are in scope:

- duplicating goods or ryo, or moving value without the transfer being recorded
- reading anything the server should not have sent — dungeon answers, an
  opponent's hand, another player's inventory
- acting with authority you do not hold: a decree without the office, a war score
  without the tenure, a vote without the suffrage
- anything that reaches combat resolution from outside a match
- desynchronising or corrupting a match another player is in

`tools/qa/exploit-hunt.ts` and `tools/qa/meta-exploit-hunt.ts` show the shape of
what has already been checked. A finding that one of them *should* have caught is
especially welcome — the probe is as much the bug as the code is.

## What does not count

- Rate limits being generous enough to be annoying rather than exploitable.
- The absence of anti-cheat for out-of-game collusion. Direct trade is free by
  design; the defence is that every transfer is logged, not that it is prevented.
- Balance complaints. Those are issues, not vulnerabilities.
