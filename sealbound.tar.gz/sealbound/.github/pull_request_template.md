**What this changes**

**Why**

**Checklist**
- [ ] `pnpm check` passes
- [ ] Balance changes include before/after numbers from `pnpm parity` or `pnpm sim:economy`
- [ ] New systems have a probe in `tools/qa/meta-exploit-hunt.ts`, and it was confirmed to fire when the guard is removed
- [ ] New design properties are asserted in `tools/qa/drift-check.ts`
- [ ] Anything a future reader could mistake for an oversight is recorded in `docs/OVERRIDES.md`
