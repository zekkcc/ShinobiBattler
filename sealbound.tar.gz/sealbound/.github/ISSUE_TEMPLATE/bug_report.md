---
name: Bug report
about: Something behaves differently from how it is documented
labels: bug
---

**What happened**

**What you expected**

**Steps**
1.
2.

**Which part**
Engine / server / client / content / tooling — as best you can tell.

**Does `pnpm check` pass on your checkout?**
