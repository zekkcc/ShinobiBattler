---
name: Balance
about: Something is too strong, too weak, or not worth doing
labels: balance
---

**What is out of line**

**What you measured**
`pnpm parity` for combat, `pnpm sim:economy` for the economy. Numbers make this
actionable; impressions usually cannot be acted on.

**What you think it should be, and what that would break**
