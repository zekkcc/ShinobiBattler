/**
 * Headless balance simulator.
 *
 *   pnpm sim -- --matches 50000 --report matrix
 *
 * Runs archetype-vs-archetype matches through the real engine and reports win
 * rates. Every archetype should land inside 43–57% against the field
 * (CLAUDE.md §10.4). Balance is fixed by editing content JSON, never engine code.
 */
import { COMBO_INDEX, COMBOS, JUTSU_BY_ID, TUNING } from '@shinobi/content';
import { createMatch, makeRng, resolveTurn, sealAccuracy, settleSkillGain, type FighterSpec, type Rng } from '@shinobi/engine';
import type { CloneState, Energy, FighterState, MatchState, Nature, Stats, SubmittedAction } from '@shinobi/shared';

/* ── Archetypes ──────────────────────────────────────────────────────── */

export interface Archetype {
  name: string;
  affinity: Nature;
  stats: Stats;
  loadout: string[];
  bloodline?: string;
  /** one line on what this build is actually trying to do */
  plan: string;
}

const S = (o: Partial<Stats>): Stats => ({
  ninjutsu: 40, taijutsu: 40, genjutsu: 40, intelligence: 40,
  strength: 40, speed: 40, stamina: 40, handSeals: 40, ...o,
});

/**
 * Fixtures are rebuilt around the three reserves, stances, combos, and natural
 * energy. Each one is meant to be a build a real player would plausibly bring,
 * and each expresses a different answer to "how do I actually win".
 *
 * Fairness is asserted, not assumed — see assertFixtureParity() below. The
 * previous fixture set drifted into unequal power budgets and made the whole
 * matrix unreadable.
 */
export const ARCHETYPES: Archetype[] = [
  {
    name: 'Artillery', affinity: 'lightning',
    plan: 'Oil the target, then detonate it. Big sealed fire, paid for in both reserves.',
    stats: S({ ninjutsu: 105, intelligence: 90, handSeals: 95, stamina: 60, speed: 50 }),
    loadout: ['fire-dragon-flame-bullet', 'dragon-flame-bomb', 'great-fire-annihilation',
      'toad-oil-bullet', 'phoenix-flower-jutsu', 'fireball-jutsu'],
  },
  {
    name: 'Brawler', affinity: 'water',
    plan: 'Physical reserve only. Never fumbles a seal, never gets interrupted, grinds you down.',
    stats: S({ taijutsu: 105, strength: 100, speed: 80, stamina: 75, handSeals: 40 }),
    loadout: ['hidden-lotus', 'front-lotus', 'leaf-hurricane',
      'dynamic-entry', 'leaf-gale', 'palm-strike'],
  },
  {
    name: 'Illusionist', affinity: 'water',
    plan: 'Deep mental reserve, slow burn. Lock the opponent out and win on tempo.',
    stats: S({ genjutsu: 105, intelligence: 95, handSeals: 85, speed: 65, stamina: 50 }),
    loadout: ['mind-destruction', 'temple-of-nirvana', 'nightmare-bloom',
      'demonic-illusion-false-dusk', 'bell-ringing-illusion', 'false-surroundings'],
  },
  {
    name: 'Swarm', affinity: 'fire',
    plan: 'Split into bodies, spend the extra actions before the split expires.',
    stats: S({ ninjutsu: 95, intelligence: 85, handSeals: 100, stamina: 55, speed: 65 }),
    loadout: ['divine-cross-cut-storm', 'multi-shadow-clone-jutsu', 'great-breakthrough',
      'vacuum-serial-waves', 'vacuum-sphere', 'gale-palm'],
  },
  {
    name: 'Berserker', affinity: 'water',
    plan: 'Open a gate early and race the HP drain to a kill.',
    stats: S({ taijutsu: 100, strength: 105, speed: 85, stamina: 75, handSeals: 35 }),
    loadout: ['piercing-fang', 'gate-of-life', 'falling-heel-drop',
      'dynamic-entry', 'leaf-strong-whirlwind', 'palm-strike'],
  },
  {
    name: 'Medic', affinity: 'water',
    plan: 'Outlast. Cleanse injuries, heal through pressure, win by attrition.',
    stats: S({ ninjutsu: 85, stamina: 110, intelligence: 90, handSeals: 75 }),
    loadout: ['healing-tide', 'life-leech', 'healing-resonance',
      'chakra-scalpel', 'poison-extraction', 'mystical-palm-technique'],
  },
  {
    name: 'Assassin', affinity: 'wind',
    plan: 'Soak them, then electrocute. Speed for turn order and substitution odds.',
    stats: S({ speed: 105, ninjutsu: 90, handSeals: 90, stamina: 60, intelligence: 55 }),
    loadout: ['false-darkness', 'chidori', 'thunder-volley',
      'water-soak', 'lightning-nail', 'lightning-strike'],
  },
  {
    name: 'Bulwark', affinity: 'earth',
    plan: 'Soak damage behind walls, set up its own water combos off the back foot.',
    stats: S({ stamina: 110, ninjutsu: 100, intelligence: 85, handSeals: 60, speed: 45 }),
    loadout: ['water-fang-lance', 'water-shark-bomb', 'mud-wall',
      'wild-water-wave', 'water-wall', 'water-soak'],
  },
  {
    name: 'Sage', affinity: 'wind',
    plan: 'Gather natural energy early, then land one forbidden technique that ends it.',
    stats: S({ ninjutsu: 100, intelligence: 100, stamina: 85, handSeals: 80, speed: 35 }),
    loadout: ['rasenshuriken', 'sage-mode', 'drilling-air-bullet',
      'vacuum-sphere', 'vacuum-blade', 'gale-palm'],
  },
  {
    name: 'Doujutsu', affinity: 'water',
    plan: 'Bloodline build: bought stats are lower, the eyes make up the difference.',
    bloodline: 'sharingan',
    stats: S({ genjutsu: 95, intelligence: 90, handSeals: 85, speed: 65, stamina: 50 }),
    loadout: ['mind-destruction', 'binding-illusion', 'phantom-pain',
      'demonic-illusion-false-dusk', 'mind-shatter', 'false-surroundings'],
  },
];

/* ── Fixture parity ──────────────────────────────────────────────────────
 * A matrix built from unequal fixtures measures the fixtures, not the game.
 * This is the check that was missing when the old set quietly drifted.
 */
const RANK_POINTS: Record<string, number> = { E: 0, D: 1, C: 2, B: 3, A: 5, S: 8 };

export function assertFixtureParity(): string[] {
  const problems: string[] = [];

  /* Affinity is defensive; jutsu nature is offensive. Balancing affinity counts
     alone is not enough — if nobody in the field attacks with earth, then water
     affinity is never countered and whoever holds it wins the "vs field" metric
     on structure rather than on strength. That is exactly what happened.

     The real invariant: every archetype must counter as many opponents as
     counter it. */
  {
    const BEATS: Record<string, string> = {
      fire: 'wind', wind: 'lightning', lightning: 'earth', earth: 'water', water: 'fire',
    };
    /** the nature this archetype actually attacks with, if any */
    const attackNature = (a: Archetype): string | null => {
      for (const id of a.loadout) {
        const j = JUTSU_BY_ID.get(id);
        if (j?.nature && j.nature in BEATS && j.effects.some((e) => e.kind === 'damage')) return j.nature;
      }
      return null;
    };
    for (const me of ARCHETYPES) {
      const mine = attackNature(me);
      let counters = 0, countered = 0;
      for (const other of ARCHETYPES) {
        if (other === me) continue;
        if (mine && BEATS[mine] === other.affinity) counters++;
        const theirs = attackNature(other);
        if (theirs && BEATS[theirs] === me.affinity) countered++;
      }
      if (counters !== countered) {
        problems.push(`${me.name} counters ${counters} and is countered by ${countered} — the field is not elementally symmetric`);
      }
    }
  }

  const statTotals = ARCHETYPES.map((a) => Object.values(a.stats).reduce((n, v) => n + v, 0));
  const baseline = statTotals[ARCHETYPES.findIndex((a) => !a.bloodline)]!;
  const BLOODLINE_STAT_DISCOUNT = 15;
  ARCHETYPES.forEach((a, i) => {
    const target = baseline - (a.bloodline ? BLOODLINE_STAT_DISCOUNT : 0);
    if (Math.abs(statTotals[i]! - target) > 5) {
      problems.push(`${a.name}: stat total ${statTotals[i]} vs an expected ${target}`);
    }
    const pts = a.loadout.reduce((n, id) => {
      const j = JUTSU_BY_ID.get(id);
      if (!j) { problems.push(`${a.name}: unknown jutsu "${id}"`); return n; }
      return n + (RANK_POINTS[j.rank] ?? 0);
    }, 0);
    // a bloodline is itself a power budget, so bloodline builds buy fewer stats
    const budget = a.bloodline ? 12 : 14;
    if (Math.abs(pts - budget) > 2) problems.push(`${a.name}: loadout worth ${pts} rank-points, budget ${budget}`);
    for (const id of a.loadout) {
      const j = JUTSU_BY_ID.get(id);
      if (j?.requires && a.stats[j.requires.stat] < j.requires.min) {
        problems.push(`${a.name}: cannot meet the requirement for "${id}" (${j.requires.stat} ${a.stats[j.requires.stat]} < ${j.requires.min})`);
      }
    }
  });
  return problems;
}

/* ── Policy ──────────────────────────────────────────────────────────────
 * A deliberately simple greedy bot. It is not meant to play well; it is meant
 * to play *consistently*, so that a win-rate swing points at content numbers
 * rather than at bot cleverness.
 */

/** Does this fighter hold something that needs natural energy it doesn't have? */
function starvedOfNature(self: FighterState): boolean {
  return [...self.loadout, ...self.granted].some((id) => {
    const j = JUTSU_BY_ID.get(id);
    return !!j && j.cost.natural > self.chakra.natural;
  });
}

/** Does this fighter carry a technique that would pay off the given setup status? */
function hasComboPayoff(self: FighterState, setup: string): boolean {
  return [...self.loadout, ...self.granted].some((id) => {
    const j = JUTSU_BY_ID.get(id);
    return !!j && j.nature !== null && COMBO_INDEX.has(`${setup}|${j.nature}`)
      && j.effects.some((e) => e.kind === 'damage');
  });
}

/** Rough size of the hit a telegraphed weave is about to deliver. */
function incomingThreat(foe: FighterState): number {
  if (!foe.weave) return 0;
  const j = JUTSU_BY_ID.get(foe.weave.jutsuId);
  if (!j) return 0;
  let power = 0;
  for (const e of j.effects) {
    if (e.kind === 'damage') power += e.power * (e.hits ?? 1);
  }
  const stat = j.discipline === 'taijutsu' ? 'strength' : j.discipline === 'genjutsu' ? 'genjutsu' : 'ninjutsu';
  return power * (1 + foe.stats[stat] / 100) * 0.55; // crude post-mitigation estimate
}

function hasBigSealedCast(self: FighterState): boolean {
  return [...self.loadout, ...self.granted].some((id) => {
    const j = JUTSU_BY_ID.get(id);
    return !!j && j.seals >= 3 && j.effects.some((e) => e.kind === 'damage')
      && (self.cooldowns[id] ?? 0) === 0
      && j.cost.physical <= self.chakra.physical && j.cost.mental <= self.chakra.mental
      && j.cost.natural <= self.chakra.natural;
  });
}

function estimateValue(id: string, self: FighterState, foe: FighterState): number {
  const j = JUTSU_BY_ID.get(id);
  if (!j) return -1;
  let v = 0;
  for (const e of j.effects) {
    switch (e.kind) {
      case 'damage': v += e.power * (e.hits ?? 1) * 0.9; break;
      case 'heal': v += self.hp / self.maxHp < 0.45 ? e.power * 1.4 : e.power * 0.15; break;
      case 'shield': v += self.shields.length === 0 ? e.power * 0.7 : e.power * 0.1; break;
      case 'applyStatus': {
        if (foe.statuses.some((s) => s.status === e.status)) { v += 8; break; }
        // laying a combo setup is only worth it if we can actually cash it in
        v += hasComboPayoff(self, e.status) ? 130 : 55;
        break;
      }
      case 'cloneSplit': v += self.clones.length === 0 ? 90 : 5; break;
      case 'gateOpen': v += self.gateTier === 0 ? 110 : 0; break;
      case 'statModifier': v += self.modifiers.length < 2 ? 45 : 5; break;
      case 'cleanseStatus': v += self.statuses.filter((s) => s.remaining > 0).length * 22; break;
      case 'dispel': v += (foe.clones.length * 45) + (foe.shields.length * 25); break;
      case 'delayed': v += 60; break;
      case 'reflectStance': v += 35; break;
      case 'interrupt': v += foe.weave ? 120 : 5; break;
      case 'substitutionCharge': v += self.substitutions === 0 ? 70 : 5; break;
      case 'chakraDelta':
        v += e.pool === 'natural'
          ? (starvedOfNature(self) ? 150 : 2)
          : (e.target === 'self' ? 20 : 25);
        break;
      case 'stance': {
        /* A weave in progress is PUBLIC (CLAUDE.md §7) and lands next turn, so
           reacting to it is a read, not clairvoyance. This is the mind-game the
           design is built around, and a bot that ignores it can only ever play
           the pure-aggression subgame. */
        const telegraphed = foe.weave !== null;
        const incoming = telegraphed ? incomingThreat(foe) : 0;
        if (e.stance === 'substitute') {
          v += self.substitutions > 0 && incoming > self.maxHp * 0.16 ? 25 + incoming * 0.7 : 6;
        } else if (e.stance === 'counter') {
          v += telegraphed && incoming > self.maxHp * 0.10 ? 15 + incoming * 0.45 : 8;
        } else {
          // Prepare is only worth a turn if there is something big to spend it on
          v += self.stance === 'prepare' ? 0 : (hasBigSealedCast(self) ? 75 : 15);
        }
        break;
      }
    }
  }
  // A cast that fumbles is worth nothing, so weight by the accuracy roll.
  if (j.seals > 0) v *= sealAccuracy(self, j.sealDifficulty);

  // Weaving costs tempo; discount long weaves.
  if (j.seals > 3) v *= 0.8;

  // Landing the combo trigger is worth much more than the technique alone.
  if (j.nature && j.effects.some((e) => e.kind === 'damage')
    && foe.statuses.some((st) => COMBO_INDEX.has(`${st.status}|${j.nature}`))) {
    v *= 1.9;
  }

  // Prepare is banked: spend it on something that actually uses seals.
  if (self.stance === 'prepare' && j.seals > 0) v *= 1.3;

  return v;
}

/**
 * Real players do not execute one script perfectly. A purely greedy bot makes
 * every pairing resolve to 0% or 100%, which measures script-vs-script rather
 * than balance. EXPLORATION mixes in sub-optimal but legal choices so each
 * pairing produces a distribution.
 */
const EXPLORATION = 0.3;

/** A body can afford a technique only if every reserve covers its share. */
function affordable(cost: { physical: number; mental: number; natural: number }, reserves: Energy): boolean {
  return cost.physical <= reserves.physical && cost.mental <= reserves.mental && cost.natural <= reserves.natural;
}

function chooseAction(
  f: FighterState, foe: FighterState, bodyId: string,
  pool: Energy, cds: Record<string, number>, rng: Rng,
): SubmittedAction {
  const legal: { id: string; v: number }[] = [];
  for (const id of [...f.loadout, 'basic-strike', 'throw-weapon', 'chakra-focus',
    'guard-stance', 'substitute', 'counter-stance-basic', 'prepare-seals', 'gather-natural-energy']) {
    const j = JUTSU_BY_ID.get(id);
    if (!j) continue;
    if ((cds[id] ?? 0) > 0) continue;
    if (j.requires && f.stats[j.requires.stat] < j.requires.min) continue;
    if (!affordable(j.cost, pool)) continue;
    legal.push({ id, v: estimateValue(id, f, foe) });
  }
  if (legal.length === 0) return { fighterId: bodyId, actionId: 'basic-strike', targetId: foe.id };
  legal.sort((x, y) => y.v - x.v);
  const topK = legal.slice(0, Math.min(3, legal.length));
  const pick = rng.chance(EXPLORATION)
    ? topK[rng.int(topK.length)]!
    : legal[0]!;
  return { fighterId: bodyId, actionId: pick.id, targetId: foe.id };
}

function actionsFor(state: MatchState, rng: Rng): SubmittedAction[] {
  const out: SubmittedAction[] = [];
  const [a, b] = state.fighters;
  for (const [self, foe] of [[a, b], [b, a]] as [FighterState, FighterState][]) {
    if (self.defeated) continue;
    if (!self.weave) out.push(chooseAction(self, foe, self.id, self.chakra, self.cooldowns, rng));
    for (const c of self.clones as CloneState[]) {
      if (c.weave) continue;
      out.push(chooseAction(self, foe, c.id, c.chakra, c.cooldowns, rng));
    }
  }
  return out;
}

/* ── Runner ──────────────────────────────────────────────────────────── */

export interface MatchOutcome {
  winner: 0 | 1 | null;
  rounds: number;
  suddenDeath: boolean;
  outcome: MatchState['outcome'];
  skill: [number, number];
  /** damage dealt by each side, split by how it got through */
  dealt: [number, number];
  viaCombo: [number, number];
  viaDot: [number, number];
  fumbles: [number, number];
}

export function simulateMatch(a: Archetype, b: Archetype, seed: string): MatchOutcome {
  /* Players building the same archetype do not roll identical stat lines.
     Jitter each fixture so the matrix reflects a band of builds, not one point. */
  const jitter = makeRng(`${seed}:build`);
  const spread = (stats: Stats): Stats => {
    const out = { ...stats };
    for (const k of Object.keys(out) as (keyof Stats)[]) {
      out[k] = Math.max(1, Math.round(out[k] * (0.9 + jitter.next() * 0.2)));
    }
    return out;
  };
  const spec = (arch: Archetype, id: string): FighterSpec => ({
    id, name: arch.name, level: 40, stats: spread(arch.stats),
    affinity: arch.affinity, loadout: arch.loadout, bloodlineId: arch.bloodline ?? null,
  });
  let state = createMatch(`sim-${seed}`, seed, spec(a, 'a'), spec(b, 'b'));
  const rng = makeRng(seed);
  let guard = 0;
  const dealt: [number, number] = [0, 0];
  const viaCombo: [number, number] = [0, 0];
  const viaDot: [number, number] = [0, 0];
  const fumbles: [number, number] = [0, 0];
  const idx = (id: string) => (id === 'a' ? 0 : 1);
  while (state.phase !== 'complete' && guard < TUNING.hardCapRound + 5) {
    const res = resolveTurn(state, actionsFor(state, rng), rng);
    for (const e of res.events) {
      if (e.t === 'damage') dealt[idx(e.sourceId)] += e.amount;
      else if (e.t === 'combo') viaCombo[idx(e.fighterId)] += e.amount;
      else if (e.t === 'statusTick') viaDot[1 - idx(e.fighterId)] += e.amount;
      else if (e.t === 'sealFailed') fumbles[idx(e.fighterId)] += 1;
    }
    state = res.state;
    guard++;
  }
  const awards = settleSkillGain(state);
  return {
    winner: state.winnerId === 'a' ? 0 : state.winnerId === 'b' ? 1 : null,
    rounds: state.round,
    suddenDeath: state.suddenDeath,
    outcome: state.outcome,
    skill: [awards[0]?.total ?? 0, awards[1]?.total ?? 0],
    dealt, viaCombo, viaDot, fumbles,
  };
}

function arg(name: string, dflt: number): number {
  const i = process.argv.indexOf(`--${name}`);
  if (i === -1) return dflt;
  const v = Number(process.argv[i + 1]);
  return Number.isFinite(v) ? v : dflt;
}

function main(): void {
  const target = arg('matches', 5000);
  const n = ARCHETYPES.length;
  const pairs = (n * (n - 1)) / 2 + n;
  const per = Math.max(20, Math.round(target / pairs / 2)); // /2 because each pairing is played from both sides

  const wins = Array.from({ length: n }, () => Array.from({ length: n }, () => 0));
  const played = Array.from({ length: n }, () => Array.from({ length: n }, () => 0));
  let totalRounds = 0, totalMatches = 0, suddenDeaths = 0, draws = 0, timeouts = 0;
  let skillSum = 0;
  const dmg = Array.from({ length: n }, () => 0);
  const combo = Array.from({ length: n }, () => 0);
  const dot = Array.from({ length: n }, () => 0);
  const fumb = Array.from({ length: n }, () => 0);
  const rounds = Array.from({ length: n }, () => 0);
  const roundBuckets = new Map<number, number>();

  for (let i = 0; i < n; i++) {
    for (let j = i; j < n; j++) {
      for (let k = 0; k < per; k++) {
        for (const [x, y] of [[i, j], [j, i]] as [number, number][]) {
          const res = simulateMatch(ARCHETYPES[x]!, ARCHETYPES[y]!, `s-${x}-${y}-${k}`);
          played[x]![y]! += 1; played[y]![x]! += 1;
          if (res.winner === 0) wins[x]![y]! += 1;
          else if (res.winner === 1) wins[y]![x]! += 1;
          else draws++;
          if (res.outcome === 'timeout') timeouts++;
          if (res.suddenDeath) suddenDeaths++;
          totalRounds += res.rounds; totalMatches++;
          dmg[x]! += res.dealt[0]; dmg[y]! += res.dealt[1];
          combo[x]! += res.viaCombo[0]; combo[y]! += res.viaCombo[1];
          dot[x]! += res.viaDot[0]; dot[y]! += res.viaDot[1];
          fumb[x]! += res.fumbles[0]; fumb[y]! += res.fumbles[1];
          rounds[x]! += res.rounds; rounds[y]! += res.rounds;
          skillSum += res.skill[0] + res.skill[1];
          const bucket = Math.min(140, Math.round(res.rounds / 10) * 10);
          roundBuckets.set(bucket, (roundBuckets.get(bucket) ?? 0) + 1);
        }
      }
    }
  }

  const pad = (s: string, w: number) => s.padEnd(w);
  const head = ARCHETYPES.map((a) => a.name.slice(0, 5));

  console.log(`\nmatches: ${totalMatches}   avg rounds: ${(totalRounds / totalMatches).toFixed(1)}   ` +
    `sudden death: ${((suddenDeaths / totalMatches) * 100).toFixed(1)}%   ` +
    `draws: ${draws}   timeouts: ${timeouts}   avg skill/match: ${(skillSum / totalMatches / 2).toFixed(2)}`);

  console.log('\nwin rate, row vs column (%)');
  console.log(pad('', 12) + head.map((h) => pad(h, 7)).join(''));
  for (let i = 0; i < n; i++) {
    const row = [];
    for (let j = 0; j < n; j++) {
      if (i === j) { row.push(pad('—', 7)); continue; }
      const p = played[i]![j]! === 0 ? 0 : (wins[i]![j]! / played[i]![j]!) * 100;
      row.push(pad(p.toFixed(1), 7));
    }
    console.log(pad(ARCHETYPES[i]!.name, 12) + row.join(''));
  }

  console.log('\nvs. the field');
  let outOfBand = 0;
  for (let i = 0; i < n; i++) {
    let w = 0, p = 0;
    for (let j = 0; j < n; j++) { if (i === j) continue; w += wins[i]![j]!; p += played[i]![j]!; }
    const rate = (w / p) * 100;
    const ok = rate >= 43 && rate <= 57;
    if (!ok) outOfBand++;
    console.log(`  ${pad(ARCHETYPES[i]!.name, 12)} ${rate.toFixed(1)}%  ${ok ? 'ok' : '<-- OUTSIDE 43-57 BAND'}`);
  }

  console.log('\noutput profile (per round, averaged over every match played)');
  console.log(pad('', 12) + pad('dmg/rd', 9) + pad('combo', 9) + pad('dot', 9) + pad('fumble/rd', 11));
  for (let i = 0; i < n; i++) {
    const r = rounds[i]! || 1;
    console.log(pad(ARCHETYPES[i]!.name, 12)
      + pad((dmg[i]! / r).toFixed(1), 9)
      + pad((combo[i]! / r).toFixed(1), 9)
      + pad((dot[i]! / r).toFixed(1), 9)
      + pad((fumb[i]! / r).toFixed(3), 11));
  }

  console.log('\nmatch length distribution');
  for (const bucket of [...roundBuckets.keys()].sort((x, y) => x - y)) {
    const c = roundBuckets.get(bucket)!;
    const bar = '#'.repeat(Math.max(1, Math.round((c / totalMatches) * 120)));
    console.log(`  ${String(bucket).padStart(4)}  ${bar} ${((c / totalMatches) * 100).toFixed(1)}%`);
  }

  if (outOfBand > 0) {
    console.log(`\n${outOfBand} archetype(s) outside the 43-57% band — content numbers need adjustment.`);
    process.exitCode = 2;
  } else {
    console.log('\nall archetypes inside the 43-57% band.');
  }
}

const invokedDirectly = process.argv[1]?.includes('sim.ts');
if (invokedDirectly) main();
