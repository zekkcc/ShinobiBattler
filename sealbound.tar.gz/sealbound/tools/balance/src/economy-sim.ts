/**
 * Economy simulator.
 *
 *   pnpm sim:economy
 *   pnpm sim:economy -- --players 60 --days 28 --seed autumn
 *
 * The combat simulator answers "is this archetype fair". This one answers the
 * questions that decide whether the meta-game is worth playing at all:
 *
 *   * Where does ryo come from, where does it go, and is the total growing?
 *   * How long does it actually take to reach the top of the crafting tree?
 *   * Do market prices settle anywhere, or does the reference band wander?
 *   * Is holding territory worth what it costs to take?
 *   * How far apart are the richest and poorest players after a season?
 *
 * Every number here comes from driving the REAL `GameService` against a real
 * store. Nothing is re-implemented. A simulator that reimplements the rules only
 * ever tells you about the simulator — this one can be wrong about player
 * behaviour, but it cannot be wrong about what the server does.
 *
 * Simulated players are deliberately unsophisticated. They are not optimising;
 * they follow a plausible routine. That biases every figure here DOWNWARD: a
 * real population contains people who work out the best loop and run it, so
 * treat these as a floor on income and a ceiling on time-to-goal.
 */
import { DUNGEONS, ECONOMY, ITEM_BY_ID, MISSIONS, TERRITORY } from '@shinobi/content';
import { makeRng, type Rng } from '@shinobi/engine';
import type { Rank, Stats } from '@shinobi/shared';
import { GameService } from '../../../apps/server/src/service.js';
import { MemoryStore, newMetaState, type PlayerRecord } from '../../../apps/server/src/store/index.js';
import { currentSeason } from '../../../apps/server/src/world.js';

/* ── Arguments ───────────────────────────────────────────────────────── */

const arg = (name: string, fallback: string): string => {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 && process.argv[i + 1] ? process.argv[i + 1]! : fallback;
};

const PLAYERS = Number(arg('players', '48'));
const DAYS = Number(arg('days', '28'));
const SEED = arg('seed', 'economy');
const VERBOSE = process.argv.includes('--verbose');

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;
/** Waking hours per simulated day. */
const ACTIVE_HOURS = 6;
/**
 * Decisions per hour.
 *
 * This was one, and it quietly libelled gathering: a trip takes 20 minutes, so
 * an hourly tick ran a third of the trips a real player would and made gathering
 * look like it paid a third of what it does. The step is now the shortest timed
 * activity in the content, so every role is measured at the cadence it actually
 * runs at.
 */
const TICKS_PER_HOUR = Math.max(1, Math.round(60 / TERRITORY.yield.gatherMinutes));
const TICK_MS = HOUR / TICKS_PER_HOUR;

/* ── Roles ───────────────────────────────────────────────────────────── */

/**
 * Five routines, chosen to cover the paths a real population would spread
 * across rather than to be individually optimal. The mix matters: a market with
 * only sellers has no prices, and a market with only buyers has no goods.
 */
type Role = 'gatherer' | 'crafter' | 'delver' | 'missionRunner' | 'trader';

const ROLE_MIX: Role[] = [
  'gatherer', 'gatherer', 'gatherer', 'gatherer',
  'crafter', 'crafter', 'crafter',
  'delver', 'delver',
  'missionRunner', 'missionRunner', 'missionRunner',
  'trader',
];

interface Sim {
  id: string;
  role: Role;
  /** crafters work toward one recipe at a time; picking a new one each hour is
      not a routine any person would follow, and it never assembles a set */
  focusRecipeId: string;
  villageId: string;
  /** what they have earned and spent, split by source, for the faucet/sink table */
  earned: Record<string, number>;
  spent: Record<string, number>;
  lastRyo: number;
  firstTier3AtMs: number | null;
}

const VILLAGES = ['konohagakure', 'sunagakure', 'kirigakure', 'iwagakure', 'kumogakure'];

const stats = (): Stats => ({
  ninjutsu: 55, taijutsu: 55, genjutsu: 55, intelligence: 55,
  strength: 55, speed: 55, stamina: 55, handSeals: 55,
});

const basePlayer = (id: string, villageId: string, rank: Rank): PlayerRecord => ({
  id, name: id, villageId, clanId: null, clanJoinedAt: null, clanContribution: 0,
  bloodlineId: null, rank, level: 25, xp: 0, stats: stats(), affinity: 'fire',
  loadout: [], known: [], reputation: 60, ryo: 5_000, training: null, mission: null,
  missionsAtRank: 0, missionsCompleted: 10, squadId: null, rogue: false, defectedAt: null,
  notoriety: 0, titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0,
  sRankCompleted: 0, rating: 1000, ...newMetaState(0),
});

/* ── Bookkeeping ─────────────────────────────────────────────────────── */

const note = (sim: Sim, bucket: 'earned' | 'spent', source: string, amount: number): void => {
  if (amount <= 0) return;
  sim[bucket][source] = (sim[bucket][source] ?? 0) + amount;
};

/**
 * Attribute a player's change in ryo since the last look to whatever they just
 * did. Reading the delta rather than trusting the message keeps the accounting
 * honest: if a handler pays out somewhere the message does not mention, it still
 * shows up in the totals.
 */
const settle = (sim: Sim, ryoNow: number, source: string): void => {
  const delta = ryoNow - sim.lastRyo;
  if (delta > 0) note(sim, 'earned', source, delta);
  else if (delta < 0) note(sim, 'spent', source, -delta);
  sim.lastRyo = ryoNow;
};

/* ── The run ─────────────────────────────────────────────────────────── */

const store = new MemoryStore();
const clock = { t: 0 };
const svc = new GameService(store, () => clock.t);
const rng: Rng = makeRng(`economy:${SEED}`);

const sims: Sim[] = [];
for (let i = 0; i < PLAYERS; i++) {
  const role = ROLE_MIX[i % ROLE_MIX.length]!;
  const villageId = VILLAGES[i % VILLAGES.length]!;
  const id = `${role}-${i}`;
  await store.createPlayer(basePlayer(id, villageId, 'chunin'));
  sims.push({
    id, role, villageId,
    focusRecipeId: ECONOMY.recipes[i % ECONOMY.recipes.length]!.id,
    earned: {}, spent: {}, lastRyo: 5_000, firstTier3AtMs: null,
  });
}

const send = async (id: string, msg: Record<string, unknown>) => {
  const out = await svc.handle(id, msg as never);
  return out.map((d) => d.message);
};

const ryoOf = async (id: string): Promise<number> => (await store.getPlayer(id))!.ryo;

/**
 * Ryo alone is a misleading scoreboard.
 *
 * The first version of this report ranked gatherers dead last, which turned out
 * to mean only that their wealth was sitting in ore and in unsold listings
 * rather than in coin. Net worth counts what a player actually has: money, goods
 * at the going rate, and anything still escrowed on the market.
 */
async function netWorth(id: string): Promise<number> {
  const player = (await store.getPlayer(id))!;
  let total = player.ryo;
  for (const [itemId, qty] of Object.entries(player.inventory)) {
    const ref = await store.getMarketRef(itemId);
    total += (ref?.reference ?? ITEM_BY_ID.get(itemId)?.baseValue ?? 0) * qty;
  }
  for (const listing of await store.listListings()) {
    if (listing.sellerId === id) total += listing.qty * listing.unitPrice;
  }
  return total;
}

/** Which resources are gatherable somewhere, this season. */
function inSeasonResources(nowMs: number): { regionId: string; itemId: string }[] {
  const season = currentSeason(nowMs).id;
  const out: { regionId: string; itemId: string }[] = [];
  for (const region of TERRITORY.regions) {
    for (const itemId of region.resources) {
      if (ITEM_BY_ID.get(itemId)?.seasons.includes(season as never)) out.push({ regionId: region.id, itemId });
    }
  }
  return out;
}

const TIER3 = ECONOMY.recipes.filter((r) => r.inputs.some((i) => {
  const item = ITEM_BY_ID.get(i.item);
  return item?.kind === 'component';
}));

const dailyMission = MISSIONS.missions.find((m) => m.rank === 'C' && m.party === 1) ?? MISSIONS.missions[0]!;

let ticks = 0;
let dungeonEntries = 0;
for (let day = 0; day < DAYS; day++) {
  for (let step = 0; step < ACTIVE_HOURS * TICKS_PER_HOUR; step++) {
    clock.t = day * DAY + step * TICK_MS;
    ticks++;

    for (const sim of sims) {
      const player = (await store.getPlayer(sim.id))!;

      /* Anything that moved since this player was last looked at, and was not
         caused by their own action, is a sale of theirs that somebody else
         bought. Attributing the delta rather than trusting a message is what
         keeps the faucet table honest across asynchronous payouts. */
      settle(sim, player.ryo, 'marketSales');

      /* Claim anything that has finished, whatever the role. A player who never
         collects is not a player. */
      if (player.gathering) {
        await send(sim.id, { type: 'claimGathering' });
        settle(sim, await ryoOf(sim.id), 'gathering');
        continue;
      }
      if (player.crafting) {
        const out = await send(sim.id, { type: 'claimCrafting' });
        if (out.some((m) => m.type === 'craftingClaimed')) {
          const claimed = out.find((m) => m.type === 'craftingClaimed') as { recipeId: string };
          if (sim.firstTier3AtMs === null && TIER3.some((r) => r.id === claimed.recipeId)) {
            sim.firstTier3AtMs = clock.t;
          }
        }
        settle(sim, await ryoOf(sim.id), 'crafting');
        continue;
      }
      if (player.mission) {
        await send(sim.id, { type: 'completeMission' });
        settle(sim, await ryoOf(sim.id), 'missions');
        continue;
      }

      switch (sim.role) {
        case 'gatherer': {
          const options = inSeasonResources(clock.t);
          if (options.length === 0) break;
          const pick = options[Math.floor(rng.next() * options.length)]!;
          await send(sim.id, { type: 'startGathering', regionId: pick.regionId, itemId: pick.itemId });
          // Sell whatever has piled up, at the going rate.
          await sellSurplus(sim);
          break;
        }

        case 'crafter': {
          /* Work toward one recipe: try it, and if the materials are short, buy
             exactly what is missing. This is what makes a crafter a CUSTOMER —
             the demand side the market needs in order to have prices at all. */
          const recipe = ECONOMY.recipes.find((r) => r.id === sim.focusRecipeId)!;
          const started = await send(sim.id, { type: 'startCrafting', recipeId: recipe.id });
          if (started.some((m) => m.type === 'craftingStarted')) {
            await sellSurplus(sim, recipe.inputs.map((i) => i.item));
            break;
          }
          const missing = recipe.inputs.filter((i) => (player.inventory[i.item] ?? 0) < i.qty).map((i) => i.item);
          const bought = await buyInputs(sim, missing);
          // Nothing on the shelves worth buying: earn instead of idling.
          if (!bought) await send(sim.id, { type: 'acceptMission', missionId: dailyMission.id });
          await sellSurplus(sim, recipe.inputs.map((i) => i.item));
          break;
        }

        case 'delver': {
          /* A delver cannot be simulated end to end, and that is by design: the
             answers exist only as salted digests, so this process has no way to
             clear a room. Rather than fabricate answers — which would make the
             simulator lie about the one system whose secrets are the feature —
             the run measures the ENTRY side (attempts, keys, cooldowns) and the
             payout is worked out arithmetically in the report instead. */
          const list = await send(sim.id, { type: 'listDungeons' });
          const dungeons = (list.find((m) => m.type === 'dungeonList') as { dungeons: { id: string; open: boolean }[] } | undefined)?.dungeons ?? [];
          const open = dungeons.find((d) => d.open);
          if (open) {
            const entered = await send(sim.id, { type: 'enterDungeon', dungeonId: open.id });
            if (entered.some((m) => m.type === 'dungeonRoom')) dungeonEntries++;
            await send(sim.id, { type: 'abandonDungeon' });
          } else {
            await send(sim.id, { type: 'acceptMission', missionId: dailyMission.id });
          }
          break;
        }

        case 'missionRunner': {
          await send(sim.id, { type: 'acceptMission', missionId: dailyMission.id });
          break;
        }

        case 'trader': {
          await buyCheap(sim);
          await sellSurplus(sim);
          break;
        }
      }
    }
  }
}

/* ── Player behaviours that touch the market ─────────────────────────── */

async function marketView(id: string) {
  const out = await send(id, { type: 'listMarket' });
  return out.find((m) => m.type === 'market') as {
    referencePrices: Record<string, number>;
    listings: { listingId: string; itemId: string; qty: number; unitPrice: number; yours: boolean }[];
  } | undefined;
}

/**
 * List surplus, keeping anything the player is saving for their own recipe.
 *
 * Sellers ask a spread rather than all quoting the same number. Real sellers
 * disagree about what a thing is worth, and a market where everyone quotes the
 * reference exactly can never move the reference — which made the first version
 * of this report show every price pinned at its base value.
 */
async function sellSurplus(sim: Sim, keep: string[] = []): Promise<void> {
  const player = (await store.getPlayer(sim.id))!;
  const market = await marketView(sim.id);
  if (!market) return;
  for (const [itemId, qty] of Object.entries(player.inventory)) {
    const item = ITEM_BY_ID.get(itemId);
    if (!item?.tradable || keep.includes(itemId)) continue;
    // Components come in ones and twos; a threshold of six never sold any.
    const floor = item.kind === 'resource' ? 6 : 1;
    if (qty < floor) continue;
    const reference = market.referencePrices[itemId] ?? item.baseValue;
    const ask = 0.8 + rng.next() * 0.35;
    const price = Math.max(1, Math.round(reference * ask));
    const offered = item.kind === 'resource' ? Math.max(1, Math.floor(qty / 2)) : qty;
    await send(sim.id, { type: 'sellItem', itemId, qty: offered, unitPrice: price });
    settle(sim, await ryoOf(sim.id), 'marketFees');
    break; // one listing per tick keeps the rate limiter out of the results
  }
}

async function buyInputs(sim: Sim, wanted: string[]): Promise<boolean> {
  const market = await marketView(sim.id);
  if (!market) return false;
  // Cheapest first — a crafter's whole margin is the gap between what the
  // materials cost and what the output fetches.
  const options = market.listings
    .filter((l) => !l.yours && wanted.includes(l.itemId))
    .sort((a, b) => a.unitPrice - b.unitPrice);
  const match = options[0];
  if (!match) return false;
  const out = await send(sim.id, { type: 'buyListing', listingId: match.listingId });
  settle(sim, await ryoOf(sim.id), 'marketPurchases');
  return out.some((m) => m.type === 'bought');
}

/** A trader buys anything listed well under its reference and relists it. */
async function buyCheap(sim: Sim): Promise<void> {
  const market = await marketView(sim.id);
  if (!market) return;
  const bargain = market.listings.find((l) => {
    const reference = market.referencePrices[l.itemId];
    return !l.yours && reference !== undefined && l.unitPrice < reference * 0.8;
  });
  if (!bargain) return;
  await send(sim.id, { type: 'buyListing', listingId: bargain.listingId });
  settle(sim, await ryoOf(sim.id), 'marketPurchases');
}

/* ── Report ──────────────────────────────────────────────────────────── */

const total = <T extends string>(rows: Record<T, number>[], key: string): number =>
  rows.reduce((n, r) => n + ((r as Record<string, number>)[key] ?? 0), 0);

const sources = new Set<string>();
for (const s of sims) {
  for (const k of Object.keys(s.earned)) sources.add(k);
  for (const k of Object.keys(s.spent)) sources.add(k);
}

const finalRyo: number[] = [];
const finalWorth: number[] = [];
for (const s of sims) { finalRyo.push(await ryoOf(s.id)); finalWorth.push(await netWorth(s.id)); }
const startingSupply = PLAYERS * 5_000;
const endingSupply = finalRyo.reduce((a, b) => a + b, 0);

const sorted = [...finalWorth].sort((a, b) => a - b);
const median = sorted[Math.floor(sorted.length / 2)]!;
const p90 = sorted[Math.floor(sorted.length * 0.9)]!;
const p10 = sorted[Math.floor(sorted.length * 0.1)]!;

console.log(`\n${'='.repeat(72)}`);
console.log(`ECONOMY SIMULATION — ${PLAYERS} players, ${DAYS} days, seed "${SEED}"`);
console.log(`${'='.repeat(72)}`);
console.log(`${ticks} ticks — ${ACTIVE_HOURS} active hours a day at ${(TICK_MS / 60_000).toFixed(0)}-minute granularity.\n`);

console.log('MONEY SUPPLY');
console.log(`  started        ${startingSupply.toLocaleString()} ryo`);
console.log(`  ended          ${endingSupply.toLocaleString()} ryo`);
const growth = ((endingSupply - startingSupply) / startingSupply) * 100;
console.log(`  change         ${growth >= 0 ? '+' : ''}${growth.toFixed(1)}% over ${DAYS} days`);
console.log(`  per player/day ${((endingSupply - startingSupply) / PLAYERS / DAYS).toFixed(0)} ryo\n`);

console.log('FAUCETS AND SINKS');
for (const source of [...sources].sort()) {
  const inflow = total(sims.map((s) => s.earned), source);
  const outflow = total(sims.map((s) => s.spent), source);
  const net = inflow - outflow;
  console.log(`  ${source.padEnd(16)} +${inflow.toLocaleString().padStart(10)}  -${outflow.toLocaleString().padStart(10)}  net ${net >= 0 ? '+' : ''}${net.toLocaleString()}`);
}

console.log(`  held as goods  ${(finalWorth.reduce((a, b) => a + b, 0) - endingSupply).toLocaleString()} ryo of value sitting in inventories and open listings\n`);

console.log('WEALTH SPREAD (net worth: ryo + goods + escrow)');
console.log(`  poorest 10%    ${p10.toLocaleString()} ryo`);
console.log(`  median         ${median.toLocaleString()} ryo`);
console.log(`  richest 10%    ${p90.toLocaleString()} ryo`);
console.log(`  p90 / p10      ${(p90 / Math.max(1, p10)).toFixed(1)}x`);

console.log('\nBY ROLE (median net worth, and how much of it is liquid)');
for (const role of [...new Set(ROLE_MIX)]) {
  const members = sims.filter((s) => s.role === role);
  const worth: number[] = [];
  const liquid: number[] = [];
  for (const m of members) { worth.push(await netWorth(m.id)); liquid.push(await ryoOf(m.id)); }
  worth.sort((a, b) => a - b);
  liquid.sort((a, b) => a - b);
  const w = worth[Math.floor(worth.length / 2)] ?? 0;
  const l = liquid[Math.floor(liquid.length / 2)] ?? 0;
  console.log(`  ${role.padEnd(15)} ${w.toLocaleString().padStart(10)}  (${((l / Math.max(1, w)) * 100).toFixed(0)}% liquid, ${members.length} players)`);
}

const reached = sims.filter((s) => s.firstTier3AtMs !== null);
console.log('\nCRAFTING PROGRESSION');
if (reached.length === 0) {
  console.log('  nobody reached a component-consuming recipe — the tree is too slow or the inputs never reached the market');
} else {
  const days = reached.map((s) => s.firstTier3AtMs! / DAY).sort((a, b) => a - b);
  console.log(`  ${reached.length} of ${PLAYERS} reached a component recipe`);
  console.log(`  first at day ${days[0]!.toFixed(1)}, median day ${days[Math.floor(days.length / 2)]!.toFixed(1)}`);
}

console.log('\nMARKET PRICES (reference vs base value)');
for (const item of ECONOMY.items.filter((i) => i.tradable)) {
  const ref = await store.getMarketRef(item.id);
  if (!ref) continue;
  const drift = ((ref.reference - item.baseValue) / item.baseValue) * 100;
  console.log(`  ${item.id.padEnd(16)} base ${String(item.baseValue).padStart(5)}  now ${String(ref.reference).padStart(5)}  ${drift >= 0 ? '+' : ''}${drift.toFixed(0)}%`);
}

const listings = await store.listListings();
console.log(`\n  ${listings.length} listings still open at the end of the run`);

console.log('\nDUNGEON ARITHMETIC (not simulated — the answers are hashed)');
console.log(`  ${dungeonEntries} entries were made across the run.`);
for (const d of DUNGEONS.dungeons) {
  const perDay = Math.min(DUNGEONS.rules.maxRunsPerDay, Math.floor(24 / d.cooldownHours) || 1);
  console.log(`  ${d.id.padEnd(16)} ${d.rewards.ryo.toLocaleString().padStart(6)} ryo x ${perDay}/day = ${(d.rewards.ryo * perDay).toLocaleString()} ryo/day to someone who knows the answers`);
}
const bestFaucet = Math.max(...DUNGEONS.dungeons.map((d) => d.rewards.ryo * (Math.min(DUNGEONS.rules.maxRunsPerDay, Math.floor(24 / d.cooldownHours) || 1))));
const missionDaily = dailyMission.ryo * Math.floor((ACTIVE_HOURS * 60) / dailyMission.minutes);
console.log(`  for comparison, ${ACTIVE_HOURS} hours of "${dailyMission.id}" pays about ${missionDaily.toLocaleString()} ryo/day`);
console.log(`  ratio: a solved dungeon is worth ${(bestFaucet / Math.max(1, missionDaily)).toFixed(1)}x a day of missions`);

/* Territory is not simulated by behaviour — no clan AI — but the arithmetic of
   whether a war pays for itself is worth stating next to everything else. */
const w = TERRITORY.war;
const returned = Math.floor(w.declareCost * w.spoils.winnerBankShareOfStake);
console.log('\nTERRITORY ARITHMETIC');
console.log(`  a declaration costs   ${w.declareCost.toLocaleString()} ryo from the clan bank`);
console.log(`  a win returns         ${returned.toLocaleString()} ryo (${(w.spoils.winnerBankShareOfStake * 100).toFixed(0)}% of the stake)`);
console.log(`  so each war burns     ${(w.declareCost - returned).toLocaleString()} ryo even when it succeeds`);
console.log('  the region has to pay that back in gathering yield to be worth holding.');

if (VERBOSE) {
  console.log('\nPER-PLAYER');
  for (const s of sims) console.log(`  ${s.id.padEnd(20)} ${(await ryoOf(s.id)).toLocaleString().padStart(10)}`);
}
console.log('');
