import { ARCHETYPES, assertFixtureParity } from './sim.js';
const p = assertFixtureParity();
console.log(`archetypes: ${ARCHETYPES.length}`);
for (const a of ARCHETYPES) {
  const total = Object.values(a.stats).reduce((n, v) => n + v, 0);
  console.log(`  ${a.name.padEnd(12)} stats ${total}  ${a.bloodline ? '[' + a.bloodline + ']' : ''}`);
}
if (p.length) { console.log('\nPARITY PROBLEMS:'); for (const x of p) console.log('  -', x); process.exitCode = 1; }
else console.log('\nparity: clean');
