import { ARCHETYPES } from './sim.js';
import { createMatch, makeRng, resolveTurn, wardOf } from '@shinobi/engine';
import type { MatchState, SubmittedAction } from '@shinobi/shared';
import { JUTSU_BY_ID } from '@shinobi/content';

const A = ARCHETYPES.find((a) => a.name === (process.argv[2] ?? 'Artillery'))!;
const B = ARCHETYPES.find((a) => a.name === (process.argv[3] ?? 'Bulwark'))!;
const spec = (x: typeof A, id: string) => ({ id, name: x.name, level: 40, stats: x.stats, affinity: x.affinity, loadout: x.loadout, bloodlineId: x.bloodline ?? null });
let s: MatchState = createMatch('t', 't', spec(A, 'a'), spec(B, 'b'));
console.log(`${A.name}: hp ${s.fighters[0].maxHp} ward ${wardOf(s.fighters[0]).toFixed(0)} energy ${JSON.stringify(s.fighters[0].maxChakra)}`);
console.log(`${B.name}: hp ${s.fighters[1].maxHp} ward ${wardOf(s.fighters[1]).toFixed(0)} energy ${JSON.stringify(s.fighters[1].maxChakra)}`);
const rng = makeRng('t');
const dmg = { a: 0, b: 0 };
const bySrc = new Map<string, number>();
for (let i = 0; i < 25 && s.phase !== 'complete'; i++) {
  const acts: SubmittedAction[] = [];
  for (const [self, foe] of [[s.fighters[0], s.fighters[1]], [s.fighters[1], s.fighters[0]]] as const) {
    if (self.weave) continue;
    const pick = [...self.loadout].find((id) => {
      const j = JUTSU_BY_ID.get(id)!;
      return (self.cooldowns[id] ?? 0) === 0 && j.cost.physical <= self.chakra.physical
        && j.cost.mental <= self.chakra.mental && j.cost.natural <= self.chakra.natural
        && (!j.requires || self.stats[j.requires.stat] >= j.requires.min);
    }) ?? 'basic-strike';
    acts.push({ fighterId: self.id, actionId: pick, targetId: foe.id });
  }
  const r = resolveTurn(s, acts, rng);
  for (const e of r.events) {
    if (e.t === 'damage') { dmg[e.sourceId as 'a' | 'b'] += e.amount; bySrc.set(e.sourceId, (bySrc.get(e.sourceId) ?? 0) + e.amount); }
    if (e.t === 'statusTick') bySrc.set(`${e.fighterId}-dot`, (bySrc.get(`${e.fighterId}-dot`) ?? 0) + e.amount);
    if (e.t === 'combo') bySrc.set(`${e.fighterId}-combo`, (bySrc.get(`${e.fighterId}-combo`) ?? 0) + e.amount);
  }
  s = r.state;
  console.log(`R${String(i).padStart(2)} hp ${String(s.fighters[0].hp).padStart(4)}/${String(s.fighters[1].hp).padStart(4)}  ` +
    r.events.filter((e) => ['cast', 'weaveStart', 'sealFailed', 'combo'].includes(e.t)).map((e) => `${e.t === 'cast' ? e.fighterId + ':' + e.jutsuId : e.t === 'weaveStart' ? e.fighterId + ':weave ' + e.jutsuId : e.t === 'combo' ? 'COMBO ' + e.comboId + '(' + e.amount + ')' : 'FUMBLE'}`).join(' '));
}
console.log('direct damage', dmg, '\nbreakdown', Object.fromEntries(bySrc));
