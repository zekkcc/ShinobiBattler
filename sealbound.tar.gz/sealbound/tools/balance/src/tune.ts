/**
 * Automated balance tuner.
 *
 *   pnpm tune -- --iterations 3 --matches 6000
 *
 * Hand-tuning one dial at a time does not converge here: every lever trades one
 * archetype for another, and each pass surfaces a new interaction (raising
 * defence made `pierce` more valuable; fixing the stance read model inverted the
 * entire meta). That is not a sign the numbers are unknowable — it is a sign the
 * search should be mechanical.
 *
 * This does coordinate descent over a small vector of content parameters, scored
 * against the simulator. It writes nothing until it beats the starting score,
 * and it only ever touches content data — never engine code (CLAUDE.md §8).
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const ROOT = join(here, '..', '..', '..');
const TUNING_PATH = join(ROOT, 'packages/content/data/tuning.json');
const BUILDER = join(ROOT, 'packages/content/src/build-jutsu.ts');

/** A parameter the tuner may move, with the range it is allowed to explore. */
interface Knob {
  path: string;            // dotted path into tuning.json
  min: number;
  max: number;
  step: number;
  why: string;
  /** a second path kept identical to this one */
  linked?: string;
}

const KNOBS: Knob[] = [
  { path: 'mitigationK', min: 120, max: 320, step: 25, why: 'global damage compression' },
  { path: 'hp.perStamina', min: 2.5, max: 6.5, step: 0.4, why: 'Stamina already feeds both reserves and both defences' },
  { path: 'hp.base', min: 260, max: 520, step: 30, why: 'flat survivability floor' },
  { path: 'energy.physical.perStamina', min: 1.4, max: 3.0, step: 0.2, why: 'Stamina as an energy stat' },
  /* Linked: the two defences move together. Letting the optimiser split them
     made chakra defence the only place worth stacking Stamina, because most of
     the field attacks the ward. */
  { path: 'guard.perStamina', min: 0.6, max: 1.6, step: 0.15, why: 'value of defensive investment', linked: 'ward.perStamina' },
  { path: 'guard.perTaijutsu', min: 0.4, max: 1.1, step: 0.1, why: 'defence from skill', linked: 'ward.perIntelligence' },
  { path: 'stances.counterReduction', min: 0.35, max: 0.55, step: 0.05, why: 'how hard Counter punishes a read' },
  { path: 'stances.counterFraction', min: 0.3, max: 0.8, step: 0.05, why: 'Counter reflect share' },
  { path: 'stances.prepareDamageMult', min: 2.05, max: 3.0, step: 0.15, why: 'Prepare payoff' },
  { path: 'sealAccuracy.base', min: 0.7, max: 0.95, step: 0.04, why: 'baseline seal reliability' },
  { path: 'sealsPerTurn.perHandSeals', min: 0.008, max: 0.03, step: 0.003, why: 'weave speed from Hand Seals' },
  { path: 'energy.mental.regenBase', min: 4, max: 12, step: 1, why: 'ninjutsu and genjutsu tempo' },
  { path: 'clones.outgoingDamageMultiplier', min: 0.1, max: 0.5, step: 0.05, why: 'clone offensive value' },
  { path: 'control.hardImmunityTurns', min: 1, max: 4, step: 1, why: 'how much control counterplay exists' },

  /* Role pricing. This is where the real mispricing lives: a `damage` role and a
     `shield` role cost the same loadout slot but are not worth the same, so an
     all-offence build was worth roughly three times a mixed one. */
  { path: 'roles.pierce', min: 0.6, max: 1.0, step: 0.05, why: 'pierce ignores defence, so it scales with defence buffs' },
  { path: 'roles.multi', min: 0.28, max: 0.5, step: 0.03, why: 'multi-hit deletes clone walls and rolls mitigation per hit' },
  { path: 'roles.nuke', min: 1.1, max: 2.4, step: 0.1, why: 'whether an S-rank justifies its setup' },
  { path: 'roles.dot', min: 0.35, max: 0.7, step: 0.05, why: 'damage-over-time bypasses shields' },
  { path: 'roles.shield', min: 0.7, max: 1.8, step: 0.1, why: 'whether a defensive slot is worth an offensive one' },
  { path: 'roles.heal', min: 0.3, max: 1.0, step: 0.05, why: 'whether sustain is a win condition' },
  { path: 'roles.drain', min: 0.5, max: 0.95, step: 0.05, why: 'leech as a hybrid slot' },
  { path: 'roles.control', min: 0.2, max: 0.5, step: 0.05, why: 'damage attached to control' },
  { path: 'roles.regen', min: 0.2, max: 0.6, step: 0.05, why: 'heal-over-time as a slot' },
  { path: 'roles.strike', min: 0.75, max: 1.15, step: 0.05, why: 'the yardstick every other role is priced against' },
  { path: 'gateDrainScale', min: 0.3, max: 1.6, step: 0.15, why: 'whether opening a gate is ever correct' },
  { path: 'roles.bodyTechnique', min: 0.4, max: 0.85, step: 0.04, why: 'taijutsu never fumbles and is never interrupted' },
];

/* ── tuning.json access ──────────────────────────────────────────────── */

type Json = Record<string, unknown>;
const readTuning = (): Json => JSON.parse(readFileSync(TUNING_PATH, 'utf8')) as Json;
const writeTuning = (t: Json) => writeFileSync(TUNING_PATH, JSON.stringify(t, null, 2) + '\n');

function getAt(obj: Json, path: string): number {
  let cur: unknown = obj;
  for (const k of path.split('.')) cur = (cur as Json)[k];
  return cur as number;
}
function setAt(obj: Json, path: string, value: number): void {
  const keys = path.split('.');
  let cur: Json = obj;
  for (const k of keys.slice(0, -1)) cur = cur[k] as Json;
  cur[keys[keys.length - 1]!] = value;
}

/* ── scoring ─────────────────────────────────────────────────────────── */

/**
 * Lower is better. Squared deviation from an even 50% against the field, plus a
 * penalty for anything outside the 43-57 band so the optimiser prefers "everyone
 * mediocre" over "most perfect, one broken".
 */
function score(matches: number): { score: number; rates: number[]; inBand: number } {
  // The simulator exits non-zero when archetypes are out of band — which is the
  // normal case while tuning — so read stdout off the failure too.
  let out: string;
  try {
    out = execFileSync('npx', ['tsx', join(ROOT, 'tools/balance/src/sim.ts'), '--matches', String(matches)],
      { cwd: ROOT, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 });
  } catch (err) {
    out = String((err as { stdout?: string }).stdout ?? '');
  }
  const rates: number[] = [];
  const section = out.split('vs. the field')[1] ?? '';
  for (const line of section.split('\n')) {
    if (line.includes('distribution') || line.trim() === '') continue;
    const m = /^\s+\S[\w ]*?\s+(\d+\.\d)%/.exec(line);
    if (m) rates.push(Number(m[1]));
    if (rates.length && !m) break;
  }
  if (rates.length === 0) throw new Error('could not parse simulator output');
  let s = 0, inBand = 0;
  for (const r of rates) {
    s += (r - 50) ** 2;
    if (r >= 43 && r <= 57) inBand++;
    else s += 150; // out-of-band penalty
  }
  return { score: s, rates, inBand };
}

/**
 * The optimiser has no idea what the game is supposed to feel like — it will
 * happily invert a stated design property to shave a few points off the score.
 * It already tried: it pushed mental energy regeneration above physical, which
 * the direction document explicitly reverses. So the drift check is a hard
 * constraint on the search, not a report you read afterwards.
 */
function violatesDesign(): boolean {
  try {
    execFileSync('npx', ['tsx', join(ROOT, 'tools/qa/drift-check.ts')], { cwd: ROOT, encoding: 'utf8' });
    return false;
  } catch {
    return true;
  }
}

function rebuildContent(): void {
  execFileSync('npx', ['tsx', BUILDER], { cwd: ROOT, encoding: 'utf8' });
}

/* ── search ──────────────────────────────────────────────────────────── */

function arg(name: string, dflt: number): number {
  const i = process.argv.indexOf(`--${name}`);
  if (i === -1) return dflt;
  const v = Number(process.argv[i + 1]);
  return Number.isFinite(v) ? v : dflt;
}

function main(): void {
  const iterations = arg('iterations', 2);
  const matches = arg('matches', 6000);

  const original = readTuning();
  let best = JSON.parse(JSON.stringify(original)) as Json;
  rebuildContent();
  let bestScore = score(matches);
  const startScore = bestScore;
  console.log(`start: score ${bestScore.score.toFixed(0)}, ${bestScore.inBand}/${bestScore.rates.length} in band`);

  for (let iter = 0; iter < iterations; iter++) {
    console.log(`\n── pass ${iter + 1} ──`);
    for (const knob of KNOBS) {
      const current = getAt(best, knob.path);
      let improvedTo: number | null = null;

      for (const dir of [1, -1]) {
        const candidate = Math.round((current + dir * knob.step) * 10000) / 10000;
        if (candidate < knob.min || candidate > knob.max) continue;

        const trial = JSON.parse(JSON.stringify(best)) as Json;
        setAt(trial, knob.path, candidate);
        if (knob.linked) setAt(trial, knob.linked, candidate);
        writeTuning(trial);
        rebuildContent();
        if (violatesDesign()) continue;

        let s;
        try { s = score(matches); } catch { continue; }

        if (s.score < bestScore.score) {
          bestScore = s;
          best = trial;
          improvedTo = candidate;
          break; // take the first improvement; the next pass will push further
        }
      }

      writeTuning(best);
      rebuildContent();
      if (improvedTo !== null) {
        console.log(`  ${knob.path}: ${current} -> ${improvedTo}  ` +
          `score ${bestScore.score.toFixed(0)}, ${bestScore.inBand} in band   (${knob.why})`);
      }
    }
  }

  if (bestScore.score < startScore.score) {
    writeTuning(best);
    rebuildContent();
    console.log(`\nimproved: ${startScore.score.toFixed(0)} -> ${bestScore.score.toFixed(0)}, ` +
      `${startScore.inBand} -> ${bestScore.inBand} archetypes in band`);
    console.log('tuning.json updated. Re-run `pnpm sim`, `pnpm test` and `pnpm drift` before committing.');
  } else {
    writeTuning(original);
    rebuildContent();
    console.log('\nno improvement found; tuning.json left unchanged');
  }
}

main();
