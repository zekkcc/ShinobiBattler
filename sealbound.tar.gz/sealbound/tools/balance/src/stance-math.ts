/**
 * Is a stance ever worth the turn it costs?
 *
 * A stance consumes your action, so it has to beat "just attack again". This
 * prints the break-even arithmetic for each one against a representative
 * exchange, because if the answer is "never" then the entire tactical layer the
 * design direction asks for is decorative.
 */
import { TUNING } from '@shinobi/content';

const INCOMING = 200;   // a solid hit from an equal-budget attacker
const MY_ATTACK = 140;  // what I'd have dealt if I had simply attacked instead

const st = TUNING.stances;

console.log(`assumptions: incoming hit ${INCOMING}, my forgone attack ${MY_ATTACK}\n`);

const prevented = INCOMING * st.counterReduction;
const landed = INCOMING - prevented;
const reflected = landed * st.counterFraction;
const counterValue = prevented + reflected;
console.log('COUNTER');
console.log(`  blocks ${st.counterReduction} of ${INCOMING} = ${prevented.toFixed(0)} prevented`);
console.log(`  reflects ${st.counterFraction} of the ${landed.toFixed(0)} that landed = ${reflected.toFixed(0)} dealt`);
console.log(`  total value ${counterValue.toFixed(0)} vs forgone attack ${MY_ATTACK}`);
console.log(`  swing: ${(counterValue - MY_ATTACK).toFixed(0)}  ` +
  `${counterValue > MY_ATTACK ? 'WORTH IT on a correct read' : '<-- NEVER WORTH IT'}\n`);

console.log('PREPARE');
const gain = MY_ATTACK * (st.prepareDamageMult - 1);
console.log(`  next cast x${st.prepareDamageMult} = +${gain.toFixed(0)} damage on one attack`);
console.log(`  two plain attacks = ${(MY_ATTACK * 2).toFixed(0)}; prepare then attack = ${(MY_ATTACK * st.prepareDamageMult).toFixed(0)}`);
console.log(`  swing: ${(MY_ATTACK * st.prepareDamageMult - MY_ATTACK * 2).toFixed(0)}  ` +
  `${st.prepareDamageMult > 2 ? 'WORTH IT' : '<-- NEVER WORTH IT (needs >2.0 to beat attacking twice)'}`);
console.log(`  (seal bonus +${st.prepareSealBonus}/turn can still save weave turns on a long cast)\n`);

console.log('SUBSTITUTE');
console.log(`  negates one hit above ${(TUNING.substitution.damageThresholdFraction * 100).toFixed(0)}% max HP at ~${(st.substituteBaseChance * 100).toFixed(0)}% base`);
console.log(`  prevented ${INCOMING} vs forgone ${MY_ATTACK} -> swing ${(INCOMING - MY_ATTACK).toFixed(0)}  ` +
  `${INCOMING * st.substituteBaseChance > MY_ATTACK ? 'WORTH IT on a correct read' : '<-- NEVER WORTH IT'}`);
