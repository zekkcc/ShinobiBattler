/**
 * Anti-drift check against docs/DESIGN-DIRECTION.txt.
 *
 * Balance tuning is the easiest place to quietly undo a design property, so this
 * asserts the properties themselves rather than any particular number.
 */
import {
  BASELINE_ACTIONS, BLOODLINES, COMBOS, COSMETICS, DUNGEONS, ECONOMY, JUTSU, LEGACY, MISSIONS,
  MENTORSHIP, MISSIONS, POLITICS, ROGUE, SEASONS, TERRITORY, TUNING, currentSeason, rollBloodline,
} from '@shinobi/content';
import { readFileSync } from 'node:fs';
import { createFighter, makeRng } from '@shinobi/engine';

const fails: string[] = [];
const ok: string[] = [];
const check = (name: string, cond: boolean, why: string) => (cond ? ok : fails).push(cond ? name : `${name}: ${why}`);

// 1. Combat is a set of live choices, not one attack button.
const wanted = ['basic-strike', 'counter-stance-basic', 'prepare-seals', 'substitute',
  'chakra-focus', 'throw-weapon', 'gather-natural-energy'];
check('every listed combat choice exists',
  wanted.every((id) => JUTSU.some((j) => j.id === id)),
  `missing: ${wanted.filter((id) => !JUTSU.some((j) => j.id === id)).join(', ')}`);
check('choices are free at the point of use',
  wanted.every((id) => { const j = JUTSU.find((x) => x.id === id)!; return j.cost.physical + j.cost.mental + j.cost.natural === 0; }),
  'a baseline choice costs energy, which makes it conditional rather than always available');
check('summon and transform exist as techniques',
  JUTSU.some((j) => j.id === 'transformation-jutsu') && JUTSU.some((j) => j.effects.some((e) => e.kind === 'cloneSplit')),
  'no transform or summon-shaped technique');

// 2. Chakra management is a skill: three reserves, asymmetric recovery.
const e = TUNING.energy;
check('physical energy recovers faster than mental', e.physical.regenBase > e.mental.regenBase,
  `physical ${e.physical.regenBase} vs mental ${e.mental.regenBase} — the design says physical returns quickly and mental slowly`);
check('natural energy never regenerates', e.natural.regenBase === 0 && e.natural.regenPerStamina === 0,
  'natural energy regenerates, so it no longer has to be gathered');
const f = createFighter({ id: 'x', name: 'x', level: 30, affinity: 'fire', loadout: [],
  stats: { ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60, strength: 60, speed: 60, stamina: 60, handSeals: 60 } });
check('natural energy starts empty', f.chakra.natural === 0, 'characters begin with natural energy already gathered');
check('the three reserves are actually distinct',
  new Set([f.maxChakra.physical, f.maxChakra.mental, f.maxChakra.natural]).size > 1,
  'the reserves have collapsed to the same value, which makes them one pool wearing three hats');

// 3. Bloodlines stay rare and lore-weighted.
let granted = 0;
const rng = makeRng('drift');
for (let i = 0; i < 20000; i++) if (rollBloodline(rng.next(), rng.next()) !== null) granted++;
check('bloodlines are rare', Math.abs(granted / 20000 - 0.2) < 0.02,
  `${((granted / 20000) * 100).toFixed(1)}% of characters roll one, target 20%`);
const rarest = BLOODLINES.reduce((a, b) => (b.rarity < a.rarity ? b : a));
const commonest = BLOODLINES.reduce((a, b) => (b.rarity > a.rarity ? b : a));
check('rarity follows lore scarcity', commonest.rarity >= rarest.rarity * 10,
  `spread is flat: ${rarest.id}=${rarest.rarity} vs ${commonest.id}=${commonest.rarity}`);

// 4. Nothing purchasable affects combat power. Enforced by there being no price
//    field on any combat record at all — the absence is the guarantee.
check('no combat record carries a price',
  !JSON.stringify(JUTSU).includes('"price"') && !JSON.stringify(BLOODLINES).includes('"price"'),
  'a price field appeared on a combat record — combat power must never be purchasable');

// 4b. The tactical layer must stay worth using. A stance costs your whole action,
//     so if it cannot beat "just attack again" it is decorative — and an automated
//     tuner will happily optimise it into that state.
{
  const st = TUNING.stances;
  const INCOMING = 200, FORGONE = 140;
  const counterValue = INCOMING * st.counterReduction
    + (INCOMING - INCOMING * st.counterReduction) * st.counterFraction;
  check('Counter beats simply attacking', counterValue > FORGONE,
    `Counter is worth ${counterValue.toFixed(0)} against a forgone attack of ${FORGONE} — nobody would ever take the stance`);
  check('Prepare beats attacking twice', st.prepareDamageMult > 2,
    `x${st.prepareDamageMult} on one cast loses to two plain attacks, so Prepare is never correct`);
  check('Substitute beats simply attacking on a correct read',
    INCOMING * st.substituteBaseChance > FORGONE,
    `expected value ${(INCOMING * st.substituteBaseChance).toFixed(0)} vs forgone ${FORGONE}`);
}

// 4c. Money now exists, so the pay-to-win constraint needs teeth. Rank is the
//      gate on power, and rank cannot be bought — no promotion requirement may
//      reference currency, and every purchasable technique must be rank-locked.
{
  const gates = MISSIONS.promotions.flatMap((p) => Object.keys(p));
  check('rank cannot be bought', !gates.some((k) => /ryo|price|cost|money|gold/i.test(k)),
    'a promotion requirement references currency — rank must be earned, never purchased');
  check('every technique tier is rank-gated as well as priced',
    Object.keys(MISSIONS.jutsuPrices).every((rank) => rank in MISSIONS.teacherRankRequired),
    'a technique rank has a price but no rank requirement, so money alone would buy it');
  const paidTiers = Object.entries(MISSIONS.jutsuPrices).filter(([, v]) => v > 0).map(([k]) => k);
  check('paid techniques are not available at the starting rank',
    paidTiers.every((r) => MISSIONS.teacherRankRequired[r as keyof typeof MISSIONS.teacherRankRequired] !== undefined),
    'a paid technique has no rank requirement');
  check('titles and standing are earned, not priced',
    !JSON.stringify(MISSIONS.reputationTiers).includes('"price"')
      || MISSIONS.reputationTiers.every((t) => typeof t.priceMultiplier === 'number'),
    'reputation appears to be purchasable');
}

// 4d. The missing-nin economy rests on one inequality: a hunter collects less
//      than the rogue loses, so a colluding pair destroys value every cycle.
//      If hunterShare ever reaches 1, bounty farming becomes free money.
{
  check('hunting destroys value rather than moving it', ROGUE.bounty.hunterShare < 1,
    `hunterShare is ${ROGUE.bounty.hunterShare} — a colluding pair would break even or profit`);
  check('a bounty must be earned before it can be posted', ROGUE.contract.minNotorietyToPost > 0,
    'a rogue with no notoriety could be farmed the moment they defect');
  check('the same pair cannot loop immediately', ROGUE.contract.cooldownMinutesSamePair > 0,
    'no cooldown between the same hunter and target');
  check('coming back costs money', ROGUE.amnesty.baseCost > 0,
    'amnesty is free, so defection carries no risk');
}

// 4e. The two defences must value Stamina equally. Nothing in the design makes
//      chakra defence the better place to stack it, and because most attacks in
//      any realistic field are ninjutsu or genjutsu, an asymmetry here makes
//      Stamina the single best stat in the game.
check('both defences value Stamina equally', TUNING.guard.perStamina === TUNING.ward.perStamina,
  `guard ${TUNING.guard.perStamina} vs ward ${TUNING.ward.perStamina} — whichever is higher becomes the only stat worth stacking`);
check('both defences value their skill stat equally', TUNING.guard.perTaijutsu === TUNING.ward.perIntelligence,
  `guard/taijutsu ${TUNING.guard.perTaijutsu} vs ward/intelligence ${TUNING.ward.perIntelligence}`);

// 4f. Legacy is the "chase legacy, not gear" pillar. Two rules hold it up: a
//      legendary confers standing rather than power, and titles are earned.
//      Giving a legendary a permanent stat bonus would hand whoever reached a
//      milestone first an advantage nobody after them can ever take away.
{
  check('legendaries confer no combat power', LEGACY.rules.grantsCombatPower === false,
    'a legendary grants combat power — whoever claimed it first would be permanently stronger');
  check('legendaries are unique per server', LEGACY.rules.uniquePerServer === true,
    'legendaries can be duplicated');
  check('titles and legendaries are not purchasable', LEGACY.rules.purchasable === false,
    'legacy items can be bought');
  const raw = JSON.stringify(LEGACY);
  check('no legacy record carries a price or a stat',
    !/"(price|cost|ryo|stat|bonus|mult)"/i.test(raw),
    'a legacy record has a price or a stat field');
  check('every title is reachable', LEGACY.titles.every((t) => t.threshold >= 0),
    'a title has an unreachable threshold');
  check('every legendary is reachable', LEGACY.legendaries.every((l) => l.threshold > 0),
    'a legendary has an unreachable threshold');
}

// 5. Combos remain reachable.
check('every combo is reachable',
  COMBOS.every((c) => JUTSU.some((j) => j.effects.some((x) => x.kind === 'applyStatus' && x.status === c.setup))
    && JUTSU.some((j) => j.nature === c.trigger)),
  'a combo has no setup or no trigger technique');

// 6. Interrupted and fumbled seals both matter.
check('sealed techniques can fumble', TUNING.sealAccuracy.max < 1 && JUTSU.some((j) => j.seals > 0 && j.sealDifficulty > 0),
  'no technique can fail its seals');

// 7. Seasons exist and actually turn. A season that never occurs is a season
//    whose content is unreachable.
{
  const day = 24 * 60 * 60 * 1000;
  const seen = new Set<string>();
  for (let d = 0; d < SEASONS.cycleDays; d++) seen.add(currentSeason(d * day).id);
  check('all four seasons occur', seen.size === SEASONS.seasons.length,
    `only ${seen.size} of ${SEASONS.seasons.length} seasons are reachable in a cycle`);
  check('some resources are seasonal', ECONOMY.items.some((i) => i.kind === 'resource' && i.seasons.length < 4),
    'every resource is available all year, so the seasons do not gate anything');
}

// 8. Territory pays in economy and training, never in combat statistics.
//    This is the deliberate reading of the direction doc's "PvP buffs": the
//    defender's edge is a multiplier on war SCORE, which is visible on the board
//    and cannot leak into a ladder match. A stat bonus for holding ground would
//    snowball and would invalidate every number in tuning.json.
{
  const raw = JSON.stringify(TERRITORY);
  check('territory grants no combat statistic',
    !/"(stat|stats|damage|power|hp|chakra|mitigation|multiplierVsPlayer)"\s*:/.test(raw),
    'a region or war rule carries a combat field');
  check("the defender's advantage is bounded", TERRITORY.war.defenderScoreMultiplier <= 1.5,
    `defenders score x${TERRITORY.war.defenderScoreMultiplier}, which makes a held region close to untakeable`);
  check('a member cannot decide a war alone',
    TERRITORY.war.score.maxPerMemberPerPeriod > 0
      && TERRITORY.war.score.maxPerMemberPerPeriod < TERRITORY.war.score.pvpWin * 1000,
    'there is no per-member contribution cap');
  check('holding ground has to be paid for again',
    TERRITORY.war.spoils.winnerBankShareOfStake < 1,
    'the whole stake comes back, so two clans can trade a region for free');
  check('mercenaries cannot be hired mid-war', TERRITORY.war.minTenureMinutesToScore > 0,
    'a clan can recruit for a war already in progress');
}

// 9. The market has to be lossy, or two accounts are a printing press.
{
  const m = ECONOMY.market;
  /* The sale tax is the seller's VILLAGE tax rate, not a constant in
     economy.json — so the floor of the political tax band is half of this
     property, and has to be checked where it actually lives. */
  check('a wash trade destroys money', m.listingFeeFraction > 0 && POLITICS.tax.min > 0,
    `listing costs ${m.listingFeeFraction} and the tax floor is ${POLITICS.tax.min}: `
    + 'if either can reach zero, collusion between two accounts costs nothing');
  check('no elected government can make trading free', POLITICS.tax.min > 0,
    'a Kage can set the sale tax to zero, which removes half the wash-trade cost');
  check('prices are banded', m.priceFloorFraction > 0 && m.priceCeilingFraction > 1,
    'a listing can be priced arbitrarily, which is how currency is laundered between accounts');
  check('the reference price returns to base', m.referenceReturnPerDay > 0,
    'a pumped reference price stays pumped, so the band can be parked anywhere');

  /* Direct trade and gifting were ADDED by owner decision on 2026-08-04, which
     removed the property that value is destroyed between accounts. Two accounts
     can now move currency freely, and no check here can pretend otherwise.
     What replaced it is attribution rather than prevention, so these are the
     properties that must now hold. See docs/OVERRIDES.md. */
  const fs = readFileSync('apps/server/src/trading.ts', 'utf8');
  check('every completed transfer is recorded',
    /recordTransfer\(/.test(fs) && /CREATE TABLE transfers/.test(readFileSync('apps/server/src/schema.sql', 'utf8')),
    'direct transfers are not written to the append-only log, so a collusion ring leaves no trace');
  check('the transfer log cannot be erased',
    !/DELETE FROM transfers|deleteTransfer/.test(readFileSync('apps/server/src/store/postgres.ts', 'utf8')),
    'something can delete rows from the transfer log');
  check('the tradable flag governs gifts as well as sales',
    /if \(!item\.tradable\) throw new TradeError/.test(fs),
    'gifting bypasses the tradable flag, which makes every untradable reward tradable');
  check('a trade settles atomically',
    /deleteTrade\(trade\.id\)/.test(fs) && fs.indexOf('deleteTrade(trade.id)') < fs.indexOf('transfer(proposer, accepter'),
    'goods move before the proposal row is claimed, so two acceptances can both pay out');
  check('some rewards are still untradable',
    ECONOMY.items.some((i) => !i.tradable),
    'every item can now be transferred, so no reward can be made unfarmable');

  // Every new mutating message must be rate limited by name rather than falling
  // through to the default, which is generous enough to brute-force a puzzle.
  check('nothing crafted or bought can be worn into a match',
    ECONOMY.items.every((i) => !i.use || Object.keys(i.use).every((k) =>
      ['trainingRateBonus', 'gatherYieldBonus', 'dungeonAttempts', 'uses'].includes(k))),
    'a consumable grants something a match could read');
}

// 9b. Crafting has to be worth doing, and the biggest faucet has to be gated.
{
  const value = (id: string, qty: number) => (ECONOMY.items.find((i) => i.id === id)?.baseValue ?? 0) * qty;
  const losers = ECONOMY.recipes.filter((r) =>
    value(r.output.item, r.output.qty) <= r.inputs.reduce((n, i) => n + value(i.item, i.qty), 0));
  check('no recipe destroys value', losers.length === 0,
    `crafting these loses money: ${losers.map((r) => r.id).join(', ')}`);

  /* A dungeon pays out on a puzzle that is only hard the FIRST time — the answer
     is shared the day after launch. Its ryo therefore has to sit near what the
     same time pays doing missions, with the jutsu, cosmetic and legendary
     carrying the prestige instead. */
  const missionWage = Math.max(...MISSIONS.missions.filter((m) => m.party === 1).map((m) => m.ryo / (m.minutes / 60)));
  const dayOfMissions = missionWage * 6;
  const worst = Math.max(...DUNGEONS.dungeons.map((d) => d.rewards.ryo));
  check('a solved dungeon does not dwarf a day of play', worst <= dayOfMissions * 3,
    `the best dungeon pays ${worst} against ${dayOfMissions.toFixed(0)} for a day of missions`);
  check('the richest dungeon is gated behind something',
    DUNGEONS.dungeons.every((d) => d.rewards.ryo < worst || d.keyItem !== null),
    'the highest-paying dungeon costs nothing to enter');
}

// 10. Politics: bounded powers, no salary, and a vote that costs real play.
{
  check('tax is banded', POLITICS.tax.min > 0 && POLITICS.tax.max < 1,
    'the tax rate can be set to zero or to everything');
  check('tax cannot be ratcheted freely', POLITICS.tax.changePerCycleMax < POLITICS.tax.max,
    'an office holder can move the rate the whole width of the band in one step');
  check('no office pays its holder',
    !/"(payout|salary|withdraw|toPlayer|stipendTo)"\s*:/i.test(JSON.stringify(POLITICS)),
    'a political power moves village money to a person, which makes the office worth buying');
  check('no commission buys combat power',
    POLITICS.treasury.commissions.every((c) => Object.keys(c.effect).every((k) =>
      ['trainingBonusVillage', 'gatherBonusVillage', 'defenceScoreBonus', 'missionInjuryReduction'].includes(k))),
    'a commission grants something that reaches a match');
  check('a vote costs real play',
    POLITICS.suffrage.minMissionsCompleted > 0 && POLITICS.suffrage.minAccountAgeMinutes > 0,
    'an election could be decided by accounts made this morning');
  check('an election leaves time to govern',
    POLITICS.nominationDays + POLITICS.votingDays < POLITICS.cycleDays,
    'the cycle is entirely campaign');
}

// 11. Dungeon answers never exist in plaintext, anywhere.
{
  const raw = JSON.stringify(DUNGEONS);
  check('puzzle answers are stored only as digests',
    !/"answer"\s*:/.test(raw) && !/"solution"\s*:/.test(raw),
    'a dungeon room carries a plaintext answer');
  check('each room is salted separately',
    new Set(DUNGEONS.dungeons.flatMap((d) => d.rooms.map((r) => r.salt))).size
      === DUNGEONS.dungeons.reduce((n, d) => n + d.rooms.length, 0),
    'two rooms share a salt, so solving one weakens the other');
  check('a wrong answer costs time', DUNGEONS.rules.wrongAnswerCooldownMinutes > 0,
    'answers can be brute-forced as fast as the rate limiter allows');
  check('a known dungeon is not a faucet',
    DUNGEONS.dungeons.every((d) => d.cooldownHours > 0) && DUNGEONS.rules.maxRunsPerDay > 0,
    'a player who has learned the answers can farm the reward all day');
}

// 12. Mentoring must not be farmable by a second account.
{
  const reward = MENTORSHIP.mentor.rewardPerMilestone;
  check('a mentor is never paid in anything sellable',
    !/ryo|item|gold|money/i.test(JSON.stringify(reward)),
    'mentoring pays currency, so a veteran and their own alt is a business');
  check('a pairing has to mature before it pays',
    MENTORSHIP.pairing.minDurationMinutesBeforeRewards > 0,
    'a pairing can be formed, milked and dissolved in a loop');
  check('a student is mentored once', MENTORSHIP.mentee.mentoredOnce,
    'the beginner bonus can be renewed forever');
  check('the mentor reward is capped per week',
    MENTORSHIP.mentor.maxRewardedMilestonesPerMenteePerWeek > 0,
    'there is no ceiling on what one mentee can pay out');
}

// 13. Cosmetics are the one thing money may buy, and they do nothing.
{
  check('cosmetics affect nothing', COSMETICS.rules.affectsCombat === false
    && COSMETICS.rules.affectsProgression === false,
    'a cosmetic claims to affect combat or progression');
  check('cosmetics are untradable', COSMETICS.rules.tradable === false,
    'cosmetics can be traded, which turns every rare drop into currency');
  check('no cosmetic carries a stat',
    !/"(stat|stats|power|bonus|multiplier|effect|damage)"\s*:/.test(JSON.stringify(COSMETICS)),
    'a cosmetic record has a stat or effect field');
  check('earned cosmetics are not also for sale',
    COSMETICS.items.every((c) => !(c.source === 'title' || c.source === 'dungeon' || c.source === 'mentor') || c.price === undefined),
    'a cosmetic that is supposed to be earned also has a price');
  check('cosmetics and tradable goods are disjoint',
    COSMETICS.items.every((c) => !ECONOMY.items.some((i) => i.id === c.id)),
    'a cosmetic id also exists as a tradable item');
}

console.log(`\ndrift check: ${ok.length} held, ${fails.length} drifted`);
for (const f2 of fails) console.log(`  ✗ ${f2}`);
if (fails.length) process.exitCode = 1; else console.log('  all design properties intact');
