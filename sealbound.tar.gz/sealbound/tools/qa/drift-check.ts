/**
 * Anti-drift check against docs/DESIGN-DIRECTION.txt.
 *
 * Balance tuning is the easiest place to quietly undo a design property, so this
 * asserts the properties themselves rather than any particular number.
 */
import { BASELINE_ACTIONS, BLOODLINES, COMBOS, JUTSU, LEGACY, MISSIONS, ROGUE, TUNING, rollBloodline } from '@shinobi/content';
import { createFighter, makeRng } from '@shinobi/engine';

const fails: string[] = [];
const ok: string[] = [];
const check = (name: string, cond: boolean, why: string) => (cond ? ok : fails).push(cond ? name : `${name}: ${why}`);

// 1. Combat is a set of live choices, not one attack button.
const wanted = ['basic-strike', 'counter-stance-basic', 'prepare-seals', 'substitute',
  'chakra-focus', 'throw-weapon', 'gather-natural-energy'];
check('every listed combat choice exists',
  wanted.every((id) => JUTSU.some((j) => j.id === id)),
  `missing: ${wanted.filter((id) => !JUTSU.some((j) => j.id === id)).join(', ')}`);
check('choices are free at the point of use',
  wanted.every((id) => { const j = JUTSU.find((x) => x.id === id)!; return j.cost.physical + j.cost.mental + j.cost.natural === 0; }),
  'a baseline choice costs energy, which makes it conditional rather than always available');
check('summon and transform exist as techniques',
  JUTSU.some((j) => j.id === 'transformation-jutsu') && JUTSU.some((j) => j.effects.some((e) => e.kind === 'cloneSplit')),
  'no transform or summon-shaped technique');

// 2. Chakra management is a skill: three reserves, asymmetric recovery.
const e = TUNING.energy;
check('physical energy recovers faster than mental', e.physical.regenBase > e.mental.regenBase,
  `physical ${e.physical.regenBase} vs mental ${e.mental.regenBase} — the design says physical returns quickly and mental slowly`);
check('natural energy never regenerates', e.natural.regenBase === 0 && e.natural.regenPerStamina === 0,
  'natural energy regenerates, so it no longer has to be gathered');
const f = createFighter({ id: 'x', name: 'x', level: 30, affinity: 'fire', loadout: [],
  stats: { ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60, strength: 60, speed: 60, stamina: 60, handSeals: 60 } });
check('natural energy starts empty', f.chakra.natural === 0, 'characters begin with natural energy already gathered');
check('the three reserves are actually distinct',
  new Set([f.maxChakra.physical, f.maxChakra.mental, f.maxChakra.natural]).size > 1,
  'the reserves have collapsed to the same value, which makes them one pool wearing three hats');

// 3. Bloodlines stay rare and lore-weighted.
let granted = 0;
const rng = makeRng('drift');
for (let i = 0; i < 20000; i++) if (rollBloodline(rng.next(), rng.next()) !== null) granted++;
check('bloodlines are rare', Math.abs(granted / 20000 - 0.2) < 0.02,
  `${((granted / 20000) * 100).toFixed(1)}% of characters roll one, target 20%`);
const rarest = BLOODLINES.reduce((a, b) => (b.rarity < a.rarity ? b : a));
const commonest = BLOODLINES.reduce((a, b) => (b.rarity > a.rarity ? b : a));
check('rarity follows lore scarcity', commonest.rarity >= rarest.rarity * 10,
  `spread is flat: ${rarest.id}=${rarest.rarity} vs ${commonest.id}=${commonest.rarity}`);

// 4. Nothing purchasable affects combat power. Enforced by there being no price
//    field on any combat record at all — the absence is the guarantee.
check('no combat record carries a price',
  !JSON.stringify(JUTSU).includes('"price"') && !JSON.stringify(BLOODLINES).includes('"price"'),
  'a price field appeared on a combat record — combat power must never be purchasable');

// 4b. The tactical layer must stay worth using. A stance costs your whole action,
//     so if it cannot beat "just attack again" it is decorative — and an automated
//     tuner will happily optimise it into that state.
{
  const st = TUNING.stances;
  const INCOMING = 200, FORGONE = 140;
  const counterValue = INCOMING * st.counterReduction
    + (INCOMING - INCOMING * st.counterReduction) * st.counterFraction;
  check('Counter beats simply attacking', counterValue > FORGONE,
    `Counter is worth ${counterValue.toFixed(0)} against a forgone attack of ${FORGONE} — nobody would ever take the stance`);
  check('Prepare beats attacking twice', st.prepareDamageMult > 2,
    `x${st.prepareDamageMult} on one cast loses to two plain attacks, so Prepare is never correct`);
  check('Substitute beats simply attacking on a correct read',
    INCOMING * st.substituteBaseChance > FORGONE,
    `expected value ${(INCOMING * st.substituteBaseChance).toFixed(0)} vs forgone ${FORGONE}`);
}

// 4c. Money now exists, so the pay-to-win constraint needs teeth. Rank is the
//      gate on power, and rank cannot be bought — no promotion requirement may
//      reference currency, and every purchasable technique must be rank-locked.
{
  const gates = MISSIONS.promotions.flatMap((p) => Object.keys(p));
  check('rank cannot be bought', !gates.some((k) => /ryo|price|cost|money|gold/i.test(k)),
    'a promotion requirement references currency — rank must be earned, never purchased');
  check('every technique tier is rank-gated as well as priced',
    Object.keys(MISSIONS.jutsuPrices).every((rank) => rank in MISSIONS.teacherRankRequired),
    'a technique rank has a price but no rank requirement, so money alone would buy it');
  const paidTiers = Object.entries(MISSIONS.jutsuPrices).filter(([, v]) => v > 0).map(([k]) => k);
  check('paid techniques are not available at the starting rank',
    paidTiers.every((r) => MISSIONS.teacherRankRequired[r as keyof typeof MISSIONS.teacherRankRequired] !== undefined),
    'a paid technique has no rank requirement');
  check('titles and standing are earned, not priced',
    !JSON.stringify(MISSIONS.reputationTiers).includes('"price"')
      || MISSIONS.reputationTiers.every((t) => typeof t.priceMultiplier === 'number'),
    'reputation appears to be purchasable');
}

// 4d. The missing-nin economy rests on one inequality: a hunter collects less
//      than the rogue loses, so a colluding pair destroys value every cycle.
//      If hunterShare ever reaches 1, bounty farming becomes free money.
{
  check('hunting destroys value rather than moving it', ROGUE.bounty.hunterShare < 1,
    `hunterShare is ${ROGUE.bounty.hunterShare} — a colluding pair would break even or profit`);
  check('a bounty must be earned before it can be posted', ROGUE.contract.minNotorietyToPost > 0,
    'a rogue with no notoriety could be farmed the moment they defect');
  check('the same pair cannot loop immediately', ROGUE.contract.cooldownMinutesSamePair > 0,
    'no cooldown between the same hunter and target');
  check('coming back costs money', ROGUE.amnesty.baseCost > 0,
    'amnesty is free, so defection carries no risk');
}

// 4e. The two defences must value Stamina equally. Nothing in the design makes
//      chakra defence the better place to stack it, and because most attacks in
//      any realistic field are ninjutsu or genjutsu, an asymmetry here makes
//      Stamina the single best stat in the game.
check('both defences value Stamina equally', TUNING.guard.perStamina === TUNING.ward.perStamina,
  `guard ${TUNING.guard.perStamina} vs ward ${TUNING.ward.perStamina} — whichever is higher becomes the only stat worth stacking`);
check('both defences value their skill stat equally', TUNING.guard.perTaijutsu === TUNING.ward.perIntelligence,
  `guard/taijutsu ${TUNING.guard.perTaijutsu} vs ward/intelligence ${TUNING.ward.perIntelligence}`);

// 4f. Legacy is the "chase legacy, not gear" pillar. Two rules hold it up: a
//      legendary confers standing rather than power, and titles are earned.
//      Giving a legendary a permanent stat bonus would hand whoever reached a
//      milestone first an advantage nobody after them can ever take away.
{
  check('legendaries confer no combat power', LEGACY.rules.grantsCombatPower === false,
    'a legendary grants combat power — whoever claimed it first would be permanently stronger');
  check('legendaries are unique per server', LEGACY.rules.uniquePerServer === true,
    'legendaries can be duplicated');
  check('titles and legendaries are not purchasable', LEGACY.rules.purchasable === false,
    'legacy items can be bought');
  const raw = JSON.stringify(LEGACY);
  check('no legacy record carries a price or a stat',
    !/"(price|cost|ryo|stat|bonus|mult)"/i.test(raw),
    'a legacy record has a price or a stat field');
  check('every title is reachable', LEGACY.titles.every((t) => t.threshold >= 0),
    'a title has an unreachable threshold');
  check('every legendary is reachable', LEGACY.legendaries.every((l) => l.threshold > 0),
    'a legendary has an unreachable threshold');
}

// 5. Combos remain reachable.
check('every combo is reachable',
  COMBOS.every((c) => JUTSU.some((j) => j.effects.some((x) => x.kind === 'applyStatus' && x.status === c.setup))
    && JUTSU.some((j) => j.nature === c.trigger)),
  'a combo has no setup or no trigger technique');

// 6. Interrupted and fumbled seals both matter.
check('sealed techniques can fumble', TUNING.sealAccuracy.max < 1 && JUTSU.some((j) => j.seals > 0 && j.sealDifficulty > 0),
  'no technique can fail its seals');

console.log(`\ndrift check: ${ok.length} held, ${fails.length} drifted`);
for (const f2 of fails) console.log(`  ✗ ${f2}`);
if (fails.length) process.exitCode = 1; else console.log('  all design properties intact');
