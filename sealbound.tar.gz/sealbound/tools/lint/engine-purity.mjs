#!/usr/bin/env node
/**
 * Enforces CLAUDE.md §4 — engine purity. Runs as part of `pnpm lint`.
 *
 * These are the invariants that make replays, client prediction, and the balance
 * simulator possible. Breaking any one of them breaks all three, so this is a
 * hard failure, not a warning.
 */
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const ROOT = new URL('../..', import.meta.url).pathname;
const ENGINE = join(ROOT, 'packages/engine/src');

const RULES = [
  { id: 'no-math-random', re: /\bMath\s*\.\s*random\b/, msg: 'Math.random — randomness must come from the injected Rng (§4.1)' },
  { id: 'no-date-now', re: /\bDate\s*\.\s*now\b|\bnew\s+Date\b|\bperformance\s*\.\s*now\b/, msg: 'clock access — time is a field on MatchState (§4.2)' },
  { id: 'no-timers', re: /\bsetTimeout\b|\bsetInterval\b|\bsetImmediate\b|\bqueueMicrotask\b/, msg: 'timer — the engine has no schedule of its own (§4.2)' },
  { id: 'no-io', re: /\bfetch\s*\(|from\s+['"]node:fs['"]|from\s+['"]fs['"]|require\(['"]fs['"]\)|\bprocess\s*\.\s*env\b/, msg: 'I/O or environment access (§4.3)' },
  { id: 'no-logging', re: /\bconsole\s*\.\s*(log|warn|error|info|debug)\b/, msg: 'logging side effect (§4.3)' },
  { id: 'no-app-imports', re: /from\s+['"](\.\.\/)*apps\/|from\s+['"]@shinobi\/(server|web)['"]/, msg: 'import from apps/* — engine may import content and shared only (§4.5)' },
  { id: 'no-any', re: /(:|<)\s*any\b|\bas\s+any\b/, msg: '`any` is banned in packages/* (§3)' },
];

function walk(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) out.push(...walk(p));
    else if (p.endsWith('.ts')) out.push(p);
  }
  return out;
}

/** Strips comments and string literals so a rule name inside a doc comment is not a hit. */
function strip(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:])\/\/.*$/gm, '$1')
    .replace(/'(?:[^'\\]|\\.)*'/g, "''")
    .replace(/"(?:[^"\\]|\\.)*"/g, '""')
    .replace(/`(?:[^`\\]|\\.)*`/g, '``');
}

let failures = 0;
for (const file of walk(ENGINE)) {
  const raw = readFileSync(file, 'utf8');
  const src = strip(raw);
  const lines = src.split('\n');
  for (const rule of RULES) {
    lines.forEach((line, i) => {
      // import-path rules need the original text, since we blanked string literals
      const subject = rule.id === 'no-app-imports' ? raw.split('\n')[i] : line;
      if (rule.re.test(subject)) {
        console.error(`  ✗ ${relative(ROOT, file)}:${i + 1}  ${rule.msg}`);
        failures++;
      }
    });
  }
}

/* §4.4 — resolveTurn must not write through to its argument. */
const resolveSrc = readFileSync(join(ENGINE, 'resolve.ts'), 'utf8');
if (!/structuredClone\(state\)/.test(resolveSrc)) {
  console.error('  ✗ resolve.ts must deep-copy `state` before touching it (§4.4)');
  failures++;
}

if (failures > 0) {
  console.error(`\nengine-purity: ${failures} violation(s)`);
  process.exit(1);
}
console.log('engine-purity: clean');
