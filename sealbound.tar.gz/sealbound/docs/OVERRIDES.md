# Direction changes from docs/DESIGN-DIRECTION.txt (2026-08-02)

That document is now the governing design direction. Where it disagrees with an
earlier decision, it wins. This file records what changed and what it invalidated,
so nobody re-litigates a settled question or quietly drifts back.

| # | Design direction says | Previously built | Resolution |
|---|---|---|---|
| 1 | Chakra is "not mana" — Physical, Mental, and Natural energy pools | Single chakra pool | **REPLACED.** Three pools. Taijutsu spends Physical, genjutsu spends Mental, ninjutsu spends both, forbidden/sage techniques additionally require Natural — which does not regenerate and must be gathered. |
| 2 | Substitute is a move the player chooses | Passive: auto-consumed on any hit above a damage threshold | **REPLACED.** Substitution is a declared stance costing your action. Passive triggering removed. |
| 3 | Seals have Difficulty, Speed, and Accuracy; interrupted seals fail | Seals had difficulty and speed only; interrupts cancelled with a refund | **EXTENDED.** Added an accuracy roll on completion. A failed weave fizzles and burns half the cost. |
| 4 | Injuries: broken arm blocks hand seals, leg injury slows, eye injury reduces accuracy | No injury layer | **ADDED** as long-duration statuses, cleared by healing or time. |
| 5 | Combos: Oil→Fire→Explosion, Mist→Lightning→Electrocution, Water→Wind→Tsunami | Only `drench`/`conduct` nature modifiers | **ADDED** a data-driven combo table. Setup status + payoff nature fires a combo and consumes the status. |
| 6 | Bloodlines are random, ~20% of players, weighted by lore rarity | Bloodline freely assignable, all equal | **REPLACED.** Added rarity weights and a seeded roll. |
| 7 | Ranks include ANBU; Chunin/Jonin exams gate progression | academy→genin→chunin→jonin→kage | **EXTENDED** with `anbu`. |
| 8 | Eight core stats, and every action improves something | Eight stats already matched | **CONFIRMED** — no change. |
| 9 | Legendary weapons: one of each unique item per server, never duplicated | Not built | **PENDING.** Uniqueness is a server-side constraint; noted so it is not implemented as "one weapon per server". |
| 10 | Pets and cosmetics must never affect combat power | Not built | **PENDING**, recorded as a hard constraint. |
| 11 | No pay-to-win, ever | n/a | **PROJECT-WIDE CONSTRAINT.** Nothing purchasable may affect combat outcomes. Titles are earned, never bought. |

## Squads (built 2026-08-03)

S-rank missions carry `party: 3` and used to be refused outright with
`needsParty` — content that existed and could not be reached. Squads close that.

The rules exist to stop a squad becoming a way to dodge consequences:

- Nobody joins without accepting an invite; an invite alone puts you nowhere.
- A player is in at most one squad, enforced by a unique constraint on
  `squad_members.player_id` rather than by application logic.
- Every member must independently meet the rank and reputation bar, so a squad
  cannot smuggle a genin into an S-rank, and one outcast closes the desk for all.
- Once the mission starts the squad is **locked**: leaving, disbanding, inviting,
  and taking a second mission are all refused. A member who senses failure coming
  cannot walk away from the reputation hit.
- The outcome is seeded from `(squadId, missionId, startedAt)`, so any member can
  report back and they all get the same answer, and reporting twice cannot
  re-roll it or pay twice.
- Odds use the squad **average**, not the sum, so three passengers cannot ride one
  specialist through an S-rank. The purse is split, so a bigger squad trades pay
  for odds — a real decision rather than a strictly better one. Reputation is not
  split: everyone was there.

## Missing-nin and hunter-nin (built 2026-08-03)

Reputation previously only moved downward, through mission failure, and the
`wanted` tier closed the mission desk with nothing able to put you there and
nobody able to act on it. Both ends of that loop are now joined.

Defecting opens the black market — forbidden techniques above your rank, at
roughly double the price — and closes the village: no desk work, no promotion,
standing on the floor. Other players can then take a contract and come for you.

**The whole design rests on one inequality.** A bounty is worth exactly what the
rogue has accumulated in notoriety, which is only ever earned by what they
actually do; it is never minted. The hunter collects `hunterShare` (0.6) of what
the rogue loses, so two players colluding — defect, get caught deliberately, split
the payout — destroy 40% of the pot every cycle. A same-pair cooldown makes it
slow as well as lossy, and being caught resets notoriety to zero so the next loop
is worth less again.

That is deliberately not a detection problem. Nobody has to notice the collusion,
because it simply loses money. `pnpm drift` now asserts `hunterShare < 1`, since
that single number is what the property rests on.

Contract values are locked when taken, so a rogue cannot inflate a payout after
the fact, and a capture can never take more ryo than the rogue actually holds.

## Clans (built 2026-08-03)

Step 8 of the core loop — "join or create a clan (guild)". Distinct from the lore
clans in `clans.json`, which are bloodline families derived from `bloodlineId`
rather than joined. The `clanId` field previously carried the lore meaning but was
never assigned by any code path, so it now carries the player clan.

Founding costs money **and** standing (chunin, 60 reputation) — the money is the
smaller half of the bar, so a clan is not something a rich academy student buys.

The interesting problem is the treasury, because a shared pot is the most obviously
lootable thing in a game like this. It is guarded three ways rather than one:
officer rank, a one-day tenure gate so a stranger cannot join and empty it, and a
rolling daily cap.

**A bug worth recording.** The first cap implementation took a fraction of the
*current* balance, which meant every withdrawal raised the remaining allowance —
an officer could still drain the whole treasury in a day, just in slices. The cap
is now a fraction of the treasury as it stood at the start of the window,
reconstructed as `bank + withdrawnToday`. A test asserts the second withdrawal
fails.

Clans are ranked on what members have contributed, not on treasury size, so one
rich founder cannot outrank an active clan.

Leadership cannot be abandoned: a leader with members must hand over first, and a
sole leader leaving dissolves the clan rather than stranding it.

## Legacy: titles and legendaries (built 2026-08-03)

The `legendary_items` and `legendary_history` tables had been sitting in the
schema, unimplemented, since the persistence work. They now back the design
direction's central pillar — *players chase legacy, not gear*.

**Titles** are derived from thresholds and nothing else. There is no grant path,
no price field anywhere in the data, and `awardTitles` is idempotent. A player can
only display one they have earned.

**Legendaries** exist at most once on the server. Uniqueness is a PRIMARY KEY on
`item_id`, not the application check above it — there is a test that deliberately
bypasses the check and asserts the storage layer rejects the second claim, because
under concurrency the check is the part that fails. The chain of custody is
append-only; nothing in the codebase deletes from `legendary_history`.

**A design decision worth not reversing.** Legendaries grant no combat power.
That is deliberate, not an omission. A permanent stat bonus handed to whoever
reached a milestone first would make the ladder unwinnable for everyone who
arrived later, and would quietly invalidate every balance number. `pnpm drift`
asserts `grantsCombatPower === false` and that no legacy record carries a stat or
price field.

### A refactor forced along the way

`createPlayer` and `savePlayer` in the Postgres store were hand-written positional
parameter lists that had drifted, through several rounds of added fields, into
`$21` appearing before `$20`. Every new column was another chance to scramble them
silently. Both are now generated from one column map, which is what let the five
new columns land without incident.

## Deferred (meta-game, mostly server-side — not yet built)

Village politics and elections, clan/guild system, territory control, player-driven
economy and crafting, black market, rogue-nin and hunter-nin loops, Chunin/Jonin/ANBU
exams, rare wandering teachers, legendary scroll hunts, mentor system, seasons and
weather, hidden dungeons, housing, pets, cosmetics, titles, seasonal story arcs,
dynamic server history.

These are recorded here rather than in code so the scope is visible. None of them
may compromise §4 engine purity or §5 server authority.

## Balance: 8 of 10 in band (2026-08-03)

Up from 5. The middle eight now sit between 46.0% and 52.7% at 20k matches. Three
structural faults were found and fixed, each now asserted so it cannot return:

1. **The field was elementally asymmetric.** Affinity is defensive; jutsu nature
   is offensive. Balancing affinity *counts* is not enough — no archetype in the
   field cast earth jutsu, so water affinity was never countered and whoever held
   it won the "vs field" metric on structure rather than strength. `pnpm parity`
   now asserts every archetype counters as many opponents as counter it, and
   checks the cycle is still live rather than balanced by being switched off.
2. **The two defences had drifted apart.** The tuner had set Stamina to buy 0.95
   ward but only 0.65 guard. Because most of any realistic field attacks the ward,
   that made Stamina the single best stat in the game. They are now linked in the
   tuner and asserted equal in `pnpm drift`.
3. **Non-damage roles were not worth their slot.** A heal restored ~133 where a
   damage slot dealt ~185, so healing, gates and setup builds all lost by
   construction. Role ceilings were raised and the tuner found workable values;
   Medic went 39% to 50%.

### Still open

- **Bulwark, 76%.** Isolated to its build: swapping in another archetype's stats
  AND loadout together drops it to 51%, but swapping either one alone changes
  almost nothing. So it is the combination, not a single overtuned number, and
  that is where the next investigation should start.
- **Sage, 24%.** Its whole plan is gather natural energy, then land one forbidden
  technique. That plan still does not pay for the turns it costs.

Neither is a global dial. Do not reach for one — the last three global passes all
traded one archetype for another until the structural faults above were fixed.

## Superseded balance finding (2026-08-02)

Archetype fixtures were rebuilt around the new systems and are now parity-checked
(`pnpm parity`): equal stat totals, equal rank-point budgets, and a declared stat
discount for bloodline builds. That made the matrix readable for the first time.

It immediately showed a real problem the old fixtures were hiding: at an identical
budget, Artillery outputs ~98 damage per round against a field average near 30.
Rank-points are the wrong budget unit — a `damage` role and a `shield` role cost
the same but are not worth the same, so an all-offense loadout is worth roughly
three times a mixed one.

This is a content-pricing problem, not a dial problem. Nine global tuning passes
moved other archetypes around Artillery without closing the gap. The fix is
per-role budget weighting, not another multiplier. See
`.claude/agents/content-balance-smith.md`.

Structural fixes that DID land, and should not be reverted:

- Defensive stat investment now has real leverage (it previously moved mitigation
  by ~6 points between a 110-stamina tank and a 60-stamina glass cannon).
- `sealsPerTurn` is no longer floored, removing a step function where one point of
  Hand Seals could double throughput.
- Ninjutsu costs are weighted up to pay for drawing on two reserves.
- S-rank economics: a technique costing 8 of a 14-point budget now hits hard
  enough to be worth the gather turn and the weave.

## Persistence (built 2026-08-03)

`PostgresStore` alongside `MemoryStore`, both behind the same interface, with one
contract suite run against both. Writing the tests executed `schema.sql` for the
first time and caught that it had drifted from the record shape — it was missing
`known`, `missions_at_rank`, `missions_completed`, and the `mission_sessions`
table entirely, all added after the schema was written and never reconciled.

The schema now also carries assertions as tests: training has no elapsed/progress
column, replays have no state-snapshot column, one live training session and one
live mission per player are enforced by primary key rather than by application
logic, and a legendary item cannot be inserted twice.

## Accounts (built 2026-08-03)

The `dev-alice` / `dev-bob` token map is gone. Registration creates the account and
the shinobi together, which closes "Create a shinobi" — the first step of the core
loop, which until now had no endpoint at all.

Choices worth not undoing:

- scrypt with a per-user salt and cost parameters stored in the digest, so they
  can be raised later without invalidating existing passwords.
- Timing-safe comparison, and a decoy hash when the account does not exist —
  skipping the hash on an unknown name makes "no such player" measurably faster
  than "wrong password", which is a free user-enumeration oracle.
- Session tokens are opaque: 256 bits of randomness, SHA-256 at rest, carrying no
  player id, role, or expiry the client could edit.
- Registration and login are the only unauthenticated mutating endpoints, so they
  are rate limited per IP. Malformed requests deliberately still consume budget.

## 2026-08-04 — The meta-game: territory, politics, economy, seasons, dungeons, mentors, cosmetics

Seven systems from `DESIGN-DIRECTION.txt` built in one pass. What follows is the
reasoning that is not obvious from the code, and the places where the direction
document was deliberately read a particular way.

### Territory grants no combat statistic — read this before "fixing" it

The direction document lists "PvP buffs" among the rewards for holding territory.
That is implemented as a **x1.25 multiplier on war score**, and on nothing else.
No region, war, law or commission touches a fighter's stats.

The reasoning, so nobody re-adds it later believing it was an oversight:

- A permanent combat bonus for whoever already holds ground snowballs. The clan
  that wins the first war fights every subsequent war with an advantage it won by
  winning, which is the definition of a runaway.
- It invalidates `tuning.json`. The 43–57% archetype win-rate band is asserted in
  CI; a territorial stat bonus makes that band a fiction, because two identical
  builds no longer play identically.
- It is invisible to the opponent. A player loses a ladder match to a number they
  cannot see, decided by a war they may not have been in.

The defender's advantage is expressed where it is legible: on the war board,
bounded, and impossible to carry into a ladder match. If the owner wants literal
combat buffs, the honest form is a separate **war-only match mode** where both
sides can see the modifier — that is a feature, not a tweak, and it is not built.

Asserted by `drift-check` ("territory grants no combat statistic") and by probe
E13, which greps the runtime as well as the content.

### Direct trade and gifting — REVERSED the same day

Originally there was no direct trade and no gifting: everything moved through an
escrowed listing with a fee on the seller and a tax on the sale, so a wash trade
between two accounts destroyed ryo every time it ran. Collusion did not have to
be *detected*, because it lost money.

**Owner decision, 2026-08-04: allow direct trading and gifting.** That property
is gone and cannot be recovered while free transfer exists. Two accounts can now
move currency and goods between them at no cost, which means:

- multi-boxing income now aggregates freely — an alt farming dungeons, missions
  and gathering can feed one main account, where previously each transfer was
  taxed;
- real-money trading becomes practical to execute in-game;
- the market is now the *slower, more expensive* way to move goods. That is
  fine — it exists for trading with strangers, and its price signal is what the
  reference band is built on — but its volume will drop, and any future work that
  reads market volume as a demand signal should know it is now a biased sample.

What was kept, because it is still defensible:

- **The `tradable` flag governs gifts as well as sales.** Otherwise gifting is
  the loophole that makes every deliberately-unfarmable reward farmable. The
  mentor's charm and cosmetics still cannot move.
- **Atomicity.** Both sides are validated, the proposal row is claimed, and only
  then does anything move. A duplication bug in a trade window is worth more to
  an attacker than every other exploit in this repository put together.
- **Attribution replaces prevention.** Every completed transfer is written to an
  append-only `transfers` table with both ends and the exact contents. A ring of
  accounts feeding one beneficiary is now a visible pattern rather than an
  impossible one. This is the honest trade-off once free transfer is a design
  goal: the remaining defence is being able to see it.

The drift check no longer asserts that no transfer message exists. It asserts the
four properties above instead.

#### A coverage limit worth knowing about

The delete-before-swap ordering inside `acceptTrade` is **not** demonstrated by
any runtime test. In one Node process the swap is synchronous and never yields,
so reordering it produces no duplicate in-process — probes E29 and E30 pass
either way, and so does a `Promise.all` test. The ordering matters only across
two server instances sharing a database, where `DELETE ... RETURNING` is the sole
arbiter. It is therefore asserted by `drift-check` reading the order of the
statements, which is the only place that can currently see it. If this ever moves
to an integration test with two real connections, that assertion can be retired.

### The sale tax is the village tax rate — and a bug that came from that

`economy.json` originally carried a `saleTaxFraction`. It was in the schema, and
both `validate:content` and `drift-check` asserted the wash-trade property
against it. **No runtime code ever read it.** The tax actually charged is the
seller's village tax rate, set by an elected government and bounded by the band
in `politics.json`.

Found by mutation-testing the adversarial harness: zeroing both fee fields in
`economy.json` failed to make the wash-trade probe fire, because the money was
being taken somewhere else entirely. The field is now deleted and both assertions
reference `POLITICS.tax.min`, which is the floor that actually holds the property
up. This is worth remembering as a category: an assertion about a number nothing
reads passes forever and protects nothing.

### Elections and office powers

Lazy certification, not a scheduled job: the first person to look at the
government seats it. A cron that fails to fire would leave a village with last
term's Kage indefinitely, and there is nothing here a job makes more correct. The
same reasoning applies to war resolution.

Ties break on votes, then reputation, then id — never on a roll, so a candidate
who lost can be shown exactly why.

Every power is bounded by content: tax moves inside a band, by a bounded step,
once per term (without the per-term limit a holder can ratchet in legal
increments to wherever they like); laws come from a fixed list; spending goes to
a fixed list of commissions. **There is no path from a village treasury to a
personal wallet** — not a capped one, none — which is what stops the office from
being worth buying.

Suffrage costs five completed missions and a day of account age. An election
decided by same-day accounts is a detection problem nobody wins; a cost is a
defence that does not have to notice anything.

### Dungeon answers

Stored only as per-room salted SHA-256. Not in the client bundle, not in the
content files, never sent to the client, compared timing-safely.
`validate:content` fails the build if a plaintext answer field appears.

A `cooldownHours` field existed in the dungeon data from the start and **nothing
enforced it** — caught by probe E21. Without it, a player who had learned three
answers could clear the same dungeon as fast as they could type, and the ryo
reward became a faucet scaling with typing speed. The cooldown is now set **on
entry** rather than on completion, so walking out does not dodge it.

### Mentors are never paid in anything sellable

Reputation and clan contribution only, capped per mentee per week, nothing before
the pairing has matured, and a student may be mentored once ever. A veteran
mentoring their own alt is therefore pointless rather than merely detectable,
which holds without the server having to work out which accounts belong to whom.

### Cosmetics

The one thing money may buy, precisely because they do nothing — and untradable,
because a cosmetic that can be sold is currency wearing a hat, and currency
eventually buys power. Title-gated cosmetics are *granted*, never sold, so no
amount of money shortens the route to one.

### Concurrency lives in the schema

Four properties are database constraints rather than application checks, because
an application check is exactly the part that loses a race:

- one war per region per period — `UNIQUE (region_id, period_index)`
- one vote per player per office per cycle — primary key on `votes`
- one active mentor per student — partial unique index on `mentorships`
- one buyer per listing — `DELETE ... RETURNING`, resolved before money moves

The meta-game store contract suite runs against both `MemoryStore` and
`PostgresStore` so the in-memory implementation cannot quietly disagree.

### Two probes that passed for the wrong reason

Recorded because the lesson generalises. On its first run the harness reported
two HIGH findings, and both were defects in the probes:

- E1 hit the rate limiter after five iterations and reported that as a finding.
  Correct server behaviour, useless probe. It now steps the clock, because the
  attacker worth modelling is the patient one.
- E27 scanned module source for `resolveTurn` and matched the **comments that
  document the rule**. It now strips comments and checks imports and call sites.

Every probe in the file has since been mutation-tested: the guard it protects was
deliberately broken and the probe confirmed to fire.

### Not built

- No web UI for any of this. `apps/web` is unchanged; all seven systems are
  server and wire protocol only.
- Black-market content exists in `economy.json` and has no handler.
- Village war is a flag that permits cross-border clan declarations. It has no
  effect on matchmaking, and deliberately so.

## 2026-08-04 — Economy simulator, and the three things it found

`pnpm sim:economy` drives 48 simulated players through the **real** `GameService`
for a 28-day season and reports where ryo comes from, where it goes, how long the
crafting tree takes, and how far apart the richest and poorest end up. Nothing in
it re-implements a rule — a simulator that reimplements the rules only ever tells
you about the simulator.

Simulated players are deliberately unsophisticated, which biases every figure
downward: a real population contains people who find the best loop and run it.
Treat the output as a floor on income and a ceiling on time-to-goal.

### Finding 1 — three recipes destroyed value, and they were the entry-level ones

`fold-steel` (-100 ryo), `press-paper` (-50) and `cure-hide` (-330) each produced
an output worth less than the materials it consumed. Because all three are the
genin-unlock recipes, **every new crafter's first experience of the crafting
system was losing money**. In the first full run the median crafter finished the
season on 141 ryo, having started with 5,000 — the worst outcome of any role by
two orders of magnitude.

Component and product values were re-derived so that every recipe clears roughly
500–670 ryo per hour, against a single-player mission wage of about 520. The
values changed: `steel-billet` 320→640, `sealing-paper` 240→360, `cured-hide`
200→800, `training-weights` 900→2450, `field-rations` 500→420, `scholars-lamp`
1400→1560, `shrine-key` 2600→1400, `vault-key` 3200→2400.

`validate:content` now **fails the build** if any recipe's output is worth less
than its inputs, and warns if a recipe pays less than a quarter of the mission
wage. `drift-check` asserts the same property. There is no legitimate reason for
a value-destroying recipe: if a step is meant to be a sink, it should be one
explicitly, not through two numbers drifting apart.

### Finding 2 — the best dungeon was free to enter and paid 6.4x a day of play

`marsh-ossuary` paid 20,000 ryo, carried the only legendary, and was the one
dungeon with **no key requirement**. A dungeon puzzle is only hard the first
time — the answers are shared the day after launch — so its ryo reward is
effectively a daily stipend for anyone who reads a wiki.

Rewards are now 2,400 / 3,600 / 5,200, putting the best at about 1.7x a day of
missions, and `marsh-ossuary` requires a `vault-key`. The jutsu, the cosmetic and
the legendary carry the prestige instead, which is what they were for.
`drift-check` now asserts both that no dungeon dwarfs a day of play and that the
richest one is gated behind something.

### Finding 3 — gathering pays about half what missions pay, and most of it is illiquid

Gatherers finish on a median net worth of ~15,700 against ~36,300 for mission
runners, and only 36% of it is liquid: the rest sits in ore nobody has bought
yet. 107 listings were still open at the end of the season.

This is **not fixed**. It may be correct — gathering is lower-effort and feeds
the crafting tree rather than paying directly — but a player who picks it is
currently taking less than half the income of a player who does not, and finding
out slowly. The options are to raise `TERRITORY.yield.baseUnits`, to give raw
resources a guaranteed buyer (a village purchase order at a floor price, which
would also give the reference band a floor), or to accept it and make the
trade-off legible in the UI. It needs a decision rather than a tweak.

### Two things the report says about the whole economy

**There is no meaningful ryo sink.** Missions supplied 845,000 of ~872,000 total
inflow over the season; the listing fee and sale tax removed about 9,000. The
money supply grew 348% in 28 days. Nothing here is broken today because prices
are anchored to `baseValue` rather than to supply, but a market whose reference
drifts with volume will inflate against a money supply that only grows. The
sinks that exist — cosmetics, war stakes, commissions — are not yet things the
simulated population buys, and none of them scales with wealth.

**Measuring ryo alone ranks roles wrongly.** The first version of this report put
gatherers dead last, which turned out to mean their wealth was in ore rather than
in coin. The report now uses net worth (ryo + goods at reference + escrow) and
also states how much of it is liquid. Worth remembering before drawing a
conclusion from a currency figure in a game where most value is goods.

### A note on simulated behaviour

The first crafter agent picked a random recipe every hour and could never
assemble a full set of materials, which made crafting look unplayable when the
real problem was smaller. Fixing the agent to work toward one recipe at a time
moved the median crafter from 141 ryo to 33,451 and inequality from 572x to 2.6x.
Both the agent and the content were wrong; only one of them was the game. When a
simulation says a system is broken, check the player before changing the rules.

## 2026-08-04 — Gathering yield raised, and the client learned the meta-game

### Gathering: baseUnits 3 -> 5, after fixing the measurement first

The simulator reported gatherers finishing on roughly half a mission runner's net
worth. Before changing any content, the measurement turned out to be partly at
fault: a gathering trip takes 20 minutes and the simulator ticked hourly, so it
ran a third of the trips a real player would and made gathering look a third as
good as it is. The tick is now the shortest timed activity in the content, so
every role is measured at the cadence it actually runs at.

With that fixed, gathering still trailed — about 56% of a mission runner. A sweep
of `baseUnits` at 4, 5 and 6 put the roles within a few percent of each other at
**5**, which is the value now shipped.

One caveat that the number alone hides: a gatherer holds roughly 90% of that
wealth as GOODS rather than coin, and 107 listings were still unsold at the end
of the season. Raising yields raises supply without raising demand, so the extra
units are only worth what somebody will pay for them. If the market stays thin,
the honest next step is a village purchase order at a floor price — which would
also give the reference band a floor it currently lacks — rather than raising
yields again.

### The web client

`apps/web` previously handled 66 server message types and none of the meta-game.
It now has six screens in `meta.tsx`, kept out of `App.tsx` because that file is
about a match and this is about everything between matches:

**World** (season, weather, government, law, public works, and the election with
live tallies), **Land** (regions, gathering, the war board), **Workshop**
(inventory, consumables, the workbench), **Market** (listings, selling, direct
trades and gifts), **Delve** (dungeon list and the one room you are standing in),
and **Mentor** (teaching, students, wardrobe).

Two rules held throughout, both inherited from the arena screens:

- **The client calculates nothing.** Every price, yield, war score, vote tally and
  puzzle prompt is a value the server sent. There is no local arithmetic that
  could disagree with the server, because there is no local arithmetic.
- **Where a number looks actionable, the screen says where it came from.** The
  market shows the reference price and explains that the band moves with real
  trades and drifts back on its own; the election says tallies are public
  deliberately; the wardrobe says outright that none of it touches a statistic.
  A figure with no provenance is one people assume the client invented.

`.field` labels are now real `<label>` elements on the new screens rather than
the `<span>` used elsewhere, so a screen reader can tie a control to its name.
The CSS covers both, so the two halves of the app still look like one app.

Still not built on the client: proposing a full item-for-item trade (only ryo
gifts and accept/refuse of incoming offers are wired), enacting laws and
commissioning works (the tax control is there as the worked example), and
declaring war on another village.

## 2026-08-04 — Prepared for a public repository and a real deployment

### One process, one origin

`apps/server` now serves the built web client alongside the API, registered last
so it can never shadow `/api`, `/ws` or `/health`. The single-page fallback is
deliberately narrow: a catch-all that is too greedy turns every mistyped API path
into an HTML page and a 200, which is miserable to debug against. Four tests in
`trust.test.ts` hold that line, including one asserting the server still starts
with no build present so development is unaffected.

`Dockerfile` and `docker-compose.yml` bring up the app and Postgres together.
The image runs as `node` rather than root, and `SEED_DEV_ACCOUNTS` — which
creates logins with a password published in the source — is never set in it.

### CI runs exactly what a developer runs

`.github/workflows/ci.yml` is `pnpm check` broken into named steps, plus the
web build. Engine purity runs first because its failure invalidates the meaning
of every check after it. Fixture parity is a separate, slower job.

`pnpm check` locally and CI are the same commands in the same order, so a green
local run means a green pipeline.

### The setting, now that this is public

The canonical *Naruto* naming stays, per the owner override in `CLAUDE.md` §2.
Publishing is distribution, which is a different exposure from private
development, so this is now stated plainly rather than left implicit:
`NOTICE.md` records that the MIT licence covers the code only, that the content
names belong to their rights holders, and exactly which six JSON files to edit to
reskin the game. No code and no balance number changes in a reskin — the ids stay,
only the display names move — which is why the names were kept in data in the
first place.

### Still missing before this is genuinely production-ready

- **No migration path.** `MIGRATE_ON_BOOT=1` applies `schema.sql` to a fresh
  database. Nothing moves an existing one forward, and this session added
  eleven player columns and fourteen tables.
- **No structured logging, metrics, or error reporting.** The server logs two
  lines at boot and nothing after.
- **No backup story** for the Postgres volume in `docker-compose.yml`.
- **The transfer audit log has no reader.** The table is written and indexed but
  nothing surfaces it, so the attribution defence that free trade rests on is not
  yet usable by a moderator.

## Anti-drift checklist

Re-read `docs/DESIGN-DIRECTION.txt` at the end of any task that touches combat,
progression, or economy, and confirm:

1. Combat still reads as chess, not as a damage race — Move / Counter / Prepare /
   Substitute / Charge / Throw / Summon / Transform / Seal all remain live choices.
2. Chakra management is still a skill: three pools, asymmetric regeneration.
3. Progression is still identity and legacy, not gear. Reputation and rank gate
   content; purchases never do.
4. Nothing purchasable affects combat power.
5. Every action a player takes still improves some stat.
6. Bloodlines remain rare. If more than ~20% of rolled characters have one, that is
   a bug.
7. Territory, office, wealth and mentorship still buy nothing a match can read.
8. Direct transfers still honour the `tradable` flag, still settle atomically,
   and are still written to the append-only transfer log. (Transfers no longer
   destroy value — that was reversed on 2026-08-04.)
9. Titles and legendary weapons are still earned, and cosmetics are still inert
   and untradable.
10. No recipe destroys value, and no dungeon pays more for a solved puzzle than
    a day of ordinary play is worth. Re-run `pnpm sim:economy` after touching any
    item value, recipe, yield, or reward.

Run `pnpm check` — it is `lint`, `validate:content`, `test`, `drift`, `qa` and
`qa:meta` in one command.
