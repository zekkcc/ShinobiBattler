-- Shinobi Battler Online — Postgres schema.
--
-- Two rules drive the shape of this file:
--   * Training time is derived from started_at against the server clock. There is
--     deliberately no "elapsed" or "progress" column for a client to write to.
--   * Replays are (seed, actions) only. There is deliberately no state-snapshot
--     column — a snapshot would let a divergent replay look authoritative.

-- Credentials live apart from game state. `password` holds a self-describing
-- scrypt digest (never a plaintext or a bare hash), and `name_key` is the
-- normalised form, so two players cannot take confusable names.
CREATE TABLE accounts (
  id           TEXT PRIMARY KEY,
  name_key     TEXT NOT NULL UNIQUE,
  password     TEXT NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at TIMESTAMPTZ
);

-- Only the SHA-256 of a session token is stored, so a database dump does not
-- hand over live sessions. There is deliberately no column for a role or a
-- player id the client could influence: the token is opaque and everything is
-- looked up from it.
CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX sessions_account_idx ON sessions (account_id);
CREATE INDEX sessions_expiry_idx ON sessions (expires_at);

-- Player clans (guilds). Distinct from the lore clans in content, which are
-- bloodline families derived from bloodline_id rather than joined.
CREATE TABLE clans (
  id                    TEXT PRIMARY KEY,
  name                  TEXT NOT NULL,
  name_key              TEXT NOT NULL UNIQUE,
  leader_id             TEXT NOT NULL,
  bank                  BIGINT NOT NULL DEFAULT 0 CHECK (bank >= 0),
  founded_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  withdrawn_today       BIGINT NOT NULL DEFAULT 0,
  withdraw_window_start TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE players (
  id              TEXT PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
  name            TEXT NOT NULL UNIQUE,
  village_id      TEXT NOT NULL,
  clan_id         TEXT REFERENCES clans(id) ON DELETE SET NULL,
  clan_joined_at  TIMESTAMPTZ,
  clan_contribution BIGINT NOT NULL DEFAULT 0,
  bloodline_id    TEXT,                    -- rolled server-side at creation, ~20% of players
  rank            TEXT NOT NULL DEFAULT 'academy',
  level           INTEGER NOT NULL DEFAULT 1,
  xp              BIGINT  NOT NULL DEFAULT 0,
  stats           JSONB   NOT NULL,
  affinity        TEXT    NOT NULL,
  loadout         JSONB   NOT NULL DEFAULT '[]'::jsonb,
  known           JSONB   NOT NULL DEFAULT '[]'::jsonb,   -- techniques learned from teachers
  reputation      INTEGER NOT NULL DEFAULT 0,
  ryo             BIGINT  NOT NULL DEFAULT 0,
  rating          INTEGER NOT NULL DEFAULT 1000,
  missions_at_rank  INTEGER NOT NULL DEFAULT 0,           -- resets on promotion
  missions_completed INTEGER NOT NULL DEFAULT 0,
  rogue           BOOLEAN NOT NULL DEFAULT false,
  defected_at     TIMESTAMPTZ,
  notoriety       INTEGER NOT NULL DEFAULT 0,             -- earned, never granted
  titles          JSONB   NOT NULL DEFAULT '[]'::jsonb,    -- earned, never purchased
  displayed_title TEXT,
  pvp_wins        INTEGER NOT NULL DEFAULT 0,
  bounties_claimed INTEGER NOT NULL DEFAULT 0,
  s_rank_completed INTEGER NOT NULL DEFAULT 0,
  -- Meta-game state. inventory/cosmetics/equipped/boosts are documents rather
  -- than tables because nothing ever queries across players by item.
  inventory       JSONB   NOT NULL DEFAULT '{}'::jsonb,
  cosmetics       JSONB   NOT NULL DEFAULT '[]'::jsonb,   -- owned; untradable by design
  equipped        JSONB   NOT NULL DEFAULT '{}'::jsonb,   -- slot -> cosmetic id
  boosts          JSONB   NOT NULL DEFAULT '{}'::jsonb,   -- out-of-combat only
  -- A single JSONB column cannot hold two sessions, which gives the same
  -- one-live-session-per-player guarantee the training table gets from its
  -- primary key. As there, there is no elapsed or progress field: everything is
  -- derived from started_at against the server clock.
  gathering       JSONB,
  crafting        JSONB,
  dungeon_run     JSONB,
  dungeon_runs_day   INTEGER NOT NULL DEFAULT 0,
  dungeon_runs_today INTEGER NOT NULL DEFAULT 0,
  dungeon_cooldowns  JSONB NOT NULL DEFAULT '{}'::jsonb,
  mentored_before BOOLEAN NOT NULL DEFAULT false,
  last_mentorship_ended_at TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- At most one live session per player, enforced by the primary key rather than
-- by application logic.
CREATE TABLE training_sessions (
  player_id   TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
  location_id TEXT NOT NULL,
  tier        SMALLINT NOT NULL CHECK (tier BETWEEN 1 AND 5),
  stat        TEXT NOT NULL,
  started_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One live mission per player, enforced by the primary key. As with training,
-- there is deliberately no progress or elapsed column: the outcome is derived
-- from started_at and a seed built from it.
CREATE TABLE mission_sessions (
  player_id   TEXT PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
  mission_id  TEXT NOT NULL,
  started_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Squads are transient, but persisted: a party mission can outlive a restart and
-- a member must not be able to escape a failure by reconnecting.
-- One row per player, so the unique constraint is what guarantees nobody holds
-- membership in two clans.
CREATE TABLE clan_members (
  clan_id   TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
  player_id TEXT NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE,
  officer   BOOLEAN NOT NULL DEFAULT false,
  invited   BOOLEAN NOT NULL DEFAULT false,
  PRIMARY KEY (clan_id, player_id)
);

CREATE TABLE squads (
  id          TEXT PRIMARY KEY,
  leader_id   TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  mission_id  TEXT,
  started_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One row per player per squad, and the unique constraint on player_id is what
-- guarantees nobody is in two squads at once.
CREATE TABLE squad_members (
  squad_id  TEXT NOT NULL REFERENCES squads(id) ON DELETE CASCADE,
  player_id TEXT NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE,
  invited   BOOLEAN NOT NULL DEFAULT false,
  PRIMARY KEY (squad_id, player_id)
);

-- A bounty contract locks its value at the moment it is taken, so a rogue
-- cannot inflate the payout afterwards. Settled contracts are kept until the
-- same-pair cooldown expires, which is what stops a colluding pair looping.
CREATE TABLE bounty_contracts (
  id          TEXT PRIMARY KEY,
  hunter_id   TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  target_id   TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  value       INTEGER NOT NULL,
  accepted_at TIMESTAMPTZ NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX bounty_hunter_idx ON bounty_contracts (hunter_id);
CREATE INDEX bounty_target_idx ON bounty_contracts (target_id);

CREATE TABLE replays (
  match_id    TEXT PRIMARY KEY,
  seed        TEXT NOT NULL,
  fighter_a   TEXT NOT NULL REFERENCES players(id),
  fighter_b   TEXT NOT NULL REFERENCES players(id),
  actions     JSONB NOT NULL,              -- SubmittedAction[], in resolution order
  winner_id   TEXT,
  outcome     TEXT NOT NULL,
  rounds      INTEGER NOT NULL,
  ended_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX replays_fighter_a_idx ON replays (fighter_a, ended_at DESC);
CREATE INDEX replays_fighter_b_idx ON replays (fighter_b, ended_at DESC);

CREATE TABLE ladder_history (
  id          BIGSERIAL PRIMARY KEY,
  player_id   TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  match_id    TEXT NOT NULL REFERENCES replays(match_id) ON DELETE CASCADE,
  rating_before INTEGER NOT NULL,
  rating_after  INTEGER NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ladder_history_player_idx ON ladder_history (player_id, recorded_at DESC);

-- Legendary items are unique per ITEM, not one item per server: each named
-- artefact exists at most once and its history is permanent.
-- item_id is the primary key, so a legendary can exist at most once on the
-- server. Two players claiming simultaneously cannot both win: the second
-- insert is rejected by the database, not by application logic.
CREATE TABLE legendary_items (
  item_id     TEXT PRIMARY KEY,
  holder_id   TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  acquired_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Append-only chain of custody. Nothing in the codebase deletes from this table;
-- "history recorded forever" is the whole point of a legendary.
CREATE TABLE legendary_history (
  id          BIGSERIAL PRIMARY KEY,
  item_id     TEXT NOT NULL,
  holder_id   TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  held_from   TIMESTAMPTZ NOT NULL,
  held_until  TIMESTAMPTZ
);
CREATE INDEX legendary_history_item_idx ON legendary_history (item_id, held_from);


-- ── Territory ──────────────────────────────────────────────────────────────
-- Villages own regions; a clan garrisons one on the village's behalf. A war
-- flips both at once, so they live on the same row.
CREATE TABLE regions (
  id                     TEXT PRIMARY KEY,
  controlling_village_id TEXT NOT NULL,
  garrison_clan_id       TEXT REFERENCES clans(id) ON DELETE SET NULL,
  captured_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One war per region per period, enforced by the unique constraint rather than
-- by application logic: two clans declaring in the same second must not both
-- succeed, and under concurrency the application check is the part that fails.
CREATE TABLE wars (
  id                TEXT PRIMARY KEY,
  region_id         TEXT NOT NULL REFERENCES regions(id) ON DELETE CASCADE,
  period_index      INTEGER NOT NULL,
  attacker_clan_id  TEXT NOT NULL REFERENCES clans(id) ON DELETE CASCADE,
  defender_clan_id  TEXT REFERENCES clans(id) ON DELETE SET NULL,
  stake             BIGINT NOT NULL DEFAULT 0 CHECK (stake >= 0),
  attacker_score    INTEGER NOT NULL DEFAULT 0,
  defender_score    INTEGER NOT NULL DEFAULT 0,
  -- player id -> score contributed, so nobody is counted twice and the
  -- per-member cap has something to count against
  contributions     JSONB NOT NULL DEFAULT '{}'::jsonb,
  declared_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolves_at       TIMESTAMPTZ NOT NULL,
  resolved          BOOLEAN NOT NULL DEFAULT false,
  winner_clan_id    TEXT,
  UNIQUE (region_id, period_index)
);
CREATE INDEX wars_unresolved_idx ON wars (resolved, resolves_at);

-- ── Market ─────────────────────────────────────────────────────────────────
-- Goods are escrowed into the listing at the moment it is created: the row IS
-- the stock. There is deliberately no quantity column on the seller's side to
-- reconcile against, because that reconciliation is where duplication bugs live.
CREATE TABLE market_listings (
  id          TEXT PRIMARY KEY,
  seller_id   TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  item_id     TEXT NOT NULL,
  qty         INTEGER NOT NULL CHECK (qty > 0),
  unit_price  BIGINT  NOT NULL CHECK (unit_price > 0),
  listed_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at  TIMESTAMPTZ NOT NULL
);
CREATE INDEX market_listings_item_idx ON market_listings (item_id, unit_price);
CREATE INDEX market_listings_seller_idx ON market_listings (seller_id);

-- The moving anchor a legal price band is measured against. Supply and demand
-- with a leash: it drifts with real volume and returns toward base value over
-- time, so one whale cannot park an item's band anywhere they like.
CREATE TABLE market_reference (
  item_id    TEXT PRIMARY KEY,
  reference  BIGINT NOT NULL CHECK (reference > 0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Direct trades between players. Nothing is escrowed here; the row is a
-- proposal, and acceptance re-checks both inventories.
CREATE TABLE trades (
  id         TEXT PRIMARY KEY,
  from_id    TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  to_id      TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  offer      JSONB NOT NULL,
  request    JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  CHECK (from_id <> to_id)
);
CREATE INDEX trades_to_idx ON trades (to_id);
CREATE INDEX trades_from_idx ON trades (from_id);

-- The permanent record of every direct transfer. Free transfer between accounts
-- is a deliberate design choice, so this table is the thing that makes a
-- collusion ring visible: it is append-only and has no delete path.
CREATE TABLE transfers (
  id      TEXT PRIMARY KEY,
  at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  kind    TEXT NOT NULL CHECK (kind IN ('trade','gift')),
  from_id TEXT NOT NULL,
  to_id   TEXT NOT NULL,
  ryo     BIGINT NOT NULL DEFAULT 0 CHECK (ryo >= 0),
  items   JSONB NOT NULL DEFAULT '[]'::jsonb
);
CREATE INDEX transfers_from_idx ON transfers (from_id, at);
CREATE INDEX transfers_to_idx ON transfers (to_id, at);

-- ── Villages and politics ──────────────────────────────────────────────────
-- There is deliberately no column here that pays a player. A treasury may only
-- be spent on a commission from the content list, which is what stops the
-- office from being worth buying.
CREATE TABLE villages (
  id             TEXT PRIMARY KEY,
  tax_rate       NUMERIC(4,3) NOT NULL DEFAULT 0.05,
  treasury       BIGINT NOT NULL DEFAULT 0 CHECK (treasury >= 0),
  laws           JSONB NOT NULL DEFAULT '[]'::jsonb,
  commissions    JSONB NOT NULL DEFAULT '[]'::jsonb,
  at_war_with    JSONB NOT NULL DEFAULT '[]'::jsonb,
  tax_set_in_cycle INTEGER NOT NULL DEFAULT -1
);

CREATE TABLE candidacies (
  village_id TEXT NOT NULL,
  office_id  TEXT NOT NULL,
  cycle      INTEGER NOT NULL,
  player_id  TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  PRIMARY KEY (village_id, office_id, cycle, player_id)
);

-- One vote per player per office per cycle. The primary key is the guarantee:
-- a client that submits the same vote twice is refused by the database, not by
-- a check that could lose a race.
CREATE TABLE votes (
  village_id   TEXT NOT NULL,
  office_id    TEXT NOT NULL,
  cycle        INTEGER NOT NULL,
  voter_id     TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  candidate_id TEXT NOT NULL,
  cast_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (village_id, office_id, cycle, voter_id)
);
CREATE INDEX votes_tally_idx ON votes (village_id, cycle, office_id);

CREATE TABLE office_holders (
  village_id TEXT NOT NULL,
  office_id  TEXT NOT NULL,
  cycle      INTEGER NOT NULL,
  holder_ids JSONB NOT NULL DEFAULT '[]'::jsonb,
  seated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (village_id, office_id, cycle)
);

-- ── Mentorship ─────────────────────────────────────────────────────────────
-- A partial unique index gives the property that matters: a student has at most
-- one active mentor, however many offers are outstanding.
CREATE TABLE mentorships (
  id            TEXT PRIMARY KEY,
  mentor_id     TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  mentee_id     TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  status        TEXT NOT NULL CHECK (status IN ('offered','active','ended')),
  started_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  ended_at      TIMESTAMPTZ,
  rewarded      JSONB NOT NULL DEFAULT '[]'::jsonb,
  reward_times  JSONB NOT NULL DEFAULT '[]'::jsonb
);
CREATE UNIQUE INDEX mentorships_one_active_mentee ON mentorships (mentee_id) WHERE status = 'active';
CREATE INDEX mentorships_mentor_idx ON mentorships (mentor_id, status);
