import { randomUUID } from 'node:crypto';
import { ITEM_BY_ID, REGION_BY_ID, TERRITORY, currentSeason } from '@shinobi/content';
import { makeRng } from '@shinobi/engine';
import type { ClanRecord, GatherSession, PlayerRecord, RegionRecord, Store, WarRecord } from './store/index.js';
import { loadVillage, villageEffects, warPeriod } from './world.js';
import { roleOf } from './clans.js';

/**
 * Territory.
 *
 * Two things this deliberately does NOT do.
 *
 * It does not give the holder of a region any combat statistic. The design
 * direction asks for "PvP buffs" from territory; a permanent stat bonus for
 * whoever already holds ground snowballs, invalidates every number in
 * tuning.json, and — worse — is invisible to the player on the other side of the
 * fight. The defender's advantage is expressed instead as a multiplier on WAR
 * SCORE, which is visible on the war board, bounded, and cannot leak into a
 * ladder match.
 *
 * It does not settle a war with a random roll. Resolution is a comparison of two
 * scores that were earned by play, so any member of either clan can work out why
 * they lost.
 */

const DAY = 24 * 60 * 60 * 1000;

export class TerritoryError extends Error {
  constructor(readonly code:
    | 'noSuchRegion' | 'notInClan' | 'notOfficer' | 'clanTooSmall' | 'windowClosed'
    | 'alreadyContested' | 'cannotAfford' | 'tooManyRegions' | 'ownGarrison'
    | 'notAtWar' | 'rogue' | 'busy' | 'notGathering' | 'notHere' | 'outOfSeason'
    | 'alreadyDeclared') {
    super(code);
  }
}

/** Regions are seeded from content on first read, so a fresh database needs no migration step. */
export async function loadRegions(store: Store, nowMs: number): Promise<RegionRecord[]> {
  const existing = await store.listRegionRecords();
  const byId = new Map(existing.map((r) => [r.id, r]));
  const out: RegionRecord[] = [];
  for (const def of TERRITORY.regions) {
    let rec = byId.get(def.id);
    if (!rec) {
      rec = { id: def.id, controllingVillageId: def.homeVillage, garrisonClanId: null, capturedAt: nowMs };
      await store.saveRegion(rec);
    }
    out.push(rec);
  }
  return out;
}

export async function loadRegion(store: Store, id: string, nowMs: number): Promise<RegionRecord> {
  if (!REGION_BY_ID.has(id)) throw new TerritoryError('noSuchRegion');
  const existing = await store.getRegion(id);
  if (existing) return existing;
  const def = REGION_BY_ID.get(id)!;
  const rec = { id, controllingVillageId: def.homeVillage, garrisonClanId: null, capturedAt: nowMs };
  await store.saveRegion(rec);
  return rec;
}

/* ── Declaring ────────────────────────────────────────────────────────── */

export interface DeclareResult { war: WarRecord; stake: number }

/**
 * A declaration costs the CLAN's money, not the declaring officer's. That is
 * what stops a single wealthy player from opening wars a clan did not agree to:
 * the treasury is already guarded by officer rank, tenure and a daily cap.
 */
export async function declareWar(
  store: Store,
  clan: ClanRecord,
  actor: PlayerRecord,
  regionId: string,
  nowMs: number,
): Promise<DeclareResult> {
  if (actor.rogue) throw new TerritoryError('rogue');
  const role = roleOf(clan, actor.id);
  if (role !== 'leader' && role !== 'officer') throw new TerritoryError('notOfficer');

  const w = TERRITORY.war;
  if (clan.memberIds.length < w.minMembersToDeclare) throw new TerritoryError('clanTooSmall');

  const period = warPeriod(nowMs);
  if (!period.declareWindowOpen) throw new TerritoryError('windowClosed');

  const region = await loadRegion(store, regionId, nowMs);
  if (region.garrisonClanId === clan.id) throw new TerritoryError('ownGarrison');

  const wars = await store.listWars();
  if (wars.some((x) => x.regionId === regionId && x.periodIndex === period.index)) {
    throw new TerritoryError('alreadyContested');
  }
  if (wars.some((x) => x.periodIndex === period.index && x.attackerClanId === clan.id)) {
    throw new TerritoryError('alreadyDeclared');
  }

  const held = (await store.listRegionRecords()).filter((r) => r.garrisonClanId === clan.id).length;
  if (held >= w.maxRegionsPerClan) throw new TerritoryError('tooManyRegions');

  /* Crossing a border needs a war between the villages. Contesting a region your
     own village already holds does not — a rival clan at home is a legitimate
     target, and it is the only entry point a new clan has. */
  if (region.controllingVillageId !== actor.villageId) {
    const home = await loadVillage(store, actor.villageId);
    if (!home.atWarWith.includes(region.controllingVillageId)) throw new TerritoryError('notAtWar');
  }

  if (clan.bank < w.declareCost) throw new TerritoryError('cannotAfford');
  clan.bank -= w.declareCost;

  const war: WarRecord = {
    id: randomUUID(),
    regionId,
    periodIndex: period.index,
    attackerClanId: clan.id,
    defenderClanId: region.garrisonClanId,
    stake: w.declareCost,
    attackerScore: 0,
    defenderScore: 0,
    contributions: {},
    declaredAt: nowMs,
    resolvesAt: period.endsAtMs,
    resolved: false,
    winnerClanId: null,
  };
  // The store rejects a second war on this region this period; that rejection,
  // not the check above, is what holds under concurrency.
  await store.createWar(war);
  return { war, stake: w.declareCost };
}

/* ── Scoring ──────────────────────────────────────────────────────────── */

export type WarDeed = 'pvpWin' | 'missionCompleted' | 'sRankCompleted' | 'bountyClaimed';

/**
 * Credit a player's deed to whichever wars their clan is fighting.
 *
 * Three properties are load-bearing:
 *   * a contributor must have been in the clan before the period opened, so a
 *     clan cannot hire mercenaries mid-war;
 *   * each member's total is capped, so one player grinding cannot decide a war
 *     on their own;
 *   * contributions are recorded per player, which is what makes the cap
 *     enforceable at all.
 */
export async function creditWarScore(
  store: Store,
  player: PlayerRecord,
  deed: WarDeed,
  nowMs: number,
): Promise<WarRecord[]> {
  if (!player.clanId || player.rogue) return [];
  const period = warPeriod(nowMs);
  const wars = (await store.listWars()).filter(
    (x) => !x.resolved && x.periodIndex === period.index
      && (x.attackerClanId === player.clanId || x.defenderClanId === player.clanId),
  );
  if (wars.length === 0) return [];

  const tenureOk = player.clanJoinedAt !== null
    && nowMs - player.clanJoinedAt >= TERRITORY.war.minTenureMinutesToScore * 60_000;
  if (!tenureOk) return [];

  const s = TERRITORY.war.score;
  const base = deed === 'pvpWin' ? s.pvpWin
    : deed === 'missionCompleted' ? s.missionCompleted
      : deed === 'sRankCompleted' ? s.sRankCompleted
        : s.bountyClaimed;

  const touched: WarRecord[] = [];
  for (const war of wars) {
    const already = war.contributions[player.id] ?? 0;
    const room = Math.max(0, s.maxPerMemberPerPeriod - already);
    const credited = Math.min(base, room);
    if (credited <= 0) continue;

    const defending = war.defenderClanId === player.clanId;
    let multiplier = 1;
    if (defending) {
      multiplier *= TERRITORY.war.defenderScoreMultiplier;
      const village = await loadVillage(store, player.villageId);
      multiplier *= 1 + villageEffects(village, nowMs).defenceScoreBonus;
    }
    const village = await loadVillage(store, player.villageId);
    multiplier *= 1 + villageEffects(village, nowMs).warScoreBonus;

    war.contributions[player.id] = already + credited;
    const points = Math.round(credited * multiplier);
    if (defending) war.defenderScore += points; else war.attackerScore += points;
    await store.saveWar(war);
    touched.push(war);
  }
  return touched;
}

/* ── Resolution ───────────────────────────────────────────────────────── */

export interface WarOutcome {
  war: WarRecord;
  winnerClanId: string | null;
  note: string;
}

/**
 * Resolve every war whose period has closed. Called opportunistically whenever
 * anyone looks at the war board rather than from a timer: a scheduled job that
 * fails to fire leaves ownership frozen, and there is no state here that needs a
 * job to be correct.
 */
export async function resolveDueWars(store: Store, nowMs: number): Promise<WarOutcome[]> {
  const due = (await store.listWars()).filter((w) => !w.resolved && w.resolvesAt <= nowMs);
  const out: WarOutcome[] = [];

  for (const war of due) {
    const attackerWins = war.attackerScore > war.defenderScore;
    war.resolved = true;
    war.winnerClanId = attackerWins ? war.attackerClanId : war.defenderClanId;

    if (attackerWins) {
      const region = await loadRegion(store, war.regionId, nowMs);
      const attacker = await store.getClan(war.attackerClanId);
      region.garrisonClanId = war.attackerClanId;
      if (attacker) {
        const holder = await store.getPlayer(attacker.leaderId);
        if (holder) region.controllingVillageId = holder.villageId;
      }
      region.capturedAt = nowMs;
      await store.saveRegion(region);

      /* The stake does not come back whole. The shortfall is burned, so two
         clans passing a region back and forth every week lose money doing it —
         the same inequality the bounty economy rests on. */
      if (attacker) {
        attacker.bank += Math.floor(war.stake * TERRITORY.war.spoils.winnerBankShareOfStake);
        await store.saveClan(attacker);
      }
      out.push({ war, winnerClanId: war.attackerClanId, note: 'The region changed hands.' });
    } else {
      const defender = war.defenderClanId ? await store.getClan(war.defenderClanId) : null;
      if (defender) {
        defender.bank += Math.floor(war.stake * TERRITORY.war.spoils.winnerBankShareOfStake);
        await store.saveClan(defender);
      }
      out.push({
        war,
        winnerClanId: war.defenderClanId,
        note: war.defenderClanId ? 'The garrison held.' : 'The assault failed and the ground stayed empty.',
      });
    }
    await store.saveWar(war);
  }
  return out;
}

/* ── Gathering ────────────────────────────────────────────────────────── */

/** One occupation at a time. Training, a mission, a gather, a craft, a dungeon. */
export function occupied(player: PlayerRecord): boolean {
  return Boolean(player.training || player.mission || player.gathering || player.crafting || player.dungeon);
}

export function startGathering(player: PlayerRecord, region: RegionRecord, itemId: string, nowMs: number): GatherSession {
  if (occupied(player)) throw new TerritoryError('busy');
  const def = REGION_BY_ID.get(region.id);
  if (!def) throw new TerritoryError('noSuchRegion');
  if (!def.resources.includes(itemId)) throw new TerritoryError('notHere');

  const item = ITEM_BY_ID.get(itemId);
  if (!item) throw new TerritoryError('notHere');
  const season = currentSeason(nowMs).id;
  if (!item.seasons.includes(season)) throw new TerritoryError('outOfSeason');

  return { regionId: region.id, itemId, startedAt: nowMs };
}

export interface GatherResult {
  itemId: string;
  units: number;
  tollUnits: number;
  tollValue: number;
  complete: boolean;
  note: string;
}

/**
 * Yield is seeded from (playerId, regionId, startedAt), so re-claiming a trip
 * cannot re-roll it and two players standing in the same place do not get the
 * same haul. Partial trips pay pro rata and nothing beyond the trip's own length
 * is ever credited, which is the training rule applied to a second resource.
 */
export function claimGathering(
  player: PlayerRecord,
  region: RegionRecord,
  nowMs: number,
  opts: { villageGatherBonus: number; outsiderPenaltyWaived: boolean; outsiderTollFraction: number },
): GatherResult {
  const session = player.gathering;
  if (!session) throw new TerritoryError('notGathering');

  const y = TERRITORY.yield;
  const elapsedMinutes = Math.max(0, (nowMs - session.startedAt) / 60_000);
  const credited = Math.min(elapsedMinutes, y.gatherMinutes);
  const fraction = credited / y.gatherMinutes;

  const insider = !player.rogue && player.villageId === region.controllingVillageId;
  const garrison = Boolean(player.clanId) && player.clanId === region.garrisonClanId;

  let multiplier = 1;
  if (insider) multiplier *= 1 + y.controllingVillageBonus;
  else if (!opts.outsiderPenaltyWaived) multiplier *= y.outsiderPenalty;
  if (garrison) multiplier *= 1 + y.garrisonClanBonus;
  multiplier *= 1 + Math.max(0, opts.villageGatherBonus) + Math.max(0, player.boosts.gatherYieldBonus);

  const rng = makeRng(`gather:${player.id}:${session.regionId}:${session.startedAt}`);
  const variance = 0.85 + rng.next() * 0.3;

  const units = Math.max(0, Math.floor(y.baseUnits * fraction * multiplier * variance));

  const owesToll = !insider && !player.rogue && !opts.outsiderPenaltyWaived;
  const tollUnits = owesToll ? Math.floor(units * opts.outsiderTollFraction) : 0;
  const item = ITEM_BY_ID.get(session.itemId);
  const tollValue = tollUnits * (item?.baseValue ?? 0);

  return {
    itemId: session.itemId,
    units: units - tollUnits,
    tollUnits,
    tollValue,
    complete: elapsedMinutes >= y.gatherMinutes,
    note: owesToll && tollUnits > 0
      ? 'A share went to the village that holds the ground.'
      : insider ? 'Home ground.' : 'Nobody asked for a cut.',
  };
}

export const WAR_PERIOD_MS = TERRITORY.war.periodDays * DAY;
