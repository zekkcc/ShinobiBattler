import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { buildServer } from './app.js';
import { Accounts } from './accounts.js';
import { MemoryStore, type Store } from './store/index.js';
import { migrate, PostgresStore } from './store/postgres.js';

/**
 * Bootstrap.
 *
 * Set DATABASE_URL to run on Postgres; without it the server runs in memory and
 * everything resets on restart, which is fine for local play and useless for
 * anything else. Nothing about the trust model differs between the two — none of
 * it lives in the storage layer.
 */
async function makeStore(): Promise<{ store: Store; kind: string }> {
  const url = process.env.DATABASE_URL;
  if (!url) return { store: new MemoryStore(), kind: 'memory (nothing survives a restart)' };

  const { default: pg } = await import('pg');
  const pool = new pg.Pool({ connectionString: url });
  if (process.env.MIGRATE_ON_BOOT === '1') await migrate(pool);
  return { store: new PostgresStore(pool), kind: 'postgres' };
}

const { store, kind } = await makeStore();

/* Seed two accounts for local play. Real deployments register through the API;
   this only runs when SEED_DEV_ACCOUNTS is set, so it can never fire in
   production and quietly create logins with a published password. */
if (process.env.SEED_DEV_ACCOUNTS === '1') {
  const accounts = new Accounts(store);
  for (const name of ['Alice', 'Bob']) {
    const result = await accounts.register({ name, password: 'developmentonly', villageId: 'konohagakure' });
    if (result.ok) console.log(`seeded ${name} — token ${result.token}`);
  }
}

/* One process serves both the API and the built client, so a deployment is a
   single container behind a single origin. WEB_DIST overrides the location; the
   default is where `pnpm build` puts it. */
const staticDir = process.env.WEB_DIST
  ?? fileURLToPath(new URL('../../web/dist', import.meta.url));

const app = await buildServer({ store, staticDir });
const port = Number(process.env.PORT ?? 3000);
await app.listen({ port, host: '0.0.0.0' });
console.log(`server listening on :${port} — storage: ${kind}`);
console.log(existsSync(staticDir)
  ? `serving the web client from ${staticDir}`
  : 'no web build found — run pnpm build, or use the Vite dev server on :5173');

/* Shut down cleanly so a container restart does not drop live sockets on the
   floor and leave matches in limbo. */
for (const signal of ['SIGTERM', 'SIGINT'] as const) {
  process.on(signal, () => {
    void app.close().then(() => process.exit(0));
  });
}
