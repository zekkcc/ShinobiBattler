/**
 * Token-bucket rate limiting. CLAUDE.md §5: rate-limit every mutating endpoint,
 * assume every client is hostile.
 *
 * Keyed per (identity, operation) so a flood of one action cannot starve another,
 * and so one player can never affect another player's budget.
 */
export interface Bucket { tokens: number; lastRefillMs: number }

export interface LimitPolicy {
  /** sustained rate */
  perMinute: number;
  /** how much can be spent at once */
  burst: number;
}

export const POLICIES = {
  submitAction: { perMinute: 120, burst: 12 },
  queue: { perMinute: 12, burst: 3 },
  forfeit: { perMinute: 10, burst: 2 },
  startTraining: { perMinute: 20, burst: 4 },
  claimTraining: { perMinute: 20, burst: 4 },
  setLoadout: { perMinute: 20, burst: 5 },
  ping: { perMinute: 120, burst: 20 },
  connect: { perMinute: 30, burst: 6 },
  login: { perMinute: 5, burst: 5 },
  register: { perMinute: 3, burst: 3 },
  getReplay: { perMinute: 30, burst: 6 },
  listMissions: { perMinute: 30, burst: 8 },
  acceptMission: { perMinute: 20, burst: 4 },
  completeMission: { perMinute: 20, burst: 4 },
  learnJutsu: { perMinute: 20, burst: 5 },
  requestPromotion: { perMinute: 10, burst: 3 },
  createSquad: { perMinute: 10, burst: 3 },
  inviteToSquad: { perMinute: 20, burst: 6 },
  acceptSquadInvite: { perMinute: 20, burst: 5 },
  leaveSquad: { perMinute: 15, burst: 4 },
  acceptPartyMission: { perMinute: 15, burst: 4 },
  completePartyMission: { perMinute: 20, burst: 4 },
  defect: { perMinute: 3, burst: 2 },
  seekAmnesty: { perMinute: 3, burst: 2 },
  listBounties: { perMinute: 30, burst: 8 },
  takeBountyContract: { perMinute: 10, burst: 3 },
  foundClan: { perMinute: 3, burst: 2 },
  inviteToClan: { perMinute: 20, burst: 6 },
  acceptClanInvite: { perMinute: 10, burst: 3 },
  leaveClan: { perMinute: 6, burst: 2 },
  kickFromClan: { perMinute: 15, burst: 5 },
  setClanOfficer: { perMinute: 15, burst: 5 },
  handOverClan: { perMinute: 3, burst: 2 },
  depositToClan: { perMinute: 20, burst: 6 },
  withdrawFromClan: { perMinute: 10, burst: 3 },
  listClans: { perMinute: 20, burst: 6 },
  listLegacy: { perMinute: 20, burst: 6 },
  setTitle: { perMinute: 20, burst: 5 },
  claimLegendary: { perMinute: 10, burst: 3 },
  legendaryHistory: { perMinute: 20, burst: 6 },
} as const satisfies Record<string, LimitPolicy>;

export type Operation = keyof typeof POLICIES;

/**
 * Fallback for an operation with no policy of its own. Adding a message type and
 * forgetting to add a policy used to crash the handler, which meant a new
 * protocol message could take the server down. Unknown operations are now
 * limited conservatively instead.
 */
export const DEFAULT_POLICY: LimitPolicy = { perMinute: 10, burst: 3 };

export class RateLimiter {
  private buckets = new Map<string, Bucket>();

  /** Returns true if the operation is allowed and consumes a token. */
  take(identity: string, op: Operation, nowMs: number): boolean {
    const policy: LimitPolicy = POLICIES[op] ?? DEFAULT_POLICY;
    const key = `${identity}|${op}`;
    let bucket = this.buckets.get(key);
    if (!bucket) {
      bucket = { tokens: policy.burst, lastRefillMs: nowMs };
      this.buckets.set(key, bucket);
    }

    const elapsedMs = Math.max(0, nowMs - bucket.lastRefillMs);
    const refill = (elapsedMs / 60_000) * policy.perMinute;
    bucket.tokens = Math.min(policy.burst, bucket.tokens + refill);
    bucket.lastRefillMs = nowMs;

    if (bucket.tokens < 1) return false;
    bucket.tokens -= 1;
    return true;
  }

  /** Drops buckets that have been idle long enough to be back at full. */
  sweep(nowMs: number, idleMs = 10 * 60_000): void {
    for (const [key, bucket] of this.buckets) {
      if (nowMs - bucket.lastRefillMs > idleMs) this.buckets.delete(key);
    }
  }

  get size(): number { return this.buckets.size; }
}
