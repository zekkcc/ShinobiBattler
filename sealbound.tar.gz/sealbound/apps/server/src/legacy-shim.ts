/** Re-exports so legacy.ts has one import surface for content + rank ordering. */
export { LEGACY, type LegacyCriterion } from '@shinobi/content';
export { RANKS as RANKS_ORDER } from '@shinobi/shared';
