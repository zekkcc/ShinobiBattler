import { LEGACY, RANKS_ORDER, type LegacyCriterion } from './legacy-shim.js';
import type { LegendaryRecord, PlayerRecord, Store } from './store/index.js';

/**
 * Legacy: titles and legendary items.
 *
 * The design direction is explicit that titles are earned and never purchased,
 * and that a legendary exists once on a server and is never duplicated. Both are
 * enforced here and, more importantly, in the schema — a unique primary key on
 * the item id is what actually guarantees uniqueness under concurrency, not the
 * check in this file.
 *
 * Neither grants combat power. That is a deliberate call rather than an
 * omission: a permanent stat bonus handed to whoever reached a milestone first
 * would make the ladder unwinnable for everyone who arrived later, and would
 * quietly invalidate every balance number. They confer standing.
 */

export class LegacyError extends Error {
  constructor(readonly code: 'notEarned' | 'alreadyHeld' | 'noSuchTitle' | 'noSuchItem' | 'notHolder') {
    super(code);
  }
}

/** Everything a criterion can be measured against. */
export interface LegacyStats {
  missionsCompleted: number;
  pvpWins: number;
  rating: number;
  bountiesClaimed: number;
  notoriety: number;
  reputation: number;
  rank: number;
  sRankCompleted: number;
  clanFounded: number;
}

export function statsFor(p: PlayerRecord): LegacyStats {
  return {
    missionsCompleted: p.missionsCompleted,
    pvpWins: p.pvpWins,
    rating: p.rating,
    bountiesClaimed: p.bountiesClaimed,
    notoriety: p.notoriety,
    reputation: p.reputation,
    rank: RANKS_ORDER.indexOf(p.rank),
    sRankCompleted: p.sRankCompleted,
    clanFounded: p.clanId ? 1 : 0,
  };
}

const meets = (stats: LegacyStats, criterion: LegacyCriterion, threshold: number) =>
  stats[criterion] >= threshold;

/* ── Titles ──────────────────────────────────────────────────────────── */

/**
 * Titles are not unique — many players can hold "The Tireless". They are simply
 * earned. There is deliberately no way to grant one outside this function, and
 * no price anywhere in the data.
 */
export function earnedTitles(p: PlayerRecord): string[] {
  const stats = statsFor(p);
  return LEGACY.titles.filter((t) => meets(stats, t.criterion, t.threshold)).map((t) => t.id);
}

/** Returns the ids newly earned since last checked, and records them. */
export function awardTitles(p: PlayerRecord): string[] {
  const earned = earnedTitles(p);
  const fresh = earned.filter((id) => !p.titles.includes(id));
  if (fresh.length) p.titles = [...p.titles, ...fresh];
  return fresh;
}

export function setDisplayedTitle(p: PlayerRecord, titleId: string | null): void {
  if (titleId === null) { p.displayedTitle = null; return; }
  if (!LEGACY.titles.some((t) => t.id === titleId)) throw new LegacyError('noSuchTitle');
  if (!p.titles.includes(titleId)) throw new LegacyError('notEarned');
  p.displayedTitle = titleId;
}

/* ── Legendary items ─────────────────────────────────────────────────── */

export interface LegendaryClaim { itemId: string; name: string; lore: string }

/**
 * Which legendaries this player has now qualified for and nobody holds yet.
 * The caller still has to win the race in the database — this only shortlists.
 */
export function claimable(p: PlayerRecord, held: LegendaryRecord[]): LegendaryClaim[] {
  const stats = statsFor(p);
  const taken = new Set(held.map((h) => h.itemId));
  return LEGACY.legendaries
    .filter((l) => !taken.has(l.id) && meets(stats, l.claim, l.threshold))
    .map((l) => ({ itemId: l.id, name: l.name, lore: l.lore }));
}

/**
 * Claims an item for a player. Uniqueness is enforced by the store's insert, so
 * two simultaneous claimants cannot both succeed — the loser gets `alreadyHeld`.
 */
export async function claimLegendary(
  store: Store, player: PlayerRecord, itemId: string, nowMs: number,
): Promise<LegendaryClaim> {
  const def = LEGACY.legendaries.find((l) => l.id === itemId);
  if (!def) throw new LegacyError('noSuchItem');

  const stats = statsFor(player);
  if (!meets(stats, def.claim, def.threshold)) throw new LegacyError('notEarned');

  const existing = await store.getLegendary(itemId);
  if (existing) throw new LegacyError('alreadyHeld');

  // The store rejects a second insert of the same id; that rejection, not the
  // check above, is what actually makes this safe.
  await store.claimLegendary({ itemId, holderId: player.id, acquiredAt: nowMs }, nowMs);
  return { itemId, name: def.name, lore: def.lore };
}

/**
 * Moves an item to a new holder and appends to its permanent record. Nothing
 * ever deletes from that record — the chain of custody is the point.
 */
export async function transferLegendary(
  store: Store, itemId: string, fromId: string, toId: string, nowMs: number,
): Promise<void> {
  const held = await store.getLegendary(itemId);
  if (!held) throw new LegacyError('noSuchItem');
  if (held.holderId !== fromId) throw new LegacyError('notHolder');
  await store.transferLegendary(itemId, toId, nowMs);
}
