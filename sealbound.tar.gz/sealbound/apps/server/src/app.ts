import Fastify, { type FastifyInstance } from 'fastify';
import websocket from '@fastify/websocket';
import { BLOODLINES, CLANS, JUTSU, MISSIONS, TRAINING, VILLAGES } from '@shinobi/content';
import type { ServerMessage } from '@shinobi/shared';
import { GameService } from './service.js';
import { RateLimiter } from './ratelimit.js';
import { MemoryStore, type Store } from './store/index.js';
import { Accounts, StoreSessionResolver, ZLogin, ZRegister } from './accounts.js';
import { currentWeather } from './training.js';

/**
 * Transport only. It resolves a connection to an authenticated player id and
 * hands the raw payload to GameService — it makes no game decisions of its own,
 * so there is exactly one place where the trust model can be got wrong.
 */

export interface SessionResolver {
  /** Maps a connection's credentials to a player id, or null to reject. */
  resolve(token: string | undefined): Promise<string | null>;
}

export interface BuildOptions {
  store?: Store;
  /** defaults to session lookup in the store; override only for tests */
  sessions?: SessionResolver;
  now?: () => number;
}

export async function buildServer(opts: BuildOptions): Promise<FastifyInstance> {
  const store = opts.store ?? new MemoryStore();
  const now = opts.now ?? Date.now;
  const service = new GameService(store, now);
  const accounts = new Accounts(store, now);
  const sessions = opts.sessions ?? new StoreSessionResolver(store, now);
  const connectLimiter = new RateLimiter();
  const authLimiter = new RateLimiter();

  const app = Fastify({ logger: false });
  await app.register(websocket);

  /** Live sockets, so a delivery addressed to a player reaches them. */
  const sockets = new Map<string, { send(data: string): void }>();

  const deliver = (messages: { to: string; message: ServerMessage }[], fallback?: string) => {
    for (const d of messages) {
      const target = d.to || fallback;
      if (!target) continue;
      sockets.get(target)?.send(JSON.stringify(d.message));
    }
  };

  /* ── Read-only content endpoints. No auth needed; nothing mutates. ──── */

  app.get('/api/content/jutsu', async () => JUTSU);
  app.get('/api/content/bloodlines', async () => BLOODLINES);
  app.get('/api/content/villages', async () => ({ villages: VILLAGES, clans: CLANS }));
  app.get('/api/content/training', async () => TRAINING);
  app.get('/api/content/missions', async () => MISSIONS);
  app.get('/api/weather', async () => ({ weather: currentWeather(now()) }));
  app.get('/health', async () => ({ ok: true, rooms: service.activeRooms }));

  /* ── Replays are (seed, actions[]); the client replays them locally. ── */
  app.get<{ Params: { matchId: string } }>('/api/replay/:matchId', async (req, reply) => {
    const replay = await store.getReplay(req.params.matchId);
    if (!replay) return reply.code(404).send({ error: 'noSuchReplay' });
    return replay;
  });

  /* ── Accounts ───────────────────────────────────────────────────────
     Registration and login are the only unauthenticated mutating endpoints, so
     they are rate limited per IP. Without that, the login form is a free
     password-guessing oracle. */

  app.post('/api/register', async (req, reply) => {
    if (!authLimiter.take(req.ip ?? 'unknown', 'register', now())) {
      return reply.code(429).send({ error: 'rateLimited', detail: 'Too many attempts. Wait a minute.' });
    }
    const parsed = ZRegister.safeParse(req.body);
    if (!parsed.success) return reply.code(400).send({ error: 'badRequest', detail: parsed.error.issues[0]?.message });

    const result = await accounts.register(parsed.data);
    if (!result.ok) return reply.code(409).send({ error: result.code, detail: result.detail });
    return reply.code(201).send({ token: result.token, playerId: result.playerId, expiresAt: result.expiresAt });
  });

  app.post('/api/login', async (req, reply) => {
    if (!authLimiter.take(req.ip ?? 'unknown', 'login', now())) {
      return reply.code(429).send({ error: 'rateLimited', detail: 'Too many attempts. Wait a minute.' });
    }
    const parsed = ZLogin.safeParse(req.body);
    if (!parsed.success) return reply.code(400).send({ error: 'badRequest' });

    const result = await accounts.login(parsed.data);
    if (!result.ok) return reply.code(401).send({ error: result.code, detail: result.detail });
    return reply.send({ token: result.token, playerId: result.playerId, expiresAt: result.expiresAt });
  });

  app.post('/api/logout', async (req, reply) => {
    const token = (req.headers.authorization ?? '').replace(/^Bearer\s+/i, '');
    if (token) await accounts.logout(token);
    return reply.send({ ok: true });
  });

  /* ── The socket ─────────────────────────────────────────────────────── */

  app.get('/ws', { websocket: true }, async (socket, req) => {
    const token = (req.headers['sec-websocket-protocol'] as string | undefined)
      ?? (req.query as { token?: string } | undefined)?.token;

    const ip = req.ip ?? 'unknown';
    if (!connectLimiter.take(ip, 'connect', now())) {
      socket.send(JSON.stringify({ type: 'error', code: 'rateLimited' } satisfies ServerMessage));
      socket.close();
      return;
    }

    const playerId = await sessions.resolve(token);
    if (!playerId) {
      socket.send(JSON.stringify({ type: 'error', code: 'unauthenticated' } satisfies ServerMessage));
      socket.close();
      return;
    }

    sockets.set(playerId, socket);
    socket.send(JSON.stringify({ type: 'welcome', playerId, weather: currentWeather(now()) } satisfies ServerMessage));
    deliver(await service.hello(playerId), playerId);

    socket.on('message', (data: Buffer) => {
      void (async () => {
        let raw: unknown;
        try {
          raw = JSON.parse(data.toString('utf8'));
        } catch {
          socket.send(JSON.stringify({ type: 'error', code: 'badJson' } satisfies ServerMessage));
          return;
        }
        // playerId comes from the authenticated socket, never from `raw`.
        const out = await service.handle(playerId, raw);
        deliver(out, playerId);
      })();
    });

    socket.on('close', () => {
      if (sockets.get(playerId) === socket) sockets.delete(playerId);
    });
  });

  /* ── Round timeouts: a silent client must not stall a match forever. ── */
  const timer = setInterval(() => {
    void (async () => deliver(await service.tickTimeouts()))();
  }, 5_000);
  const sweeper = setInterval(() => { void accounts.sweepSessions(); }, 60 * 60_000);
  app.addHook('onClose', async () => { clearInterval(timer); clearInterval(sweeper); });

  return app;
}
