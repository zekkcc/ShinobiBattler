import { POLITICS, VILLAGE_BY_ID } from '@shinobi/content';
import { RANKS, type Rank } from '@shinobi/shared';
import type { OfficeRecord, PlayerRecord, Store, VillageRecord } from './store/index.js';
import { cycleIndex, electionPhase, loadVillage } from './world.js';

/**
 * Village politics.
 *
 * The design direction asks for players to actually run villages — Kage,
 * council, taxes, laws, war. The obvious failure mode is not that the wrong
 * person wins; it is that winning becomes worth buying. Three things prevent
 * that, and all three are structural rather than a matter of tuning:
 *
 *   1. Every power is bounded by content. Tax moves inside a band and once per
 *      term; laws come from a fixed list with fixed effects; spending comes from
 *      a fixed list of commissions.
 *   2. There is no path from the village treasury to a personal wallet. Not a
 *      capped one — none at all. `validate:content` fails the build if a payout
 *      field ever appears in politics.json.
 *   3. No power is combat power. The strongest thing an office can buy is a
 *      training bonus and a war-score bonus, neither of which is visible inside
 *      `resolveTurn`.
 *
 * Suffrage is the other half. A vote costs five completed missions and a day of
 * standing — deliberately made of things that take real play, because an
 * election decided by fresh accounts is a detection problem nobody wins, and a
 * cost is a defence that does not have to notice anything.
 */

const DAY = 24 * 60 * 60 * 1000;
const rankIndex = (r: Rank) => RANKS.indexOf(r);

export class PoliticsError extends Error {
  constructor(readonly code:
    | 'noSuchOffice' | 'noSuchVillage' | 'wrongPhase' | 'notEligible' | 'alreadyStanding'
    | 'notACandidate' | 'alreadyVoted' | 'rogue' | 'notInOffice' | 'noPower'
    | 'taxOutOfBand' | 'taxAlreadySet' | 'unknownLaw' | 'lawSlotsFull' | 'lawNotActive'
    | 'unknownCommission' | 'cannotAfford' | 'tooManyCommissions' | 'sameVillage'
    | 'differentVillage') {
    super(code);
  }
}

/* ── Eligibility ──────────────────────────────────────────────────────── */

export function suffrageProblem(player: PlayerRecord, nowMs: number): string | null {
  const s = POLITICS.suffrage;
  if (player.rogue && !s.roguesMayVote) return 'rogue';
  if (rankIndex(player.rank) < rankIndex(s.minRank)) return 'rank';
  if (player.missionsCompleted < s.minMissionsCompleted) return 'missions';
  if (nowMs - player.createdAt < s.minAccountAgeMinutes * 60_000) return 'tooNew';
  return null;
}

export function mayStand(player: PlayerRecord, officeId: string): boolean {
  const office = POLITICS.offices.find((o) => o.id === officeId);
  if (!office || player.rogue) return false;
  return rankIndex(player.rank) >= rankIndex(office.minRank) && player.reputation >= office.minReputation;
}

/* ── Standing and voting ──────────────────────────────────────────────── */

export async function stand(store: Store, player: PlayerRecord, officeId: string, nowMs: number): Promise<void> {
  if (!POLITICS.offices.some((o) => o.id === officeId)) throw new PoliticsError('noSuchOffice');
  const { cycle, phase } = electionPhase(nowMs);
  if (phase !== 'nomination') throw new PoliticsError('wrongPhase');
  if (!mayStand(player, officeId)) throw new PoliticsError('notEligible');
  try {
    await store.addCandidacy({ villageId: player.villageId, officeId, cycle, playerId: player.id });
  } catch {
    throw new PoliticsError('alreadyStanding');
  }
}

export async function castVote(
  store: Store,
  voter: PlayerRecord,
  officeId: string,
  candidateId: string,
  nowMs: number,
): Promise<void> {
  const { cycle, phase } = electionPhase(nowMs);
  if (phase !== 'voting') throw new PoliticsError('wrongPhase');
  if (suffrageProblem(voter, nowMs)) throw new PoliticsError('notEligible');

  const candidacies = await store.listCandidacies(voter.villageId, cycle);
  if (!candidacies.some((c) => c.officeId === officeId && c.playerId === candidateId)) {
    throw new PoliticsError('notACandidate');
  }
  try {
    // One vote per player per office per cycle. The store's rejection is the
    // guarantee — a check here would lose a race with itself.
    await store.castVote({ villageId: voter.villageId, officeId, cycle, voterId: voter.id, candidateId });
  } catch {
    throw new PoliticsError('alreadyVoted');
  }
}

/* ── Certification ────────────────────────────────────────────────────── */

/**
 * Seats the offices for `cycle` from the votes cast in `cycle - 1`.
 *
 * Idempotent, and called lazily whenever anyone looks at the government rather
 * than from a timer. A scheduled job that fails to fire would leave a village
 * with last term's Kage indefinitely, and there is nothing here that a job makes
 * more correct.
 *
 * Ties break on reputation and then on id — never on a random roll, so a
 * candidate who lost can be shown exactly why.
 */
export async function certify(store: Store, villageId: string, cycle: number): Promise<OfficeRecord[]> {
  const existing = await store.listOffices(villageId, cycle);
  if (existing.length > 0) return existing;
  if (cycle < 1) return [];

  const previous = cycle - 1;
  const candidacies = await store.listCandidacies(villageId, previous);
  const votes = await store.listVotes(villageId, previous);

  const seated: OfficeRecord[] = [];
  for (const office of POLITICS.offices) {
    const standing = candidacies.filter((c) => c.officeId === office.id);
    if (standing.length === 0) {
      const empty = { villageId, officeId: office.id, cycle, holderIds: [] };
      await store.saveOffice(empty);
      seated.push(empty);
      continue;
    }
    const counted = new Map<string, number>();
    for (const c of standing) counted.set(c.playerId, 0);
    for (const v of votes) {
      if (v.officeId !== office.id) continue;
      if (!counted.has(v.candidateId)) continue;
      counted.set(v.candidateId, counted.get(v.candidateId)! + 1);
    }

    const ranked = [...counted.entries()];
    const reputations = new Map<string, number>();
    for (const [id] of ranked) reputations.set(id, (await store.getPlayer(id))?.reputation ?? 0);

    ranked.sort((a, b) =>
      b[1] - a[1]
      || (reputations.get(b[0]) ?? 0) - (reputations.get(a[0]) ?? 0)
      || a[0].localeCompare(b[0]));

    const record = {
      villageId,
      officeId: office.id,
      cycle,
      holderIds: ranked.slice(0, office.seats).map(([id]) => id),
    };
    await store.saveOffice(record);
    seated.push(record);
  }
  return seated;
}

export async function currentOffices(store: Store, villageId: string, nowMs: number): Promise<OfficeRecord[]> {
  return certify(store, villageId, cycleIndex(nowMs));
}

export async function holdsPower(
  store: Store,
  player: PlayerRecord,
  power: 'setTax' | 'enactLaw' | 'commissionWork' | 'declareVillageWar' | 'postBounty',
  nowMs: number,
): Promise<boolean> {
  const offices = await currentOffices(store, player.villageId, nowMs);
  for (const held of offices) {
    if (!held.holderIds.includes(player.id)) continue;
    const def = POLITICS.offices.find((o) => o.id === held.officeId);
    if (def?.powers.includes(power)) return true;
  }
  return false;
}

/* ── Powers ───────────────────────────────────────────────────────────── */

/**
 * Tax moves inside a band, by a bounded step, once per term. Without the
 * per-term limit a Kage could ratchet the rate in small legal increments over an
 * afternoon and arrive at the same place the band was meant to prevent.
 */
export function setTax(village: VillageRecord, rate: number, nowMs: number): number {
  const t = POLITICS.tax;
  const cycle = cycleIndex(nowMs);
  if (village.taxSetInCycle === cycle) throw new PoliticsError('taxAlreadySet');
  const rounded = Math.round(rate * 1000) / 1000;
  if (rounded < t.min || rounded > t.max) throw new PoliticsError('taxOutOfBand');
  if (Math.abs(rounded - village.taxRate) > t.changePerCycleMax + 1e-9) throw new PoliticsError('taxOutOfBand');
  village.taxRate = rounded;
  village.taxSetInCycle = cycle;
  return rounded;
}

export function enactLaw(village: VillageRecord, lawId: string): void {
  if (!POLITICS.laws.some((l) => l.id === lawId)) throw new PoliticsError('unknownLaw');
  if (village.laws.includes(lawId)) return;
  if (village.laws.length >= POLITICS.maxActiveLaws) throw new PoliticsError('lawSlotsFull');
  village.laws.push(lawId);
}

export function repealLaw(village: VillageRecord, lawId: string): void {
  if (!village.laws.includes(lawId)) throw new PoliticsError('lawNotActive');
  village.laws = village.laws.filter((l) => l !== lawId);
}

export function commission(village: VillageRecord, commissionId: string, nowMs: number): { id: string; endsAt: number } {
  const def = POLITICS.treasury.commissions.find((c) => c.id === commissionId);
  if (!def) throw new PoliticsError('unknownCommission');
  const live = village.commissions.filter((c) => c.endsAt > nowMs);
  if (live.some((c) => c.id === commissionId)) throw new PoliticsError('tooManyCommissions');
  if (live.length >= POLITICS.treasury.maxActiveCommissions) throw new PoliticsError('tooManyCommissions');
  if (village.treasury < def.cost) throw new PoliticsError('cannotAfford');

  village.treasury -= def.cost;
  const entry = { id: def.id, endsAt: nowMs + def.durationDays * DAY };
  // Expired entries are dropped here rather than swept: the read path already
  // ignores them, and keeping them would grow the row forever.
  village.commissions = [...live, entry];
  return entry;
}

/**
 * A village war is a flag and nothing else. It permits clan declarations across
 * that border; it changes no combat number and cannot lock anybody out of the
 * ladder. Both sides are marked, because a war that only one side can see is a
 * war one side cannot answer.
 */
export async function declareVillageWar(
  store: Store,
  actorVillage: VillageRecord,
  targetVillageId: string,
): Promise<void> {
  if (actorVillage.id === targetVillageId) throw new PoliticsError('sameVillage');
  if (!VILLAGE_BY_ID.has(targetVillageId)) throw new PoliticsError('noSuchVillage');
  if (!actorVillage.atWarWith.includes(targetVillageId)) actorVillage.atWarWith.push(targetVillageId);

  const target = await loadVillage(store, targetVillageId);
  if (!target.atWarWith.includes(actorVillage.id)) {
    target.atWarWith.push(actorVillage.id);
    await store.saveVillage(target);
  }
}

/** Tax collected on a sale funds the seller's village and nothing else. */
export async function collectTax(store: Store, villageId: string, amount: number): Promise<void> {
  if (amount <= 0) return;
  const village = await loadVillage(store, villageId);
  village.treasury += Math.floor(amount);
  await store.saveVillage(village);
}
