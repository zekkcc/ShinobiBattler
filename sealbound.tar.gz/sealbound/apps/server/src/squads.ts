import { randomUUID } from 'node:crypto';
import { MISSIONS, MISSION_BY_ID, type Mission } from '@shinobi/content';
import { makeRng } from '@shinobi/engine';
import { RANKS, type Rank, type StatKey } from '@shinobi/shared';
import type { PlayerRecord, SquadRecord, Store } from './store/index.js';
import { canTakeWork } from './missions.js';

/**
 * Squads and party missions.
 *
 * S-rank work needs a squad, which until now meant S-rank content existed and
 * was unreachable. The rules that matter are the ones that stop a squad being a
 * way to dodge consequences:
 *
 *   * Nobody joins without accepting an invite.
 *   * A player is in at most one squad, and cannot hold a solo mission and a
 *     party mission at once.
 *   * Once a party mission starts, the squad is locked. Leaving is refused, so a
 *     member who senses failure coming cannot walk away from the reputation hit.
 *   * The outcome is seeded from the squad and its start time, so reporting back
 *     repeatedly — or from a different member — cannot re-roll it.
 */

export const MAX_SQUAD = 4;

export class SquadError extends Error {
  constructor(readonly code:
    | 'alreadyInSquad' | 'notInSquad' | 'notLeader' | 'squadFull' | 'noSuchSquad'
    | 'noSuchPlayer' | 'notInvited' | 'onMission' | 'squadLocked' | 'tooFewMembers'
    | 'unknownMission' | 'notAPartyMission' | 'rankLocked' | 'reputationLocked'
    | 'notFinished' | 'busy') {
    super(code);
  }
}

const rankIndex = (r: Rank) => RANKS.indexOf(r);

/* ── Forming a squad ─────────────────────────────────────────────────── */

export function newSquad(leader: PlayerRecord): SquadRecord {
  if (leader.squadId) throw new SquadError('alreadyInSquad');
  if (leader.mission) throw new SquadError('onMission');
  return { id: randomUUID(), leaderId: leader.id, memberIds: [leader.id], invitedIds: [], mission: null };
}

export function invite(squad: SquadRecord, leader: PlayerRecord, target: PlayerRecord): void {
  if (squad.leaderId !== leader.id) throw new SquadError('notLeader');
  if (squad.mission) throw new SquadError('squadLocked');
  if (target.squadId) throw new SquadError('alreadyInSquad');
  if (target.mission) throw new SquadError('busy');
  if (squad.memberIds.length + squad.invitedIds.length >= MAX_SQUAD) throw new SquadError('squadFull');
  if (!squad.invitedIds.includes(target.id)) squad.invitedIds.push(target.id);
}

/** Joining is opt-in: an invite alone puts nobody in a squad. */
export function acceptInvite(squad: SquadRecord, player: PlayerRecord): void {
  if (!squad.invitedIds.includes(player.id)) throw new SquadError('notInvited');
  if (squad.mission) throw new SquadError('squadLocked');
  if (player.mission) throw new SquadError('busy');
  if (squad.memberIds.length >= MAX_SQUAD) throw new SquadError('squadFull');
  squad.invitedIds = squad.invitedIds.filter((id) => id !== player.id);
  squad.memberIds.push(player.id);
}

/** Refusing an invite, or backing out before the mission starts. */
export function leaveSquad(squad: SquadRecord, player: PlayerRecord): { disbanded: boolean } {
  if (squad.mission && squad.memberIds.includes(player.id)) throw new SquadError('squadLocked');
  squad.invitedIds = squad.invitedIds.filter((id) => id !== player.id);
  squad.memberIds = squad.memberIds.filter((id) => id !== player.id);
  if (squad.memberIds.length === 0) return { disbanded: true };
  if (squad.leaderId === player.id) squad.leaderId = squad.memberIds[0]!;
  return { disbanded: false };
}

/* ── Taking party work ───────────────────────────────────────────────── */

export function acceptPartyMission(
  squad: SquadRecord, leader: PlayerRecord, members: PlayerRecord[], missionId: string, nowMs: number,
): void {
  if (squad.leaderId !== leader.id) throw new SquadError('notLeader');
  if (squad.mission) throw new SquadError('squadLocked');

  const mission = MISSION_BY_ID.get(missionId);
  if (!mission) throw new SquadError('unknownMission');
  if (mission.party < 2) throw new SquadError('notAPartyMission');
  if (squad.memberIds.length < mission.party) throw new SquadError('tooFewMembers');

  // Every member must independently qualify — a squad is not a way to smuggle a
  // genin into an S-rank, and one outcast closes the desk for the whole squad.
  for (const m of members) {
    if (rankIndex(m.rank) < rankIndex(mission.requiredRank)) throw new SquadError('rankLocked');
    if (!canTakeWork(m)) throw new SquadError('reputationLocked');
    if (m.mission) throw new SquadError('busy');
  }

  squad.mission = { missionId, startedAt: nowMs };
}

export interface PartyOutcome {
  mission: Mission;
  success: boolean;
  chance: number;
  /** per member */
  ryo: number;
  xp: number;
  reputation: number;
}

/**
 * Party odds run off the squad's average in the relevant stat, with a small
 * bonus for bringing more than the minimum. Averaging rather than summing is
 * what stops three passengers riding one specialist through an S-rank.
 */
export function partySuccessChance(members: PlayerRecord[], mission: Mission): number {
  const c = MISSIONS.successCurve;
  if (members.length === 0) return c.min;
  const avg = members.reduce((n, m) => n + m.stats[mission.stat as StatKey], 0) / members.length;
  const extra = Math.max(0, members.length - mission.party) * 0.04;
  const raw = c.base + (avg - mission.difficulty) * c.perStatPoint + extra;
  return Math.max(c.min, Math.min(c.max, raw));
}

export function resolvePartyMission(squad: SquadRecord, members: PlayerRecord[], nowMs: number): PartyOutcome {
  if (!squad.mission) throw new SquadError('notInSquad');
  const mission = MISSION_BY_ID.get(squad.mission.missionId);
  if (!mission) throw new SquadError('unknownMission');

  const elapsed = (nowMs - squad.mission.startedAt) / 60_000;
  if (elapsed < mission.minutes) throw new SquadError('notFinished');

  // Seeded from the squad, so any member reporting back gets the same answer and
  // reporting twice cannot re-roll it.
  const rng = makeRng(`party:${squad.id}:${mission.id}:${squad.mission.startedAt}`);
  const chance = partySuccessChance(members, mission);
  const success = rng.chance(chance);
  const f = MISSIONS.failure;

  /* The purse is split, so a bigger squad is better odds at lower pay per head —
     a real trade rather than a strictly better choice. Reputation is not split:
     everyone was there. */
  const share = 1 / members.length;
  return {
    mission,
    success,
    chance,
    ryo: Math.round((success ? mission.ryo : mission.ryo * f.ryoShare) * share),
    xp: Math.round((success ? mission.xp : mission.xp * f.xpShare) * share),
    reputation: success ? mission.reputation : -f.reputationLoss,
  };
}

export function applyPartyOutcome(member: PlayerRecord, outcome: PartyOutcome): void {
  member.ryo += outcome.ryo;
  member.xp += outcome.xp;
  member.reputation += outcome.reputation;
  if (outcome.success) {
    member.missionsAtRank += 1;
    member.missionsCompleted += 1;
  }
}

/* ── Helpers for the service ─────────────────────────────────────────── */

export async function loadMembers(store: Store, squad: SquadRecord): Promise<PlayerRecord[]> {
  const out: PlayerRecord[] = [];
  for (const id of squad.memberIds) {
    const p = await store.getPlayer(id);
    if (p) out.push(p);
  }
  return out;
}

export function partyMissionsFor(player: PlayerRecord): Mission[] {
  if (!canTakeWork(player)) return [];
  return MISSIONS.missions.filter(
    (m) => m.party > 1 && rankIndex(player.rank) >= rankIndex(m.requiredRank),
  );
}
