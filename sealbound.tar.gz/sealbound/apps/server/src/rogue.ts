import { randomUUID } from 'node:crypto';
import { ROGUE } from '@shinobi/content';
import type { PlayerRecord } from './store/index.js';

/**
 * Missing-nin and hunter-nin.
 *
 * Defecting opens the black market and better-paying forbidden work, and closes
 * the village: no missions from the desk, no promotions, standing on the floor.
 * Other players can then take a contract and come for you.
 *
 * The whole design turns on one number. A bounty is worth exactly what the rogue
 * has accumulated in notoriety — it is never minted — and the hunter collects
 * only `hunterShare` of what the rogue loses. Two players colluding (defect, get
 * caught on purpose, split the payout) therefore destroy 40% of the pot every
 * cycle and are further slowed by a same-pair cooldown. Farming it is not
 * defended against by detection; it simply loses money.
 */

export interface BountyContract {
  id: string;
  hunterId: string;
  targetId: string;
  acceptedAt: number;
  expiresAt: number;
  /** value locked in when the contract was taken, so it cannot be pumped after */
  value: number;
}

export class RogueError extends Error {
  constructor(readonly code:
    | 'alreadyRogue' | 'notRogue' | 'onMission' | 'inSquad' | 'inMatch'
    | 'cannotAfford' | 'amnestyCooldown' | 'noSuchTarget' | 'targetNotRogue'
    | 'notWorthHunting' | 'selfContract' | 'alreadyHunting' | 'pairCooldown'
    | 'noContract' | 'contractExpired') {
    super(code);
  }
}

/* ── Leaving ─────────────────────────────────────────────────────────── */

export function defect(player: PlayerRecord, nowMs: number): void {
  if (player.rogue) throw new RogueError('alreadyRogue');
  if (player.mission) throw new RogueError('onMission');
  if (player.squadId) throw new RogueError('inSquad');

  player.rogue = true;
  player.defectedAt = nowMs;
  player.notoriety = 0;
  // Standing collapses; the desk is already closed at this level.
  player.reputation = Math.min(player.reputation, ROGUE.defection.reputationFloor);
}

export function amnestyCost(player: PlayerRecord): number {
  return Math.round(ROGUE.amnesty.baseCost + player.notoriety * ROGUE.amnesty.perNotoriety);
}

export function seekAmnesty(player: PlayerRecord, nowMs: number): number {
  if (!player.rogue) throw new RogueError('notRogue');
  if (player.mission) throw new RogueError('onMission');

  const heldMinutes = (nowMs - (player.defectedAt ?? nowMs)) / 60_000;
  if (heldMinutes < ROGUE.amnesty.cooldownMinutes) throw new RogueError('amnestyCooldown');

  const cost = amnestyCost(player);
  if (player.ryo < cost) throw new RogueError('cannotAfford');

  player.ryo -= cost;
  player.rogue = false;
  player.defectedAt = null;
  player.notoriety = 0;   // the slate is bought clean; nothing carries over
  player.reputation = ROGUE.amnesty.reputationOnReturn;
  return cost;
}

/* ── Notoriety ───────────────────────────────────────────────────────── */

export function addNotoriety(player: PlayerRecord, amount: number): void {
  if (!player.rogue) return;
  player.notoriety = Math.min(ROGUE.notoriety.max, player.notoriety + amount);
}

/** What this rogue's head is currently worth. Derived, never stored. */
export function bountyOn(rogue: PlayerRecord): number {
  if (!rogue.rogue) return 0;
  const b = ROGUE.bounty;
  return Math.round(b.base + rogue.notoriety * b.perNotoriety + rogue.level * b.perLevel);
}

export function isWorthHunting(rogue: PlayerRecord): boolean {
  return rogue.rogue && rogue.notoriety >= ROGUE.contract.minNotorietyToPost;
}

/* ── Contracts ───────────────────────────────────────────────────────── */

export function takeContract(
  hunter: PlayerRecord,
  target: PlayerRecord,
  existing: BountyContract[],
  nowMs: number,
): BountyContract {
  if (hunter.id === target.id) throw new RogueError('selfContract');
  if (hunter.rogue) throw new RogueError('alreadyRogue');
  if (!target.rogue) throw new RogueError('targetNotRogue');
  if (!isWorthHunting(target)) throw new RogueError('notWorthHunting');

  const live = existing.filter((c) => c.hunterId === hunter.id && c.expiresAt > nowMs);
  if (live.length >= ROGUE.contract.maxActivePerHunter) throw new RogueError('alreadyHunting');

  /* Same pair, recently settled? Refuse. Collusion already loses money; this
     stops it being a fast loop as well as a lossy one. */
  const recent = existing.find(
    (c) => c.hunterId === hunter.id && c.targetId === target.id
      && nowMs - c.acceptedAt < ROGUE.contract.cooldownMinutesSamePair * 60_000,
  );
  if (recent) throw new RogueError('pairCooldown');

  return {
    id: randomUUID(),
    hunterId: hunter.id,
    targetId: target.id,
    acceptedAt: nowMs,
    expiresAt: nowMs + ROGUE.contract.durationMinutes * 60_000,
    // Locked in now, so a rogue cannot inflate the payout after the fact.
    value: bountyOn(target),
  };
}

export interface BountyClaim { paidToHunter: number; takenFromRogue: number }

/**
 * Settles a contract after the hunter beats the target in a match. The rogue
 * loses the full value; the hunter receives only a share of it. The difference
 * is destroyed, which is what makes this unfarmable rather than merely policed.
 */
export function claimBounty(
  contract: BountyContract,
  hunter: PlayerRecord,
  rogue: PlayerRecord,
  nowMs: number,
): BountyClaim {
  if (nowMs > contract.expiresAt) throw new RogueError('contractExpired');

  const taken = Math.min(rogue.ryo, Math.min(contract.value, bountyOn(rogue)));
  const paid = Math.round(taken * ROGUE.bounty.hunterShare);

  rogue.ryo -= taken;
  rogue.notoriety = 0;          // being caught resets what you were worth
  hunter.ryo += paid;
  hunter.reputation += 4;       // hunting is village work, and it is seen as such

  return { paidToHunter: paid, takenFromRogue: taken };
}

/* ── Black market ────────────────────────────────────────────────────── */

/** Forbidden teachers ask no questions, only more money. */
export function blackMarketPrice(basePrice: number): number {
  return Math.max(1, Math.round(basePrice * ROGUE.blackMarket.priceMultiplier));
}

export function rogueMissionPay(ryo: number): number {
  return Math.round(ryo * ROGUE.blackMarket.missionPayMultiplier);
}
