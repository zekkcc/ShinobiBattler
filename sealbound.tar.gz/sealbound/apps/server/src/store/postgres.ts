import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { Nature, Rank, Stats } from '@shinobi/shared';
import type { MissionSession } from '../missions.js';
import type {
  AccountRecord, Boosts, CandidacyRecord, ClanRecord, CraftSession, DungeonRun, GatherSession,
  LegendaryHistoryEntry, LegendaryRecord, ListingRecord, MarketRefRecord, MentorshipRecord,
  TradeRecord, TransferRecord,
  OfficeRecord, PlayerRecord, RegionRecord, ReplayRecord, SessionRecord, SquadRecord, Store,
  TrainingSession, VillageRecord, VoteRecord, WarRecord,
} from './index.js';
import type { BountyContract } from '../rogue.js';

/**
 * Postgres-backed store.
 *
 * Deliberately written against a tiny driver interface rather than a specific
 * client, so the same code runs on `pg.Pool` in production and on an in-process
 * Postgres in the tests. That matters: an untested schema is a guess, and this
 * one had already drifted from the record shape before anyone executed it.
 */
export interface SqlDriver {
  query<T = Record<string, unknown>>(text: string, params?: unknown[]): Promise<{ rows: T[] }>;
}

const here = dirname(fileURLToPath(import.meta.url));

export function schemaSql(): string {
  return readFileSync(join(here, '..', 'schema.sql'), 'utf8');
}

/** Runs schema.sql. Statement-at-a-time so a driver without multi-statement support works. */
export async function migrate(driver: SqlDriver): Promise<void> {
  const statements = schemaSql()
    .split(/;\s*$/m)
    .map((s) => s.replace(/^\s*--.*$/gm, '').trim())
    .filter(Boolean);
  for (const statement of statements) await driver.query(statement);
}

/* ── row mapping ─────────────────────────────────────────────────────── */

interface PlayerRow {
  id: string; name: string; village_id: string; clan_id: string | null;
  bloodline_id: string | null; rank: string; level: number; xp: string | number;
  stats: Stats; affinity: string; loadout: string[]; known: string[];
  reputation: number; ryo: string | number; rating: number;
  missions_at_rank: number; missions_completed: number;
  rogue: boolean; defected_at: Date | string | null; notoriety: number;
  training_location_id: string | null; training_tier: number | null;
  training_stat: string | null; training_started_at: Date | string | null;
  mission_id: string | null; mission_started_at: Date | string | null;
  squad_id: string | null;
  clan_joined_at: Date | string | null; clan_contribution: number;
  titles: string[]; displayed_title: string | null;
  pvp_wins: number; bounties_claimed: number; s_rank_completed: number;
  created_at: Date | string;
  inventory: Record<string, number> | null;
  cosmetics: string[] | null;
  equipped: Record<string, string> | null;
  boosts: Partial<Boosts> | null;
  gathering: GatherSession | null;
  crafting: CraftSession | null;
  dungeon_run: DungeonRun | null;
  dungeon_runs_day: number; dungeon_runs_today: number;
  dungeon_cooldowns: Record<string, number> | null;
  mentored_before: boolean; last_mentorship_ended_at: Date | string | null;
}

const ms = (v: Date | string | null): number => (v === null ? 0 : new Date(v).getTime());
const num = (v: string | number): number => (typeof v === 'string' ? Number(v) : v);

function toRecord(row: PlayerRow): PlayerRecord {
  const training: TrainingSession | null = row.training_started_at
    ? {
        stat: row.training_stat as TrainingSession['stat'],
        tier: row.training_tier!,
        locationId: row.training_location_id!,
        startedAt: ms(row.training_started_at),
      }
    : null;

  const mission: MissionSession | null = row.mission_started_at
    ? { missionId: row.mission_id!, startedAt: ms(row.mission_started_at) }
    : null;

  return {
    id: row.id,
    name: row.name,
    villageId: row.village_id,
    clanId: row.clan_id,
    clanJoinedAt: row.clan_joined_at ? ms(row.clan_joined_at) : null,
    clanContribution: Number(row.clan_contribution ?? 0),
    bloodlineId: row.bloodline_id,
    rank: row.rank as Rank,
    level: row.level,
    xp: num(row.xp),
    stats: row.stats,
    affinity: row.affinity as Nature,
    loadout: row.loadout ?? [],
    known: row.known ?? [],
    reputation: row.reputation,
    ryo: num(row.ryo),
    training,
    mission,
    missionsAtRank: row.missions_at_rank,
    missionsCompleted: row.missions_completed,
    squadId: row.squad_id,
    rogue: row.rogue,
    defectedAt: row.defected_at ? ms(row.defected_at) : null,
    notoriety: row.notoriety,
    titles: row.titles ?? [],
    displayedTitle: row.displayed_title,
    pvpWins: row.pvp_wins,
    bountiesClaimed: row.bounties_claimed,
    sRankCompleted: row.s_rank_completed,
    rating: row.rating,
    createdAt: ms(row.created_at),
    inventory: row.inventory ?? {},
    cosmetics: row.cosmetics ?? [],
    equipped: row.equipped ?? {},
    boosts: {
      trainingRateBonus: Number(row.boosts?.trainingRateBonus ?? 0),
      gatherYieldBonus: Number(row.boosts?.gatherYieldBonus ?? 0),
      dungeonAttempts: Number(row.boosts?.dungeonAttempts ?? 0),
    },
    gathering: row.gathering ?? null,
    crafting: row.crafting ?? null,
    dungeon: row.dungeon_run ?? null,
    dungeonRunsDay: Number(row.dungeon_runs_day ?? 0),
    dungeonRunsToday: Number(row.dungeon_runs_today ?? 0),
    dungeonCooldowns: row.dungeon_cooldowns ?? {},
    mentoredBefore: Boolean(row.mentored_before),
    lastMentorshipEndedAt: row.last_mentorship_ended_at ? ms(row.last_mentorship_ended_at) : null,
  };
}

const SELECT_PLAYER = `
  SELECT p.*,
         t.location_id AS training_location_id,
         t.tier        AS training_tier,
         t.stat        AS training_stat,
         t.started_at  AS training_started_at,
         m.mission_id  AS mission_id,
         m.started_at  AS mission_started_at,
         sm.squad_id   AS squad_id
  FROM players p
  LEFT JOIN training_sessions t ON t.player_id = p.id
  LEFT JOIN mission_sessions  m ON m.player_id = p.id
  LEFT JOIN squad_members    sm ON sm.player_id = p.id AND sm.invited = false
`;

/* ── store ───────────────────────────────────────────────────────────── */

export class PostgresStore implements Store {
  constructor(private readonly db: SqlDriver) {}

  /* ── Legendary items ───────────────────────────────────────────────── */

  async claimLegendary(record: LegendaryRecord, nowMs: number): Promise<void> {
    // No ON CONFLICT: a second claim on the same item MUST fail. The primary key
    // is what makes "one per server" true under concurrency.
    await this.db.query(
      `INSERT INTO legendary_items (item_id, holder_id, acquired_at)
       VALUES ($1,$2,to_timestamp($3::double precision / 1000))`,
      [record.itemId, record.holderId, record.acquiredAt],
    );
    await this.db.query(
      `INSERT INTO legendary_history (item_id, holder_id, held_from)
       VALUES ($1,$2,to_timestamp($3::double precision / 1000))`,
      [record.itemId, record.holderId, nowMs],
    );
  }

  async getLegendary(itemId: string): Promise<LegendaryRecord | null> {
    const { rows } = await this.db.query<{ item_id: string; holder_id: string; acquired_at: Date | string }>(
      'SELECT * FROM legendary_items WHERE item_id=$1', [itemId],
    );
    const r = rows[0];
    return r ? { itemId: r.item_id, holderId: r.holder_id, acquiredAt: ms(r.acquired_at) } : null;
  }

  async listLegendaries(): Promise<LegendaryRecord[]> {
    const { rows } = await this.db.query<{ item_id: string; holder_id: string; acquired_at: Date | string }>(
      'SELECT * FROM legendary_items',
    );
    return rows.map((r) => ({ itemId: r.item_id, holderId: r.holder_id, acquiredAt: ms(r.acquired_at) }));
  }

  async transferLegendary(itemId: string, toHolderId: string, nowMs: number): Promise<void> {
    await this.db.query(
      `UPDATE legendary_history SET held_until=to_timestamp($2::double precision / 1000)
       WHERE item_id=$1 AND held_until IS NULL`,
      [itemId, nowMs],
    );
    await this.db.query(
      `UPDATE legendary_items SET holder_id=$2, acquired_at=to_timestamp($3::double precision / 1000)
       WHERE item_id=$1`,
      [itemId, toHolderId, nowMs],
    );
    await this.db.query(
      `INSERT INTO legendary_history (item_id, holder_id, held_from)
       VALUES ($1,$2,to_timestamp($3::double precision / 1000))`,
      [itemId, toHolderId, nowMs],
    );
  }

  async legendaryHistory(itemId: string): Promise<LegendaryHistoryEntry[]> {
    const { rows } = await this.db.query<{ item_id: string; holder_id: string; held_from: Date | string; held_until: Date | string | null }>(
      'SELECT * FROM legendary_history WHERE item_id=$1 ORDER BY held_from', [itemId],
    );
    return rows.map((r) => ({
      itemId: r.item_id, holderId: r.holder_id,
      heldFrom: ms(r.held_from), heldUntil: r.held_until ? ms(r.held_until) : null,
    }));
  }

  /* ── Clans ─────────────────────────────────────────────────────────── */

  async createClan(c: ClanRecord): Promise<void> { await this.writeClan(c, true); }
  async saveClan(c: ClanRecord): Promise<void> { await this.writeClan(c, false); }

  private async writeClan(c: ClanRecord, insert: boolean): Promise<void> {
    if (insert) {
      await this.db.query(
        `INSERT INTO clans (id, name, name_key, leader_id, bank, founded_at, withdrawn_today, withdraw_window_start)
         VALUES ($1,$2,$3,$4,$5,to_timestamp($6::double precision / 1000),$7,to_timestamp($8::double precision / 1000))`,
        [c.id, c.name, c.nameKey, c.leaderId, c.bank, c.foundedAt, c.withdrawnToday, c.withdrawWindowStart],
      );
    } else {
      await this.db.query(
        `UPDATE clans SET name=$2, name_key=$3, leader_id=$4, bank=$5, withdrawn_today=$6,
           withdraw_window_start=to_timestamp($7::double precision / 1000) WHERE id=$1`,
        [c.id, c.name, c.nameKey, c.leaderId, c.bank, c.withdrawnToday, c.withdrawWindowStart],
      );
      await this.db.query('DELETE FROM clan_members WHERE clan_id=$1', [c.id]);
    }
    for (const id of c.memberIds) {
      await this.db.query(
        `INSERT INTO clan_members (clan_id, player_id, officer, invited) VALUES ($1,$2,$3,false)
         ON CONFLICT (player_id) DO UPDATE SET clan_id=EXCLUDED.clan_id, officer=EXCLUDED.officer, invited=false`,
        [c.id, id, c.officerIds.includes(id)],
      );
    }
    for (const id of c.invitedIds) {
      await this.db.query(
        `INSERT INTO clan_members (clan_id, player_id, officer, invited) VALUES ($1,$2,false,true)
         ON CONFLICT (player_id) DO UPDATE SET clan_id=EXCLUDED.clan_id, invited=true`,
        [c.id, id],
      );
    }
  }

  private async hydrateClan(row: { id: string; name: string; name_key: string; leader_id: string; bank: string | number; founded_at: Date | string; withdrawn_today: string | number; withdraw_window_start: Date | string }): Promise<ClanRecord> {
    const members = await this.db.query<{ player_id: string; officer: boolean; invited: boolean }>(
      'SELECT player_id, officer, invited FROM clan_members WHERE clan_id=$1 ORDER BY player_id', [row.id],
    );
    return {
      id: row.id, name: row.name, nameKey: row.name_key, leaderId: row.leader_id,
      memberIds: members.rows.filter((m) => !m.invited).map((m) => m.player_id),
      officerIds: members.rows.filter((m) => !m.invited && m.officer).map((m) => m.player_id),
      invitedIds: members.rows.filter((m) => m.invited).map((m) => m.player_id),
      bank: num(row.bank), foundedAt: ms(row.founded_at),
      withdrawnToday: num(row.withdrawn_today), withdrawWindowStart: ms(row.withdraw_window_start),
    };
  }

  async getClan(id: string): Promise<ClanRecord | null> {
    const { rows } = await this.db.query<never>('SELECT * FROM clans WHERE id=$1', [id]);
    return rows[0] ? this.hydrateClan(rows[0]) : null;
  }

  async getClanByNameKey(nameKey: string): Promise<ClanRecord | null> {
    const { rows } = await this.db.query<never>('SELECT * FROM clans WHERE name_key=$1', [nameKey]);
    return rows[0] ? this.hydrateClan(rows[0]) : null;
  }

  async deleteClan(id: string): Promise<void> {
    await this.db.query('DELETE FROM clans WHERE id=$1', [id]);
  }

  async listClans(): Promise<ClanRecord[]> {
    const { rows } = await this.db.query<never>('SELECT * FROM clans');
    return Promise.all(rows.map((r) => this.hydrateClan(r)));
  }

  /* ── Bounties ──────────────────────────────────────────────────────── */

  async saveContract(c: BountyContract): Promise<void> {
    await this.db.query(
      `INSERT INTO bounty_contracts (id, hunter_id, target_id, value, accepted_at, expires_at)
       VALUES ($1,$2,$3,$4,to_timestamp($5::double precision / 1000),to_timestamp($6::double precision / 1000))
       ON CONFLICT (id) DO NOTHING`,
      [c.id, c.hunterId, c.targetId, c.value, c.acceptedAt, c.expiresAt],
    );
  }

  async listContracts(): Promise<BountyContract[]> {
    const { rows } = await this.db.query<{
      id: string; hunter_id: string; target_id: string; value: number;
      accepted_at: Date | string; expires_at: Date | string;
    }>('SELECT * FROM bounty_contracts');
    return rows.map((r) => ({
      id: r.id, hunterId: r.hunter_id, targetId: r.target_id, value: r.value,
      acceptedAt: ms(r.accepted_at), expiresAt: ms(r.expires_at),
    }));
  }

  async deleteContract(id: string): Promise<void> {
    await this.db.query('DELETE FROM bounty_contracts WHERE id=$1', [id]);
  }

  async listRogues(): Promise<PlayerRecord[]> {
    const { rows } = await this.db.query<PlayerRow>(`${SELECT_PLAYER} WHERE p.rogue = true`);
    return rows.map(toRecord);
  }

  /* ── Squads ────────────────────────────────────────────────────────── */

  async createSquad(s: SquadRecord): Promise<void> { await this.saveSquad(s, true); }

  async saveSquad(s: SquadRecord, insert = false): Promise<void> {
    if (insert) {
      await this.db.query(
        `INSERT INTO squads (id, leader_id, mission_id, started_at)
         VALUES ($1,$2,$3,CASE WHEN $4::double precision IS NULL THEN NULL ELSE to_timestamp($4::double precision / 1000) END)`,
        [s.id, s.leaderId, s.mission?.missionId ?? null, s.mission?.startedAt ?? null],
      );
    } else {
      await this.db.query(
        `UPDATE squads SET leader_id=$2, mission_id=$3,
           started_at=CASE WHEN $4::double precision IS NULL THEN NULL ELSE to_timestamp($4::double precision / 1000) END
         WHERE id=$1`,
        [s.id, s.leaderId, s.mission?.missionId ?? null, s.mission?.startedAt ?? null],
      );
      await this.db.query('DELETE FROM squad_members WHERE squad_id=$1', [s.id]);
    }
    for (const id of s.memberIds) {
      await this.db.query(
        'INSERT INTO squad_members (squad_id, player_id, invited) VALUES ($1,$2,false) ON CONFLICT (player_id) DO UPDATE SET squad_id=EXCLUDED.squad_id, invited=false',
        [s.id, id],
      );
    }
    for (const id of s.invitedIds) {
      await this.db.query(
        'INSERT INTO squad_members (squad_id, player_id, invited) VALUES ($1,$2,true) ON CONFLICT (player_id) DO UPDATE SET squad_id=EXCLUDED.squad_id, invited=true',
        [s.id, id],
      );
    }
  }

  async getSquad(id: string): Promise<SquadRecord | null> {
    const { rows } = await this.db.query<{ id: string; leader_id: string; mission_id: string | null; started_at: Date | string | null }>(
      'SELECT * FROM squads WHERE id=$1', [id],
    );
    const row = rows[0];
    if (!row) return null;
    const members = await this.db.query<{ player_id: string; invited: boolean }>(
      'SELECT player_id, invited FROM squad_members WHERE squad_id=$1 ORDER BY player_id', [id],
    );
    return {
      id: row.id,
      leaderId: row.leader_id,
      memberIds: members.rows.filter((m) => !m.invited).map((m) => m.player_id),
      invitedIds: members.rows.filter((m) => m.invited).map((m) => m.player_id),
      mission: row.started_at ? { missionId: row.mission_id!, startedAt: ms(row.started_at) } : null,
    };
  }

  async deleteSquad(id: string): Promise<void> {
    await this.db.query('DELETE FROM squads WHERE id=$1', [id]);
  }

  /* ── Accounts and sessions ─────────────────────────────────────────── */

  async createAccount(a: AccountRecord): Promise<void> {
    await this.db.query(
      'INSERT INTO accounts (id, name_key, password) VALUES ($1,$2,$3)',
      [a.id, a.nameKey, a.password],
    );
  }

  async getAccountByNameKey(nameKey: string): Promise<AccountRecord | null> {
    const { rows } = await this.db.query<{ id: string; name_key: string; password: string }>(
      'SELECT id, name_key, password FROM accounts WHERE name_key=$1', [nameKey],
    );
    const row = rows[0];
    return row ? { id: row.id, nameKey: row.name_key, password: row.password } : null;
  }

  async createSession(s: SessionRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO sessions (token_hash, account_id, expires_at)
       VALUES ($1,$2,to_timestamp($3::double precision / 1000))`,
      [s.tokenHash, s.accountId, s.expiresAt],
    );
  }

  async getSession(tokenHash: string): Promise<SessionRecord | null> {
    const { rows } = await this.db.query<{ token_hash: string; account_id: string; expires_at: Date | string }>(
      'SELECT token_hash, account_id, expires_at FROM sessions WHERE token_hash=$1', [tokenHash],
    );
    const row = rows[0];
    return row ? { tokenHash: row.token_hash, accountId: row.account_id, expiresAt: ms(row.expires_at) } : null;
  }

  async deleteSession(tokenHash: string): Promise<void> {
    await this.db.query('DELETE FROM sessions WHERE token_hash=$1', [tokenHash]);
  }

  async deleteExpiredSessions(nowMs: number): Promise<number> {
    const { rows } = await this.db.query<{ token_hash: string }>(
      'DELETE FROM sessions WHERE expires_at <= to_timestamp($1::double precision / 1000) RETURNING token_hash',
      [nowMs],
    );
    return rows.length;
  }

  /* ── Territory ─────────────────────────────────────────────────────── */

  async getRegion(id: string): Promise<RegionRecord | null> {
    const { rows } = await this.db.query<{ id: string; controlling_village_id: string; garrison_clan_id: string | null; captured_at: Date | string }>(
      'SELECT * FROM regions WHERE id=$1', [id],
    );
    const r = rows[0];
    return r ? { id: r.id, controllingVillageId: r.controlling_village_id, garrisonClanId: r.garrison_clan_id, capturedAt: ms(r.captured_at) } : null;
  }

  async listRegionRecords(): Promise<RegionRecord[]> {
    const { rows } = await this.db.query<{ id: string; controlling_village_id: string; garrison_clan_id: string | null; captured_at: Date | string }>(
      'SELECT * FROM regions ORDER BY id',
    );
    return rows.map((r) => ({ id: r.id, controllingVillageId: r.controlling_village_id, garrisonClanId: r.garrison_clan_id, capturedAt: ms(r.captured_at) }));
  }

  async saveRegion(r: RegionRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO regions (id, controlling_village_id, garrison_clan_id, captured_at)
       VALUES ($1,$2,$3,to_timestamp($4::double precision / 1000))
       ON CONFLICT (id) DO UPDATE SET controlling_village_id=EXCLUDED.controlling_village_id,
         garrison_clan_id=EXCLUDED.garrison_clan_id, captured_at=EXCLUDED.captured_at`,
      [r.id, r.controllingVillageId, r.garrisonClanId, r.capturedAt],
    );
  }

  async createWar(w: WarRecord): Promise<void> {
    // No ON CONFLICT: the second declaration on a region this period MUST fail.
    await this.db.query(
      `INSERT INTO wars (id, region_id, period_index, attacker_clan_id, defender_clan_id, stake,
         attacker_score, defender_score, contributions, declared_at, resolves_at, resolved, winner_clan_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9::jsonb,
         to_timestamp($10::double precision / 1000), to_timestamp($11::double precision / 1000), $12, $13)`,
      [w.id, w.regionId, w.periodIndex, w.attackerClanId, w.defenderClanId, w.stake,
        w.attackerScore, w.defenderScore, JSON.stringify(w.contributions), w.declaredAt, w.resolvesAt, w.resolved, w.winnerClanId],
    );
  }

  private toWar(r: Record<string, unknown>): WarRecord {
    return {
      id: r.id as string,
      regionId: r.region_id as string,
      periodIndex: Number(r.period_index),
      attackerClanId: r.attacker_clan_id as string,
      defenderClanId: (r.defender_clan_id as string | null) ?? null,
      stake: num(r.stake as string | number),
      attackerScore: Number(r.attacker_score),
      defenderScore: Number(r.defender_score),
      contributions: (r.contributions as Record<string, number>) ?? {},
      declaredAt: ms(r.declared_at as Date | string),
      resolvesAt: ms(r.resolves_at as Date | string),
      resolved: Boolean(r.resolved),
      winnerClanId: (r.winner_clan_id as string | null) ?? null,
    };
  }

  async getWar(id: string): Promise<WarRecord | null> {
    const { rows } = await this.db.query('SELECT * FROM wars WHERE id=$1', [id]);
    return rows[0] ? this.toWar(rows[0]) : null;
  }

  async listWars(): Promise<WarRecord[]> {
    const { rows } = await this.db.query('SELECT * FROM wars ORDER BY declared_at');
    return rows.map((r) => this.toWar(r));
  }

  async saveWar(w: WarRecord): Promise<void> {
    await this.db.query(
      `UPDATE wars SET defender_clan_id=$2, stake=$3, attacker_score=$4, defender_score=$5,
         contributions=$6::jsonb, resolved=$7, winner_clan_id=$8 WHERE id=$1`,
      [w.id, w.defenderClanId, w.stake, w.attackerScore, w.defenderScore,
        JSON.stringify(w.contributions), w.resolved, w.winnerClanId],
    );
  }

  /* ── Market ────────────────────────────────────────────────────────── */

  async createListing(l: ListingRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO market_listings (id, seller_id, item_id, qty, unit_price, listed_at, expires_at)
       VALUES ($1,$2,$3,$4,$5,to_timestamp($6::double precision / 1000),to_timestamp($7::double precision / 1000))`,
      [l.id, l.sellerId, l.itemId, l.qty, l.unitPrice, l.listedAt, l.expiresAt],
    );
  }

  private toListing(r: Record<string, unknown>): ListingRecord {
    return {
      id: r.id as string, sellerId: r.seller_id as string, itemId: r.item_id as string,
      qty: Number(r.qty), unitPrice: num(r.unit_price as string | number),
      listedAt: ms(r.listed_at as Date | string), expiresAt: ms(r.expires_at as Date | string),
    };
  }

  async getListing(id: string): Promise<ListingRecord | null> {
    const { rows } = await this.db.query('SELECT * FROM market_listings WHERE id=$1', [id]);
    return rows[0] ? this.toListing(rows[0]) : null;
  }

  async listListings(): Promise<ListingRecord[]> {
    const { rows } = await this.db.query('SELECT * FROM market_listings ORDER BY listed_at');
    return rows.map((r) => this.toListing(r));
  }

  /**
   * The DELETE is what settles a purchase. Two buyers racing the same listing
   * both pass the application check; only one gets a row back from here, and the
   * other is told the listing is gone. That is why this returns a boolean rather
   * than void.
   */
  async deleteListing(id: string): Promise<boolean> {
    const { rows } = await this.db.query('DELETE FROM market_listings WHERE id=$1 RETURNING id', [id]);
    return rows.length > 0;
  }

  /* ── Direct trade ──────────────────────────────────────────────────── */

  async createTrade(t: TradeRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO trades (id, from_id, to_id, offer, request, created_at, expires_at)
       VALUES ($1,$2,$3,$4::jsonb,$5::jsonb,
         to_timestamp($6::double precision / 1000), to_timestamp($7::double precision / 1000))`,
      [t.id, t.fromId, t.toId, JSON.stringify(t.offer), JSON.stringify(t.request), t.createdAt, t.expiresAt],
    );
  }

  private toTrade(r: Record<string, unknown>): TradeRecord {
    return {
      id: r.id as string,
      fromId: r.from_id as string,
      toId: r.to_id as string,
      offer: r.offer as TradeRecord['offer'],
      request: r.request as TradeRecord['request'],
      createdAt: ms(r.created_at as Date | string),
      expiresAt: ms(r.expires_at as Date | string),
    };
  }

  async getTrade(id: string): Promise<TradeRecord | null> {
    const { rows } = await this.db.query('SELECT * FROM trades WHERE id=$1', [id]);
    return rows[0] ? this.toTrade(rows[0]) : null;
  }

  async listTradesFor(playerId: string): Promise<TradeRecord[]> {
    const { rows } = await this.db.query(
      'SELECT * FROM trades WHERE from_id=$1 OR to_id=$1 ORDER BY created_at', [playerId],
    );
    return rows.map((r) => this.toTrade(r));
  }

  /** Only one caller gets the row back, which is what settles a double-accept. */
  async deleteTrade(id: string): Promise<boolean> {
    const { rows } = await this.db.query('DELETE FROM trades WHERE id=$1 RETURNING id', [id]);
    return rows.length > 0;
  }

  async recordTransfer(e: TransferRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO transfers (id, at, kind, from_id, to_id, ryo, items)
       VALUES ($1,to_timestamp($2::double precision / 1000),$3,$4,$5,$6,$7::jsonb)`,
      [e.id, e.at, e.kind, e.fromId, e.toId, Math.max(0, Math.round(e.ryo)), JSON.stringify(e.items)],
    );
  }

  async listTransfers(playerId: string): Promise<TransferRecord[]> {
    const { rows } = await this.db.query<{ id: string; at: Date | string; kind: string; from_id: string; to_id: string; ryo: string | number; items: { itemId: string; qty: number }[] }>(
      'SELECT * FROM transfers WHERE from_id=$1 OR to_id=$1 ORDER BY at', [playerId],
    );
    return rows.map((r) => ({
      id: r.id, at: ms(r.at), kind: r.kind as TransferRecord['kind'],
      fromId: r.from_id, toId: r.to_id, ryo: num(r.ryo), items: r.items ?? [],
    }));
  }

  async getMarketRef(itemId: string): Promise<MarketRefRecord | null> {
    const { rows } = await this.db.query<{ item_id: string; reference: string | number; updated_at: Date | string }>(
      'SELECT * FROM market_reference WHERE item_id=$1', [itemId],
    );
    const r = rows[0];
    return r ? { itemId: r.item_id, reference: num(r.reference), updatedAt: ms(r.updated_at) } : null;
  }

  async saveMarketRef(r: MarketRefRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO market_reference (item_id, reference, updated_at)
       VALUES ($1,$2,to_timestamp($3::double precision / 1000))
       ON CONFLICT (item_id) DO UPDATE SET reference=EXCLUDED.reference, updated_at=EXCLUDED.updated_at`,
      [r.itemId, Math.max(1, Math.round(r.reference)), r.updatedAt],
    );
  }

  async listMarketRefs(): Promise<MarketRefRecord[]> {
    const { rows } = await this.db.query<{ item_id: string; reference: string | number; updated_at: Date | string }>(
      'SELECT * FROM market_reference',
    );
    return rows.map((r) => ({ itemId: r.item_id, reference: num(r.reference), updatedAt: ms(r.updated_at) }));
  }

  /* ── Villages and politics ─────────────────────────────────────────── */

  async getVillage(id: string): Promise<VillageRecord | null> {
    const { rows } = await this.db.query<{ id: string; tax_rate: string | number; treasury: string | number; laws: string[]; commissions: { id: string; endsAt: number }[]; at_war_with: string[]; tax_set_in_cycle: number }>(
      'SELECT * FROM villages WHERE id=$1', [id],
    );
    const v = rows[0];
    if (!v) return null;
    return {
      id: v.id, taxRate: Number(v.tax_rate), treasury: num(v.treasury),
      laws: v.laws ?? [], commissions: v.commissions ?? [], atWarWith: v.at_war_with ?? [],
      taxSetInCycle: Number(v.tax_set_in_cycle),
    };
  }

  async saveVillage(v: VillageRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO villages (id, tax_rate, treasury, laws, commissions, at_war_with, tax_set_in_cycle)
       VALUES ($1,$2,$3,$4::jsonb,$5::jsonb,$6::jsonb,$7)
       ON CONFLICT (id) DO UPDATE SET tax_rate=EXCLUDED.tax_rate, treasury=EXCLUDED.treasury,
         laws=EXCLUDED.laws, commissions=EXCLUDED.commissions, at_war_with=EXCLUDED.at_war_with,
         tax_set_in_cycle=EXCLUDED.tax_set_in_cycle`,
      [v.id, v.taxRate, Math.max(0, Math.round(v.treasury)), JSON.stringify(v.laws),
        JSON.stringify(v.commissions), JSON.stringify(v.atWarWith), v.taxSetInCycle],
    );
  }

  async addCandidacy(c: CandidacyRecord): Promise<void> {
    await this.db.query(
      'INSERT INTO candidacies (village_id, office_id, cycle, player_id) VALUES ($1,$2,$3,$4)',
      [c.villageId, c.officeId, c.cycle, c.playerId],
    );
  }

  async listCandidacies(villageId: string, cycle: number): Promise<CandidacyRecord[]> {
    const { rows } = await this.db.query<{ village_id: string; office_id: string; cycle: number; player_id: string }>(
      'SELECT * FROM candidacies WHERE village_id=$1 AND cycle=$2', [villageId, cycle],
    );
    return rows.map((r) => ({ villageId: r.village_id, officeId: r.office_id, cycle: Number(r.cycle), playerId: r.player_id }));
  }

  async castVote(v: VoteRecord): Promise<void> {
    // No ON CONFLICT. One vote per player per office per cycle is the property.
    await this.db.query(
      'INSERT INTO votes (village_id, office_id, cycle, voter_id, candidate_id) VALUES ($1,$2,$3,$4,$5)',
      [v.villageId, v.officeId, v.cycle, v.voterId, v.candidateId],
    );
  }

  async listVotes(villageId: string, cycle: number): Promise<VoteRecord[]> {
    const { rows } = await this.db.query<{ village_id: string; office_id: string; cycle: number; voter_id: string; candidate_id: string }>(
      'SELECT * FROM votes WHERE village_id=$1 AND cycle=$2', [villageId, cycle],
    );
    return rows.map((r) => ({ villageId: r.village_id, officeId: r.office_id, cycle: Number(r.cycle), voterId: r.voter_id, candidateId: r.candidate_id }));
  }

  async saveOffice(o: OfficeRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO office_holders (village_id, office_id, cycle, holder_ids)
       VALUES ($1,$2,$3,$4::jsonb)
       ON CONFLICT (village_id, office_id, cycle) DO UPDATE SET holder_ids=EXCLUDED.holder_ids`,
      [o.villageId, o.officeId, o.cycle, JSON.stringify(o.holderIds)],
    );
  }

  async listOffices(villageId: string, cycle: number): Promise<OfficeRecord[]> {
    const { rows } = await this.db.query<{ village_id: string; office_id: string; cycle: number; holder_ids: string[] }>(
      'SELECT * FROM office_holders WHERE village_id=$1 AND cycle=$2', [villageId, cycle],
    );
    return rows.map((r) => ({ villageId: r.village_id, officeId: r.office_id, cycle: Number(r.cycle), holderIds: r.holder_ids ?? [] }));
  }

  /* ── Mentorship ────────────────────────────────────────────────────── */

  private toMentorship(r: Record<string, unknown>): MentorshipRecord {
    return {
      id: r.id as string, mentorId: r.mentor_id as string, menteeId: r.mentee_id as string,
      status: r.status as MentorshipRecord['status'],
      startedAt: ms(r.started_at as Date | string),
      endedAt: r.ended_at ? ms(r.ended_at as Date | string) : null,
      rewarded: (r.rewarded as string[]) ?? [],
      rewardTimes: (r.reward_times as number[]) ?? [],
    };
  }

  async createMentorship(m: MentorshipRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO mentorships (id, mentor_id, mentee_id, status, started_at, ended_at, rewarded, reward_times)
       VALUES ($1,$2,$3,$4,to_timestamp($5::double precision / 1000),
         CASE WHEN $6::double precision IS NULL THEN NULL ELSE to_timestamp($6::double precision / 1000) END,
         $7::jsonb,$8::jsonb)`,
      [m.id, m.mentorId, m.menteeId, m.status, m.startedAt, m.endedAt,
        JSON.stringify(m.rewarded), JSON.stringify(m.rewardTimes)],
    );
  }

  async getMentorship(id: string): Promise<MentorshipRecord | null> {
    const { rows } = await this.db.query('SELECT * FROM mentorships WHERE id=$1', [id]);
    return rows[0] ? this.toMentorship(rows[0]) : null;
  }

  async listMentorshipsFor(playerId: string): Promise<MentorshipRecord[]> {
    const { rows } = await this.db.query(
      'SELECT * FROM mentorships WHERE mentor_id=$1 OR mentee_id=$1 ORDER BY started_at', [playerId],
    );
    return rows.map((r) => this.toMentorship(r));
  }

  async saveMentorship(m: MentorshipRecord): Promise<void> {
    await this.db.query(
      `UPDATE mentorships SET status=$2,
         ended_at=CASE WHEN $3::double precision IS NULL THEN NULL ELSE to_timestamp($3::double precision / 1000) END,
         rewarded=$4::jsonb, reward_times=$5::jsonb WHERE id=$1`,
      [m.id, m.status, m.endedAt, JSON.stringify(m.rewarded), JSON.stringify(m.rewardTimes)],
    );
  }

  /**
   * One column map drives both insert and update.
   *
   * These were hand-written positional parameter lists, and after several rounds
   * of adding fields they had drifted into `$21` appearing before `$20`. Every
   * new column was a chance to scramble them silently. Generating the
   * placeholders removes that whole class of mistake.
   */
  private playerColumns(p: PlayerRecord): { sql: string; value: unknown }[] {
    /** epoch millis -> timestamptz, preserving null */
    const ts = (n: number | null) =>
      ({ sql: `CASE WHEN ?::double precision IS NULL THEN NULL ELSE to_timestamp(?::double precision / 1000) END`, value: n });
    const plain = (v: unknown) => ({ sql: '?', value: v });
    return [
      ['id', plain(p.id)], ['name', plain(p.name)], ['village_id', plain(p.villageId)],
      ['clan_id', plain(p.clanId)], ['clan_joined_at', ts(p.clanJoinedAt)],
      ['clan_contribution', plain(p.clanContribution)],
      ['bloodline_id', plain(p.bloodlineId)], ['rank', plain(p.rank)],
      ['level', plain(p.level)], ['xp', plain(p.xp)],
      ['stats', plain(JSON.stringify(p.stats))], ['affinity', plain(p.affinity)],
      ['loadout', plain(JSON.stringify(p.loadout))], ['known', plain(JSON.stringify(p.known))],
      ['reputation', plain(p.reputation)], ['ryo', plain(p.ryo)], ['rating', plain(p.rating)],
      ['missions_at_rank', plain(p.missionsAtRank)], ['missions_completed', plain(p.missionsCompleted)],
      ['rogue', plain(p.rogue)], ['notoriety', plain(p.notoriety)], ['defected_at', ts(p.defectedAt)],
      ['titles', plain(JSON.stringify(p.titles))], ['displayed_title', plain(p.displayedTitle)],
      ['pvp_wins', plain(p.pvpWins)], ['bounties_claimed', plain(p.bountiesClaimed)],
      ['s_rank_completed', plain(p.sRankCompleted)],
      ['created_at', ts(p.createdAt)],
      ['inventory', plain(JSON.stringify(p.inventory))],
      ['cosmetics', plain(JSON.stringify(p.cosmetics))],
      ['equipped', plain(JSON.stringify(p.equipped))],
      ['boosts', plain(JSON.stringify(p.boosts))],
      ['gathering', plain(p.gathering ? JSON.stringify(p.gathering) : null)],
      ['crafting', plain(p.crafting ? JSON.stringify(p.crafting) : null)],
      ['dungeon_run', plain(p.dungeon ? JSON.stringify(p.dungeon) : null)],
      ['dungeon_runs_day', plain(p.dungeonRunsDay)],
      ['dungeon_runs_today', plain(p.dungeonRunsToday)],
      ['dungeon_cooldowns', plain(JSON.stringify(p.dungeonCooldowns))],
      ['mentored_before', plain(p.mentoredBefore)],
      ['last_mentorship_ended_at', ts(p.lastMentorshipEndedAt)],
    ].map(([name, spec]) => ({ name, ...(spec as { sql: string; value: unknown }) })) as never;
  }

  async createPlayer(p: PlayerRecord): Promise<void> {
    const cols = this.playerColumns(p) as unknown as { name: string; sql: string; value: unknown }[];
    const params: unknown[] = [];
    const names = cols.map((c) => c.name);
    const values = cols.map((c) => {
      // a column's SQL may reference its own parameter more than once
      const uses = (c.sql.match(/\?/g) ?? []).length;
      const first = params.length + 1;
      params.push(c.value);
      let i = 0;
      return c.sql.replace(/\?/g, () => `$${first + (uses > 1 ? 0 : i++)}`);
    });
    await this.db.query(
      `INSERT INTO players (${names.join(', ')}) VALUES (${values.join(', ')})`,
      params,
    );
    await this.writeSessions(p);
  }

  async getPlayer(id: string): Promise<PlayerRecord | null> {
    const { rows } = await this.db.query<PlayerRow>(`${SELECT_PLAYER} WHERE p.id = $1`, [id]);
    return rows[0] ? toRecord(rows[0]) : null;
  }

  async getPlayerByName(name: string): Promise<PlayerRecord | null> {
    const { rows } = await this.db.query<PlayerRow>(`${SELECT_PLAYER} WHERE lower(p.name) = lower($1)`, [name.trim()]);
    return rows[0] ? toRecord(rows[0]) : null;
  }

  async savePlayer(p: PlayerRecord): Promise<void> {
    const cols = (this.playerColumns(p) as unknown as { name: string; sql: string; value: unknown }[])
      .filter((c) => c.name !== 'id');
    const params: unknown[] = [p.id];
    const sets = cols.map((c) => {
      const first = params.length + 1;
      params.push(c.value);
      return `${c.name}=${c.sql.replace(/\?/g, () => `$${first}`)}`;
    });
    await this.db.query(
      `UPDATE players SET ${sets.join(', ')}, updated_at=now() WHERE id=$1`,
      params,
    );
    await this.writeSessions(p);
  }

  /**
   * Sessions live in their own tables with the player id as primary key, so the
   * database — not application logic — is what guarantees at most one live
   * training session and one live mission per player.
   */
  private async writeSessions(p: PlayerRecord): Promise<void> {
    if (p.training) {
      await this.db.query(
        `INSERT INTO training_sessions (player_id, location_id, tier, stat, started_at)
         VALUES ($1,$2,$3,$4,to_timestamp($5::double precision / 1000))
         ON CONFLICT (player_id) DO UPDATE SET
           location_id=EXCLUDED.location_id, tier=EXCLUDED.tier,
           stat=EXCLUDED.stat, started_at=EXCLUDED.started_at`,
        [p.id, p.training.locationId, p.training.tier, p.training.stat, p.training.startedAt],
      );
    } else {
      await this.db.query('DELETE FROM training_sessions WHERE player_id=$1', [p.id]);
    }

    if (p.mission) {
      await this.db.query(
        `INSERT INTO mission_sessions (player_id, mission_id, started_at)
         VALUES ($1,$2,to_timestamp($3::double precision / 1000))
         ON CONFLICT (player_id) DO UPDATE SET
           mission_id=EXCLUDED.mission_id, started_at=EXCLUDED.started_at`,
        [p.id, p.mission.missionId, p.mission.startedAt],
      );
    } else {
      await this.db.query('DELETE FROM mission_sessions WHERE player_id=$1', [p.id]);
    }
  }

  async saveReplay(r: ReplayRecord): Promise<void> {
    await this.db.query(
      `INSERT INTO replays (match_id, seed, fighter_a, fighter_b, actions, winner_id, outcome, rounds, ended_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,to_timestamp($9::double precision / 1000))
       ON CONFLICT (match_id) DO NOTHING`,
      [r.matchId, r.seed, r.fighterIds[0], r.fighterIds[1], JSON.stringify(r.actions),
        r.winnerId, r.outcome, r.rounds, r.endedAt],
    );
  }

  async getReplay(matchId: string): Promise<ReplayRecord | null> {
    const { rows } = await this.db.query<Record<string, never>>(
      'SELECT * FROM replays WHERE match_id=$1', [matchId],
    );
    return rows[0] ? toReplay(rows[0]) : null;
  }

  async listReplaysFor(playerId: string, limit: number): Promise<ReplayRecord[]> {
    const { rows } = await this.db.query<Record<string, never>>(
      `SELECT * FROM replays WHERE fighter_a=$1 OR fighter_b=$1
       ORDER BY ended_at DESC LIMIT $2`,
      [playerId, limit],
    );
    return rows.map(toReplay);
  }
}

function toReplay(row: Record<string, unknown>): ReplayRecord {
  return {
    matchId: row.match_id as string,
    seed: row.seed as string,
    fighterIds: [row.fighter_a as string, row.fighter_b as string],
    actions: row.actions as ReplayRecord['actions'],
    winnerId: (row.winner_id as string | null) ?? null,
    outcome: row.outcome as string,
    rounds: row.rounds as number,
    endedAt: ms(row.ended_at as Date | string),
  };
}
