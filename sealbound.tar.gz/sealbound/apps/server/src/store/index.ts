import type { Nature, Rank, StatKey, Stats, SubmittedAction } from '@shinobi/shared';
import type { MissionSession } from '../missions.js';
import type { BountyContract } from '../rogue.js';

/**
 * Everything the server persists. Postgres is the production implementation
 * (see schema.sql); the in-memory one exists so the trust-model tests can run
 * without infrastructure — the properties in CLAUDE.md §5 and §8 are the point,
 * not the driver.
 */

export interface TrainingSession {
  stat: StatKey;
  tier: number;
  locationId: string;
  /** server clock at start — the client never supplies elapsed time (§5) */
  startedAt: number;
}

export interface PlayerRecord {
  id: string;
  name: string;
  villageId: string;
  /** player clan (guild). The LORE clan is derived from bloodlineId, not stored. */
  clanId: string | null;
  clanJoinedAt: number | null;
  clanContribution: number;
  bloodlineId: string | null;
  rank: Rank;
  level: number;
  xp: number;
  stats: Stats;
  affinity: Nature;
  loadout: string[];
  /** techniques the player has actually learned; a loadout may only draw on these */
  known: string[];
  reputation: number;
  ryo: number;
  training: TrainingSession | null;
  mission: MissionSession | null;
  /** set while in a squad; a player may only be in one */
  squadId: string | null;
  /** missing-nin: no village work, no promotion, open season */
  rogue: boolean;
  defectedAt: number | null;
  /** what a missing-nin has actually done — the only thing a bounty is worth */
  notoriety: number;
  /** earned titles. There is no code path that grants one without earning it. */
  titles: string[];
  displayedTitle: string | null;
  pvpWins: number;
  bountiesClaimed: number;
  sRankCompleted: number;
  /** completed missions since the last promotion — the gate is per rank */
  missionsAtRank: number;
  missionsCompleted: number;
  rating: number;
}

/** A finished match, stored as (seed, actions[]) and nothing else (CLAUDE.md §12). */
export interface ReplayRecord {
  matchId: string;
  seed: string;
  fighterIds: [string, string];
  actions: SubmittedAction[];
  winnerId: string | null;
  outcome: string;
  rounds: number;
  endedAt: number;
}

export interface AccountRecord {
  id: string;
  /** normalised name — the uniqueness key, never shown to players */
  nameKey: string;
  /** self-describing scrypt digest; never a plaintext or a bare hash */
  password: string;
}

export interface SessionRecord {
  tokenHash: string;
  accountId: string;
  expiresAt: number;
}

/**
 * A squad is transient — formed for a mission, disbanded after. It is persisted
 * rather than held in memory because a party mission can outlive a restart, and
 * members must not be able to escape a failure by reconnecting.
 */
export interface SquadRecord {
  id: string;
  leaderId: string;
  memberIds: string[];
  invitedIds: string[];
  mission: { missionId: string; startedAt: number } | null;
}

export interface ClanRecord {
  id: string;
  name: string;
  /** normalised, so two clans cannot take confusable names */
  nameKey: string;
  leaderId: string;
  memberIds: string[];
  officerIds: string[];
  invitedIds: string[];
  bank: number;
  foundedAt: number;
  withdrawnToday: number;
  withdrawWindowStart: number;
}

export interface LegendaryRecord {
  itemId: string;
  holderId: string;
  acquiredAt: number;
}

export interface LegendaryHistoryEntry {
  itemId: string;
  holderId: string;
  heldFrom: number;
  heldUntil: number | null;
}

export interface Store {
  /** Rejects if the item already has a holder — that rejection is the guarantee. */
  claimLegendary(record: LegendaryRecord, nowMs: number): Promise<void>;
  getLegendary(itemId: string): Promise<LegendaryRecord | null>;
  listLegendaries(): Promise<LegendaryRecord[]>;
  transferLegendary(itemId: string, toHolderId: string, nowMs: number): Promise<void>;
  legendaryHistory(itemId: string): Promise<LegendaryHistoryEntry[]>;
  createClan(c: ClanRecord): Promise<void>;
  getClan(id: string): Promise<ClanRecord | null>;
  getClanByNameKey(nameKey: string): Promise<ClanRecord | null>;
  saveClan(c: ClanRecord): Promise<void>;
  deleteClan(id: string): Promise<void>;
  listClans(): Promise<ClanRecord[]>;
  saveContract(c: BountyContract): Promise<void>;
  listContracts(nowMs: number): Promise<BountyContract[]>;
  deleteContract(id: string): Promise<void>;
  listRogues(): Promise<PlayerRecord[]>;
  createSquad(s: SquadRecord): Promise<void>;
  getSquad(id: string): Promise<SquadRecord | null>;
  saveSquad(s: SquadRecord): Promise<void>;
  deleteSquad(id: string): Promise<void>;
  createAccount(a: AccountRecord): Promise<void>;
  getAccountByNameKey(nameKey: string): Promise<AccountRecord | null>;
  createSession(s: SessionRecord): Promise<void>;
  getSession(tokenHash: string): Promise<SessionRecord | null>;
  deleteSession(tokenHash: string): Promise<void>;
  deleteExpiredSessions(nowMs: number): Promise<number>;
  createPlayer(p: PlayerRecord): Promise<void>;
  getPlayer(id: string): Promise<PlayerRecord | null>;
  getPlayerByName(name: string): Promise<PlayerRecord | null>;
  savePlayer(p: PlayerRecord): Promise<void>;
  saveReplay(r: ReplayRecord): Promise<void>;
  getReplay(matchId: string): Promise<ReplayRecord | null>;
  listReplaysFor(playerId: string, limit: number): Promise<ReplayRecord[]>;
}

export class MemoryStore implements Store {
  private players = new Map<string, PlayerRecord>();
  private replays = new Map<string, ReplayRecord>();
  private accounts = new Map<string, AccountRecord>();
  private sessions = new Map<string, SessionRecord>();
  private squads = new Map<string, SquadRecord>();
  private contracts = new Map<string, BountyContract>();
  private clans = new Map<string, ClanRecord>();
  private legendaries = new Map<string, LegendaryRecord>();
  private legendaryLog: LegendaryHistoryEntry[] = [];

  async claimLegendary(record: LegendaryRecord, nowMs: number): Promise<void> {
    if (this.legendaries.has(record.itemId)) throw new Error('legendary already held');
    this.legendaries.set(record.itemId, { ...record });
    this.legendaryLog.push({ itemId: record.itemId, holderId: record.holderId, heldFrom: nowMs, heldUntil: null });
  }
  async getLegendary(itemId: string): Promise<LegendaryRecord | null> {
    const l = this.legendaries.get(itemId);
    return l ? { ...l } : null;
  }
  async listLegendaries(): Promise<LegendaryRecord[]> {
    return [...this.legendaries.values()].map((l) => ({ ...l }));
  }
  async transferLegendary(itemId: string, toHolderId: string, nowMs: number): Promise<void> {
    const held = this.legendaries.get(itemId);
    if (!held) throw new Error('no such legendary');
    const open = this.legendaryLog.find((h) => h.itemId === itemId && h.heldUntil === null);
    if (open) open.heldUntil = nowMs;
    this.legendaries.set(itemId, { itemId, holderId: toHolderId, acquiredAt: nowMs });
    this.legendaryLog.push({ itemId, holderId: toHolderId, heldFrom: nowMs, heldUntil: null });
  }
  async legendaryHistory(itemId: string): Promise<LegendaryHistoryEntry[]> {
    return this.legendaryLog.filter((h) => h.itemId === itemId).map((h) => ({ ...h }));
  }

  async createClan(c: ClanRecord): Promise<void> {
    if ([...this.clans.values()].some((x) => x.nameKey === c.nameKey)) throw new Error('clan name taken');
    this.clans.set(c.id, structuredClone(c));
  }
  async getClan(id: string): Promise<ClanRecord | null> {
    const c = this.clans.get(id);
    return c ? structuredClone(c) : null;
  }
  async getClanByNameKey(nameKey: string): Promise<ClanRecord | null> {
    const c = [...this.clans.values()].find((x) => x.nameKey === nameKey);
    return c ? structuredClone(c) : null;
  }
  async saveClan(c: ClanRecord): Promise<void> { this.clans.set(c.id, structuredClone(c)); }
  async deleteClan(id: string): Promise<void> { this.clans.delete(id); }
  async listClans(): Promise<ClanRecord[]> { return [...this.clans.values()].map((c) => structuredClone(c)); }

  async saveContract(c: BountyContract): Promise<void> { this.contracts.set(c.id, { ...c }); }
  async listContracts(): Promise<BountyContract[]> {
    return [...this.contracts.values()].map((c) => ({ ...c }));
  }
  async deleteContract(id: string): Promise<void> { this.contracts.delete(id); }
  async listRogues(): Promise<PlayerRecord[]> {
    return [...this.players.values()].filter((p) => p.rogue).map((p) => structuredClone(p));
  }

  async createSquad(s: SquadRecord): Promise<void> { this.squads.set(s.id, structuredClone(s)); }
  async getSquad(id: string): Promise<SquadRecord | null> {
    const s = this.squads.get(id);
    return s ? structuredClone(s) : null;
  }
  async saveSquad(s: SquadRecord): Promise<void> { this.squads.set(s.id, structuredClone(s)); }
  async deleteSquad(id: string): Promise<void> { this.squads.delete(id); }

  async createAccount(a: AccountRecord): Promise<void> {
    if ([...this.accounts.values()].some((x) => x.nameKey === a.nameKey)) {
      throw new Error('name taken');
    }
    this.accounts.set(a.id, { ...a });
  }

  async getAccountByNameKey(nameKey: string): Promise<AccountRecord | null> {
    const found = [...this.accounts.values()].find((a) => a.nameKey === nameKey);
    return found ? { ...found } : null;
  }

  async createSession(s: SessionRecord): Promise<void> { this.sessions.set(s.tokenHash, { ...s }); }

  async getSession(tokenHash: string): Promise<SessionRecord | null> {
    const s = this.sessions.get(tokenHash);
    return s ? { ...s } : null;
  }

  async deleteSession(tokenHash: string): Promise<void> { this.sessions.delete(tokenHash); }

  async deleteExpiredSessions(nowMs: number): Promise<number> {
    let removed = 0;
    for (const [k, s] of this.sessions) if (s.expiresAt <= nowMs) { this.sessions.delete(k); removed++; }
    return removed;
  }

  async createPlayer(p: PlayerRecord): Promise<void> {
    if (this.players.has(p.id)) throw new Error(`player exists: ${p.id}`);
    this.players.set(p.id, structuredClone(p));
  }

  async getPlayer(id: string): Promise<PlayerRecord | null> {
    const p = this.players.get(id);
    return p ? structuredClone(p) : null;
  }

  async getPlayerByName(name: string): Promise<PlayerRecord | null> {
    const key = name.trim().toLowerCase();
    const found = [...this.players.values()].find((p) => p.name.toLowerCase() === key);
    return found ? structuredClone(found) : null;
  }

  async savePlayer(p: PlayerRecord): Promise<void> {
    this.players.set(p.id, structuredClone(p));
  }

  async saveReplay(r: ReplayRecord): Promise<void> {
    this.replays.set(r.matchId, structuredClone(r));
  }

  async getReplay(matchId: string): Promise<ReplayRecord | null> {
    const r = this.replays.get(matchId);
    return r ? structuredClone(r) : null;
  }

  async listReplaysFor(playerId: string, limit: number): Promise<ReplayRecord[]> {
    return [...this.replays.values()]
      .filter((r) => r.fighterIds.includes(playerId))
      .sort((a, b) => b.endedAt - a.endedAt)
      .slice(0, limit)
      .map((r) => structuredClone(r));
  }
}
