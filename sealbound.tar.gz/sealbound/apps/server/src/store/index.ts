import type { Nature, Rank, StatKey, Stats, SubmittedAction } from '@shinobi/shared';
import type { MissionSession } from '../missions.js';
import type { BountyContract } from '../rogue.js';

/**
 * Everything the server persists. Postgres is the production implementation
 * (see schema.sql); the in-memory one exists so the trust-model tests can run
 * without infrastructure — the properties in CLAUDE.md §5 and §8 are the point,
 * not the driver.
 */

export interface TrainingSession {
  stat: StatKey;
  tier: number;
  locationId: string;
  /** server clock at start — the client never supplies elapsed time (§5) */
  startedAt: number;
}

/** A timed gathering trip. Like training, elapsed time is derived from `startedAt`. */
export interface GatherSession { regionId: string; itemId: string; startedAt: number }

/** A crafting job at a station. Same rule: the client never supplies elapsed time. */
export interface CraftSession { recipeId: string; startedAt: number }

/**
 * A dungeon attempt in progress. `roomIndex` is the server's cursor through the
 * rooms — the client is told the prompt for the current room and nothing about
 * the ones after it.
 */
export interface DungeonRun {
  dungeonId: string;
  roomIndex: number;
  attemptsLeft: number;
  startedAt: number;
  /** set after a wrong answer; the run cannot be advanced before this */
  lockedUntil: number;
}

/**
 * Consumable effects waiting to be spent. Every field here is out-of-combat by
 * construction — there is deliberately no field a match could read.
 */
export interface Boosts {
  trainingRateBonus: number;
  gatherYieldBonus: number;
  dungeonAttempts: number;
}

export interface PlayerRecord {
  id: string;
  name: string;
  villageId: string;
  /** player clan (guild). The LORE clan is derived from bloodlineId, not stored. */
  clanId: string | null;
  clanJoinedAt: number | null;
  clanContribution: number;
  bloodlineId: string | null;
  rank: Rank;
  level: number;
  xp: number;
  stats: Stats;
  affinity: Nature;
  loadout: string[];
  /** techniques the player has actually learned; a loadout may only draw on these */
  known: string[];
  reputation: number;
  ryo: number;
  training: TrainingSession | null;
  mission: MissionSession | null;
  /** set while in a squad; a player may only be in one */
  squadId: string | null;
  /** missing-nin: no village work, no promotion, open season */
  rogue: boolean;
  defectedAt: number | null;
  /** what a missing-nin has actually done — the only thing a bounty is worth */
  notoriety: number;
  /** earned titles. There is no code path that grants one without earning it. */
  titles: string[];
  displayedTitle: string | null;
  pvpWins: number;
  bountiesClaimed: number;
  sRankCompleted: number;
  /** completed missions since the last promotion — the gate is per rank */
  missionsAtRank: number;
  missionsCompleted: number;
  rating: number;
  /** account creation, used by suffrage — a vote costs a day of standing */
  createdAt: number;
  /** itemId -> quantity. Resources, components, consumables and keys. */
  inventory: Record<string, number>;
  /** owned cosmetics. Untradable by design, so this is append-only in practice. */
  cosmetics: string[];
  /** slot -> cosmetic id */
  equipped: Record<string, string>;
  boosts: Boosts;
  gathering: GatherSession | null;
  crafting: CraftSession | null;
  dungeon: DungeonRun | null;
  /** day index of the last dungeon run, and how many were made on that day */
  dungeonRunsDay: number;
  dungeonRunsToday: number;
  /** dungeon id -> the instant it may be re-entered. A known answer is not a faucet. */
  dungeonCooldowns: Record<string, number>;
  /** a player may be mentored once, ever */
  mentoredBefore: boolean;
  lastMentorshipEndedAt: number | null;
}

/**
 * The meta-game half of a player record, in one place.
 *
 * Every construction site takes these from here rather than spelling them out,
 * which is the same lesson the Postgres column map taught: a hand-written field
 * list drifts silently every time the shape grows.
 */
export function newMetaState(nowMs: number): Pick<PlayerRecord,
  'createdAt' | 'inventory' | 'cosmetics' | 'equipped' | 'boosts' | 'gathering' | 'crafting'
  | 'dungeon' | 'dungeonRunsDay' | 'dungeonRunsToday' | 'dungeonCooldowns'
  | 'mentoredBefore' | 'lastMentorshipEndedAt'> {
  return {
    createdAt: nowMs,
    inventory: {},
    cosmetics: [],
    equipped: {},
    boosts: { trainingRateBonus: 0, gatherYieldBonus: 0, dungeonAttempts: 0 },
    gathering: null,
    crafting: null,
    dungeon: null,
    dungeonRunsDay: 0,
    dungeonRunsToday: 0,
    dungeonCooldowns: {},
    mentoredBefore: false,
    lastMentorshipEndedAt: null,
  };
}

/** One side of a proposed trade. */
export interface TradeSide { ryo: number; items: { itemId: string; qty: number }[] }

/**
 * A proposed direct trade.
 *
 * Nothing is escrowed at proposal time — the goods are checked again at the
 * moment of acceptance. That means a player may offer the same stack to several
 * people, and the first acceptance wins; the rest are told it is no longer
 * available. Escrowing instead would be defensible, but it makes an offer a way
 * to lock up someone's inventory, and a rejected proposal would have to unwind.
 */
export interface TradeRecord {
  id: string;
  fromId: string;
  toId: string;
  offer: TradeSide;
  request: TradeSide;
  createdAt: number;
  expiresAt: number;
}

/**
 * A completed transfer between two players.
 *
 * This exists because direct trade and gifting are, by design, a free way to
 * move value between accounts. That was previously impossible — every transfer
 * went through a market that taxed it — and the property that collusion loses
 * money is now gone. What replaces it is not prevention but ATTRIBUTION: every
 * transfer is recorded, permanently, with both ends and the exact contents.
 * A ring of accounts moving value in one direction is trivially visible in this
 * table, which is the honest defence once free transfer is a design goal.
 */
export interface TransferRecord {
  id: string;
  at: number;
  kind: 'trade' | 'gift';
  fromId: string;
  toId: string;
  ryo: number;
  items: { itemId: string; qty: number }[];
}

/**
 * Who holds a region. Villages own regions; a clan garrisons one on the
 * village's behalf, and a war flips both at once.
 */
export interface RegionRecord {
  id: string;
  controllingVillageId: string;
  garrisonClanId: string | null;
  capturedAt: number;
}

/**
 * One war per region per period, enforced by a unique constraint rather than by
 * application logic. Contributions are recorded per player so the same member
 * cannot be counted twice and so a cap can be applied per person.
 */
export interface WarRecord {
  id: string;
  regionId: string;
  periodIndex: number;
  attackerClanId: string;
  defenderClanId: string | null;
  /** ryo staked by the attacker at declaration; locked at that moment */
  stake: number;
  attackerScore: number;
  defenderScore: number;
  contributions: Record<string, number>;
  declaredAt: number;
  resolvesAt: number;
  resolved: boolean;
  winnerClanId: string | null;
}

/** Goods are escrowed into the listing, so the seller cannot sell what they spent. */
export interface ListingRecord {
  id: string;
  sellerId: string;
  itemId: string;
  qty: number;
  unitPrice: number;
  listedAt: number;
  expiresAt: number;
}

/** The moving reference price an item's legal band is anchored to. */
export interface MarketRefRecord { itemId: string; reference: number; updatedAt: number }

export interface VillageRecord {
  id: string;
  taxRate: number;
  treasury: number;
  laws: string[];
  commissions: { id: string; endsAt: number }[];
  atWarWith: string[];
  /** the cycle the tax rate was last changed in, so it moves once per term */
  taxSetInCycle: number;
}

export interface CandidacyRecord { villageId: string; officeId: string; cycle: number; playerId: string }

/** One vote per player per office per cycle — the store rejects the second. */
export interface VoteRecord { villageId: string; officeId: string; cycle: number; voterId: string; candidateId: string }

export interface OfficeRecord { villageId: string; officeId: string; cycle: number; holderIds: string[] }

export interface MentorshipRecord {
  id: string;
  mentorId: string;
  menteeId: string;
  status: 'offered' | 'active' | 'ended';
  startedAt: number;
  endedAt: number | null;
  /** milestone ids already paid, so a milestone can never pay twice */
  rewarded: string[];
  /** when each reward was paid, for the weekly cap */
  rewardTimes: number[];
}

/** A finished match, stored as (seed, actions[]) and nothing else (CLAUDE.md §12). */
export interface ReplayRecord {
  matchId: string;
  seed: string;
  fighterIds: [string, string];
  actions: SubmittedAction[];
  winnerId: string | null;
  outcome: string;
  rounds: number;
  endedAt: number;
}

export interface AccountRecord {
  id: string;
  /** normalised name — the uniqueness key, never shown to players */
  nameKey: string;
  /** self-describing scrypt digest; never a plaintext or a bare hash */
  password: string;
}

export interface SessionRecord {
  tokenHash: string;
  accountId: string;
  expiresAt: number;
}

/**
 * A squad is transient — formed for a mission, disbanded after. It is persisted
 * rather than held in memory because a party mission can outlive a restart, and
 * members must not be able to escape a failure by reconnecting.
 */
export interface SquadRecord {
  id: string;
  leaderId: string;
  memberIds: string[];
  invitedIds: string[];
  mission: { missionId: string; startedAt: number } | null;
}

export interface ClanRecord {
  id: string;
  name: string;
  /** normalised, so two clans cannot take confusable names */
  nameKey: string;
  leaderId: string;
  memberIds: string[];
  officerIds: string[];
  invitedIds: string[];
  bank: number;
  foundedAt: number;
  withdrawnToday: number;
  withdrawWindowStart: number;
}

export interface LegendaryRecord {
  itemId: string;
  holderId: string;
  acquiredAt: number;
}

export interface LegendaryHistoryEntry {
  itemId: string;
  holderId: string;
  heldFrom: number;
  heldUntil: number | null;
}

export interface Store {
  /* ── Territory ─────────────────────────────────────────────────────── */
  getRegion(id: string): Promise<RegionRecord | null>;
  listRegionRecords(): Promise<RegionRecord[]>;
  saveRegion(r: RegionRecord): Promise<void>;
  /** Rejects a second war on the same region in the same period. */
  createWar(w: WarRecord): Promise<void>;
  getWar(id: string): Promise<WarRecord | null>;
  listWars(): Promise<WarRecord[]>;
  saveWar(w: WarRecord): Promise<void>;

  /* ── Market ────────────────────────────────────────────────────────── */
  createListing(l: ListingRecord): Promise<void>;
  getListing(id: string): Promise<ListingRecord | null>;
  listListings(): Promise<ListingRecord[]>;
  /** Returns false if the row was already gone — that is how a double-buy loses. */
  deleteListing(id: string): Promise<boolean>;
  createTrade(trade: TradeRecord): Promise<void>;
  getTrade(id: string): Promise<TradeRecord | null>;
  listTradesFor(playerId: string): Promise<TradeRecord[]>;
  /** True for the caller that actually removed it — settles a double-accept race. */
  deleteTrade(id: string): Promise<boolean>;
  recordTransfer(entry: TransferRecord): Promise<void>;
  listTransfers(playerId: string): Promise<TransferRecord[]>;
  getMarketRef(itemId: string): Promise<MarketRefRecord | null>;
  saveMarketRef(r: MarketRefRecord): Promise<void>;
  listMarketRefs(): Promise<MarketRefRecord[]>;

  /* ── Villages and politics ─────────────────────────────────────────── */
  getVillage(id: string): Promise<VillageRecord | null>;
  saveVillage(v: VillageRecord): Promise<void>;
  addCandidacy(c: CandidacyRecord): Promise<void>;
  listCandidacies(villageId: string, cycle: number): Promise<CandidacyRecord[]>;
  /** Rejects a second vote by the same player for the same office and cycle. */
  castVote(v: VoteRecord): Promise<void>;
  listVotes(villageId: string, cycle: number): Promise<VoteRecord[]>;
  saveOffice(o: OfficeRecord): Promise<void>;
  listOffices(villageId: string, cycle: number): Promise<OfficeRecord[]>;

  /* ── Mentorship ────────────────────────────────────────────────────── */
  createMentorship(m: MentorshipRecord): Promise<void>;
  getMentorship(id: string): Promise<MentorshipRecord | null>;
  listMentorshipsFor(playerId: string): Promise<MentorshipRecord[]>;
  saveMentorship(m: MentorshipRecord): Promise<void>;

  /** Rejects if the item already has a holder — that rejection is the guarantee. */
  claimLegendary(record: LegendaryRecord, nowMs: number): Promise<void>;
  getLegendary(itemId: string): Promise<LegendaryRecord | null>;
  listLegendaries(): Promise<LegendaryRecord[]>;
  transferLegendary(itemId: string, toHolderId: string, nowMs: number): Promise<void>;
  legendaryHistory(itemId: string): Promise<LegendaryHistoryEntry[]>;
  createClan(c: ClanRecord): Promise<void>;
  getClan(id: string): Promise<ClanRecord | null>;
  getClanByNameKey(nameKey: string): Promise<ClanRecord | null>;
  saveClan(c: ClanRecord): Promise<void>;
  deleteClan(id: string): Promise<void>;
  listClans(): Promise<ClanRecord[]>;
  saveContract(c: BountyContract): Promise<void>;
  listContracts(nowMs: number): Promise<BountyContract[]>;
  deleteContract(id: string): Promise<void>;
  listRogues(): Promise<PlayerRecord[]>;
  createSquad(s: SquadRecord): Promise<void>;
  getSquad(id: string): Promise<SquadRecord | null>;
  saveSquad(s: SquadRecord): Promise<void>;
  deleteSquad(id: string): Promise<void>;
  createAccount(a: AccountRecord): Promise<void>;
  getAccountByNameKey(nameKey: string): Promise<AccountRecord | null>;
  createSession(s: SessionRecord): Promise<void>;
  getSession(tokenHash: string): Promise<SessionRecord | null>;
  deleteSession(tokenHash: string): Promise<void>;
  deleteExpiredSessions(nowMs: number): Promise<number>;
  createPlayer(p: PlayerRecord): Promise<void>;
  getPlayer(id: string): Promise<PlayerRecord | null>;
  getPlayerByName(name: string): Promise<PlayerRecord | null>;
  savePlayer(p: PlayerRecord): Promise<void>;
  saveReplay(r: ReplayRecord): Promise<void>;
  getReplay(matchId: string): Promise<ReplayRecord | null>;
  listReplaysFor(playerId: string, limit: number): Promise<ReplayRecord[]>;
}

export class MemoryStore implements Store {
  private regions = new Map<string, RegionRecord>();
  private wars = new Map<string, WarRecord>();
  private listings = new Map<string, ListingRecord>();
  private marketRefs = new Map<string, MarketRefRecord>();
  private villages = new Map<string, VillageRecord>();
  private candidacies: CandidacyRecord[] = [];
  private votes: VoteRecord[] = [];
  private offices = new Map<string, OfficeRecord>();
  private mentorships = new Map<string, MentorshipRecord>();
  private players = new Map<string, PlayerRecord>();

  async getRegion(id: string): Promise<RegionRecord | null> {
    const r = this.regions.get(id);
    return r ? { ...r } : null;
  }
  async listRegionRecords(): Promise<RegionRecord[]> { return [...this.regions.values()].map((r) => ({ ...r })); }
  async saveRegion(r: RegionRecord): Promise<void> { this.regions.set(r.id, { ...r }); }

  async createWar(w: WarRecord): Promise<void> {
    // Mirrors the unique constraint in schema.sql: one war per region per period.
    if ([...this.wars.values()].some((x) => x.regionId === w.regionId && x.periodIndex === w.periodIndex)) {
      throw new Error('region already contested this period');
    }
    this.wars.set(w.id, structuredClone(w));
  }
  async getWar(id: string): Promise<WarRecord | null> {
    const w = this.wars.get(id);
    return w ? structuredClone(w) : null;
  }
  async listWars(): Promise<WarRecord[]> { return [...this.wars.values()].map((w) => structuredClone(w)); }
  async saveWar(w: WarRecord): Promise<void> { this.wars.set(w.id, structuredClone(w)); }

  async createListing(l: ListingRecord): Promise<void> { this.listings.set(l.id, { ...l }); }
  async getListing(id: string): Promise<ListingRecord | null> {
    const l = this.listings.get(id);
    return l ? { ...l } : null;
  }
  private trades = new Map<string, TradeRecord>();
  private transfers: TransferRecord[] = [];

  async createTrade(trade: TradeRecord): Promise<void> { this.trades.set(trade.id, { ...trade }); }
  async getTrade(id: string): Promise<TradeRecord | null> {
    const t = this.trades.get(id);
    return t ? { ...t } : null;
  }
  async listTradesFor(playerId: string): Promise<TradeRecord[]> {
    return [...this.trades.values()].filter((t) => t.fromId === playerId || t.toId === playerId).map((t) => ({ ...t }));
  }
  async deleteTrade(id: string): Promise<boolean> { return this.trades.delete(id); }
  async recordTransfer(entry: TransferRecord): Promise<void> { this.transfers.push({ ...entry }); }
  async listTransfers(playerId: string): Promise<TransferRecord[]> {
    return this.transfers.filter((t) => t.fromId === playerId || t.toId === playerId).map((t) => ({ ...t }));
  }

  async listListings(): Promise<ListingRecord[]> { return [...this.listings.values()].map((l) => ({ ...l })); }
  async deleteListing(id: string): Promise<boolean> { return this.listings.delete(id); }
  async getMarketRef(itemId: string): Promise<MarketRefRecord | null> {
    const r = this.marketRefs.get(itemId);
    return r ? { ...r } : null;
  }
  async saveMarketRef(r: MarketRefRecord): Promise<void> { this.marketRefs.set(r.itemId, { ...r }); }
  async listMarketRefs(): Promise<MarketRefRecord[]> { return [...this.marketRefs.values()].map((r) => ({ ...r })); }

  async getVillage(id: string): Promise<VillageRecord | null> {
    const v = this.villages.get(id);
    return v ? structuredClone(v) : null;
  }
  async saveVillage(v: VillageRecord): Promise<void> { this.villages.set(v.id, structuredClone(v)); }
  async addCandidacy(c: CandidacyRecord): Promise<void> {
    if (this.candidacies.some((x) => x.villageId === c.villageId && x.officeId === c.officeId && x.cycle === c.cycle && x.playerId === c.playerId)) {
      throw new Error('already standing');
    }
    this.candidacies.push({ ...c });
  }
  async listCandidacies(villageId: string, cycle: number): Promise<CandidacyRecord[]> {
    return this.candidacies.filter((c) => c.villageId === villageId && c.cycle === cycle).map((c) => ({ ...c }));
  }
  async castVote(v: VoteRecord): Promise<void> {
    // The rejection is the guarantee, exactly as with a legendary claim.
    if (this.votes.some((x) => x.villageId === v.villageId && x.officeId === v.officeId && x.cycle === v.cycle && x.voterId === v.voterId)) {
      throw new Error('already voted');
    }
    this.votes.push({ ...v });
  }
  async listVotes(villageId: string, cycle: number): Promise<VoteRecord[]> {
    return this.votes.filter((v) => v.villageId === villageId && v.cycle === cycle).map((v) => ({ ...v }));
  }
  async saveOffice(o: OfficeRecord): Promise<void> {
    this.offices.set(`${o.villageId}|${o.officeId}|${o.cycle}`, structuredClone(o));
  }
  async listOffices(villageId: string, cycle: number): Promise<OfficeRecord[]> {
    return [...this.offices.values()].filter((o) => o.villageId === villageId && o.cycle === cycle).map((o) => structuredClone(o));
  }

  async createMentorship(m: MentorshipRecord): Promise<void> {
    if (m.status === 'active' && [...this.mentorships.values()].some((x) => x.menteeId === m.menteeId && x.status === 'active')) {
      throw new Error('mentee already has a mentor');
    }
    this.mentorships.set(m.id, structuredClone(m));
  }
  async getMentorship(id: string): Promise<MentorshipRecord | null> {
    const m = this.mentorships.get(id);
    return m ? structuredClone(m) : null;
  }
  async listMentorshipsFor(playerId: string): Promise<MentorshipRecord[]> {
    return [...this.mentorships.values()]
      .filter((m) => m.mentorId === playerId || m.menteeId === playerId)
      .map((m) => structuredClone(m));
  }
  async saveMentorship(m: MentorshipRecord): Promise<void> {
    if (m.status === 'active') {
      const clash = [...this.mentorships.values()].some((x) => x.id !== m.id && x.menteeId === m.menteeId && x.status === 'active');
      if (clash) throw new Error('mentee already has a mentor');
    }
    this.mentorships.set(m.id, structuredClone(m));
  }

  private replays = new Map<string, ReplayRecord>();
  private accounts = new Map<string, AccountRecord>();
  private sessions = new Map<string, SessionRecord>();
  private squads = new Map<string, SquadRecord>();
  private contracts = new Map<string, BountyContract>();
  private clans = new Map<string, ClanRecord>();
  private legendaries = new Map<string, LegendaryRecord>();
  private legendaryLog: LegendaryHistoryEntry[] = [];

  async claimLegendary(record: LegendaryRecord, nowMs: number): Promise<void> {
    if (this.legendaries.has(record.itemId)) throw new Error('legendary already held');
    this.legendaries.set(record.itemId, { ...record });
    this.legendaryLog.push({ itemId: record.itemId, holderId: record.holderId, heldFrom: nowMs, heldUntil: null });
  }
  async getLegendary(itemId: string): Promise<LegendaryRecord | null> {
    const l = this.legendaries.get(itemId);
    return l ? { ...l } : null;
  }
  async listLegendaries(): Promise<LegendaryRecord[]> {
    return [...this.legendaries.values()].map((l) => ({ ...l }));
  }
  async transferLegendary(itemId: string, toHolderId: string, nowMs: number): Promise<void> {
    const held = this.legendaries.get(itemId);
    if (!held) throw new Error('no such legendary');
    const open = this.legendaryLog.find((h) => h.itemId === itemId && h.heldUntil === null);
    if (open) open.heldUntil = nowMs;
    this.legendaries.set(itemId, { itemId, holderId: toHolderId, acquiredAt: nowMs });
    this.legendaryLog.push({ itemId, holderId: toHolderId, heldFrom: nowMs, heldUntil: null });
  }
  async legendaryHistory(itemId: string): Promise<LegendaryHistoryEntry[]> {
    return this.legendaryLog.filter((h) => h.itemId === itemId).map((h) => ({ ...h }));
  }

  async createClan(c: ClanRecord): Promise<void> {
    if ([...this.clans.values()].some((x) => x.nameKey === c.nameKey)) throw new Error('clan name taken');
    this.clans.set(c.id, structuredClone(c));
  }
  async getClan(id: string): Promise<ClanRecord | null> {
    const c = this.clans.get(id);
    return c ? structuredClone(c) : null;
  }
  async getClanByNameKey(nameKey: string): Promise<ClanRecord | null> {
    const c = [...this.clans.values()].find((x) => x.nameKey === nameKey);
    return c ? structuredClone(c) : null;
  }
  async saveClan(c: ClanRecord): Promise<void> { this.clans.set(c.id, structuredClone(c)); }
  async deleteClan(id: string): Promise<void> { this.clans.delete(id); }
  async listClans(): Promise<ClanRecord[]> { return [...this.clans.values()].map((c) => structuredClone(c)); }

  async saveContract(c: BountyContract): Promise<void> { this.contracts.set(c.id, { ...c }); }
  async listContracts(): Promise<BountyContract[]> {
    return [...this.contracts.values()].map((c) => ({ ...c }));
  }
  async deleteContract(id: string): Promise<void> { this.contracts.delete(id); }
  async listRogues(): Promise<PlayerRecord[]> {
    return [...this.players.values()].filter((p) => p.rogue).map((p) => structuredClone(p));
  }

  async createSquad(s: SquadRecord): Promise<void> { this.squads.set(s.id, structuredClone(s)); }
  async getSquad(id: string): Promise<SquadRecord | null> {
    const s = this.squads.get(id);
    return s ? structuredClone(s) : null;
  }
  async saveSquad(s: SquadRecord): Promise<void> { this.squads.set(s.id, structuredClone(s)); }
  async deleteSquad(id: string): Promise<void> { this.squads.delete(id); }

  async createAccount(a: AccountRecord): Promise<void> {
    if ([...this.accounts.values()].some((x) => x.nameKey === a.nameKey)) {
      throw new Error('name taken');
    }
    this.accounts.set(a.id, { ...a });
  }

  async getAccountByNameKey(nameKey: string): Promise<AccountRecord | null> {
    const found = [...this.accounts.values()].find((a) => a.nameKey === nameKey);
    return found ? { ...found } : null;
  }

  async createSession(s: SessionRecord): Promise<void> { this.sessions.set(s.tokenHash, { ...s }); }

  async getSession(tokenHash: string): Promise<SessionRecord | null> {
    const s = this.sessions.get(tokenHash);
    return s ? { ...s } : null;
  }

  async deleteSession(tokenHash: string): Promise<void> { this.sessions.delete(tokenHash); }

  async deleteExpiredSessions(nowMs: number): Promise<number> {
    let removed = 0;
    for (const [k, s] of this.sessions) if (s.expiresAt <= nowMs) { this.sessions.delete(k); removed++; }
    return removed;
  }

  async createPlayer(p: PlayerRecord): Promise<void> {
    if (this.players.has(p.id)) throw new Error(`player exists: ${p.id}`);
    this.players.set(p.id, structuredClone(p));
  }

  async getPlayer(id: string): Promise<PlayerRecord | null> {
    const p = this.players.get(id);
    return p ? structuredClone(p) : null;
  }

  async getPlayerByName(name: string): Promise<PlayerRecord | null> {
    const key = name.trim().toLowerCase();
    const found = [...this.players.values()].find((p) => p.name.toLowerCase() === key);
    return found ? structuredClone(found) : null;
  }

  async savePlayer(p: PlayerRecord): Promise<void> {
    this.players.set(p.id, structuredClone(p));
  }

  async saveReplay(r: ReplayRecord): Promise<void> {
    this.replays.set(r.matchId, structuredClone(r));
  }

  async getReplay(matchId: string): Promise<ReplayRecord | null> {
    const r = this.replays.get(matchId);
    return r ? structuredClone(r) : null;
  }

  async listReplaysFor(playerId: string, limit: number): Promise<ReplayRecord[]> {
    return [...this.replays.values()]
      .filter((r) => r.fighterIds.includes(playerId))
      .sort((a, b) => b.endedAt - a.endedAt)
      .slice(0, limit)
      .map((r) => structuredClone(r));
  }
}
