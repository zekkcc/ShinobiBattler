import { RANKS, type Rank, type StatKey } from '@shinobi/shared';
import { TRAINING } from '@shinobi/content';
import type { PlayerRecord, TrainingSession } from './store/index.js';

/**
 * Training.
 *
 * The one rule that matters: elapsed time is ALWAYS derived from the stored
 * `startedAt` against the server clock (CLAUDE.md §5). No endpoint accepts a
 * duration, an elapsed value, or a completion claim from the client. A player
 * who sits offline for a week gains exactly what the tier allows, no more.
 */

export interface TrainingResult {
  gains: Partial<Record<StatKey, number>>;
  minutesCredited: number;
  complete: boolean;
}

export class TrainingError extends Error {
  constructor(readonly code: 'alreadyTraining' | 'notTraining' | 'unknownLocation' | 'unknownTier' | 'rankLocked') {
    super(code);
  }
}

const rankIndex = (r: Rank) => RANKS.indexOf(r);

export function startTraining(
  player: PlayerRecord,
  locationId: string,
  tier: number,
  nowMs: number,
): TrainingSession {
  if (player.training) throw new TrainingError('alreadyTraining');

  const location = TRAINING.locations.find((l) => l.id === locationId);
  if (!location) throw new TrainingError('unknownLocation');

  const tierDef = TRAINING.tiers.find((t) => t.tier === tier);
  if (!tierDef) throw new TrainingError('unknownTier');

  if (rankIndex(player.rank) < rankIndex(location.unlockRank)) throw new TrainingError('rankLocked');

  return { stat: location.primary, tier, locationId, startedAt: nowMs };
}

/**
 * Credit a training session. Safe to call at any point — partial sessions pay
 * pro rata, and nothing beyond the tier's duration is ever credited, so leaving
 * a session running is not an exploit.
 */
export function claimTraining(
  player: PlayerRecord,
  nowMs: number,
  weatherId: string,
  externalBonus = 0,
): TrainingResult {
  const session = player.training;
  if (!session) throw new TrainingError('notTraining');

  const location = TRAINING.locations.find((l) => l.id === session.locationId);
  const tierDef = TRAINING.tiers.find((t) => t.tier === session.tier);
  if (!location || !tierDef) throw new TrainingError('unknownLocation');

  const elapsedMinutes = Math.max(0, (nowMs - session.startedAt) / 60_000);
  const credited = Math.min(elapsedMinutes, tierDef.minutes);

  /* Long sessions pay less per minute. Without this, the optimal strategy is to
     log in twice a day, which is the opposite of what the design asks for. */
  const flat = Math.min(credited, TRAINING.diminishingAbove);
  const excess = Math.max(0, credited - TRAINING.diminishingAbove);
  const effectiveMinutes = flat + excess * TRAINING.diminishingFactor;

  const weather = TRAINING.weather.find((w) => w.id === weatherId) ?? TRAINING.weather[0]!;

  /* Outside bonuses — season, a mentor, a village commission, a consumable —
     arrive as one multiplier rather than as a growing argument list. Every one
     of them is out-of-combat by construction. */
  const base = effectiveMinutes * TRAINING.gainPerMinute * tierDef.multiplier * location.rate
    * (1 + Math.max(0, externalBonus));

  const gains: Partial<Record<StatKey, number>> = {};
  const credit = (stat: StatKey, share: number) => {
    const bonus = 1 + (weather.statBonus[stat] ?? 0);
    const amount = Math.round(base * share * bonus * 100) / 100;
    if (amount > 0) gains[stat] = (gains[stat] ?? 0) + amount;
  };
  credit(location.primary, TRAINING.primaryShare);
  credit(location.secondary, TRAINING.secondaryShare);

  return {
    gains,
    minutesCredited: Math.round(credited * 100) / 100,
    complete: elapsedMinutes >= tierDef.minutes,
  };
}

export function applyTraining(player: PlayerRecord, result: TrainingResult): void {
  for (const [stat, amount] of Object.entries(result.gains)) {
    const key = stat as StatKey;
    player.stats[key] = Math.min(500, Math.round((player.stats[key] + amount) * 100) / 100);
  }
  player.training = null;
}

/**
 * Weather is global, hourly, and clock-derived, so every player sees the same
 * sky and nobody can reroll it. It now draws from the current SEASON's table —
 * snow in winter, heat in summer — which lives in world.ts with the rest of the
 * world clock. Re-exported here because this is where callers already look.
 */
export { currentWeather } from './world.js';
