import { randomUUID } from 'node:crypto';
import { ECONOMY, ITEM_BY_ID, RECIPE_BY_ID } from '@shinobi/content';
import { RANKS, type Rank } from '@shinobi/shared';
import type { CraftSession, ListingRecord, MarketRefRecord, PlayerRecord, Store } from './store/index.js';
import { occupied } from './territory.js';

/**
 * The player economy.
 *
 * The design direction asks for players crafting, harvesting and trading, with
 * prices set by supply and demand. The hard constraint it also sets is that
 * nothing purchasable may affect combat power, and the two pull against each
 * other the moment a crafted item is allowed to matter in a fight.
 *
 * The line drawn here is absolute and structural rather than a matter of
 * balance: no item has a combat field, no code path carries an item into
 * `resolveTurn`, and `validate:content` fails the build if an item ever grows
 * one. An item may make training or gathering go faster. It may not make you
 * win.
 *
 * One thing worth being explicit about, because it was briefly wrong: the sale
 * tax is the SELLER'S VILLAGE TAX RATE, passed in by the caller. There is no
 * sale-tax constant in economy.json. That makes the tax something an elected
 * government actually sets, and it makes the political tax band — whose floor is
 * above zero — half of the guarantee below.
 *
 * The second property worth stating: there is no direct trade and no gifting.
 * Everything moves through a listing that escrows the goods and charges on both
 * sides, so a wash trade between two accounts destroys ryo every time it runs.
 * Collusion does not have to be detected if it simply loses money.
 */

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;
const rankIndex = (r: Rank) => RANKS.indexOf(r);

export class EconomyError extends Error {
  constructor(readonly code:
    | 'unknownItem' | 'unknownRecipe' | 'busy' | 'notCrafting' | 'notReady'
    | 'missingInputs' | 'rankLocked' | 'requirementNotMet' | 'notConsumable'
    | 'noneHeld' | 'untradable' | 'priceOutOfBand' | 'tooManyListings'
    | 'cannotAfford' | 'noSuchListing' | 'ownListing' | 'rogue' | 'stackFull'
    | 'badQuantity') {
    super(code);
  }
}

/* ── Inventory ────────────────────────────────────────────────────────── */

export function held(player: PlayerRecord, itemId: string): number {
  return player.inventory[itemId] ?? 0;
}

/** Adds to a stack, refusing to exceed the item's own cap rather than clamping silently. */
export function give(player: PlayerRecord, itemId: string, qty: number): void {
  const item = ITEM_BY_ID.get(itemId);
  if (!item) throw new EconomyError('unknownItem');
  if (qty <= 0) throw new EconomyError('badQuantity');
  const next = held(player, itemId) + qty;
  if (next > item.stackMax) throw new EconomyError('stackFull');
  player.inventory[itemId] = next;
}

/** Removes from a stack. Returns nothing and throws rather than partially removing. */
export function take(player: PlayerRecord, itemId: string, qty: number): void {
  if (qty <= 0) throw new EconomyError('badQuantity');
  const have = held(player, itemId);
  if (have < qty) throw new EconomyError('missingInputs');
  if (have === qty) delete player.inventory[itemId];
  else player.inventory[itemId] = have - qty;
}

/* ── Crafting ─────────────────────────────────────────────────────────── */

/**
 * Inputs are consumed when the job STARTS, not when it is claimed. Consuming on
 * claim would let a player start a craft, sell the inputs, and collect the
 * output anyway — the materials have to leave the inventory at the moment they
 * are committed.
 */
export function startCrafting(player: PlayerRecord, recipeId: string, nowMs: number): CraftSession {
  if (player.rogue) throw new EconomyError('rogue');
  if (occupied(player)) throw new EconomyError('busy');
  const recipe = RECIPE_BY_ID.get(recipeId);
  if (!recipe) throw new EconomyError('unknownRecipe');
  if (rankIndex(player.rank) < rankIndex(recipe.unlockRank)) throw new EconomyError('rankLocked');
  if (player.stats[recipe.requires.stat] < recipe.requires.min) throw new EconomyError('requirementNotMet');

  for (const input of recipe.inputs) {
    if (held(player, input.item) < input.qty) throw new EconomyError('missingInputs');
  }
  // Check every input before removing any, so a failure part-way cannot eat half
  // the materials.
  for (const input of recipe.inputs) take(player, input.item, input.qty);

  return { recipeId, startedAt: nowMs };
}

export interface CraftResult { recipeId: string; item: string; qty: number }

/** A craft pays nothing until it is finished; there is no pro-rata half-billet. */
export function claimCrafting(player: PlayerRecord, nowMs: number): CraftResult {
  const session = player.crafting;
  if (!session) throw new EconomyError('notCrafting');
  const recipe = RECIPE_BY_ID.get(session.recipeId);
  if (!recipe) throw new EconomyError('unknownRecipe');
  if (nowMs - session.startedAt < recipe.minutes * 60_000) throw new EconomyError('notReady');

  give(player, recipe.output.item, recipe.output.qty);
  player.crafting = null;
  return { recipeId: recipe.id, item: recipe.output.item, qty: recipe.output.qty };
}

/* ── Consumables ──────────────────────────────────────────────────────── */

/**
 * Every field a consumable can touch is out-of-combat. The `use` block in the
 * schema is `.strict()`, so an item that tried to grant anything else would not
 * parse, and the build would fail before the server ever saw it.
 */
export function useItem(player: PlayerRecord, itemId: string): string {
  const item = ITEM_BY_ID.get(itemId);
  if (!item) throw new EconomyError('unknownItem');
  if (item.kind !== 'consumable' || !item.use) throw new EconomyError('notConsumable');
  if (held(player, itemId) < 1) throw new EconomyError('noneHeld');

  take(player, itemId, 1);
  const use = item.use;
  if (use.trainingRateBonus) player.boosts.trainingRateBonus += use.trainingRateBonus;
  if (use.gatherYieldBonus) player.boosts.gatherYieldBonus += use.gatherYieldBonus;
  if (use.dungeonAttempts) player.boosts.dungeonAttempts += use.dungeonAttempts;
  return item.name;
}

/** Boosts are spent, not decayed — a bonus that is never consumed is a permanent buff. */
export function spendTrainingBoost(player: PlayerRecord): number {
  const bonus = player.boosts.trainingRateBonus;
  player.boosts.trainingRateBonus = 0;
  return bonus;
}

export function spendGatherBoost(player: PlayerRecord): number {
  const bonus = player.boosts.gatherYieldBonus;
  player.boosts.gatherYieldBonus = 0;
  return bonus;
}

/* ── Prices ───────────────────────────────────────────────────────────── */

/**
 * Supply and demand, on a leash.
 *
 * The reference price drifts with real volume and returns toward the item's base
 * value over time. The return is what stops one wealthy player parking an item's
 * legal band wherever they like and leaving it there: to hold a price they have
 * to keep buying at it.
 */
export function decayedReference(ref: MarketRefRecord | null, itemId: string, nowMs: number): number {
  const base = ITEM_BY_ID.get(itemId)?.baseValue ?? 1;
  if (!ref) return base;
  const days = Math.max(0, (nowMs - ref.updatedAt) / DAY);
  const pull = Math.min(1, days * ECONOMY.market.referenceReturnPerDay);
  return Math.max(1, Math.round(ref.reference + (base - ref.reference) * pull));
}

export function priceBand(reference: number): { min: number; max: number } {
  return {
    min: Math.max(1, Math.floor(reference * ECONOMY.market.priceFloorFraction)),
    max: Math.max(2, Math.ceil(reference * ECONOMY.market.priceCeilingFraction)),
  };
}

export async function referenceFor(store: Store, itemId: string, nowMs: number): Promise<number> {
  return decayedReference(await store.getMarketRef(itemId), itemId, nowMs);
}

/* ── The market ───────────────────────────────────────────────────────── */

export interface ListResult { listing: ListingRecord; fee: number }

export async function listForSale(
  store: Store,
  seller: PlayerRecord,
  itemId: string,
  qty: number,
  unitPrice: number,
  nowMs: number,
): Promise<ListResult> {
  if (seller.rogue) throw new EconomyError('rogue');
  const m = ECONOMY.market;
  if (rankIndex(seller.rank) < rankIndex(m.minRankToTrade)) throw new EconomyError('rankLocked');

  const item = ITEM_BY_ID.get(itemId);
  if (!item) throw new EconomyError('unknownItem');
  if (!item.tradable) throw new EconomyError('untradable');
  if (qty <= 0 || unitPrice <= 0) throw new EconomyError('badQuantity');

  const mine = (await store.listListings()).filter((l) => l.sellerId === seller.id);
  if (mine.length >= m.maxActiveListingsPerPlayer) throw new EconomyError('tooManyListings');

  const band = priceBand(await referenceFor(store, itemId, nowMs));
  if (unitPrice < band.min || unitPrice > band.max) throw new EconomyError('priceOutOfBand');

  const fee = Math.ceil(qty * unitPrice * m.listingFeeFraction);
  if (seller.ryo < fee) throw new EconomyError('cannotAfford');

  // Escrow first: the goods leave the seller now, so they cannot be listed twice
  // or spent while a buyer is deciding.
  take(seller, itemId, qty);
  seller.ryo -= fee;

  const listing: ListingRecord = {
    id: randomUUID(),
    sellerId: seller.id,
    itemId,
    qty,
    unitPrice,
    listedAt: nowMs,
    expiresAt: nowMs + m.listingDurationHours * HOUR,
  };
  await store.createListing(listing);
  return { listing, fee };
}

export interface BuyResult {
  listing: ListingRecord;
  paid: number;
  tax: number;
  toSeller: number;
  sellerId: string;
}

/**
 * The DELETE settles the sale.
 *
 * Two buyers can both pass every check above; only one of them gets a row back
 * from `deleteListing`, and the loser is told it is gone before any money moves.
 * Doing it the other way round — pay, then delete — is how a market ends up
 * paying twice for one stack.
 */
export async function buyListing(
  store: Store,
  buyer: PlayerRecord,
  listingId: string,
  taxRate: number,
  nowMs: number,
): Promise<BuyResult> {
  if (buyer.rogue) throw new EconomyError('rogue');
  const listing = await store.getListing(listingId);
  if (!listing || listing.expiresAt <= nowMs) throw new EconomyError('noSuchListing');
  if (listing.sellerId === buyer.id) throw new EconomyError('ownListing');

  const total = listing.qty * listing.unitPrice;
  if (buyer.ryo < total) throw new EconomyError('cannotAfford');

  const item = ITEM_BY_ID.get(listing.itemId);
  if (!item) throw new EconomyError('unknownItem');
  if (held(buyer, listing.itemId) + listing.qty > item.stackMax) throw new EconomyError('stackFull');

  const won = await store.deleteListing(listingId);
  if (!won) throw new EconomyError('noSuchListing');

  buyer.ryo -= total;
  give(buyer, listing.itemId, listing.qty);

  const tax = Math.floor(total * Math.max(0, taxRate));
  return { listing, paid: total, tax, toSeller: total - tax, sellerId: listing.sellerId };
}

/** Cancelling returns the goods. The listing fee is not returned — it was the cost of trying. */
export async function cancelListing(store: Store, seller: PlayerRecord, listingId: string): Promise<ListingRecord> {
  const listing = await store.getListing(listingId);
  if (!listing) throw new EconomyError('noSuchListing');
  if (listing.sellerId !== seller.id) throw new EconomyError('noSuchListing');
  const won = await store.deleteListing(listingId);
  if (!won) throw new EconomyError('noSuchListing');
  give(seller, listing.itemId, listing.qty);
  return listing;
}

/** Expired listings hand the goods back. Called lazily whenever the board is read. */
export async function sweepExpired(store: Store, nowMs: number): Promise<number> {
  let returned = 0;
  for (const listing of await store.listListings()) {
    if (listing.expiresAt > nowMs) continue;
    if (!(await store.deleteListing(listing.id))) continue;
    const seller = await store.getPlayer(listing.sellerId);
    if (seller) {
      try { give(seller, listing.itemId, listing.qty); } catch { /* stack full: the goods are lost, which is the seller's problem */ }
      await store.savePlayer(seller);
    }
    returned++;
  }
  return returned;
}

/** A completed sale nudges the reference price toward what someone actually paid. */
export async function recordSale(store: Store, itemId: string, unitPrice: number, nowMs: number): Promise<void> {
  const current = await referenceFor(store, itemId, nowMs);
  const next = current + (unitPrice - current) * ECONOMY.market.referenceAdjustPerSale;
  await store.saveMarketRef({ itemId, reference: Math.max(1, Math.round(next)), updatedAt: nowMs });
}
