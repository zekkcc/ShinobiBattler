import { TUNING } from '@shinobi/content';
import {
  createMatch, makeRng, resolveTurn, sanitizeActions, settleSkillGain,
  type FighterSpec, type Rng,
} from '@shinobi/engine';
import type { MatchEvent, MatchState, SubmittedAction } from '@shinobi/shared';
import type { PlayerRecord, ReplayRecord, Store } from './store/index.js';

/**
 * A live 1v1. This is the whole trust boundary: clients hand in intent, the room
 * decides everything else.
 *
 * Never accepted from a client: damage, hit/miss, RNG rolls, cooldown state,
 * energy totals, or elapsed time (CLAUDE.md §5). The only thing that crosses is
 * `{ actionId, targetId }` for a body the sender owns.
 */
export class MatchRoom {
  readonly matchId: string;
  readonly seed: string;
  readonly fighterIds: [string, string];

  private state: MatchState;
  private rng: Rng;
  /** the replay record, built incrementally: (seed, actions[]) and nothing else */
  private readonly actionLog: SubmittedAction[] = [];
  /** intents for the round currently being collected, keyed by owning player */
  private pending = new Map<string, SubmittedAction[]>();
  private finished = false;

  constructor(matchId: string, seed: string, a: FighterSpec, b: FighterSpec) {
    this.matchId = matchId;
    this.seed = seed;
    this.fighterIds = [a.id, b.id];
    this.state = createMatch(matchId, seed, a, b);
    this.rng = makeRng(seed);
  }

  get round(): number { return this.state.round; }
  get isComplete(): boolean { return this.state.phase === 'complete'; }
  get winnerId(): string | null { return this.state.winnerId; }
  get outcome(): MatchState['outcome'] { return this.state.outcome; }

  /**
   * What a given player is allowed to see. The engine's MatchState is already
   * public-by-design (a weave in progress is visible per §7), but loadouts and
   * the skill ledger are not the opponent's business.
   */
  viewFor(playerId: string): MatchState {
    const view = structuredClone(this.state);
    for (const f of view.fighters) {
      if (f.id === playerId) continue;
      f.loadout = [];
      f.skillLedger = {};
    }
    return view;
  }

  /**
   * Record one player's intent for this round.
   *
   * `playerId` comes from the authenticated connection, never from the payload.
   * Anything addressed to a body that player does not own is dropped here, and
   * `resolveTurn` enforces ownership a second time.
   */
  submit(playerId: string, actions: SubmittedAction[]): { accepted: number; rejected: number } {
    if (this.finished || !this.fighterIds.includes(playerId)) return { accepted: 0, rejected: actions.length };

    const clean = sanitizeActions(this.state, playerId, actions);

    // One action per body per round; the first submission for a body wins, so a
    // client cannot spam to re-roll or to drive a body twice.
    const seen = new Set<string>();
    const deduped: SubmittedAction[] = [];
    for (const a of clean) {
      if (seen.has(a.fighterId)) continue;
      seen.add(a.fighterId);
      deduped.push(a);
    }

    this.pending.set(playerId, deduped);
    return { accepted: deduped.length, rejected: actions.length - deduped.length };
  }

  hasSubmitted(playerId: string): boolean { return this.pending.has(playerId); }

  /** True once every fighter still standing has handed something in. */
  get readyToResolve(): boolean {
    return this.state.fighters.every((f) => f.defeated || this.pending.has(f.id));
  }

  /**
   * Resolve one round. `nowMs` is the server clock — the engine never reads a
   * clock itself, so time is advanced from out here (CLAUDE.md §4.2).
   */
  resolve(nowMs: number): MatchEvent[] {
    if (this.finished) return [];

    const actions = [...this.pending.values()].flat();
    this.actionLog.push(...actions);
    this.pending.clear();

    this.state = { ...this.state, timeMs: nowMs };
    const result = resolveTurn(this.state, actions, this.rng);
    this.state = result.state;

    if (this.state.phase === 'complete') this.finished = true;
    return result.events;
  }

  /**
   * A player who never submits forfeits the round, not the match — an idle
   * client must not be able to stall a match indefinitely.
   */
  timeOutMissing(): string[] {
    const missing: string[] = [];
    for (const f of this.state.fighters) {
      if (f.defeated || this.pending.has(f.id)) continue;
      this.pending.set(f.id, []);
      missing.push(f.id);
    }
    return missing;
  }

  forfeit(playerId: string): void {
    if (this.finished || !this.fighterIds.includes(playerId)) return;
    this.pending.set(playerId, [{ fighterId: playerId, actionId: 'forfeit', targetId: playerId, submittedBy: playerId }]);
  }

  /** Replay record: seed plus the action log. No state snapshots (CLAUDE.md §12). */
  toReplay(endedAt: number): ReplayRecord {
    return {
      matchId: this.matchId,
      seed: this.seed,
      fighterIds: this.fighterIds,
      actions: [...this.actionLog],
      winnerId: this.state.winnerId,
      outcome: this.state.outcome,
      rounds: this.state.round,
      endedAt,
    };
  }

  /**
   * Settle the match into stat gains and rating. Computed from the engine's
   * ledger — the client is never trusted for a stat delta.
   */
  async settle(store: Store, endedAt: number): Promise<void> {
    if (!this.finished) return;

    await store.saveReplay(this.toReplay(endedAt));

    const awards = settleSkillGain(this.state);
    for (const award of awards) {
      const player = await store.getPlayer(award.fighterId);
      if (!player) continue;

      for (const [stat, amount] of Object.entries(award.gains)) {
        const key = stat as keyof typeof player.stats;
        player.stats[key] = Math.min(500, Math.round((player.stats[key] + amount) * 100) / 100);
      }

      const won = this.state.winnerId === player.id;
      const other = this.fighterIds.find((id) => id !== player.id);
      const opponent = other ? await store.getPlayer(other) : null;
      player.rating = nextRating(player.rating, opponent?.rating ?? player.rating, won, this.state.outcome);
      player.xp += Math.round(award.total * 40) + (won ? 120 : 45);
      player.reputation += won ? 3 : 1;

      await store.savePlayer(player);
    }
  }
}

/** Standard Elo. Draws and timeouts score a half. */
export function nextRating(mine: number, theirs: number, won: boolean, outcome: string): number {
  const K = 24;
  const expected = 1 / (1 + 10 ** ((theirs - mine) / 400));
  const actual = outcome === 'draw' ? 0.5 : won ? 1 : 0;
  return Math.max(0, Math.round(mine + K * (actual - expected)));
}

export function specFor(p: PlayerRecord): FighterSpec {
  return {
    id: p.id,
    name: p.name,
    level: p.level,
    stats: p.stats,
    affinity: p.affinity,
    loadout: p.loadout,
    bloodlineId: p.bloodlineId,
  };
}

export const ROUND_TIMEOUT_MS = 30_000;
export const MAX_ROUNDS = TUNING.hardCapRound + 2;
