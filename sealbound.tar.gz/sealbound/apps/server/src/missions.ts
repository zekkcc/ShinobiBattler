import { MISSIONS, MISSION_BY_ID, type Mission } from '@shinobi/content';
import { makeRng } from '@shinobi/engine';
import { RANKS, type Rank, type StatKey } from '@shinobi/shared';
import type { PlayerRecord } from './store/index.js';

/**
 * Missions, reputation, and rank.
 *
 * This is the spine of the daily loop: take work, earn money and standing, and
 * let standing gate what you are offered next. Two rules keep it honest:
 *
 *   * Elapsed time comes from the stored `startedAt` against the server clock,
 *     exactly as training does. No endpoint accepts a duration.
 *   * The success roll is seeded from (playerId, missionId, startedAt), so it is
 *     fixed the moment the mission is accepted. Re-requesting the result cannot
 *     re-roll it, and neither can disconnecting and coming back.
 */

export interface MissionSession {
  missionId: string;
  startedAt: number;
}

export class MissionError extends Error {
  constructor(readonly code:
    | 'alreadyOnMission' | 'notOnMission' | 'unknownMission'
    | 'rankLocked' | 'reputationLocked' | 'notFinished' | 'needsParty') {
    super(code);
  }
}

const rankIndex = (r: Rank) => RANKS.indexOf(r);

/* ── Reputation ──────────────────────────────────────────────────────── */

export function reputationTier(reputation: number) {
  const tiers = [...MISSIONS.reputationTiers].sort((a, b) => a.atOrBelow - b.atOrBelow);
  return tiers.find((t) => reputation <= t.atOrBelow) ?? tiers[tiers.length - 1]!;
}

/** What a player actually pays. Standing is the discount; there is no cash shop. */
export function priceFor(basePrice: number, player: PlayerRecord): number {
  return Math.max(1, Math.round(basePrice * reputationTier(player.reputation).priceMultiplier));
}

/** Low standing closes the mission desk entirely. */
export function canTakeWork(player: PlayerRecord): boolean {
  return reputationTier(player.reputation).missionAccess;
}

/* ── Availability ────────────────────────────────────────────────────── */

export function availableMissions(player: PlayerRecord): Mission[] {
  if (!canTakeWork(player)) return [];
  return MISSIONS.missions.filter((m) => rankIndex(player.rank) >= rankIndex(m.requiredRank));
}

/* ── Accept ──────────────────────────────────────────────────────────── */

export function acceptMission(player: PlayerRecord, missionId: string, nowMs: number): MissionSession {
  if (player.mission) throw new MissionError('alreadyOnMission');

  const mission = MISSION_BY_ID.get(missionId);
  if (!mission) throw new MissionError('unknownMission');
  if (rankIndex(player.rank) < rankIndex(mission.requiredRank)) throw new MissionError('rankLocked');
  if (!canTakeWork(player)) throw new MissionError('reputationLocked');

  /* Party missions need a squad. Squads are not built yet, so rather than
     quietly letting one shinobi solo an S-rank, this refuses and says why. */
  if (mission.party > 1) throw new MissionError('needsParty');

  return { missionId, startedAt: nowMs };
}

/* ── Resolve ─────────────────────────────────────────────────────────── */

export interface MissionOutcome {
  mission: Mission;
  success: boolean;
  chance: number;
  ryo: number;
  xp: number;
  reputation: number;
  injured: boolean;
}

/** Odds of success: the relevant stat against the mission's difficulty. */
export function successChance(player: PlayerRecord, mission: Mission): number {
  const c = MISSIONS.successCurve;
  const stat = player.stats[mission.stat as StatKey];
  const raw = c.base + (stat - mission.difficulty) * c.perStatPoint;
  return Math.max(c.min, Math.min(c.max, raw));
}

export function resolveMission(player: PlayerRecord, nowMs: number): MissionOutcome {
  const session = player.mission;
  if (!session) throw new MissionError('notOnMission');

  const mission = MISSION_BY_ID.get(session.missionId);
  if (!mission) throw new MissionError('unknownMission');

  const elapsedMinutes = (nowMs - session.startedAt) / 60_000;
  if (elapsedMinutes < mission.minutes) throw new MissionError('notFinished');

  // Seeded from the session, so the outcome was decided when the mission began.
  const rng = makeRng(`mission:${player.id}:${mission.id}:${session.startedAt}`);
  const chance = successChance(player, mission);
  const success = rng.chance(chance);
  const f = MISSIONS.failure;

  return {
    mission,
    success,
    chance,
    ryo: success ? mission.ryo : Math.round(mission.ryo * f.ryoShare),
    xp: success ? mission.xp : Math.round(mission.xp * f.xpShare),
    reputation: success ? mission.reputation : -f.reputationLoss,
    injured: !success && rng.chance(f.injuryChance),
  };
}

export function applyMission(player: PlayerRecord, outcome: MissionOutcome): void {
  player.ryo += outcome.ryo;
  player.xp += outcome.xp;
  player.reputation += outcome.reputation;
  player.mission = null;
  if (outcome.success) {
    player.missionsAtRank += 1;
    player.missionsCompleted += 1;
  }
  syncLevel(player);
}

/* ── Level and rank ──────────────────────────────────────────────────── */

/** Total XP required to have reached a given level. */
export function xpForLevel(level: number): number {
  const { base, exponent } = MISSIONS.levelCurve;
  if (level <= 1) return 0;
  return Math.round(base * (level - 1) ** exponent);
}

export function levelForXp(xp: number): number {
  let level = 1;
  while (level < 200 && xp >= xpForLevel(level + 1)) level += 1;
  return level;
}

export function syncLevel(player: PlayerRecord): void {
  player.level = levelForXp(player.xp);
}

export interface PromotionCheck {
  eligible: boolean;
  to: Rank | null;
  note: string;
  /** what is still missing, in the player's terms */
  missing: string[];
}

/**
 * Rank is earned, never bought. The exams in the design direction are these
 * gates: standing, completed work at your current rank, ladder record, level.
 */
export function checkPromotion(player: PlayerRecord): PromotionCheck {
  if (player.rogue) {
    return {
      eligible: false, to: null,
      note: 'A missing-nin holds no rank. The village promotes its own.',
      missing: ['return to your village'],
    };
  }
  const rule = MISSIONS.promotions.find((p) => p.from === player.rank);
  if (!rule) return { eligible: false, to: null, note: 'There is no rank above this one.', missing: [] };

  const missing: string[] = [];
  if (player.level < rule.level) missing.push(`reach level ${rule.level} (you are ${player.level})`);
  if (player.reputation < rule.reputation) missing.push(`earn ${rule.reputation} reputation (you have ${player.reputation})`);
  if (player.rating < rule.rating) missing.push(`hold a ${rule.rating} ladder rating (you are at ${player.rating})`);
  if (player.missionsAtRank < rule.missionsAtRank) {
    missing.push(`complete ${rule.missionsAtRank} missions at this rank (you have ${player.missionsAtRank})`);
  }

  return { eligible: missing.length === 0, to: rule.to as Rank, note: rule.note, missing };
}

export function promote(player: PlayerRecord): Rank {
  const check = checkPromotion(player);
  if (!check.eligible || !check.to) throw new MissionError('rankLocked');
  player.rank = check.to;
  player.missionsAtRank = 0;   // the count is per rank, so the next gate is fresh work
  return player.rank;
}
