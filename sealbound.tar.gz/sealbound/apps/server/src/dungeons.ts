import { createHash, timingSafeEqual } from 'node:crypto';
import { DUNGEONS, DUNGEON_BY_ID, currentSeason, type Dungeon } from '@shinobi/content';
import { RANKS, type Rank } from '@shinobi/shared';
import type { DungeonRun, PlayerRecord, RegionRecord } from './store/index.js';
import { occupied } from './territory.js';

/**
 * Hidden dungeons.
 *
 * The whole feature rests on one property: the answers never leave the server.
 * They are not sent to the client, they are not in the client bundle, and they
 * are not in the content files either — only a salted SHA-256 of each is stored,
 * and the salts are per room so a single solved room does not weaken the rest.
 * `validate:content` fails the build if a plaintext answer ever appears.
 *
 * That is stronger than it needs to be for a puzzle, and deliberately so: this
 * is the one system where the client would otherwise be told the win condition,
 * and CLAUDE.md §5 says to assume every client is hostile.
 */

const DAY = 24 * 60 * 60 * 1000;
const rankIndex = (r: Rank) => RANKS.indexOf(r);

export class DungeonError extends Error {
  constructor(readonly code:
    | 'noSuchDungeon' | 'busy' | 'rankLocked' | 'outOfSeason' | 'needKey'
    | 'notInRun' | 'runExpired' | 'locked' | 'outOfAttempts' | 'dailyLimit'
    | 'wrongRegion' | 'onCooldown') {
    super(code);
  }
}

/**
 * Answers are compared after normalisation, so "The User", "the user" and
 * "the-user" are the same answer. A puzzle that punishes typing is not a puzzle.
 */
export function normaliseAnswer(input: string): string {
  return input.toLowerCase().replace(/[^a-z0-9]/g, '');
}

/** Timing-safe, because a comparison that returns early leaks the prefix. */
export function verifyAnswer(salt: string, expectedHash: string, given: string): boolean {
  const actual = createHash('sha256').update(`${salt}:${normaliseAnswer(given)}`).digest();
  const expected = Buffer.from(expectedHash, 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export interface DungeonAvailability { open: boolean; reason: string | null }

export function availability(
  dungeon: Dungeon,
  player: PlayerRecord,
  nowMs: number,
  keyHeld: boolean,
): DungeonAvailability {
  if (rankIndex(player.rank) < rankIndex(dungeon.minRank)) return { open: false, reason: `requires ${dungeon.minRank}` };
  const season = currentSeason(nowMs).id;
  if (dungeon.seasons.length > 0 && !dungeon.seasons.includes(season)) {
    return { open: false, reason: `only in ${dungeon.seasons.join(', ')}` };
  }
  if (dungeon.keyItem && !keyHeld) return { open: false, reason: `needs a ${dungeon.keyItem.replace(/-/g, ' ')}` };
  const until = player.dungeonCooldowns[dungeon.id] ?? 0;
  if (until > nowMs) return { open: false, reason: 'sealed again until the hour comes round' };
  if (runsLeftToday(player, nowMs) <= 0) return { open: false, reason: 'no attempts left today' };
  return { open: true, reason: null };
}

export function runsLeftToday(player: PlayerRecord, nowMs: number): number {
  const day = Math.floor(nowMs / DAY);
  if (player.dungeonRunsDay !== day) return DUNGEONS.rules.maxRunsPerDay;
  return Math.max(0, DUNGEONS.rules.maxRunsPerDay - player.dungeonRunsToday);
}

/**
 * Enter. The key is consumed on entry, not on completion — otherwise a player
 * could enter, learn the first room, walk out, and come back with the same key.
 */
export function enterDungeon(
  player: PlayerRecord,
  dungeonId: string,
  region: RegionRecord | null,
  nowMs: number,
): { run: DungeonRun; dungeon: Dungeon; consumesKey: string | null } {
  const dungeon = DUNGEON_BY_ID.get(dungeonId);
  if (!dungeon) throw new DungeonError('noSuchDungeon');
  if (occupied(player)) throw new DungeonError('busy');
  if (rankIndex(player.rank) < rankIndex(dungeon.minRank)) throw new DungeonError('rankLocked');
  if (region && region.id !== dungeon.regionId) throw new DungeonError('wrongRegion');

  const season = currentSeason(nowMs).id;
  if (dungeon.seasons.length > 0 && !dungeon.seasons.includes(season)) throw new DungeonError('outOfSeason');
  /* A per-dungeon cooldown, set on ENTRY rather than on completion.
     Without it, a player who has learned the answers can run the same three
     rooms all day and the ryo reward becomes a faucet that scales with how fast
     they can type. Setting it on entry also means walking out does not dodge it. */
  if ((player.dungeonCooldowns[dungeonId] ?? 0) > nowMs) throw new DungeonError('onCooldown');
  if (runsLeftToday(player, nowMs) <= 0) throw new DungeonError('dailyLimit');

  const day = Math.floor(nowMs / DAY);
  if (player.dungeonRunsDay !== day) { player.dungeonRunsDay = day; player.dungeonRunsToday = 0; }
  player.dungeonRunsToday += 1;
  player.dungeonCooldowns[dungeonId] = nowMs + dungeon.cooldownHours * 60 * 60 * 1000;

  const first = dungeon.rooms[0]!;
  const run: DungeonRun = {
    dungeonId,
    roomIndex: 0,
    attemptsLeft: first.attempts + Math.max(0, player.boosts.dungeonAttempts),
    startedAt: nowMs,
    lockedUntil: 0,
  };
  player.boosts.dungeonAttempts = 0;
  return { run, dungeon, consumesKey: dungeon.keyItem };
}

export type AnswerOutcome =
  | { kind: 'advanced'; roomIndex: number }
  | { kind: 'cleared' }
  | { kind: 'wrong'; attemptsLeft: number; lockedUntil: number }
  | { kind: 'failed' };

/**
 * A wrong answer costs an attempt and locks the run briefly. The lock is what
 * makes brute force expensive: without it a script can walk a short answer space
 * in a second, and the salted hash would be protecting nothing.
 */
export function answerRoom(player: PlayerRecord, given: string, nowMs: number): AnswerOutcome {
  const run = player.dungeon;
  if (!run) throw new DungeonError('notInRun');
  const dungeon = DUNGEON_BY_ID.get(run.dungeonId);
  if (!dungeon) { player.dungeon = null; throw new DungeonError('noSuchDungeon'); }

  if (nowMs - run.startedAt > DUNGEONS.rules.runExpiryMinutes * 60_000) {
    player.dungeon = null;
    throw new DungeonError('runExpired');
  }
  if (nowMs < run.lockedUntil) throw new DungeonError('locked');

  const room = dungeon.rooms[run.roomIndex];
  if (!room) { player.dungeon = null; throw new DungeonError('notInRun'); }

  if (verifyAnswer(room.salt, room.answerHash, given)) {
    const next = run.roomIndex + 1;
    if (next >= dungeon.rooms.length) {
      player.dungeon = null;
      return { kind: 'cleared' };
    }
    run.roomIndex = next;
    run.attemptsLeft = dungeon.rooms[next]!.attempts;
    run.lockedUntil = 0;
    return { kind: 'advanced', roomIndex: next };
  }

  run.attemptsLeft -= 1;
  if (run.attemptsLeft <= 0) {
    player.dungeon = null;
    return { kind: 'failed' };
  }
  run.lockedUntil = nowMs + DUNGEONS.rules.wrongAnswerCooldownMinutes * 60_000;
  return { kind: 'wrong', attemptsLeft: run.attemptsLeft, lockedUntil: run.lockedUntil };
}

/** What the client is allowed to see: this room, and nothing about the next one. */
export function roomView(run: DungeonRun): { roomId: string; index: number; total: number; prompt: string; hint: string } {
  const dungeon = DUNGEON_BY_ID.get(run.dungeonId)!;
  const room = dungeon.rooms[run.roomIndex]!;
  return {
    roomId: room.id,
    index: run.roomIndex + 1,
    total: dungeon.rooms.length,
    prompt: room.prompt,
    hint: room.hint,
  };
}
