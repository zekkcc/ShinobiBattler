import { randomUUID } from 'node:crypto';
import { CLAN_RULES } from '@shinobi/content';
import { RANKS, type Rank } from '@shinobi/shared';
import { normaliseName, nameProblem } from './auth.js';
import type { ClanRecord, PlayerRecord } from './store/index.js';

/**
 * Player clans.
 *
 * Distinct from the lore clans in content — those are bloodline families you are
 * born into. These are organisations players found and join.
 *
 * The interesting problem is the bank. A shared pot that anyone can withdraw from
 * is the most obviously lootable thing in a game like this, so it is guarded
 * three ways rather than one: officer rank, a tenure gate so a stranger cannot
 * join and immediately empty it, and a per-day cap so an officer who turns can
 * only take a slice before anyone notices.
 */

export type ClanRole = 'member' | 'officer' | 'leader';

export class ClanError extends Error {
  constructor(readonly code:
    | 'alreadyInClan' | 'notInClan' | 'noSuchClan' | 'nameTaken' | 'badName'
    | 'rankTooLow' | 'reputationTooLow' | 'cannotAfford' | 'clanFull'
    | 'notLeader' | 'notOfficer' | 'notInvited' | 'noSuchMember'
    | 'tooManyOfficers' | 'leaderCannotLeave' | 'cannotKickLeader'
    | 'tooNew' | 'dailyLimit' | 'insufficientFunds' | 'rogue') {
    super(code);
  }
}

const rankIndex = (r: Rank) => RANKS.indexOf(r);

export function roleOf(clan: ClanRecord, playerId: string): ClanRole | null {
  if (clan.leaderId === playerId) return 'leader';
  if (clan.officerIds.includes(playerId)) return 'officer';
  if (clan.memberIds.includes(playerId)) return 'member';
  return null;
}

/* ── Founding ────────────────────────────────────────────────────────── */

export function foundClan(founder: PlayerRecord, name: string, nowMs: number): ClanRecord {
  if (founder.clanId) throw new ClanError('alreadyInClan');
  if (founder.rogue) throw new ClanError('rogue');

  const f = CLAN_RULES.founding;
  if (rankIndex(founder.rank) < rankIndex(f.minRank)) throw new ClanError('rankTooLow');
  if (founder.reputation < f.minReputation) throw new ClanError('reputationTooLow');
  if (founder.ryo < f.ryoCost) throw new ClanError('cannotAfford');
  if (nameProblem(name.trim())) throw new ClanError('badName');

  founder.ryo -= f.ryoCost;
  return {
    id: randomUUID(),
    name: name.trim(),
    nameKey: normaliseName(name),
    leaderId: founder.id,
    memberIds: [founder.id],
    officerIds: [],
    invitedIds: [],
    bank: 0,
    foundedAt: nowMs,
    withdrawnToday: 0,
    withdrawWindowStart: nowMs,
  };
}

/* ── Membership ──────────────────────────────────────────────────────── */

export function inviteToClan(clan: ClanRecord, actor: PlayerRecord, target: PlayerRecord): void {
  const role = roleOf(clan, actor.id);
  if (role !== 'leader' && role !== 'officer') throw new ClanError('notOfficer');
  if (target.clanId) throw new ClanError('alreadyInClan');
  if (target.rogue) throw new ClanError('rogue');
  if (clan.memberIds.length + clan.invitedIds.length >= CLAN_RULES.size.max) throw new ClanError('clanFull');
  if (!clan.invitedIds.includes(target.id)) clan.invitedIds.push(target.id);
}

/** Joining is opt-in, exactly as with squads. */
export function acceptClanInvite(clan: ClanRecord, player: PlayerRecord, nowMs: number): void {
  if (!clan.invitedIds.includes(player.id)) throw new ClanError('notInvited');
  if (player.clanId) throw new ClanError('alreadyInClan');
  if (clan.memberIds.length >= CLAN_RULES.size.max) throw new ClanError('clanFull');
  clan.invitedIds = clan.invitedIds.filter((id) => id !== player.id);
  clan.memberIds.push(player.id);
  player.clanId = clan.id;
  player.clanJoinedAt = nowMs;
  player.clanContribution = 0;
}

/**
 * A leader cannot simply walk out and leave the clan ownerless — they hand over
 * first, or dissolve it deliberately.
 */
export function leaveClan(clan: ClanRecord, player: PlayerRecord): void {
  if (roleOf(clan, player.id) === null) throw new ClanError('notInClan');
  if (clan.leaderId === player.id && clan.memberIds.length > 1) throw new ClanError('leaderCannotLeave');
  clan.memberIds = clan.memberIds.filter((id) => id !== player.id);
  clan.officerIds = clan.officerIds.filter((id) => id !== player.id);
  player.clanId = null;
  player.clanJoinedAt = null;
  player.clanContribution = 0;
}

export function kickFromClan(clan: ClanRecord, actor: PlayerRecord, target: PlayerRecord): void {
  const actorRole = roleOf(clan, actor.id);
  const targetRole = roleOf(clan, target.id);
  if (targetRole === null) throw new ClanError('noSuchMember');
  if (targetRole === 'leader') throw new ClanError('cannotKickLeader');
  // An officer may remove members; only the leader may remove an officer.
  if (actorRole === 'officer' && targetRole === 'officer') throw new ClanError('notLeader');
  if (actorRole !== 'leader' && actorRole !== 'officer') throw new ClanError('notOfficer');

  clan.memberIds = clan.memberIds.filter((id) => id !== target.id);
  clan.officerIds = clan.officerIds.filter((id) => id !== target.id);
  target.clanId = null;
  target.clanJoinedAt = null;
  target.clanContribution = 0;
}

export function setOfficer(clan: ClanRecord, actor: PlayerRecord, targetId: string, promote: boolean): void {
  if (clan.leaderId !== actor.id) throw new ClanError('notLeader');
  if (!clan.memberIds.includes(targetId)) throw new ClanError('noSuchMember');
  if (promote) {
    if (clan.officerIds.length >= CLAN_RULES.size.officersMax) throw new ClanError('tooManyOfficers');
    if (!clan.officerIds.includes(targetId)) clan.officerIds.push(targetId);
  } else {
    clan.officerIds = clan.officerIds.filter((id) => id !== targetId);
  }
}

export function handOverLeadership(clan: ClanRecord, actor: PlayerRecord, targetId: string): void {
  if (clan.leaderId !== actor.id) throw new ClanError('notLeader');
  if (!clan.memberIds.includes(targetId)) throw new ClanError('noSuchMember');
  clan.officerIds = clan.officerIds.filter((id) => id !== targetId);
  if (!clan.officerIds.includes(actor.id)) clan.officerIds.push(actor.id);
  clan.leaderId = targetId;
}

/* ── The bank ────────────────────────────────────────────────────────── */

export function deposit(clan: ClanRecord, player: PlayerRecord, amount: number): void {
  if (roleOf(clan, player.id) === null) throw new ClanError('notInClan');
  if (amount <= 0 || player.ryo < amount) throw new ClanError('insufficientFunds');
  player.ryo -= amount;
  clan.bank += amount;
  player.clanContribution += Math.round(amount * CLAN_RULES.contribution.perRyoDeposited);
}

/**
 * Withdrawal is the loot-bearing operation, so it is gated three separate ways:
 * rank, tenure, and a rolling daily cap on a fraction of the treasury.
 */
export function withdraw(clan: ClanRecord, player: PlayerRecord, amount: number, nowMs: number): number {
  const role = roleOf(clan, player.id);
  if (role === null) throw new ClanError('notInClan');
  if (CLAN_RULES.bank.withdrawRequiresOfficer && role === 'member') throw new ClanError('notOfficer');

  const tenure = (nowMs - (player.clanJoinedAt ?? nowMs)) / 60_000;
  if (tenure < CLAN_RULES.bank.memberTenureMinutesToWithdraw) throw new ClanError('tooNew');

  if (amount <= 0 || amount > clan.bank) throw new ClanError('insufficientFunds');

  // Roll the window forward before checking, so the cap is per day, not per lifetime.
  if (nowMs - clan.withdrawWindowStart >= 24 * 60 * 60_000) {
    clan.withdrawWindowStart = nowMs;
    clan.withdrawnToday = 0;
  }
  /* The cap is a fraction of the treasury as it stood at the START of the
     window — `bank + withdrawnToday` reconstructs that. Taking the fraction of
     the current balance instead would raise the remaining allowance with every
     withdrawal, so an officer could still drain the whole thing in a day, just
     in slices. */
  const treasuryAtWindowStart = clan.bank + clan.withdrawnToday;
  const dailyCap = Math.floor(treasuryAtWindowStart * CLAN_RULES.bank.withdrawFractionPerDay);
  if (clan.withdrawnToday + amount > dailyCap) throw new ClanError('dailyLimit');

  clan.bank -= amount;
  clan.withdrawnToday += amount;
  player.ryo += amount;
  return amount;
}

/* ── Standing ────────────────────────────────────────────────────────── */

export function creditContribution(player: PlayerRecord, kind: 'mission' | 'pvpWin'): void {
  if (!player.clanId) return;
  const c = CLAN_RULES.contribution;
  player.clanContribution += kind === 'mission' ? c.perMissionCompleted : c.perPvpWin;
}

export interface ClanStanding { clanId: string; name: string; members: number; contribution: number; bank: number }

/**
 * Ranked on what the members have actually done, not on the size of the
 * treasury — otherwise one rich founder outranks an active clan.
 */
export function rankClans(clans: ClanRecord[], contributionByClan: Map<string, number>): ClanStanding[] {
  return clans
    .map((c) => ({
      clanId: c.id,
      name: c.name,
      members: c.memberIds.length,
      contribution: contributionByClan.get(c.id) ?? 0,
      bank: c.bank,
    }))
    .sort((a, b) => b.contribution - a.contribution || b.members - a.members);
}
