import { randomUUID } from 'node:crypto';
import { MENTORSHIP } from '@shinobi/content';
import { RANKS, type Rank } from '@shinobi/shared';
import type { MentorshipRecord, PlayerRecord, Store } from './store/index.js';

/**
 * The mentor system.
 *
 * "Veterans mentor beginners, rewards both" is one line in the design direction
 * and about six exploits in practice, because the obvious implementation pays a
 * veteran for the existence of a beginner — and a veteran can make beginners.
 *
 * The defence is that the mentor is never paid in anything a second account
 * would want. Reputation and clan contribution are not transferable, cannot be
 * sold, and are capped per mentee per week. A farmed reward that cannot be moved
 * to the account that wanted it is not worth farming, and that holds without the
 * server having to work out which two accounts belong to the same person.
 *
 * The rest is arithmetic that makes the loop slow as well as pointless: a
 * student may be mentored once ever, a pairing pays nothing for its first two
 * days, and there is a cooldown between pairings.
 */

const rankIndex = (r: Rank) => RANKS.indexOf(r);
const WEEK = 7 * 24 * 60 * 60 * 1000;

export class MentorshipError extends Error {
  constructor(readonly code:
    | 'noSuchPlayer' | 'self' | 'rogue' | 'rankTooLow' | 'reputationTooLow'
    | 'menteeTooSenior' | 'alreadyMentored' | 'alreadyPaired' | 'tooManyMentees'
    | 'differentVillage' | 'levelGapTooSmall' | 'cooldown' | 'noSuchOffer'
    | 'notYours' | 'notPaired') {
    super(code);
  }
}

export function activeOf(records: MentorshipRecord[], playerId: string): MentorshipRecord | undefined {
  return records.find((m) => m.status === 'active' && (m.mentorId === playerId || m.menteeId === playerId));
}

/**
 * An offer, not a pairing. Nobody is enrolled without accepting, exactly as with
 * squads and clans — a mentor who could attach themselves to a stranger would be
 * able to farm that stranger's progress without them ever agreeing to it.
 */
export async function offerMentorship(
  store: Store,
  mentor: PlayerRecord,
  mentee: PlayerRecord,
  nowMs: number,
): Promise<MentorshipRecord> {
  const m = MENTORSHIP;
  if (mentor.id === mentee.id) throw new MentorshipError('self');
  if (m.pairing.roguesExcluded && (mentor.rogue || mentee.rogue)) throw new MentorshipError('rogue');
  if (rankIndex(mentor.rank) < rankIndex(m.mentor.minRank)) throw new MentorshipError('rankTooLow');
  if (mentor.reputation < m.mentor.minReputation) throw new MentorshipError('reputationTooLow');
  if (rankIndex(mentee.rank) > rankIndex(m.mentee.maxRank)) throw new MentorshipError('menteeTooSenior');
  if (m.mentee.mentoredOnce && mentee.mentoredBefore) throw new MentorshipError('alreadyMentored');
  if (m.pairing.sameVillageRequired && mentor.villageId !== mentee.villageId) throw new MentorshipError('differentVillage');
  if (mentor.level - mentee.level < m.pairing.levelGapMin) throw new MentorshipError('levelGapTooSmall');

  if (mentor.lastMentorshipEndedAt !== null
    && nowMs - mentor.lastMentorshipEndedAt < m.pairing.cooldownMinutesBetweenPairings * 60_000) {
    throw new MentorshipError('cooldown');
  }

  const mine = await store.listMentorshipsFor(mentor.id);
  const live = mine.filter((x) => x.mentorId === mentor.id && x.status === 'active');
  if (live.length >= m.mentor.maxConcurrentMentees) throw new MentorshipError('tooManyMentees');

  const theirs = await store.listMentorshipsFor(mentee.id);
  if (theirs.some((x) => x.status === 'active')) throw new MentorshipError('alreadyPaired');

  const record: MentorshipRecord = {
    id: randomUUID(),
    mentorId: mentor.id,
    menteeId: mentee.id,
    status: 'offered',
    startedAt: nowMs,
    endedAt: null,
    rewarded: [],
    rewardTimes: [],
  };
  await store.createMentorship(record);
  return record;
}

export async function acceptMentorship(
  store: Store,
  record: MentorshipRecord,
  mentee: PlayerRecord,
  nowMs: number,
): Promise<void> {
  if (record.menteeId !== mentee.id) throw new MentorshipError('notYours');
  if (record.status !== 'offered') throw new MentorshipError('noSuchOffer');
  if (MENTORSHIP.mentee.mentoredOnce && mentee.mentoredBefore) throw new MentorshipError('alreadyMentored');

  record.status = 'active';
  record.startedAt = nowMs;
  // The store carries a partial unique index on an active mentee, so a student
  // accepting two offers in the same instant loses the second at the database.
  await store.saveMentorship(record);
  mentee.mentoredBefore = true;
}

export async function endMentorship(
  store: Store,
  record: MentorshipRecord,
  nowMs: number,
  mentor: PlayerRecord | null,
): Promise<void> {
  record.status = 'ended';
  record.endedAt = nowMs;
  await store.saveMentorship(record);
  if (mentor) mentor.lastMentorshipEndedAt = nowMs;
}

/* ── Milestones ───────────────────────────────────────────────────────── */

export interface MilestonePayout {
  milestoneId: string;
  reputation: number;
  clanContribution: number;
}

function reached(mentee: PlayerRecord, milestoneId: string, startRank: Rank): boolean {
  const def = MENTORSHIP.milestones.find((x) => x.id === milestoneId);
  if (!def) return false;
  if (def.criterion === 'rank') return rankIndex(mentee.rank) > rankIndex(startRank);
  const value = def.criterion === 'missionsCompleted' ? mentee.missionsCompleted : mentee.pvpWins;
  return value >= (def.threshold ?? Number.POSITIVE_INFINITY);
}

/**
 * Pay a mentor for what their student has actually done.
 *
 * Three gates, each closing a different loop: the pairing must have matured, a
 * milestone pays once ever, and there is a weekly ceiling per mentee. Payment is
 * applied to the mentor record by the caller, which keeps this function free of
 * store writes and therefore trivially testable.
 */
export function duePayouts(
  record: MentorshipRecord,
  mentee: PlayerRecord,
  startRank: Rank,
  nowMs: number,
): MilestonePayout[] {
  if (record.status !== 'active') return [];
  if (nowMs - record.startedAt < MENTORSHIP.pairing.minDurationMinutesBeforeRewards * 60_000) return [];

  const paidThisWeek = record.rewardTimes.filter((t) => nowMs - t < WEEK).length;
  let room = MENTORSHIP.mentor.maxRewardedMilestonesPerMenteePerWeek - paidThisWeek;
  if (room <= 0) return [];

  const out: MilestonePayout[] = [];
  for (const def of MENTORSHIP.milestones) {
    if (room <= 0) break;
    if (record.rewarded.includes(def.id)) continue;
    if (!reached(mentee, def.id, startRank)) continue;
    out.push({
      milestoneId: def.id,
      reputation: MENTORSHIP.mentor.rewardPerMilestone.reputation,
      clanContribution: MENTORSHIP.mentor.rewardPerMilestone.clanContribution,
    });
    room--;
  }
  return out;
}

export function recordPayouts(record: MentorshipRecord, payouts: MilestonePayout[], nowMs: number): void {
  for (const p of payouts) {
    record.rewarded.push(p.milestoneId);
    record.rewardTimes.push(nowMs);
  }
  // Keep the ledger from growing without bound; anything older than a week can
  // no longer affect the cap.
  record.rewardTimes = record.rewardTimes.filter((t) => nowMs - t < WEEK);
}

/** The training bonus a student is currently getting, if any. */
export function menteeTrainingBonus(record: MentorshipRecord | undefined, menteeId: string, lawBonus: number): number {
  if (!record || record.status !== 'active' || record.menteeId !== menteeId) return 0;
  return MENTORSHIP.mentee.trainingBonus + Math.max(0, lawBonus);
}
