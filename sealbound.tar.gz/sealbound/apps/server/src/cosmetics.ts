import { COSMETICS, COSMETIC_BY_ID, currentSeason } from '@shinobi/content';
import type { PlayerRecord } from './store/index.js';

/**
 * Cosmetics.
 *
 * These are allowed to be the only thing money buys, precisely because they do
 * nothing. There is no stat field in the catalogue, no code path from a cosmetic
 * to a match, and `validate:content` fails the build if one appears.
 *
 * They are also untradable. A cosmetic that could be sold is currency wearing a
 * hat, and currency eventually buys power — which is the exact thing the design
 * direction forbids. That is why a rare drop from a dungeon stays with whoever
 * earned it.
 *
 * Titles are handled elsewhere (legacy.ts) and remain earned-only. A cosmetic
 * may be GATED on a title, which is a different thing: it cannot be bought
 * without the title, and the title cannot be bought at all.
 */

export class CosmeticError extends Error {
  constructor(readonly code:
    | 'unknownCosmetic' | 'alreadyOwned' | 'notOwned' | 'notPurchasable'
    | 'outOfSeason' | 'titleNotEarned' | 'cannotAfford') {
    super(code);
  }
}

/** Defaults are owned by everybody without appearing in anyone's list. */
export function owns(player: PlayerRecord, cosmeticId: string): boolean {
  const def = COSMETIC_BY_ID.get(cosmeticId);
  if (!def) return false;
  return def.source === 'default' || player.cosmetics.includes(cosmeticId);
}

export interface Availability { available: boolean; reason: string | null; price: number | null }

export function availability(player: PlayerRecord, cosmeticId: string, nowMs: number): Availability {
  const def = COSMETIC_BY_ID.get(cosmeticId);
  if (!def) return { available: false, reason: 'unknown', price: null };
  if (owns(player, cosmeticId)) return { available: false, reason: 'owned', price: def.price ?? null };

  switch (def.source) {
    case 'purchase':
      return { available: true, reason: null, price: def.price ?? null };
    case 'season': {
      const inSeason = def.season === currentSeason(nowMs).id;
      return { available: inSeason, reason: inSeason ? null : `sold only in ${def.season}`, price: def.price ?? null };
    }
    case 'title': {
      const earned = def.title !== undefined && player.titles.includes(def.title);
      return { available: earned, reason: earned ? null : 'requires a title you have not earned', price: null };
    }
    case 'craft':
      return { available: false, reason: 'comes off a workbench', price: null };
    case 'dungeon':
      return { available: false, reason: 'found, not sold', price: null };
    case 'mentor':
      return { available: false, reason: 'given by a student', price: null };
    default:
      return { available: false, reason: null, price: null };
  }
}

/**
 * Buying. Only `purchase` and `season` sources have a price at all; everything
 * else has to be earned somewhere, and a title-gated cosmetic is granted rather
 * than sold so that no amount of money shortens the route to it.
 */
export function buy(player: PlayerRecord, cosmeticId: string, nowMs: number): number {
  const def = COSMETIC_BY_ID.get(cosmeticId);
  if (!def) throw new CosmeticError('unknownCosmetic');
  if (owns(player, cosmeticId)) throw new CosmeticError('alreadyOwned');

  if (def.source === 'title') {
    if (!def.title || !player.titles.includes(def.title)) throw new CosmeticError('titleNotEarned');
    player.cosmetics.push(cosmeticId);
    return 0;
  }
  if (def.source === 'season') {
    if (def.season !== currentSeason(nowMs).id) throw new CosmeticError('outOfSeason');
  } else if (def.source !== 'purchase') {
    throw new CosmeticError('notPurchasable');
  }

  const price = def.price ?? 0;
  if (price <= 0) throw new CosmeticError('notPurchasable');
  if (player.ryo < price) throw new CosmeticError('cannotAfford');

  player.ryo -= price;
  player.cosmetics.push(cosmeticId);
  return price;
}

/** Granting, for the sources that are earned: a dungeon, a workbench, a student. */
export function grant(player: PlayerRecord, cosmeticId: string): boolean {
  if (!COSMETIC_BY_ID.has(cosmeticId)) return false;
  if (player.cosmetics.includes(cosmeticId)) return false;
  player.cosmetics.push(cosmeticId);
  return true;
}

export function equip(player: PlayerRecord, cosmeticId: string): string {
  const def = COSMETIC_BY_ID.get(cosmeticId);
  if (!def) throw new CosmeticError('unknownCosmetic');
  if (!owns(player, cosmeticId)) throw new CosmeticError('notOwned');
  player.equipped[def.slot] = cosmeticId;
  return def.slot;
}

/** What a fresh character is wearing: one default per slot, chosen by content order. */
export function defaultLoadout(): Record<string, string> {
  const out: Record<string, string> = {};
  for (const c of COSMETICS.items) {
    if (c.source === 'default' && !(c.slot in out)) out[c.slot] = c.id;
  }
  return out;
}
