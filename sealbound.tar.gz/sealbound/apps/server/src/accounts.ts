import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { VILLAGES, rollBloodline } from '@shinobi/content';
import { makeRng } from '@shinobi/engine';
import {
  hashPassword, hashToken, issueSession, nameProblem, normaliseName,
  passwordProblem, verifyPassword,
} from './auth.js';
import type { SessionResolver } from './app.js';
import type { PlayerRecord, Store } from './store/index.js';

/**
 * Accounts.
 *
 * Registration creates the credential and the shinobi together: one account is
 * one character, which is what makes reputation and rank mean anything.
 *
 * Login is deliberately uniform. A wrong name and a wrong password produce the
 * same message and do the same amount of work, so the endpoint cannot be used to
 * enumerate who plays here.
 */

export const ZRegister = z.object({
  name: z.string().min(1).max(64),
  password: z.string().min(1).max(200),
  villageId: z.string().regex(/^[a-z0-9-]+$/).max(32),
});

export const ZLogin = z.object({
  name: z.string().min(1).max(64),
  password: z.string().min(1).max(200),
});

export type AuthResult =
  | { ok: true; token: string; playerId: string; expiresAt: number }
  | { ok: false; code: string; detail: string };

const GENERIC_LOGIN_FAILURE = 'That name and password do not match.';

/** A throwaway digest to verify against when no account exists, so timing matches. */
let decoyDigest: string | null = null;
async function decoy(): Promise<string> {
  decoyDigest ??= await hashPassword(randomUUID());
  return decoyDigest;
}

export class Accounts {
  constructor(private readonly store: Store, private readonly now: () => number = Date.now) {}

  async register(input: z.infer<typeof ZRegister>): Promise<AuthResult> {
    const nameIssue = nameProblem(input.name.trim());
    if (nameIssue) return { ok: false, code: 'badName', detail: nameIssue };

    const passwordIssue = passwordProblem(input.password);
    if (passwordIssue) return { ok: false, code: 'weakPassword', detail: passwordIssue };

    const village = VILLAGES.find((v) => v.id === input.villageId);
    if (!village) return { ok: false, code: 'unknownVillage', detail: 'Pick a village from the list.' };

    const nameKey = normaliseName(input.name);
    if (await this.store.getAccountByNameKey(nameKey)) {
      return { ok: false, code: 'nameTaken', detail: 'Somebody already goes by that name.' };
    }

    const id = randomUUID();
    await this.store.createAccount({ id, nameKey, password: await hashPassword(input.password) });
    await this.store.createPlayer(newPlayer(id, input.name.trim(), village.id, id));

    return this.startSession(id);
  }

  async login(input: z.infer<typeof ZLogin>): Promise<AuthResult> {
    const account = await this.store.getAccountByNameKey(normaliseName(input.name));

    /* Verify against a decoy when the account is missing. Skipping the hash on a
       bad name would make "no such player" measurably faster than "wrong
       password", which is a free user-enumeration oracle. */
    const digest = account?.password ?? (await decoy());
    const matches = await verifyPassword(input.password, digest);

    if (!account || !matches) {
      return { ok: false, code: 'badCredentials', detail: GENERIC_LOGIN_FAILURE };
    }
    return this.startSession(account.id);
  }

  private async startSession(accountId: string): Promise<AuthResult> {
    const session = issueSession(this.now());
    await this.store.createSession({
      tokenHash: session.tokenHash,
      accountId,
      expiresAt: session.expiresAt,
    });
    return { ok: true, token: session.token, playerId: accountId, expiresAt: session.expiresAt };
  }

  async logout(token: string): Promise<void> {
    await this.store.deleteSession(hashToken(token));
  }

  /** Housekeeping; safe to call on a timer. */
  async sweepSessions(): Promise<number> {
    return this.store.deleteExpiredSessions(this.now());
  }
}

/**
 * Resolves a connection's token to a player id. An expired session is deleted on
 * sight rather than merely rejected, so a stale token cannot linger.
 */
export class StoreSessionResolver implements SessionResolver {
  constructor(private readonly store: Store, private readonly now: () => number = Date.now) {}

  async resolve(token: string | undefined): Promise<string | null> {
    if (!token) return null;
    const session = await this.store.getSession(hashToken(token));
    if (!session) return null;
    if (session.expiresAt <= this.now()) {
      await this.store.deleteSession(session.tokenHash);
      return null;
    }
    return session.accountId;
  }
}

/** Character creation. The bloodline roll happens here, server-side, exactly once. */
export function newPlayer(id: string, name: string, villageId: string, seed: string): PlayerRecord {
  const rng = makeRng(`create:${seed}`);
  const village = VILLAGES.find((v) => v.id === villageId) ?? VILLAGES[0]!;
  return {
    id,
    name,
    villageId: village.id,
    clanId: null,
    clanJoinedAt: null,
    clanContribution: 0,
    bloodlineId: rollBloodline(rng.next(), rng.next()),
    rank: 'academy',
    level: 1,
    xp: 0,
    stats: {
      ninjutsu: 10, taijutsu: 10, genjutsu: 10, intelligence: 10,
      strength: 10, speed: 10, stamina: 10, handSeals: 10,
    },
    affinity: village.affinityBias,
    loadout: [],
    known: [],
    reputation: 0,
    ryo: 250,
    training: null,
    mission: null,
    missionsAtRank: 0,
    missionsCompleted: 0,
    squadId: null,
    rogue: false,
    defectedAt: null,
    notoriety: 0,
    titles: [],
    displayedTitle: null,
    pvpWins: 0,
    bountiesClaimed: 0,
    sRankCompleted: 0,
    rating: 1000,
  };
}
