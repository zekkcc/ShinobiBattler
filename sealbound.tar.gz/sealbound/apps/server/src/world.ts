import { POLITICS, SEASONS, TERRITORY, TRAINING, currentSeason } from '@shinobi/content';
import type { Store, VillageRecord } from './store/index.js';

/**
 * The world clock.
 *
 * Season, weather, the election cycle and the territory war period are all pure
 * functions of the server clock. None of them is stored, which means there is no
 * state to desynchronise, nothing a reconnect can reroll, and no row anybody can
 * race. It also means every one of them is trivially testable at an arbitrary
 * instant, which is why they live here rather than inside the handlers.
 *
 * Nothing in this file reads the wall clock itself — `nowMs` is always passed in,
 * the same discipline the engine follows for `MatchState.timeMs`.
 */

const HOUR = 60 * 60 * 1000;
const DAY = 24 * HOUR;

export { currentSeason };

/**
 * Weather rotates hourly, drawn from the current season's own table. Winter has
 * snow in it and summer does not, which is the point — but the rotation is still
 * global and still clock-derived, so two players in the same village always see
 * the same sky.
 */
export function currentWeather(nowMs: number): string {
  const season = currentSeason(nowMs);
  const slot = Math.floor(nowMs / HOUR);
  const id = season.weather[slot % season.weather.length]!;
  // Defensive: a season table that drifted from training.json would otherwise
  // hand a nonexistent weather id to the training calculation.
  return TRAINING.weather.some((w) => w.id === id) ? id : TRAINING.weather[0]!.id;
}

/** Training bonus contributed by the season, on top of the weather's own. */
export function seasonStatBonus(nowMs: number, stat: string): number {
  const season = currentSeason(nowMs);
  return (season.statBonus as Record<string, number | undefined>)[stat] ?? 0;
}

/* ── Election cycle ───────────────────────────────────────────────────── */

export type ElectionPhase = 'nomination' | 'voting' | 'governing';

export function cycleIndex(nowMs: number): number {
  return Math.floor(nowMs / (POLITICS.cycleDays * DAY));
}

export function cycleStart(cycle: number): number {
  return cycle * POLITICS.cycleDays * DAY;
}

/**
 * A cycle runs nomination -> voting -> governing. The result of cycle N seats
 * the office for cycle N+1, so there is never a moment with no government and
 * never a way to hold voting open until a friendly result arrives.
 */
export function electionPhase(nowMs: number): { cycle: number; phase: ElectionPhase; phaseEndsAtMs: number } {
  const cycle = cycleIndex(nowMs);
  const intoCycle = nowMs - cycleStart(cycle);
  const nominationEnds = POLITICS.nominationDays * DAY;
  const votingEnds = nominationEnds + POLITICS.votingDays * DAY;
  if (intoCycle < nominationEnds) return { cycle, phase: 'nomination', phaseEndsAtMs: cycleStart(cycle) + nominationEnds };
  if (intoCycle < votingEnds) return { cycle, phase: 'voting', phaseEndsAtMs: cycleStart(cycle) + votingEnds };
  return { cycle, phase: 'governing', phaseEndsAtMs: cycleStart(cycle + 1) };
}

/* ── War period ───────────────────────────────────────────────────────── */

export function warPeriod(nowMs: number): { index: number; startsAtMs: number; endsAtMs: number; declareWindowOpen: boolean } {
  const length = TERRITORY.war.periodDays * DAY;
  const index = Math.floor(nowMs / length);
  const startsAtMs = index * length;
  return {
    index,
    startsAtMs,
    endsAtMs: startsAtMs + length,
    declareWindowOpen: nowMs - startsAtMs < TERRITORY.war.declareWindowDays * DAY,
  };
}

/* ── Village state ────────────────────────────────────────────────────── */

export function defaultVillage(id: string): VillageRecord {
  return {
    id,
    taxRate: POLITICS.tax.default,
    treasury: 0,
    laws: [],
    commissions: [],
    atWarWith: [],
    taxSetInCycle: -1,
  };
}

/** Villages are created lazily, so a fresh database needs no seeding step. */
export async function loadVillage(store: Store, id: string): Promise<VillageRecord> {
  const existing = await store.getVillage(id);
  if (existing) return existing;
  const fresh = defaultVillage(id);
  await store.saveVillage(fresh);
  return fresh;
}

export interface VillageEffects {
  taxRate: number;
  trainingBonus: number;
  gatherBonus: number;
  defenceScoreBonus: number;
  warScoreBonus: number;
  missionInjuryReduction: number;
  menteeBonus: number;
  outsiderPenaltyWaived: boolean;
  outsiderTollFraction: number;
}

/**
 * Everything a village's politics currently do, collapsed into one value.
 *
 * Expired commissions are simply not counted rather than being swept by a job:
 * an effect that has to be cleaned up is an effect that survives a missed sweep,
 * and a village would quietly keep a bonus it stopped paying for.
 */
export function villageEffects(village: VillageRecord, nowMs: number): VillageEffects {
  const out: VillageEffects = {
    taxRate: village.taxRate,
    trainingBonus: 0,
    gatherBonus: 0,
    defenceScoreBonus: 0,
    warScoreBonus: 0,
    missionInjuryReduction: 0,
    menteeBonus: 0,
    outsiderPenaltyWaived: false,
    outsiderTollFraction: TERRITORY.yield.outsiderTollFraction,
  };

  for (const active of village.commissions) {
    if (active.endsAt <= nowMs) continue;
    const def = POLITICS.treasury.commissions.find((c) => c.id === active.id);
    if (!def) continue;
    out.trainingBonus += def.effect.trainingBonusVillage ?? 0;
    out.gatherBonus += def.effect.gatherBonusVillage ?? 0;
    out.defenceScoreBonus += def.effect.defenceScoreBonus ?? 0;
    out.missionInjuryReduction += def.effect.missionInjuryReduction ?? 0;
  }

  for (const lawId of village.laws) {
    const law = POLITICS.laws.find((l) => l.id === lawId);
    if (!law) continue;
    if (law.effect.outsiderPenaltyWaived) out.outsiderPenaltyWaived = true;
    if (law.effect.warScoreBonus) out.warScoreBonus += law.effect.warScoreBonus;
    if (law.effect.outsiderTollFraction !== undefined) out.outsiderTollFraction = law.effect.outsiderTollFraction;
    if (law.effect.menteeBonus) out.menteeBonus += law.effect.menteeBonus;
  }

  return out;
}

/** Live commissions only — the expired ones are history, not state to clear. */
export function activeCommissions(village: VillageRecord, nowMs: number): { id: string; endsAt: number }[] {
  return village.commissions.filter((c) => c.endsAt > nowMs);
}

export const SEASON_IDS = SEASONS.seasons.map((s) => s.id);
