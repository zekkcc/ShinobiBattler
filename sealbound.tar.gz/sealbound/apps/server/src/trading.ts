import { randomUUID } from 'node:crypto';
import { ECONOMY, ITEM_BY_ID } from '@shinobi/content';
import { RANKS, type Rank } from '@shinobi/shared';
import type { PlayerRecord, Store, TradeRecord, TradeSide, TransferRecord } from './store/index.js';
import { give, held, take } from './economy.js';

/**
 * Direct trade and gifting.
 *
 * Owner decision, 2026-08-04: players may transfer goods and money to each
 * other directly. This deliberately reverses the earlier design, in which every
 * transfer went through a taxed market so that a wash trade between two accounts
 * destroyed value. That property is gone and cannot be recovered while free
 * transfer exists — two accounts can now move currency between them at no cost.
 *
 * What is still defensible has been kept, and it is worth being explicit about
 * what each thing does and does not buy:
 *
 *   * ATOMICITY. A trade either happens completely or not at all. Both sides are
 *     validated, the proposal row is deleted (which is what settles a race
 *     between two acceptances), and only then does anything move. This is a
 *     correctness property, not an anti-abuse one — but a duplication bug in a
 *     trade window is worth more to an attacker than every exploit in this
 *     repository combined.
 *   * THE `tradable` FLAG IS STILL HONOURED. A mentor's charm and anything else
 *     marked untradable still cannot move, so the rewards designed to be
 *     unfarmable stay unfarmable. Gifting is a transfer, and the flag governs
 *     transfers.
 *   * ATTRIBUTION REPLACES PREVENTION. Every completed transfer is written to an
 *     append-only log with both ends and the exact contents. A ring of accounts
 *     feeding one beneficiary is now a visible pattern rather than an impossible
 *     one. This is the honest trade-off: once free transfer is a design goal, the
 *     remaining defence is being able to see it.
 *
 * The market keeps its fee and its tax. It is now the slower, more expensive way
 * to move goods, which is fine — it exists for trading with strangers, and its
 * price signal is what the reference band is built on.
 */

const rankIndex = (r: Rank) => RANKS.indexOf(r);
const HOUR = 60 * 60 * 1000;

export class TradeError extends Error {
  constructor(readonly code:
    | 'noSuchPlayer' | 'self' | 'rogue' | 'rankLocked' | 'unknownItem' | 'untradable'
    | 'badQuantity' | 'nothingOffered' | 'cannotAfford' | 'missingInputs' | 'stackFull'
    | 'noSuchTrade' | 'notYours' | 'expired' | 'tooManyOpen' | 'inMatch' | 'busy') {
    super(code);
  }
}

export const MAX_OPEN_TRADES = 8;
export const TRADE_EXPIRY_HOURS = 24;

/** Nobody may transfer at all until they have played enough to be worth impersonating. */
function assertMayTransfer(player: PlayerRecord): void {
  if (player.rogue) throw new TradeError('rogue');
  if (rankIndex(player.rank) < rankIndex(ECONOMY.market.minRankToTrade)) throw new TradeError('rankLocked');
}

/** Validates a side's contents in isolation — shape, existence, and the tradable flag. */
export function validateSide(side: TradeSide): void {
  if (side.ryo < 0 || !Number.isInteger(side.ryo)) throw new TradeError('badQuantity');
  const seen = new Set<string>();
  for (const entry of side.items) {
    if (!Number.isInteger(entry.qty) || entry.qty <= 0) throw new TradeError('badQuantity');
    const item = ITEM_BY_ID.get(entry.itemId);
    if (!item) throw new TradeError('unknownItem');
    // The flag governs every transfer, not just the market. Otherwise gifting
    // would be the loophole that makes every untradable reward tradable.
    if (!item.tradable) throw new TradeError('untradable');
    // The same item twice on one side would let the second entry pass a check
    // the first had already spent.
    if (seen.has(entry.itemId)) throw new TradeError('badQuantity');
    seen.add(entry.itemId);
  }
}

/** Can this player actually hand over this side, right now? */
export function canDeliver(player: PlayerRecord, side: TradeSide): boolean {
  if (player.ryo < side.ryo) return false;
  return side.items.every((e) => held(player, e.itemId) >= e.qty);
}

/** Would receiving this side overflow a stack? Checked before anything moves. */
export function canReceive(player: PlayerRecord, side: TradeSide): boolean {
  return side.items.every((e) => {
    const item = ITEM_BY_ID.get(e.itemId);
    return item ? held(player, e.itemId) + e.qty <= item.stackMax : false;
  });
}

export async function proposeTrade(
  store: Store,
  from: PlayerRecord,
  to: PlayerRecord,
  offer: TradeSide,
  request: TradeSide,
  nowMs: number,
): Promise<TradeRecord> {
  if (from.id === to.id) throw new TradeError('self');
  assertMayTransfer(from);
  assertMayTransfer(to);
  validateSide(offer);
  validateSide(request);
  if (offer.ryo === 0 && offer.items.length === 0 && request.ryo === 0 && request.items.length === 0) {
    throw new TradeError('nothingOffered');
  }

  const mine = (await store.listTradesFor(from.id)).filter((t) => t.fromId === from.id && t.expiresAt > nowMs);
  if (mine.length >= MAX_OPEN_TRADES) throw new TradeError('tooManyOpen');

  // Checked here for a useful error, and again at acceptance because this is
  // only a snapshot — the proposer may spend it in the meantime.
  if (!canDeliver(from, offer)) throw new TradeError('missingInputs');

  const trade: TradeRecord = {
    id: randomUUID(),
    fromId: from.id,
    toId: to.id,
    offer,
    request,
    createdAt: nowMs,
    expiresAt: nowMs + TRADE_EXPIRY_HOURS * HOUR,
  };
  await store.createTrade(trade);
  return trade;
}

/**
 * Move one side's contents from one player to the other. Callers must have
 * validated BOTH directions first: this mutates, and a failure part-way through
 * would leave goods destroyed.
 */
function transfer(from: PlayerRecord, to: PlayerRecord, side: TradeSide): void {
  if (side.ryo > 0) { from.ryo -= side.ryo; to.ryo += side.ryo; }
  for (const entry of side.items) {
    take(from, entry.itemId, entry.qty);
    give(to, entry.itemId, entry.qty);
  }
}

export interface SettledTrade { trade: TradeRecord; transfers: TransferRecord[] }

/**
 * Accept and settle.
 *
 * Order matters and is the whole correctness argument:
 *   1. validate both sides can deliver AND both sides can receive;
 *   2. delete the proposal — whoever gets `true` back owns the settlement, so
 *      two simultaneous acceptances cannot both proceed;
 *   3. only then move anything.
 *
 * Doing step 3 before step 2 is how a trade window pays out twice.
 *
 * A caveat on how this is tested, because it is easy to believe it is covered
 * when it is not. Inside a single Node process the swap is synchronous and never
 * yields, so reordering steps 2 and 3 does NOT produce a duplicate in-process —
 * the runtime probes cannot demonstrate the bug, and neither can a
 * `Promise.all` test. The ordering matters for a multi-instance deployment
 * against Postgres, where the `DELETE ... RETURNING` is the only arbiter between
 * two servers. It is therefore asserted by `drift-check` reading the order of
 * these statements, which is the only place that can currently see it.
 */
export async function acceptTrade(
  store: Store,
  trade: TradeRecord,
  proposer: PlayerRecord,
  accepter: PlayerRecord,
  nowMs: number,
): Promise<SettledTrade> {
  if (trade.toId !== accepter.id) throw new TradeError('notYours');
  if (trade.expiresAt <= nowMs) throw new TradeError('expired');
  assertMayTransfer(proposer);
  assertMayTransfer(accepter);
  validateSide(trade.offer);
  validateSide(trade.request);

  if (!canDeliver(proposer, trade.offer)) throw new TradeError('missingInputs');
  if (!canDeliver(accepter, trade.request)) throw new TradeError('cannotAfford');
  if (!canReceive(accepter, trade.offer) || !canReceive(proposer, trade.request)) throw new TradeError('stackFull');

  if (!(await store.deleteTrade(trade.id))) throw new TradeError('noSuchTrade');

  transfer(proposer, accepter, trade.offer);
  transfer(accepter, proposer, trade.request);

  const transfers: TransferRecord[] = [];
  if (trade.offer.ryo > 0 || trade.offer.items.length > 0) {
    transfers.push({
      id: randomUUID(), at: nowMs, kind: 'trade',
      fromId: proposer.id, toId: accepter.id, ryo: trade.offer.ryo, items: trade.offer.items,
    });
  }
  if (trade.request.ryo > 0 || trade.request.items.length > 0) {
    transfers.push({
      id: randomUUID(), at: nowMs, kind: 'trade',
      fromId: accepter.id, toId: proposer.id, ryo: trade.request.ryo, items: trade.request.items,
    });
  }
  for (const entry of transfers) await store.recordTransfer(entry);
  return { trade, transfers };
}

/**
 * A gift is a one-sided transfer that settles immediately. It is deliberately
 * NOT modelled as a trade with an empty request: there is nothing for the
 * recipient to weigh up, and a proposal they must accept to receive a present is
 * ceremony rather than safety.
 */
export async function giftTo(
  store: Store,
  from: PlayerRecord,
  to: PlayerRecord,
  side: TradeSide,
  nowMs: number,
): Promise<TransferRecord> {
  if (from.id === to.id) throw new TradeError('self');
  assertMayTransfer(from);
  assertMayTransfer(to);
  validateSide(side);
  if (side.ryo === 0 && side.items.length === 0) throw new TradeError('nothingOffered');
  if (!canDeliver(from, side)) throw new TradeError(side.ryo > from.ryo ? 'cannotAfford' : 'missingInputs');
  if (!canReceive(to, side)) throw new TradeError('stackFull');

  transfer(from, to, side);

  const entry: TransferRecord = {
    id: randomUUID(), at: nowMs, kind: 'gift',
    fromId: from.id, toId: to.id, ryo: side.ryo, items: side.items,
  };
  await store.recordTransfer(entry);
  return entry;
}

/** Expired proposals are dropped lazily when the trade list is read. */
export async function sweepExpiredTrades(store: Store, playerId: string, nowMs: number): Promise<TradeRecord[]> {
  const all = await store.listTradesFor(playerId);
  const live: TradeRecord[] = [];
  for (const t of all) {
    if (t.expiresAt <= nowMs) await store.deleteTrade(t.id);
    else live.push(t);
  }
  return live;
}
