import { randomBytes, scrypt as scryptCb, timingSafeEqual, createHash } from 'node:crypto';
import { promisify } from 'node:util';

const scrypt = promisify(scryptCb) as (
  password: string | Buffer, salt: string | Buffer, keylen: number, options?: { N?: number; r?: number; p?: number },
) => Promise<Buffer>;

/**
 * Passwords and sessions.
 *
 * Decisions worth stating, because getting any of them wrong is worse than
 * having no accounts at all:
 *
 *   * scrypt, not a bare hash. Salted per user, cost parameters stored alongside
 *     the digest so they can be raised later without invalidating anyone.
 *   * Comparison is timing-safe. A plain `===` on a digest leaks by how long it
 *     takes to fail.
 *   * Session tokens are 256 bits of randomness, and only their SHA-256 is
 *     stored. A stolen database dump does not hand over live sessions.
 *   * The token is opaque. It carries no player id, no role, no expiry the
 *     client could edit — every one of those is looked up server-side.
 */

const SCRYPT = { N: 16384, r: 8, p: 1 } as const;
const KEY_LENGTH = 64;

/** Format: scrypt$N$r$p$salt$digest — self-describing so cost can be raised later. */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const digest = await scrypt(password, salt, KEY_LENGTH, SCRYPT);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${digest.toString('base64')}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;

  const [, n, r, p, saltB64, digestB64] = parts;
  const salt = Buffer.from(saltB64!, 'base64');
  const expected = Buffer.from(digestB64!, 'base64');

  let actual: Buffer;
  try {
    actual = await scrypt(password, salt, expected.length, { N: Number(n), r: Number(r), p: Number(p) });
  } catch {
    return false;
  }
  if (actual.length !== expected.length) return false;
  return timingSafeEqual(actual, expected);
}

/* ── Sessions ────────────────────────────────────────────────────────── */

export const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

export interface IssuedSession { token: string; tokenHash: string; expiresAt: number }

/** The plaintext token is returned once, to the client. Only the hash is stored. */
export function issueSession(nowMs: number, ttlMs = SESSION_TTL_MS): IssuedSession {
  const token = randomBytes(32).toString('base64url');
  return { token, tokenHash: hashToken(token), expiresAt: nowMs + ttlMs };
}

export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

/* ── Input rules ─────────────────────────────────────────────────────── */

export const NAME_PATTERN = /^[A-Za-z0-9][A-Za-z0-9 _-]{1,22}[A-Za-z0-9]$/;

export function nameProblem(name: string): string | null {
  if (!NAME_PATTERN.test(name)) {
    return 'Names are 3 to 24 characters: letters, numbers, spaces, hyphens and underscores.';
  }
  return null;
}

export function passwordProblem(password: string): string | null {
  if (password.length < 10) return 'Use at least 10 characters.';
  if (password.length > 200) return 'That password is too long.';
  // Length beats composition rules, so there is deliberately no symbol requirement.
  if (/^(.)\1+$/.test(password)) return 'Pick something less repetitive.';
  return null;
}

/** Case- and space-insensitive key, so two players cannot take confusable names. */
export function normaliseName(name: string): string {
  return name.trim().toLowerCase().replace(/[\s_-]+/g, '');
}
