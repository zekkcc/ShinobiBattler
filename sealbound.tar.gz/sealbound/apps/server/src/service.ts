import { BASELINE_ACTIONS, JUTSU_BY_ID, MISSIONS, TRAINING } from '@shinobi/content';
import { ZClientMessage, type ClientMessage, type MatchEvent, type Rank, type ServerMessage } from '@shinobi/shared';
import { MatchRoom, ROUND_TIMEOUT_MS, specFor } from './matchroom.js';
import { RateLimiter, type Operation } from './ratelimit.js';
import { applyTraining, claimTraining, currentWeather, startTraining, TrainingError } from './training.js';
import type { PlayerRecord, Store } from './store/index.js';
import {
  acceptMission, applyMission, availableMissions, canTakeWork, checkPromotion,
  MissionError, priceFor, promote, reputationTier, resolveMission, successChance,
  xpForLevel, syncLevel as syncLevelFor,
} from './missions.js';
import {
  acceptInvite, acceptPartyMission, applyPartyOutcome, invite, leaveSquad,
  loadMembers, newSquad, partyMissionsFor, partySuccessChance, resolvePartyMission,
  SquadError,
} from './squads.js';
import type { SquadRecord } from './store/index.js';
import {
  addNotoriety, amnestyCost, blackMarketPrice, bountyOn, claimBounty, defect,
  isWorthHunting, RogueError, seekAmnesty, takeContract, type BountyContract,
} from './rogue.js';
import { LEGACY, ROGUE } from '@shinobi/content';
import {
  awardTitles, claimable, claimLegendary, LegacyError, setDisplayedTitle,
} from './legacy.js';
import {
  acceptClanInvite, ClanError, creditContribution, deposit, foundClan, handOverLeadership,
  inviteToClan, kickFromClan, leaveClan, rankClans, roleOf, setOfficer, withdraw,
} from './clans.js';
import type { ClanRecord, MentorshipRecord } from './store/index.js';
import {
  COSMETICS, DUNGEONS, ECONOMY, ITEM_BY_ID, MENTORSHIP, POLITICS, REGION_BY_ID,
  TERRITORY, TRAINING as TRAINING_DATA, VILLAGE_BY_ID,
} from '@shinobi/content';
import {
  activeCommissions, currentSeason, currentWeather as weatherNow, electionPhase,
  loadVillage, seasonStatBonus, villageEffects, warPeriod,
} from './world.js';
import {
  claimGathering, creditWarScore, declareWar, loadRegion, loadRegions, occupied,
  resolveDueWars, startGathering, TerritoryError,
} from './territory.js';
import {
  buyListing, cancelListing, claimCrafting, EconomyError, give, held, listForSale,
  priceBand, recordSale, referenceFor, spendGatherBoost, spendTrainingBoost,
  startCrafting, sweepExpired, useItem,
} from './economy.js';
import {
  castVote as castVoteFor, collectTax, commission, currentOffices, declareVillageWar,
  enactLaw, holdsPower, PoliticsError, repealLaw, setTax, stand, suffrageProblem, mayStand,
} from './politics.js';
import { answerRoom, availability as dungeonAvailability, DungeonError, enterDungeon, roomView, runsLeftToday } from './dungeons.js';
import {
  acceptMentorship, activeOf, duePayouts, endMentorship, MentorshipError,
  menteeTrainingBonus, offerMentorship, recordPayouts,
} from './mentorship.js';
import {
  acceptTrade, giftTo, proposeTrade, sweepExpiredTrades, TradeError, type SettledTrade,
} from './trading.js';
import { availability as cosmeticAvailability, buy as buyCosmetic, CosmeticError, defaultLoadout, equip as equipCosmetic, grant as grantCosmetic } from './cosmetics.js';

/**
 * The server-authoritative game service.
 *
 * Everything that decides an outcome happens here. The transport (WebSocket) only
 * supplies two things: an authenticated player id, and an untrusted blob. The
 * blob is Zod-parsed before any handler sees it (CLAUDE.md §5).
 */

export interface Delivery { to: string; message: ServerMessage }

const LOADOUT_LIMIT = 8;
const RANK_ORDER = ['academy', 'genin', 'chunin', 'jonin', 'anbu', 'kage'] as const;

export class GameService {
  private rooms = new Map<string, MatchRoom>();
  private roomOf = new Map<string, string>();          // playerId -> matchId
  private queue = new Map<Rank, string[]>();
  private limiter = new RateLimiter();

  constructor(private readonly store: Store, private readonly now: () => number = Date.now) {}

  /**
   * Entry point for anything arriving over the wire.
   *
   * `playerId` is supplied by the transport from the authenticated session. It is
   * never read from `raw` — a client that puts a playerId in its payload is
   * simply ignored.
   */
  async handle(playerId: string, raw: unknown): Promise<Delivery[]> {
    const parsed = ZClientMessage.safeParse(raw);
    if (!parsed.success) {
      return [{ to: playerId, message: { type: 'error', code: 'badMessage', detail: parsed.error.issues[0]?.message } }];
    }
    const msg: ClientMessage = parsed.data;

    if (!this.limiter.take(playerId, msg.type as Operation, this.now())) {
      return [{ to: playerId, message: { type: 'error', code: 'rateLimited', detail: msg.type } }];
    }

    switch (msg.type) {
      case 'ping': return [{ to: playerId, message: { type: 'pong' } }];
      case 'queue': return this.onQueue(playerId, msg.rank);
      case 'submitAction': return this.onSubmit(playerId, msg.matchId, msg.action);
      case 'forfeit': return this.onForfeit(playerId, msg.matchId);
      case 'setLoadout': return this.onSetLoadout(playerId, msg.jutsuIds);
      case 'startTraining': return this.onStartTraining(playerId, msg.locationId, msg.tier);
      case 'claimTraining': return this.onClaimTraining(playerId);
      case 'getReplay': return this.onGetReplay(msg.matchId);
      case 'listMissions': return this.onListMissions(playerId);
      case 'acceptMission': return this.onAcceptMission(playerId, msg.missionId);
      case 'completeMission': return this.onCompleteMission(playerId);
      case 'learnJutsu': return this.onLearnJutsu(playerId, msg.jutsuId);
      case 'requestPromotion': return this.onRequestPromotion(playerId);
      case 'createSquad': return this.onCreateSquad(playerId);
      case 'inviteToSquad': return this.onInvite(playerId, msg.name);
      case 'acceptSquadInvite': return this.onAcceptInvite(playerId, msg.squadId);
      case 'leaveSquad': return this.onLeaveSquad(playerId);
      case 'acceptPartyMission': return this.onAcceptParty(playerId, msg.missionId);
      case 'completePartyMission': return this.onCompleteParty(playerId);
      case 'defect': return this.onDefect(playerId);
      case 'seekAmnesty': return this.onAmnesty(playerId);
      case 'listBounties': return this.onListBounties(playerId);
      case 'takeBountyContract': return this.onTakeContract(playerId, msg.targetId);
      case 'foundClan': return this.onFoundClan(playerId, msg.name);
      case 'inviteToClan': return this.onClanInvite(playerId, msg.name);
      case 'acceptClanInvite': return this.onAcceptClan(playerId, msg.clanId);
      case 'leaveClan': return this.onLeaveClan(playerId);
      case 'kickFromClan': return this.onKick(playerId, msg.playerId);
      case 'setClanOfficer': return this.onSetOfficer(playerId, msg.playerId, msg.officer);
      case 'handOverClan': return this.onHandOver(playerId, msg.playerId);
      case 'depositToClan': return this.onDeposit(playerId, msg.amount);
      case 'withdrawFromClan': return this.onWithdraw(playerId, msg.amount);
      case 'listClans': return this.onListClans(playerId);
      case 'listLegacy': return this.onListLegacy(playerId);
      case 'setTitle': return this.onSetTitle(playerId, msg.titleId);
      case 'claimLegendary': return this.onClaimLegendary(playerId, msg.itemId);
      case 'legendaryHistory': return this.onLegendaryHistory(playerId, msg.itemId);
      case 'worldStatus': return this.onWorldStatus(playerId);
      case 'listRegions': return this.onListRegions(playerId);
      case 'warStatus': return this.onWarStatus(playerId);
      case 'declareWar': return this.onDeclareWar(playerId, msg.regionId);
      case 'startGathering': return this.onStartGathering(playerId, msg.regionId, msg.itemId);
      case 'claimGathering': return this.onClaimGathering(playerId);
      case 'inventory': return this.onInventory(playerId);
      case 'listRecipes': return this.onListRecipes(playerId);
      case 'startCrafting': return this.onStartCrafting(playerId, msg.recipeId);
      case 'claimCrafting': return this.onClaimCrafting(playerId);
      case 'useItem': return this.onUseItem(playerId, msg.itemId);
      case 'listMarket': return this.onListMarket(playerId, msg.itemId);
      case 'sellItem': return this.onSellItem(playerId, msg.itemId, msg.qty, msg.unitPrice);
      case 'buyListing': return this.onBuyListing(playerId, msg.listingId);
      case 'cancelListing': return this.onCancelListing(playerId, msg.listingId);
      case 'proposeTrade': return this.onProposeTrade(playerId, msg);
      case 'acceptTrade': return this.onAcceptTrade(playerId, msg.tradeId);
      case 'declineTrade': return this.onDeclineTrade(playerId, msg.tradeId);
      case 'listTrades': return this.onListTrades(playerId);
      case 'giftItems': return this.onGift(playerId, msg.toName, { ryo: 0, items: msg.items });
      case 'giftRyo': return this.onGift(playerId, msg.toName, { ryo: msg.amount, items: [] });
      case 'electionStatus': return this.onElectionStatus(playerId);
      case 'standForOffice': return this.onStand(playerId, msg.officeId);
      case 'castVote': return this.onCastVote(playerId, msg.officeId, msg.candidateId);
      case 'setVillageTax': return this.onSetTax(playerId, msg.rate);
      case 'enactLaw': return this.onEnactLaw(playerId, msg.lawId);
      case 'repealLaw': return this.onRepealLaw(playerId, msg.lawId);
      case 'commissionWork': return this.onCommission(playerId, msg.commissionId);
      case 'declareVillageWar': return this.onDeclareVillageWar(playerId, msg.villageId);
      case 'listDungeons': return this.onListDungeons(playerId);
      case 'enterDungeon': return this.onEnterDungeon(playerId, msg.dungeonId);
      case 'answerRoom': return this.onAnswerRoom(playerId, msg.answer);
      case 'abandonDungeon': return this.onAbandonDungeon(playerId);
      case 'offerMentorship': return this.onOfferMentorship(playerId, msg.name);
      case 'acceptMentorship': return this.onAcceptMentorship(playerId, msg.mentorId);
      case 'endMentorship': return this.onEndMentorship(playerId);
      case 'mentorStatus': return this.onMentorStatus(playerId);
      case 'listCosmetics': return this.onListCosmetics(playerId);
      case 'buyCosmetic': return this.onBuyCosmetic(playerId, msg.cosmeticId);
      case 'equipCosmetic': return this.onEquipCosmetic(playerId, msg.cosmeticId);
      default: {
        const never: never = msg;
        return [{ to: playerId, message: { type: 'error', code: 'unhandled', detail: JSON.stringify(never) } }];
      }
    }
  }

  /** Everything a player is allowed to know about themselves. */
  profileFor(player: PlayerRecord): ServerMessage {
    const promotion = checkPromotion(player);
    return {
      type: 'profile',
      rank: player.rank,
      level: player.level,
      xp: player.xp,
      xpForNext: xpForLevel(player.level + 1),
      ryo: player.ryo,
      reputation: player.reputation,
      standing: reputationTier(player.reputation).id,
      known: player.known,
      loadout: player.loadout,
      missionsAtRank: player.missionsAtRank,
      clanId: player.clanId,
      clanContribution: player.clanContribution,
      titles: player.titles,
      displayedTitle: player.displayedTitle,
      rogue: player.rogue,
      notoriety: player.notoriety,
      bounty: bountyOn(player),
      amnestyCost: player.rogue ? amnestyCost(player) : 0,
      promotion: { eligible: promotion.eligible, missing: promotion.missing, note: promotion.note },
    };
  }

  /** Called by the transport once a connection is authenticated. */
  async hello(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [];
    return [{ to: playerId, message: this.profileFor(player) }];
  }

  /* ── Matchmaking ───────────────────────────────────────────────────── */

  private async onQueue(playerId: string, rank: Rank): Promise<Delivery[]> {
    if (this.roomOf.has(playerId)) {
      return [{ to: playerId, message: { type: 'error', code: 'alreadyInMatch' } }];
    }
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];

    // A client asking to queue at a rank it has not earned is ignored; the
    // server uses the stored rank, not the requested one.
    const bucket = this.queue.get(player.rank) ?? [];
    const opponentId = bucket.find((id) => id !== playerId);

    if (!opponentId) {
      if (!bucket.includes(playerId)) bucket.push(playerId);
      this.queue.set(player.rank, bucket);
      return [{ to: playerId, message: { type: 'queued', rank: player.rank } }];
    }

    this.queue.set(player.rank, bucket.filter((id) => id !== opponentId && id !== playerId));
    const opponent = await this.store.getPlayer(opponentId);
    if (!opponent) return this.onQueue(playerId, rank);

    return this.startMatch(player, opponent);
  }

  private startMatch(a: PlayerRecord, b: PlayerRecord): Delivery[] {
    const matchId = `m-${a.id}-${b.id}-${this.now()}`;
    const seed = `${matchId}:${a.rating}:${b.rating}`;
    const room = new MatchRoom(matchId, seed, specFor(a), specFor(b));
    this.rooms.set(matchId, room);
    this.roomOf.set(a.id, matchId);
    this.roomOf.set(b.id, matchId);

    return [
      { to: a.id, message: { type: 'matchFound', matchId, opponentName: b.name, state: room.viewFor(a.id) } },
      { to: b.id, message: { type: 'matchFound', matchId, opponentName: a.name, state: room.viewFor(b.id) } },
    ];
  }

  /* ── Combat ────────────────────────────────────────────────────────── */

  private async onSubmit(playerId: string, matchId: string, action: { fighterId: string; actionId: string; targetId: string }): Promise<Delivery[]> {
    const room = this.rooms.get(matchId);
    if (!room || this.roomOf.get(playerId) !== matchId) {
      return [{ to: playerId, message: { type: 'error', code: 'notInThisMatch' } }];
    }
    if (room.isComplete) return [{ to: playerId, message: { type: 'error', code: 'matchOver' } }];

    /* The submitter is the authenticated connection, full stop. Whatever
       `submittedBy` the client put in the payload is discarded here. */
    const stamped = { ...action, submittedBy: playerId };
    const { accepted } = room.submit(playerId, [stamped]);
    if (accepted === 0) {
      return [{ to: playerId, message: { type: 'error', code: 'rejectedAction', detail: 'not a body you control' } }];
    }

    if (!room.readyToResolve) {
      return [{ to: playerId, message: { type: 'awaitingOpponent', matchId, round: room.round } }];
    }
    return this.resolveRoom(room);
  }

  private async resolveRoom(room: MatchRoom): Promise<Delivery[]> {
    const events: MatchEvent[] = room.resolve(this.now());
    const out: Delivery[] = room.fighterIds.map((id) => ({
      to: id,
      message: { type: 'roundResolved', matchId: room.matchId, events, state: room.viewFor(id) } as ServerMessage,
    }));

    if (room.isComplete) out.push(...(await this.endMatch(room)));
    return out;
  }

  private async endMatch(room: MatchRoom): Promise<Delivery[]> {
    const outcome = room.outcome;
    await room.settle(this.store, this.now());

    /* A missing-nin who wins becomes more notorious, and therefore worth more.
       Notoriety is only ever earned by what a rogue actually does. */
    const extra: Delivery[] = [];
    if (room.winnerId) {
      const winner = await this.store.getPlayer(room.winnerId);
      if (winner) {
        if (winner.rogue) addNotoriety(winner, ROGUE.notoriety.perPvpWin);
        creditContribution(winner, 'pvpWin');
        winner.pvpWins += 1;
        extra.push(...(await this.syncTitles(winner)));
        await this.store.savePlayer(winner);
        // A duel won is worth something to whichever war the winner's clan is
        // fighting, and to whoever is teaching them.
        await creditWarScore(this.store, winner, 'pvpWin', this.now());
        extra.push(...(await this.payMentor(winner)));
      }
      const loserId = room.fighterIds.find((id) => id !== room.winnerId);
      if (loserId) extra.push(...(await this.settleBounty(room.winnerId, loserId)));
    }
    for (const id of room.fighterIds) this.roomOf.delete(id);
    this.rooms.delete(room.matchId);

    const out: Delivery[] = [];
    for (const id of room.fighterIds) {
      const player = await this.store.getPlayer(id);
      out.push({
        to: id,
        message: {
          type: 'matchEnded',
          matchId: room.matchId,
          winnerId: room.winnerId,
          outcome,
          gains: {},
          rating: player?.rating ?? 0,
        },
      });
    }
    return [...out, ...extra];
  }

  private async onForfeit(playerId: string, matchId: string): Promise<Delivery[]> {
    const room = this.rooms.get(matchId);
    if (!room || this.roomOf.get(playerId) !== matchId) {
      return [{ to: playerId, message: { type: 'error', code: 'notInThisMatch' } }];
    }
    room.forfeit(playerId);
    room.timeOutMissing();
    return this.resolveRoom(room);
  }

  /** Called on a timer by the transport: a silent client loses the round, not the match. */
  async tickTimeouts(): Promise<Delivery[]> {
    const out: Delivery[] = [];
    for (const room of [...this.rooms.values()]) {
      if (room.isComplete) continue;
      if (!room.readyToResolve) {
        room.timeOutMissing();
        out.push(...(await this.resolveRoom(room)));
      }
    }
    return out;
  }

  /* ── Loadout ───────────────────────────────────────────────────────── */

  private async onSetLoadout(playerId: string, jutsuIds: string[]): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    if (this.roomOf.has(playerId)) {
      return [{ to: playerId, message: { type: 'error', code: 'cannotChangeLoadoutMidMatch' } }];
    }

    const unique = [...new Set(jutsuIds)].slice(0, LOADOUT_LIMIT);
    for (const id of unique) {
      const jutsu = JUTSU_BY_ID.get(id);
      if (!jutsu) return [{ to: playerId, message: { type: 'error', code: 'unknownJutsu', detail: id } }];
      // Stat requirements are checked here as well as in the engine, so an
      // illegal loadout can never be persisted in the first place.
      if (jutsu.requires && player.stats[jutsu.requires.stat] < jutsu.requires.min) {
        return [{ to: playerId, message: { type: 'error', code: 'requirementNotMet', detail: id } }];
      }
      // You can only carry what you have learned. Baselines are always yours.
      const free = (BASELINE_ACTIONS as readonly string[]).includes(id);
      if (!free && !player.known.includes(id)) {
        return [{ to: playerId, message: { type: 'error', code: 'notLearned', detail: id } }];
      }
    }

    player.loadout = unique;
    await this.store.savePlayer(player);
    return [
      { to: playerId, message: { type: 'loadoutSet', jutsuIds: unique } },
      { to: playerId, message: this.profileFor(player) },
    ];
  }

  /* ── Training ──────────────────────────────────────────────────────── */

  private async onStartTraining(playerId: string, locationId: string, tier: number): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const session = startTraining(player, locationId, tier, this.now());
      player.training = session;
      await this.store.savePlayer(player);
      const minutes = TRAINING.tiers.find((t) => t.tier === tier)!.minutes;
      return [{ to: playerId, message: { type: 'trainingStarted', locationId, tier, endsAtMs: session.startedAt + minutes * 60_000 } }];
    } catch (err) {
      const code = err instanceof TrainingError ? err.code : 'trainingFailed';
      return [{ to: playerId, message: { type: 'error', code } }];
    }
  }

  private async onClaimTraining(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const now = this.now();
      /* Everything outside the session that makes it count for more, gathered in
         one place: the season, the village's own spending, a mentor, and any
         consumable the player readied. Each is out-of-combat by construction. */
      const village = await loadVillage(this.store, player.villageId);
      const effects = villageEffects(village, now);
      const pairing = (await this.store.listMentorshipsFor(player.id))
        .find((m) => m.menteeId === player.id && m.status === 'active');
      const location = TRAINING_DATA.locations.find((l) => l.id === player.training?.locationId);
      const bonus = effects.trainingBonus
        + menteeTrainingBonus(pairing, player.id, effects.menteeBonus)
        + spendTrainingBoost(player)
        + (location ? seasonStatBonus(now, location.primary) : 0);

      const result = claimTraining(player, now, weatherNow(now), bonus);
      applyTraining(player, result);
      await this.store.savePlayer(player);
      return [
        { to: playerId, message: { type: 'trainingClaimed', gains: result.gains, minutesCredited: result.minutesCredited } },
        { to: playerId, message: this.profileFor(player) },
      ];
    } catch (err) {
      const code = err instanceof TrainingError ? err.code : 'trainingFailed';
      return [{ to: playerId, message: { type: 'error', code } }];
    }
  }

  /* ── Missions ──────────────────────────────────────────────────────── */

  private async onListMissions(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const tier = reputationTier(player.reputation);
    return [{
      to: playerId,
      message: {
        type: 'missionBoard',
        standing: canTakeWork(player) ? tier.note : tier.note,
        missions: availableMissions(player).map((m) => ({
          id: m.id, name: m.name, rank: m.rank, minutes: m.minutes,
          ryo: m.ryo, xp: m.xp, reputation: m.reputation, brief: m.brief,
          chance: Math.round(successChance(player, m) * 100),
        })),
      },
    }];
  }

  private async onAcceptMission(playerId: string, missionId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const session = acceptMission(player, missionId, this.now());
      player.mission = session;
      await this.store.savePlayer(player);
      const minutes = MISSIONS.missions.find((m) => m.id === missionId)!.minutes;
      return [{ to: playerId, message: { type: 'missionAccepted', missionId, endsAtMs: session.startedAt + minutes * 60_000 } }];
    } catch (err) {
      return [{ to: playerId, message: { type: 'error', code: err instanceof MissionError ? err.code : 'missionFailed' } }];
    }
  }

  private async onCompleteMission(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const outcome = resolveMission(player, this.now());
      applyMission(player, outcome);
      if (outcome.success) creditContribution(player, 'mission');
      await this.store.savePlayer(player);
      const earned = await this.syncTitles(player);
      await this.store.savePlayer(player);
      if (outcome.success) await creditWarScore(this.store, player, 'missionCompleted', this.now());
      const mentorPay = await this.payMentor(player);
      return [
        {
          to: playerId,
          message: {
            type: 'missionResolved', missionId: outcome.mission.id, success: outcome.success,
            ryo: outcome.ryo, xp: outcome.xp, reputation: outcome.reputation, injured: outcome.injured,
          },
        },
        ...earned,
        ...mentorPay,
        { to: playerId, message: this.profileFor(player) },
      ];
    } catch (err) {
      return [{ to: playerId, message: { type: 'error', code: err instanceof MissionError ? err.code : 'missionFailed' } }];
    }
  }

  /* ── Squads ────────────────────────────────────────────────────────── */

  private squadFail(playerId: string, err: unknown): Delivery[] {
    return [{ to: playerId, message: { type: 'error', code: err instanceof SquadError ? err.code : 'squadFailed' } }];
  }

  /** The squad view every member sees, including what work it now qualifies for. */
  private async squadView(squad: SquadRecord): Promise<ServerMessage> {
    const members = await loadMembers(this.store, squad);
    const mission = squad.mission ? MISSIONS.missions.find((m) => m.id === squad.mission!.missionId) : undefined;
    return {
      type: 'squad',
      squadId: squad.id,
      leaderId: squad.leaderId,
      members: members.map((m) => ({ id: m.id, name: m.name, rank: m.rank })),
      invited: squad.invitedIds,
      mission: squad.mission && mission
        ? { missionId: squad.mission.missionId, endsAtMs: squad.mission.startedAt + mission.minutes * 60_000 }
        : null,
      partyMissions: (members[0] ? partyMissionsFor(members[0]) : []).map((m) => ({
        id: m.id, name: m.name, minutes: m.minutes, ryo: m.ryo, party: m.party, brief: m.brief,
        chance: Math.round(partySuccessChance(members, m) * 100),
      })),
    };
  }

  private async broadcastSquad(squad: SquadRecord): Promise<Delivery[]> {
    const view = await this.squadView(squad);
    return squad.memberIds.map((id) => ({ to: id, message: view }));
  }

  private async onCreateSquad(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const squad = newSquad(player);
      await this.store.createSquad(squad);
      player.squadId = squad.id;
      await this.store.savePlayer(player);
      return this.broadcastSquad(squad);
    } catch (err) { return this.squadFail(playerId, err); }
  }

  private async onInvite(playerId: string, name: string): Promise<Delivery[]> {
    const leader = await this.store.getPlayer(playerId);
    if (!leader?.squadId) return [{ to: playerId, message: { type: 'error', code: 'notInSquad' } }];
    const squad = await this.store.getSquad(leader.squadId);
    if (!squad) return [{ to: playerId, message: { type: 'error', code: 'noSuchSquad' } }];

    const target = await this.store.getPlayerByName(name);
    if (!target || target.id === leader.id) {
      return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    }
    try {
      invite(squad, leader, target);
      await this.store.saveSquad(squad);
      return [
        ...(await this.broadcastSquad(squad)),
        { to: target.id, message: { type: 'squadInvite', squadId: squad.id, from: leader.name } },
      ];
    } catch (err) { return this.squadFail(playerId, err); }
  }

  private async onAcceptInvite(playerId: string, squadId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const squad = await this.store.getSquad(squadId);
    if (!squad) return [{ to: playerId, message: { type: 'error', code: 'noSuchSquad' } }];
    try {
      acceptInvite(squad, player);
      await this.store.saveSquad(squad);
      player.squadId = squad.id;
      await this.store.savePlayer(player);
      return this.broadcastSquad(squad);
    } catch (err) { return this.squadFail(playerId, err); }
  }

  private async onLeaveSquad(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player?.squadId) return [{ to: playerId, message: { type: 'error', code: 'notInSquad' } }];
    const squad = await this.store.getSquad(player.squadId);
    if (!squad) return [{ to: playerId, message: { type: 'error', code: 'noSuchSquad' } }];
    try {
      const before = [...squad.memberIds];
      const { disbanded } = leaveSquad(squad, player);
      player.squadId = null;
      await this.store.savePlayer(player);
      if (disbanded) {
        await this.store.deleteSquad(squad.id);
        return before.map((id) => ({ to: id, message: { type: 'squadDisbanded' } as ServerMessage }));
      }
      await this.store.saveSquad(squad);
      return [
        ...(await this.broadcastSquad(squad)),
        { to: playerId, message: { type: 'squadDisbanded' } },
      ];
    } catch (err) { return this.squadFail(playerId, err); }
  }

  private async onAcceptParty(playerId: string, missionId: string): Promise<Delivery[]> {
    const leader = await this.store.getPlayer(playerId);
    if (!leader?.squadId) return [{ to: playerId, message: { type: 'error', code: 'notInSquad' } }];
    const squad = await this.store.getSquad(leader.squadId);
    if (!squad) return [{ to: playerId, message: { type: 'error', code: 'noSuchSquad' } }];
    try {
      const members = await loadMembers(this.store, squad);
      acceptPartyMission(squad, leader, members, missionId, this.now());
      await this.store.saveSquad(squad);
      return this.broadcastSquad(squad);
    } catch (err) { return this.squadFail(playerId, err); }
  }

  private async onCompleteParty(playerId: string): Promise<Delivery[]> {
    const caller = await this.store.getPlayer(playerId);
    if (!caller?.squadId) return [{ to: playerId, message: { type: 'error', code: 'notInSquad' } }];
    const squad = await this.store.getSquad(caller.squadId);
    if (!squad?.mission) return [{ to: playerId, message: { type: 'error', code: 'notInSquad' } }];
    try {
      const members = await loadMembers(this.store, squad);
      const outcome = resolvePartyMission(squad, members, this.now());

      const out: Delivery[] = [];
      for (const member of members) {
        applyPartyOutcome(member, outcome);
        if (outcome.success && outcome.mission.rank === 'S') {
          member.sRankCompleted += 1;
          await creditWarScore(this.store, member, 'sRankCompleted', this.now());
        }
        syncLevelFor(member);
        out.push(...(await this.syncTitles(member)));
        member.squadId = null;
        await this.store.savePlayer(member);
        out.push({
          to: member.id,
          message: {
            type: 'partyMissionResolved', missionId: outcome.mission.id, success: outcome.success,
            ryo: outcome.ryo, xp: outcome.xp, reputation: outcome.reputation,
          },
        });
        out.push({ to: member.id, message: this.profileFor(member) });
      }
      // The squad exists for the mission; it is done, so the squad is done.
      await this.store.deleteSquad(squad.id);
      return out;
    } catch (err) { return this.squadFail(playerId, err); }
  }

  /* ── Missing-nin and hunter-nin ────────────────────────────────────── */

  private rogueFail(playerId: string, err: unknown): Delivery[] {
    return [{ to: playerId, message: { type: 'error', code: err instanceof RogueError ? err.code : 'rogueFailed' } }];
  }

  private async onDefect(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    if (this.roomOf.has(playerId)) return [{ to: playerId, message: { type: 'error', code: 'inMatch' } }];
    try {
      defect(player, this.now());
      await this.store.savePlayer(player);
      return [
        { to: playerId, message: { type: 'defected', note: ROGUE.defection.note } },
        { to: playerId, message: this.profileFor(player) },
      ];
    } catch (err) { return this.rogueFail(playerId, err); }
  }

  private async onAmnesty(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const paid = seekAmnesty(player, this.now());
      await this.store.savePlayer(player);
      return [
        { to: playerId, message: { type: 'returned', paid, note: ROGUE.amnesty.note } },
        { to: playerId, message: this.profileFor(player) },
      ];
    } catch (err) { return this.rogueFail(playerId, err); }
  }

  private async onListBounties(playerId: string): Promise<Delivery[]> {
    const contracts = await this.store.listContracts(this.now());
    const mine = contracts.find((c) => c.hunterId === playerId && c.expiresAt > this.now());
    const rogues = await this.store.listRogues();
    return [{
      to: playerId,
      message: {
        type: 'bountyBoard',
        bounties: rogues
          .filter((r) => r.id !== playerId && isWorthHunting(r))
          .map((r) => ({ targetId: r.id, name: r.name, level: r.level, notoriety: r.notoriety, value: bountyOn(r) })),
        yourContract: mine ? { targetId: mine.targetId, expiresAtMs: mine.expiresAt, value: mine.value } : null,
      },
    }];
  }

  private async onTakeContract(playerId: string, targetId: string): Promise<Delivery[]> {
    const hunter = await this.store.getPlayer(playerId);
    const target = await this.store.getPlayer(targetId);
    if (!hunter || !target) return [{ to: playerId, message: { type: 'error', code: 'noSuchTarget' } }];
    try {
      const existing = await this.store.listContracts(this.now());
      const contract = takeContract(hunter, target, existing, this.now());
      await this.store.saveContract(contract);
      return [{
        to: playerId,
        message: { type: 'contractTaken', targetId, value: contract.value, expiresAtMs: contract.expiresAt },
      }];
    } catch (err) { return this.rogueFail(playerId, err); }
  }

  /** Settles any live contract the winner held on the loser. */
  private async settleBounty(winnerId: string, loserId: string): Promise<Delivery[]> {
    const contracts = await this.store.listContracts(this.now());
    const contract = contracts.find(
      (c: BountyContract) => c.hunterId === winnerId && c.targetId === loserId && c.expiresAt > this.now(),
    );
    if (!contract) return [];

    const hunter = await this.store.getPlayer(winnerId);
    const rogue = await this.store.getPlayer(loserId);
    if (!hunter || !rogue || !rogue.rogue) return [];

    const claim = claimBounty(contract, hunter, rogue, this.now());
    hunter.bountiesClaimed += 1;
    await creditWarScore(this.store, hunter, 'bountyClaimed', this.now());
    const earnedByHunter = await this.syncTitles(hunter);
    await this.store.savePlayer(hunter);
    await this.store.savePlayer(rogue);
    // The contract row stays until the same-pair cooldown lapses; only its
    // expiry is brought forward so it can no longer be claimed again.
    await this.store.saveContract({ ...contract, expiresAt: this.now() - 1 });

    return [
      { to: hunter.id, message: { type: 'bountyClaimed', targetName: rogue.name, paid: claim.paidToHunter } },
      ...earnedByHunter,
      { to: rogue.id, message: { type: 'bountyLost', hunterName: hunter.name, taken: claim.takenFromRogue } },
    ];
  }

  /* ── Legacy: titles and legendary items ────────────────────────────── */

  /**
   * Re-checks every title after anything that could have earned one. Titles are
   * only ever produced here, from thresholds — there is no grant path.
   */
  private async syncTitles(player: PlayerRecord): Promise<Delivery[]> {
    const fresh = awardTitles(player);
    if (fresh.length === 0) return [];
    return [{
      to: player.id,
      message: {
        type: 'titlesEarned',
        titles: fresh.map((id) => {
          const t = LEGACY.titles.find((x) => x.id === id)!;
          return { id: t.id, name: t.name, blurb: t.blurb };
        }),
      },
    }];
  }

  private async onListLegacy(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const held = await this.store.listLegendaries();

    const holders = new Map<string, string>();
    for (const h of held) holders.set(h.holderId, (await this.store.getPlayer(h.holderId))?.name ?? 'unknown');

    return [{
      to: playerId,
      message: {
        type: 'legacy',
        titles: LEGACY.titles.map((t) => ({
          id: t.id, name: t.name, blurb: t.blurb, earned: player.titles.includes(t.id),
        })),
        displayed: player.displayedTitle,
        claimable: claimable(player, held),
        held: held.map((h) => ({
          itemId: h.itemId,
          name: LEGACY.legendaries.find((l) => l.id === h.itemId)?.name ?? h.itemId,
          holderName: holders.get(h.holderId) ?? 'unknown',
          yours: h.holderId === playerId,
        })),
      },
    }];
  }

  private async onSetTitle(playerId: string, titleId: string | null): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      setDisplayedTitle(player, titleId);
      await this.store.savePlayer(player);
      return [{ to: playerId, message: { type: 'titleSet', titleId } }];
    } catch (err) {
      return [{ to: playerId, message: { type: 'error', code: err instanceof LegacyError ? err.code : 'legacyFailed' } }];
    }
  }

  private async onClaimLegendary(playerId: string, itemId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const claim = await claimLegendary(this.store, player, itemId, this.now());
      return [{ to: playerId, message: { type: 'legendaryClaimed', ...claim } }];
    } catch (err) {
      // A losing racer hits the store's unique constraint rather than the check.
      const code = err instanceof LegacyError ? err.code : 'alreadyHeld';
      return [{ to: playerId, message: { type: 'error', code } }];
    }
  }

  private async onLegendaryHistory(playerId: string, itemId: string): Promise<Delivery[]> {
    const chain = await this.store.legendaryHistory(itemId);
    const out = [];
    for (const entry of chain) {
      out.push({
        holderName: (await this.store.getPlayer(entry.holderId))?.name ?? 'unknown',
        heldFrom: entry.heldFrom,
        heldUntil: entry.heldUntil,
      });
    }
    return [{ to: playerId, message: { type: 'legendaryChain', itemId, chain: out } }];
  }

  /* ── Clans ─────────────────────────────────────────────────────────── */

  private clanFail(playerId: string, err: unknown): Delivery[] {
    return [{ to: playerId, message: { type: 'error', code: err instanceof ClanError ? err.code : 'clanFailed' } }];
  }

  private async clanView(clan: ClanRecord, viewerId: string): Promise<ServerMessage> {
    const members = [];
    for (const id of clan.memberIds) {
      const m = await this.store.getPlayer(id);
      if (m) members.push({ id: m.id, name: m.name, role: roleOf(clan, id) ?? 'member', contribution: m.clanContribution });
    }
    return {
      type: 'clan', clanId: clan.id, name: clan.name, leaderId: clan.leaderId,
      bank: clan.bank, members, invited: clan.invitedIds,
      yourRole: roleOf(clan, viewerId) ?? 'none',
    };
  }

  private async broadcastClan(clan: ClanRecord): Promise<Delivery[]> {
    const out: Delivery[] = [];
    for (const id of clan.memberIds) out.push({ to: id, message: await this.clanView(clan, id) });
    return out;
  }

  private async clanOf(playerId: string): Promise<{ player: PlayerRecord; clan: ClanRecord } | null> {
    const player = await this.store.getPlayer(playerId);
    if (!player?.clanId) return null;
    const clan = await this.store.getClan(player.clanId);
    return clan ? { player, clan } : null;
  }

  private async onFoundClan(playerId: string, name: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const existing = await this.store.getClanByNameKey(name.trim().toLowerCase().replace(/[\s_-]+/g, ''));
      if (existing) throw new ClanError('nameTaken');
      const clan = foundClan(player, name, this.now());
      await this.store.createClan(clan);
      player.clanId = clan.id;
      player.clanJoinedAt = this.now();
      player.clanContribution = 0;
      await this.store.savePlayer(player);
      return [...(await this.broadcastClan(clan)), { to: playerId, message: this.profileFor(player) }];
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onClanInvite(playerId: string, name: string): Promise<Delivery[]> {
    const ctx = await this.clanOf(playerId);
    if (!ctx) return [{ to: playerId, message: { type: 'error', code: 'notInClan' } }];
    const target = await this.store.getPlayerByName(name);
    if (!target || target.id === playerId) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      inviteToClan(ctx.clan, ctx.player, target);
      await this.store.saveClan(ctx.clan);
      return [
        ...(await this.broadcastClan(ctx.clan)),
        { to: target.id, message: { type: 'clanInvite', clanId: ctx.clan.id, name: ctx.clan.name, from: ctx.player.name } },
      ];
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onAcceptClan(playerId: string, clanId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    const clan = await this.store.getClan(clanId);
    if (!player || !clan) return [{ to: playerId, message: { type: 'error', code: 'noSuchClan' } }];
    try {
      acceptClanInvite(clan, player, this.now());
      await this.store.saveClan(clan);
      await this.store.savePlayer(player);
      return [...(await this.broadcastClan(clan)), { to: playerId, message: this.profileFor(player) }];
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onLeaveClan(playerId: string): Promise<Delivery[]> {
    const ctx = await this.clanOf(playerId);
    if (!ctx) return [{ to: playerId, message: { type: 'error', code: 'notInClan' } }];
    try {
      const soleMember = ctx.clan.memberIds.length === 1;
      leaveClan(ctx.clan, ctx.player);
      await this.store.savePlayer(ctx.player);
      if (soleMember) {
        await this.store.deleteClan(ctx.clan.id);
        return [{ to: playerId, message: { type: 'clanLeft' } }, { to: playerId, message: this.profileFor(ctx.player) }];
      }
      await this.store.saveClan(ctx.clan);
      return [...(await this.broadcastClan(ctx.clan)), { to: playerId, message: { type: 'clanLeft' } }];
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onKick(playerId: string, targetId: string): Promise<Delivery[]> {
    const ctx = await this.clanOf(playerId);
    const target = await this.store.getPlayer(targetId);
    if (!ctx || !target) return [{ to: playerId, message: { type: 'error', code: 'noSuchMember' } }];
    try {
      kickFromClan(ctx.clan, ctx.player, target);
      await this.store.saveClan(ctx.clan);
      await this.store.savePlayer(target);
      return [...(await this.broadcastClan(ctx.clan)), { to: target.id, message: { type: 'clanLeft' } }];
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onSetOfficer(playerId: string, targetId: string, officer: boolean): Promise<Delivery[]> {
    const ctx = await this.clanOf(playerId);
    if (!ctx) return [{ to: playerId, message: { type: 'error', code: 'notInClan' } }];
    try {
      setOfficer(ctx.clan, ctx.player, targetId, officer);
      await this.store.saveClan(ctx.clan);
      return this.broadcastClan(ctx.clan);
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onHandOver(playerId: string, targetId: string): Promise<Delivery[]> {
    const ctx = await this.clanOf(playerId);
    if (!ctx) return [{ to: playerId, message: { type: 'error', code: 'notInClan' } }];
    try {
      handOverLeadership(ctx.clan, ctx.player, targetId);
      await this.store.saveClan(ctx.clan);
      return this.broadcastClan(ctx.clan);
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onDeposit(playerId: string, amount: number): Promise<Delivery[]> {
    const ctx = await this.clanOf(playerId);
    if (!ctx) return [{ to: playerId, message: { type: 'error', code: 'notInClan' } }];
    try {
      deposit(ctx.clan, ctx.player, amount);
      await this.store.saveClan(ctx.clan);
      await this.store.savePlayer(ctx.player);
      return [...(await this.broadcastClan(ctx.clan)), { to: playerId, message: this.profileFor(ctx.player) }];
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onWithdraw(playerId: string, amount: number): Promise<Delivery[]> {
    const ctx = await this.clanOf(playerId);
    if (!ctx) return [{ to: playerId, message: { type: 'error', code: 'notInClan' } }];
    try {
      withdraw(ctx.clan, ctx.player, amount, this.now());
      await this.store.saveClan(ctx.clan);
      await this.store.savePlayer(ctx.player);
      return [...(await this.broadcastClan(ctx.clan)), { to: playerId, message: this.profileFor(ctx.player) }];
    } catch (err) { return this.clanFail(playerId, err); }
  }

  private async onListClans(playerId: string): Promise<Delivery[]> {
    const clans = await this.store.listClans();
    const totals = new Map<string, number>();
    for (const clan of clans) {
      let sum = 0;
      for (const id of clan.memberIds) sum += (await this.store.getPlayer(id))?.clanContribution ?? 0;
      totals.set(clan.id, sum);
    }
    return [{ to: playerId, message: { type: 'clanRankings', clans: rankClans(clans, totals) } }];
  }

  /* ── Learning techniques ───────────────────────────────────────────── */

  private async onLearnJutsu(playerId: string, jutsuId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];

    const jutsu = JUTSU_BY_ID.get(jutsuId);
    if (!jutsu) return [{ to: playerId, message: { type: 'error', code: 'unknownJutsu', detail: jutsuId } }];
    if (player.known.includes(jutsuId)) return [{ to: playerId, message: { type: 'error', code: 'alreadyKnown' } }];

    /* The black market asks no questions about rank, only for more money. That
       is the trade a missing-nin makes. */
    const needed = MISSIONS.teacherRankRequired[jutsu.rank]!;
    if (!(player.rogue && ROGUE.blackMarket.ignoresRankGate)
      && RANK_ORDER.indexOf(player.rank) < RANK_ORDER.indexOf(needed)) {
      return [{ to: playerId, message: { type: 'error', code: 'rankLocked', detail: jutsuId } }];
    }

    const listed = MISSIONS.jutsuPrices[jutsu.rank]!;
    const price = player.rogue ? blackMarketPrice(listed) : priceFor(listed, player);
    if (player.ryo < price) {
      return [{ to: playerId, message: { type: 'error', code: 'cannotAfford', detail: String(price) } }];
    }

    player.ryo -= price;
    player.known.push(jutsuId);
    await this.store.savePlayer(player);
    return [
      { to: playerId, message: { type: 'jutsuLearned', jutsuId, paid: price, ryo: player.ryo } },
      { to: playerId, message: this.profileFor(player) },
    ];
  }

  /* ── Rank ──────────────────────────────────────────────────────────── */

  private async onRequestPromotion(playerId: string): Promise<Delivery[]> {
    const player = await this.store.getPlayer(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const check = checkPromotion(player);
    if (!check.eligible) {
      return [{ to: playerId, message: { type: 'promotionDenied', missing: check.missing, note: check.note } }];
    }
    const rank = promote(player);
    await this.store.savePlayer(player);
    return [
      { to: playerId, message: { type: 'promotion', rank, note: check.note } },
      { to: playerId, message: this.profileFor(player) },
    ];
  }

  /* ── Replays ───────────────────────────────────────────────────────── */

  private async onGetReplay(matchId: string): Promise<Delivery[]> {
    const replay = await this.store.getReplay(matchId);
    if (!replay) return [{ to: '', message: { type: 'error', code: 'noSuchReplay' } }];
    return [{ to: '', message: { type: 'replay', matchId, seed: replay.seed, actions: replay.actions } }];
  }


  /* ══════════════════════════════════════════════════════════════════════
     Meta-game: world, territory, economy, politics, dungeons, mentors,
     cosmetics.

     Everything below follows the same two rules as everything above it. The
     client sends intent and nothing else — no yields, no prices it computed, no
     war scores, no puzzle answers. And nothing here can reach `resolveTurn`: the
     meta-game pays in money, materials, standing and ground, never in combat
     statistics.
     ══════════════════════════════════════════════════════════════════════ */

  private metaFail(playerId: string, err: unknown): Delivery[] {
    const code = err instanceof TradeError ? err.code
      : err instanceof TerritoryError ? err.code
      : err instanceof EconomyError ? err.code
        : err instanceof PoliticsError ? err.code
          : err instanceof DungeonError ? err.code
            : err instanceof MentorshipError ? err.code
              : err instanceof CosmeticError ? err.code
                : 'failed';
    return [{ to: playerId, message: { type: 'error', code } }];
  }

  private async player(playerId: string): Promise<PlayerRecord | null> {
    return this.store.getPlayer(playerId);
  }

  /* ── World ─────────────────────────────────────────────────────────── */

  private async onWorldStatus(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const now = this.now();
    const village = await loadVillage(this.store, player.villageId);
    const season = currentSeason(now);
    const offices = await currentOffices(this.store, player.villageId, now);

    const named: { officeId: string; name: string; holders: { id: string; name: string }[] }[] = [];
    for (const office of offices) {
      const holders = [];
      for (const id of office.holderIds) {
        const h = await this.store.getPlayer(id);
        if (h) holders.push({ id: h.id, name: h.name });
      }
      named.push({
        officeId: office.officeId,
        name: POLITICS.offices.find((o) => o.id === office.officeId)?.name ?? office.officeId,
        holders,
      });
    }

    return [{
      to: playerId,
      message: {
        type: 'world',
        season: season.id,
        seasonName: season.name,
        weather: weatherNow(now),
        villageId: village.id,
        taxRate: village.taxRate,
        laws: village.laws.map((id) => {
          const law = POLITICS.laws.find((l) => l.id === id);
          return { id, name: law?.name ?? id, blurb: law?.blurb ?? '' };
        }),
        commissions: activeCommissions(village, now).map((c) => ({
          id: c.id,
          name: POLITICS.treasury.commissions.find((x) => x.id === c.id)?.name ?? c.id,
          endsAtMs: c.endsAt,
        })),
        offices: named,
        atWarWith: village.atWarWith,
      },
    }];
  }

  /* ── Territory ─────────────────────────────────────────────────────── */

  private async onListRegions(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const now = this.now();
    const records = await loadRegions(this.store, now);
    const season = currentSeason(now).id;

    const regions = [];
    for (const r of records) {
      const def = REGION_BY_ID.get(r.id)!;
      const clan = r.garrisonClanId ? await this.store.getClan(r.garrisonClanId) : null;
      regions.push({
        id: r.id,
        name: def.name,
        country: def.country,
        controllingVillage: r.controllingVillageId,
        garrisonClan: r.garrisonClanId,
        garrisonClanName: clan?.name ?? null,
        // Only what is actually in season is offered; the rest is not a secret,
        // it simply is not there this month.
        resources: def.resources.filter((id) => ITEM_BY_ID.get(id)?.seasons.includes(season as never)),
        trainingBonus: def.trainingBonus,
        yoursToGather: !player.rogue && r.controllingVillageId === player.villageId,
      });
    }
    return [{ to: playerId, message: { type: 'regions', regions } }];
  }

  /**
   * Reading the board is also what resolves wars whose period has closed. A
   * timer that fails to fire would freeze ownership; this cannot, because the
   * first person to look does the work.
   */
  private async onWarStatus(playerId: string): Promise<Delivery[]> {
    const now = this.now();
    const outcomes = await resolveDueWars(this.store, now);
    const period = warPeriod(now);
    const wars = (await this.store.listWars()).filter((w) => !w.resolved);

    const rows = [];
    for (const w of wars) {
      const attacker = await this.store.getClan(w.attackerClanId);
      rows.push({
        regionId: w.regionId,
        regionName: REGION_BY_ID.get(w.regionId)?.name ?? w.regionId,
        attackerClanId: w.attackerClanId,
        attackerClanName: attacker?.name ?? 'unknown',
        defenderClanId: w.defenderClanId,
        attackerScore: w.attackerScore,
        defenderScore: w.defenderScore,
        resolvesAtMs: w.resolvesAt,
      });
    }

    const out: Delivery[] = [{
      to: playerId,
      message: {
        type: 'warBoard',
        periodEndsAtMs: period.endsAtMs,
        declareWindowOpen: period.declareWindowOpen,
        wars: rows,
      },
    }];
    for (const o of outcomes) {
      out.push({
        to: playerId,
        message: {
          type: 'warResolved',
          regionId: o.war.regionId,
          winnerClanId: o.winnerClanId,
          attackerScore: o.war.attackerScore,
          defenderScore: o.war.defenderScore,
          note: o.note,
        },
      });
    }
    return out;
  }

  private async onDeclareWar(playerId: string, regionId: string): Promise<Delivery[]> {
    const ctx = await this.clanOf(playerId);
    if (!ctx) return [{ to: playerId, message: { type: 'error', code: 'notInClan' } }];
    try {
      await resolveDueWars(this.store, this.now());
      const { war, stake } = await declareWar(this.store, ctx.clan, ctx.player, regionId, this.now());
      await this.store.saveClan(ctx.clan);
      const out: Delivery[] = [{
        to: playerId,
        message: { type: 'warDeclared', regionId, stake, resolvesAtMs: war.resolvesAt },
      }];
      // Both clans are told. A war the defender cannot see is one they cannot answer.
      if (war.defenderClanId) {
        const defender = await this.store.getClan(war.defenderClanId);
        for (const id of defender?.memberIds ?? []) {
          out.push({ to: id, message: { type: 'warDeclared', regionId, stake, resolvesAtMs: war.resolvesAt } });
        }
      }
      return out;
    } catch (err) {
      // A lost race arrives from the store, not from the check above it.
      if (!(err instanceof TerritoryError)) {
        return [{ to: playerId, message: { type: 'error', code: 'alreadyContested' } }];
      }
      return this.metaFail(playerId, err);
    }
  }

  private async onStartGathering(playerId: string, regionId: string, itemId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    if (this.roomOf.has(playerId)) return [{ to: playerId, message: { type: 'error', code: 'inMatch' } }];
    try {
      const region = await loadRegion(this.store, regionId, this.now());
      const session = startGathering(player, region, itemId, this.now());
      player.gathering = session;
      await this.store.savePlayer(player);
      return [{
        to: playerId,
        message: {
          type: 'gatheringStarted',
          regionId,
          itemId,
          endsAtMs: session.startedAt + TERRITORY.yield.gatherMinutes * 60_000,
        },
      }];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onClaimGathering(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player?.gathering) return [{ to: playerId, message: { type: 'error', code: 'notGathering' } }];
    try {
      const now = this.now();
      const region = await loadRegion(this.store, player.gathering.regionId, now);
      const village = await loadVillage(this.store, region.controllingVillageId);
      const effects = villageEffects(village, now);

      const result = claimGathering(player, region, now, {
        villageGatherBonus: effects.gatherBonus,
        outsiderPenaltyWaived: effects.outsiderPenaltyWaived,
        outsiderTollFraction: effects.outsiderTollFraction,
      });
      spendGatherBoost(player);
      player.gathering = null;
      if (result.units > 0) {
        try { give(player, result.itemId, result.units); } catch { /* stack full: the surplus is left on the ground */ }
      }
      await this.store.savePlayer(player);

      if (result.tollValue > 0) await collectTax(this.store, region.controllingVillageId, result.tollValue);

      return [
        {
          to: playerId,
          message: {
            type: 'gatheringClaimed',
            itemId: result.itemId,
            units: result.units,
            toll: result.tollUnits,
            note: result.note,
          },
        },
        ...(await this.inventoryView(player)),
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  /* ── Economy ───────────────────────────────────────────────────────── */

  private async inventoryView(player: PlayerRecord): Promise<Delivery[]> {
    return [{
      to: player.id,
      message: {
        type: 'inventory',
        ryo: player.ryo,
        items: Object.entries(player.inventory).map(([itemId, qty]) => ({
          itemId,
          name: ITEM_BY_ID.get(itemId)?.name ?? itemId,
          kind: ITEM_BY_ID.get(itemId)?.kind ?? 'unknown',
          qty,
        })),
        cosmetics: player.cosmetics,
        equipped: { ...defaultLoadout(), ...player.equipped },
      },
    }];
  }

  private async onInventory(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    return this.inventoryView(player);
  }

  private async onListRecipes(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    return [{
      to: playerId,
      message: {
        type: 'recipes',
        recipes: ECONOMY.recipes.map((r) => {
          const missing = r.inputs.filter((i) => held(player, i.item) < i.qty).map((i) => i.item);
          const gated = player.stats[r.requires.stat] < r.requires.min;
          return {
            id: r.id, name: r.name, station: r.station, minutes: r.minutes,
            inputs: r.inputs.map((i) => ({ item: i.item, qty: i.qty })),
            output: { item: r.output.item, qty: r.output.qty },
            craftable: missing.length === 0 && !gated,
            missing: gated ? [...missing, `${r.requires.stat} ${r.requires.min}`] : missing,
          };
        }),
      },
    }];
  }

  private async onStartCrafting(playerId: string, recipeId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    if (this.roomOf.has(playerId)) return [{ to: playerId, message: { type: 'error', code: 'inMatch' } }];
    try {
      const session = startCrafting(player, recipeId, this.now());
      player.crafting = session;
      await this.store.savePlayer(player);
      const minutes = ECONOMY.recipes.find((r) => r.id === recipeId)!.minutes;
      return [
        { to: playerId, message: { type: 'craftingStarted', recipeId, endsAtMs: session.startedAt + minutes * 60_000 } },
        ...(await this.inventoryView(player)),
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onClaimCrafting(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const result = claimCrafting(player, this.now());
      // Some finishes are cosmetic rather than an item; those are granted, never sold.
      const cosmetic = COSMETICS.items.find((c) => c.source === 'craft' && c.recipe === result.recipeId);
      if (cosmetic) grantCosmetic(player, cosmetic.id);
      await this.store.savePlayer(player);
      return [
        { to: playerId, message: { type: 'craftingClaimed', recipeId: result.recipeId, item: result.item, qty: result.qty } },
        ...(await this.inventoryView(player)),
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onUseItem(playerId: string, itemId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const name = useItem(player, itemId);
      await this.store.savePlayer(player);
      return [
        { to: playerId, message: { type: 'itemUsed', itemId, note: `${name} readied.` } },
        ...(await this.inventoryView(player)),
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onListMarket(playerId: string, itemId?: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const now = this.now();
    await sweepExpired(this.store, now);
    const village = await loadVillage(this.store, player.villageId);

    const listings = (await this.store.listListings()).filter((l) => !itemId || l.itemId === itemId);
    const rows = [];
    for (const l of listings) {
      const seller = await this.store.getPlayer(l.sellerId);
      rows.push({
        listingId: l.id, itemId: l.itemId,
        name: ITEM_BY_ID.get(l.itemId)?.name ?? l.itemId,
        qty: l.qty, unitPrice: l.unitPrice,
        sellerName: seller?.name ?? 'unknown',
        yours: l.sellerId === playerId,
        expiresAtMs: l.expiresAt,
      });
    }

    const referencePrices: Record<string, number> = {};
    for (const item of ECONOMY.items) {
      if (item.tradable) referencePrices[item.id] = await referenceFor(this.store, item.id, now);
    }
    return [{ to: playerId, message: { type: 'market', referencePrices, taxRate: village.taxRate, listings: rows } }];
  }

  private async onSellItem(playerId: string, itemId: string, qty: number, unitPrice: number): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const { listing, fee } = await listForSale(this.store, player, itemId, qty, unitPrice, this.now());
      await this.store.savePlayer(player);
      return [
        { to: playerId, message: { type: 'listed', listingId: listing.id, itemId, qty, unitPrice, feePaid: fee } },
        ...(await this.inventoryView(player)),
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onBuyListing(playerId: string, listingId: string): Promise<Delivery[]> {
    const buyer = await this.player(playerId);
    if (!buyer) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const now = this.now();
      const seller = await this.store.getPlayer((await this.store.getListing(listingId))?.sellerId ?? '');
      const sellerVillage = seller ? await loadVillage(this.store, seller.villageId) : null;
      const taxRate = sellerVillage?.taxRate ?? POLITICS.tax.default;

      const result = await buyListing(this.store, buyer, listingId, taxRate, now);
      await this.store.savePlayer(buyer);

      const paidTo = await this.store.getPlayer(result.sellerId);
      if (paidTo) {
        paidTo.ryo += result.toSeller;
        await this.store.savePlayer(paidTo);
        await collectTax(this.store, paidTo.villageId, result.tax);
      }
      await recordSale(this.store, result.listing.itemId, result.listing.unitPrice, now);

      const out: Delivery[] = [
        {
          to: playerId,
          message: {
            type: 'bought', listingId, itemId: result.listing.itemId,
            qty: result.listing.qty, paid: result.paid,
          },
        },
        ...(await this.inventoryView(buyer)),
      ];
      if (paidTo) out.push({ to: paidTo.id, message: this.profileFor(paidTo) });
      return out;
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onCancelListing(playerId: string, listingId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      await cancelListing(this.store, player, listingId);
      await this.store.savePlayer(player);
      return [
        { to: playerId, message: { type: 'listingCancelled', listingId } },
        ...(await this.inventoryView(player)),
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }


  /* ── Direct trade and gifting ──────────────────────────────────────── */

  private named(side: { ryo: number; items: { itemId: string; qty: number }[] }) {
    return side.items.map((i) => ({ itemId: i.itemId, name: ITEM_BY_ID.get(i.itemId)?.name ?? i.itemId, qty: i.qty }));
  }

  private async onProposeTrade(playerId: string, msg: {
    toName: string;
    offerRyo: number; offerItems: { itemId: string; qty: number }[];
    requestRyo: number; requestItems: { itemId: string; qty: number }[];
  }): Promise<Delivery[]> {
    const from = await this.player(playerId);
    const to = await this.store.getPlayerByName(msg.toName);
    if (!from || !to) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const offer = { ryo: msg.offerRyo, items: msg.offerItems };
      const request = { ryo: msg.requestRyo, items: msg.requestItems };
      const trade = await proposeTrade(this.store, from, to, offer, request, this.now());
      const payload = {
        type: 'tradeProposed' as const,
        tradeId: trade.id, fromName: from.name, toName: to.name,
        offerRyo: offer.ryo, offerItems: this.named(offer),
        requestRyo: request.ryo, requestItems: this.named(request),
        expiresAtMs: trade.expiresAt,
      };
      // Both ends see the same description of the deal. A proposal the other
      // party learns about only through a UI they may not have open is a trap.
      return [{ to: playerId, message: payload }, { to: to.id, message: payload }];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onAcceptTrade(playerId: string, tradeId: string): Promise<Delivery[]> {
    const accepter = await this.player(playerId);
    if (!accepter) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const trade = await this.store.getTrade(tradeId);
    if (!trade || trade.toId !== playerId) return [{ to: playerId, message: { type: 'error', code: 'noSuchTrade' } }];
    const proposer = await this.store.getPlayer(trade.fromId);
    if (!proposer) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];

    let settled: SettledTrade;
    try {
      settled = await acceptTrade(this.store, trade, proposer, accepter, this.now());
    } catch (err) { return this.metaFail(playerId, err); }

    // Both records are saved only after the swap has fully succeeded.
    await this.store.savePlayer(proposer);
    await this.store.savePlayer(accepter);

    return [
      { to: proposer.id, message: { type: 'tradeSettled', tradeId, withName: accepter.name, note: 'The trade went through.' } },
      { to: accepter.id, message: { type: 'tradeSettled', tradeId, withName: proposer.name, note: 'The trade went through.' } },
      ...(await this.inventoryView(proposer)),
      ...(await this.inventoryView(accepter)),
    ];
  }

  private async onDeclineTrade(playerId: string, tradeId: string): Promise<Delivery[]> {
    const trade = await this.store.getTrade(tradeId);
    // Either party may walk away: the proposer is cancelling, the recipient is refusing.
    if (!trade || (trade.toId !== playerId && trade.fromId !== playerId)) {
      return [{ to: playerId, message: { type: 'error', code: 'noSuchTrade' } }];
    }
    if (!(await this.store.deleteTrade(tradeId))) {
      return [{ to: playerId, message: { type: 'error', code: 'noSuchTrade' } }];
    }
    const other = await this.store.getPlayer(trade.fromId === playerId ? trade.toId : trade.fromId);
    const me = await this.store.getPlayer(playerId);
    const out: Delivery[] = [{ to: playerId, message: { type: 'tradeDeclined', tradeId, withName: other?.name ?? 'unknown' } }];
    if (other) out.push({ to: other.id, message: { type: 'tradeDeclined', tradeId, withName: me?.name ?? 'unknown' } });
    return out;
  }

  private async onListTrades(playerId: string): Promise<Delivery[]> {
    const live = await sweepExpiredTrades(this.store, playerId, this.now());
    const incoming = [];
    const outgoing = [];
    for (const t of live) {
      const otherId = t.fromId === playerId ? t.toId : t.fromId;
      const other = await this.store.getPlayer(otherId);
      const row = { tradeId: t.id, offerRyo: t.offer.ryo, requestRyo: t.request.ryo, expiresAtMs: t.expiresAt };
      if (t.toId === playerId) incoming.push({ ...row, fromName: other?.name ?? 'unknown' });
      else outgoing.push({ ...row, toName: other?.name ?? 'unknown' });
    }
    return [{ to: playerId, message: { type: 'trades', incoming, outgoing } }];
  }

  private async onGift(
    playerId: string,
    toName: string,
    side: { ryo: number; items: { itemId: string; qty: number }[] },
  ): Promise<Delivery[]> {
    const from = await this.player(playerId);
    const to = await this.store.getPlayerByName(toName);
    if (!from || !to) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      await giftTo(this.store, from, to, side, this.now());
      await this.store.savePlayer(from);
      await this.store.savePlayer(to);
      return [
        { to: playerId, message: { type: 'gifted', toName: to.name, ryo: side.ryo, items: side.items } },
        { to: to.id, message: { type: 'giftReceived', fromName: from.name, ryo: side.ryo, items: side.items } },
        ...(await this.inventoryView(from)),
        ...(await this.inventoryView(to)),
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  /* ── Politics ──────────────────────────────────────────────────────── */

  private async onElectionStatus(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const now = this.now();
    const { cycle, phase, phaseEndsAtMs } = electionPhase(now);
    await currentOffices(this.store, player.villageId, now);

    const candidacies = await this.store.listCandidacies(player.villageId, cycle);
    const votes = await this.store.listVotes(player.villageId, cycle);
    const mayVote = suffrageProblem(player, now) === null;

    const races = [];
    for (const office of POLITICS.offices) {
      const standing = candidacies.filter((c) => c.officeId === office.id);
      const candidates = [];
      for (const c of standing) {
        const p = await this.store.getPlayer(c.playerId);
        candidates.push({
          id: c.playerId,
          name: p?.name ?? 'unknown',
          // Live tallies are public. A hidden count is a count nobody can audit,
          // and there is nothing secret here worth the loss of trust.
          votes: votes.filter((v) => v.officeId === office.id && v.candidateId === c.playerId).length,
        });
      }
      races.push({
        officeId: office.id,
        name: office.name,
        seats: office.seats,
        candidates,
        yourVote: votes.find((v) => v.officeId === office.id && v.voterId === playerId)?.candidateId ?? null,
        youMayStand: phase === 'nomination' && mayStand(player, office.id)
          && !standing.some((c) => c.playerId === playerId),
        youMayVote: phase === 'voting' && mayVote,
      });
    }
    return [{ to: playerId, message: { type: 'election', villageId: player.villageId, cycle, phase, phaseEndsAtMs, races } }];
  }

  private async onStand(playerId: string, officeId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      await stand(this.store, player, officeId, this.now());
      return [{ to: playerId, message: { type: 'nominated', officeId } }];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onCastVote(playerId: string, officeId: string, candidateId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      await castVoteFor(this.store, player, officeId, candidateId, this.now());
      return [{ to: playerId, message: { type: 'voted', officeId, candidateId } }];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  /** Every decree runs the same gate: hold the office, and hold the power. */
  private async decree(
    playerId: string,
    power: 'setTax' | 'enactLaw' | 'commissionWork' | 'declareVillageWar',
    apply: (player: PlayerRecord, village: Awaited<ReturnType<typeof loadVillage>>) => Promise<string>,
  ): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const now = this.now();
    if (!(await holdsPower(this.store, player, power, now))) {
      return [{ to: playerId, message: { type: 'error', code: 'noPower' } }];
    }
    const village = await loadVillage(this.store, player.villageId);
    try {
      const detail = await apply(player, village);
      await this.store.saveVillage(village);
      const kind = power === 'setTax' ? 'tax' : power === 'commissionWork' ? 'commission' : power === 'declareVillageWar' ? 'war' : 'law';
      return [{ to: playerId, message: { type: 'decree', kind, detail } }];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private onSetTax(playerId: string, rate: number): Promise<Delivery[]> {
    return this.decree(playerId, 'setTax', async (_p, village) => {
      const set = setTax(village, rate, this.now());
      return `tax set to ${(set * 100).toFixed(1)}%`;
    });
  }

  private onEnactLaw(playerId: string, lawId: string): Promise<Delivery[]> {
    return this.decree(playerId, 'enactLaw', async (_p, village) => {
      enactLaw(village, lawId);
      return `${lawId} enacted`;
    });
  }

  private onRepealLaw(playerId: string, lawId: string): Promise<Delivery[]> {
    return this.decree(playerId, 'enactLaw', async (_p, village) => {
      repealLaw(village, lawId);
      return `${lawId} repealed`;
    });
  }

  private onCommission(playerId: string, commissionId: string): Promise<Delivery[]> {
    return this.decree(playerId, 'commissionWork', async (_p, village) => {
      const entry = commission(village, commissionId, this.now());
      return `${entry.id} commissioned`;
    });
  }

  private onDeclareVillageWar(playerId: string, villageId: string): Promise<Delivery[]> {
    return this.decree(playerId, 'declareVillageWar', async (_p, village) => {
      await declareVillageWar(this.store, village, villageId);
      return `war declared on ${VILLAGE_BY_ID.get(villageId)?.name ?? villageId}`;
    });
  }

  /* ── Dungeons ──────────────────────────────────────────────────────── */

  private async onListDungeons(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const now = this.now();
    return [{
      to: playerId,
      message: {
        type: 'dungeonList',
        season: currentSeason(now).id,
        dungeons: DUNGEONS.dungeons.map((d) => {
          const state = dungeonAvailability(d, player, now, d.keyItem ? held(player, d.keyItem) > 0 : true);
          return {
            id: d.id, name: d.name, regionId: d.regionId, blurb: d.blurb,
            open: state.open, reason: state.reason, runsLeftToday: runsLeftToday(player, now),
          };
        }),
      },
    }];
  }

  private async onEnterDungeon(playerId: string, dungeonId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    if (this.roomOf.has(playerId)) return [{ to: playerId, message: { type: 'error', code: 'inMatch' } }];
    try {
      const { run, consumesKey } = enterDungeon(player, dungeonId, null, this.now());
      // The key is spent on the way in, so a peek at the first room costs one.
      if (consumesKey) {
        if (held(player, consumesKey) < 1) throw new DungeonError('needKey');
        player.inventory[consumesKey] = held(player, consumesKey) - 1;
        if (player.inventory[consumesKey] === 0) delete player.inventory[consumesKey];
      }
      player.dungeon = run;
      await this.store.savePlayer(player);
      const view = roomView(run);
      return [{
        to: playerId,
        message: {
          type: 'dungeonRoom', dungeonId, roomId: view.roomId, index: view.index, total: view.total,
          prompt: view.prompt, hint: view.hint, attemptsLeft: run.attemptsLeft,
          expiresAtMs: run.startedAt + DUNGEONS.rules.runExpiryMinutes * 60_000,
        },
      }];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onAnswerRoom(playerId: string, answer: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player?.dungeon) return [{ to: playerId, message: { type: 'error', code: 'notInRun' } }];
    const dungeonId = player.dungeon.dungeonId;
    try {
      const now = this.now();
      const outcome = answerRoom(player, answer, now);

      if (outcome.kind === 'cleared') {
        const rewards = await this.payDungeon(player, dungeonId, now);
        await this.store.savePlayer(player);
        return rewards;
      }
      await this.store.savePlayer(player);

      if (outcome.kind === 'failed') {
        return [{ to: playerId, message: { type: 'dungeonFailed', dungeonId, note: 'The room closes. Come back with a better guess.' } }];
      }
      if (outcome.kind === 'wrong') {
        return [{
          to: playerId,
          message: { type: 'dungeonProgress', dungeonId, correct: false, note: `Wrong. ${outcome.attemptsLeft} left.` },
        }];
      }
      const view = roomView(player.dungeon!);
      return [
        { to: playerId, message: { type: 'dungeonProgress', dungeonId, correct: true, note: 'The way opens.' } },
        {
          to: playerId,
          message: {
            type: 'dungeonRoom', dungeonId, roomId: view.roomId, index: view.index, total: view.total,
            prompt: view.prompt, hint: view.hint, attemptsLeft: player.dungeon!.attemptsLeft,
            expiresAtMs: player.dungeon!.startedAt + DUNGEONS.rules.runExpiryMinutes * 60_000,
          },
        },
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  /** Rewards are applied once, at the moment the last room is answered. */
  private async payDungeon(player: PlayerRecord, dungeonId: string, nowMs: number): Promise<Delivery[]> {
    const dungeon = DUNGEONS.dungeons.find((d) => d.id === dungeonId)!;
    const r = dungeon.rewards;
    player.ryo += r.ryo;
    for (const item of r.items) {
      try { give(player, item.item, item.qty); } catch { /* stack full */ }
    }
    // A technique is added to `known`; the loadout rules still apply, so this is
    // access to a technique rather than power handed over directly.
    let jutsu: string | null = null;
    if (r.jutsu && !player.known.includes(r.jutsu)) { player.known.push(r.jutsu); jutsu = r.jutsu; }
    const cosmetic = r.cosmetic && grantCosmetic(player, r.cosmetic) ? r.cosmetic : null;

    let legendary: string | null = null;
    if (r.legendary) {
      try {
        await this.store.claimLegendary({ itemId: r.legendary, holderId: player.id, acquiredAt: nowMs }, nowMs);
        legendary = r.legendary;
      } catch {
        // Somebody already holds it. One per server, and the store is what says so.
        legendary = null;
      }
    }
    return [{
      to: player.id,
      message: {
        type: 'dungeonCleared', dungeonId, ryo: r.ryo,
        items: r.items.map((i) => ({ item: i.item, qty: i.qty })),
        jutsu, cosmetic, legendary,
      },
    }];
  }

  private async onAbandonDungeon(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    // The run is spent either way: walking out does not give the attempt back.
    player.dungeon = null;
    await this.store.savePlayer(player);
    return [{ to: playerId, message: { type: 'dungeonFailed', dungeonId: '', note: 'You leave the way you came.' } }];
  }

  /* ── Mentorship ────────────────────────────────────────────────────── */

  private async mentorView(playerId: string): Promise<Delivery[]> {
    const records = await this.store.listMentorshipsFor(playerId);
    const asMentor = [];
    for (const m of records.filter((x) => x.mentorId === playerId && x.status === 'active')) {
      const mentee = await this.store.getPlayer(m.menteeId);
      asMentor.push({
        menteeId: m.menteeId,
        menteeName: mentee?.name ?? 'unknown',
        startedAt: m.startedAt,
        milestones: m.rewarded,
      });
    }
    const mine = records.find((x) => x.menteeId === playerId && x.status === 'active');
    const mentor = mine ? await this.store.getPlayer(mine.mentorId) : null;
    const offers = [];
    for (const m of records.filter((x) => x.menteeId === playerId && x.status === 'offered')) {
      const from = await this.store.getPlayer(m.mentorId);
      offers.push({ mentorId: m.mentorId, mentorName: from?.name ?? 'unknown' });
    }
    return [{
      to: playerId,
      message: {
        type: 'mentorship',
        asMentor,
        asMentee: mine && mentor
          ? {
            mentorId: mine.mentorId, mentorName: mentor.name, startedAt: mine.startedAt,
            trainingBonus: MENTORSHIP.mentee.trainingBonus,
          }
          : null,
        offers,
      },
    }];
  }

  private async onMentorStatus(playerId: string): Promise<Delivery[]> {
    return this.mentorView(playerId);
  }

  private async onOfferMentorship(playerId: string, name: string): Promise<Delivery[]> {
    const mentor = await this.player(playerId);
    const mentee = await this.store.getPlayerByName(name);
    if (!mentor || !mentee) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      await offerMentorship(this.store, mentor, mentee, this.now());
      return [
        { to: playerId, message: { type: 'mentorshipOffered', menteeName: mentee.name } },
        ...(await this.mentorView(mentee.id)),
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onAcceptMentorship(playerId: string, mentorId: string): Promise<Delivery[]> {
    const mentee = await this.player(playerId);
    if (!mentee) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const offer = (await this.store.listMentorshipsFor(playerId))
      .find((m) => m.mentorId === mentorId && m.menteeId === playerId && m.status === 'offered');
    if (!offer) return [{ to: playerId, message: { type: 'error', code: 'noSuchOffer' } }];
    try {
      await acceptMentorship(this.store, offer, mentee, this.now());
      await this.store.savePlayer(mentee);
      const mentor = await this.store.getPlayer(mentorId);
      return [
        { to: playerId, message: { type: 'mentorshipStarted', withName: mentor?.name ?? 'unknown', asMentor: false } },
        { to: mentorId, message: { type: 'mentorshipStarted', withName: mentee.name, asMentor: true } },
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onEndMentorship(playerId: string): Promise<Delivery[]> {
    const records = await this.store.listMentorshipsFor(playerId);
    const active = activeOf(records, playerId);
    if (!active) return [{ to: playerId, message: { type: 'error', code: 'notPaired' } }];
    const mentor = await this.store.getPlayer(active.mentorId);
    const mentee = await this.store.getPlayer(active.menteeId);

    // The student's parting gift is untradable, which is what stops it becoming
    // a way to mint goods out of a pairing.
    if (mentor && playerId === active.menteeId) {
      try { give(mentor, MENTORSHIP.mentor.graduationGift, 1); } catch { /* already holds one */ }
      const emote = COSMETICS.items.find((c) => c.source === 'mentor');
      if (emote) grantCosmetic(mentor, emote.id);
    }
    await endMentorship(this.store, active, this.now(), mentor);
    if (mentor) await this.store.savePlayer(mentor);

    const note = 'The pairing ends.';
    const out: Delivery[] = [];
    if (mentor) out.push({ to: mentor.id, message: { type: 'mentorshipEnded', withName: mentee?.name ?? 'unknown', note } });
    if (mentee) out.push({ to: mentee.id, message: { type: 'mentorshipEnded', withName: mentor?.name ?? 'unknown', note } });
    return out;
  }

  /**
   * Pay a mentor for what their student has done. Called after anything that
   * could move a mentee forward; every gate lives in `duePayouts`, so this
   * cannot pay twice however often it runs.
   */
  private async payMentor(mentee: PlayerRecord): Promise<Delivery[]> {
    const records = await this.store.listMentorshipsFor(mentee.id);
    const active = records.find((m) => m.menteeId === mentee.id && m.status === 'active');
    if (!active) return [];
    const mentor = await this.store.getPlayer(active.mentorId);
    if (!mentor) return [];

    const payouts = duePayouts(active, mentee, 'academy', this.now());
    if (payouts.length === 0) return [];

    const out: Delivery[] = [];
    for (const p of payouts) {
      mentor.reputation += p.reputation;
      if (mentor.clanId) mentor.clanContribution += p.clanContribution;
      out.push({
        to: mentor.id,
        message: {
          type: 'menteeMilestone', menteeName: mentee.name, milestoneId: p.milestoneId,
          reputation: p.reputation, contribution: p.clanContribution,
        },
      });
    }
    recordPayouts(active, payouts, this.now());
    await this.store.saveMentorship(active);
    await this.store.savePlayer(mentor);
    return out;
  }

  /* ── Cosmetics ─────────────────────────────────────────────────────── */

  private async onListCosmetics(playerId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    const now = this.now();
    return [{
      to: playerId,
      message: {
        type: 'cosmetics',
        owned: player.cosmetics,
        equipped: { ...defaultLoadout(), ...player.equipped },
        catalogue: COSMETICS.items.map((c) => {
          const state = cosmeticAvailability(player, c.id, now);
          return {
            id: c.id, name: c.name, slot: c.slot, source: c.source,
            price: state.price, owned: player.cosmetics.includes(c.id) || c.source === 'default',
            available: state.available, reason: state.reason,
          };
        }),
      },
    }];
  }

  private async onBuyCosmetic(playerId: string, cosmeticId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const paid = buyCosmetic(player, cosmeticId, this.now());
      await this.store.savePlayer(player);
      return [
        { to: playerId, message: { type: 'cosmeticBought', cosmeticId, paid } },
        { to: playerId, message: this.profileFor(player) },
      ];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  private async onEquipCosmetic(playerId: string, cosmeticId: string): Promise<Delivery[]> {
    const player = await this.player(playerId);
    if (!player) return [{ to: playerId, message: { type: 'error', code: 'noSuchPlayer' } }];
    try {
      const slot = equipCosmetic(player, cosmeticId);
      await this.store.savePlayer(player);
      return [{ to: playerId, message: { type: 'cosmeticEquipped', cosmeticId, slot } }];
    } catch (err) { return this.metaFail(playerId, err); }
  }

  /* ── Introspection for tests and ops ───────────────────────────────── */

  roomFor(playerId: string): MatchRoom | undefined {
    const id = this.roomOf.get(playerId);
    return id ? this.rooms.get(id) : undefined;
  }
  get activeRooms(): number { return this.rooms.size; }
  get roundTimeoutMs(): number { return ROUND_TIMEOUT_MS; }
}
