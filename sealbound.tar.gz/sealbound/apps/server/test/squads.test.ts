import { beforeEach, describe, expect, it } from 'vitest';
import { MISSIONS, MISSION_BY_ID } from '@shinobi/content';
import type { ServerMessage, Stats } from '@shinobi/shared';
import { GameService } from '../src/service.js';
import { MemoryStore, type PlayerRecord } from '../src/store/index.js';
import { partySuccessChance, resolvePartyMission } from '../src/squads.js';

const PARTY = MISSIONS.missions.find((m) => m.party > 1)!;

const stats = (o: Partial<Stats> = {}): Stats => ({
  ninjutsu: 150, taijutsu: 150, genjutsu: 150, intelligence: 150,
  strength: 150, speed: 150, stamina: 150, handSeals: 150, ...o,
});

const player = (id: string, o: Partial<PlayerRecord> = {}): PlayerRecord => ({
  id, name: id, villageId: 'konohagakure', clanId: null, clanJoinedAt: null, clanContribution: 0, bloodlineId: null,
  rank: 'anbu', level: 70, xp: 0, stats: stats(), affinity: 'fire',
  loadout: [], known: [], reputation: 300, ryo: 0, training: null, mission: null,
  missionsAtRank: 0, missionsCompleted: 0, squadId: null, rogue: false, defectedAt: null, notoriety: 0,
  titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0, sRankCompleted: 0, rating: 1400, ...o,
});

let store: MemoryStore;
let clock: number;
let svc: GameService;

beforeEach(async () => {
  store = new MemoryStore();
  clock = 1_700_000_000_000;
  svc = new GameService(store, () => clock);
  for (const id of ['kaito', 'rin', 'sora', 'toma']) await store.createPlayer(player(id));
});

const first = (out: { message: ServerMessage }[]) => out[0]!.message;
const code = (out: { message: ServerMessage }[]) => (first(out) as { code?: string }).code;

/** Forms a squad of `names`, all invites accepted. Returns the squad id. */
async function formSquad(names: string[]): Promise<string> {
  const created = await svc.handle(names[0]!, { type: 'createSquad' });
  const squadId = (first(created) as { squadId: string }).squadId;
  for (const name of names.slice(1)) {
    await svc.handle(names[0]!, { type: 'inviteToSquad', name });
    await svc.handle(name, { type: 'acceptSquadInvite', squadId });
  }
  return squadId;
}

/* ── Consent ─────────────────────────────────────────────────────────── */

describe('joining a squad is opt-in', () => {
  it('an invite alone does not put anyone in the squad', async () => {
    const created = await svc.handle('kaito', { type: 'createSquad' });
    const squadId = (first(created) as { squadId: string }).squadId;
    await svc.handle('kaito', { type: 'inviteToSquad', name: 'rin' });

    expect((await store.getPlayer('rin'))!.squadId).toBeNull();
    const squad = await store.getSquad(squadId);
    expect(squad!.memberIds).not.toContain('rin');
    expect(squad!.invitedIds).toContain('rin');
  });

  it('accepting joins, and the whole squad is told', async () => {
    const created = await svc.handle('kaito', { type: 'createSquad' });
    const squadId = (first(created) as { squadId: string }).squadId;
    await svc.handle('kaito', { type: 'inviteToSquad', name: 'rin' });
    const out = await svc.handle('rin', { type: 'acceptSquadInvite', squadId });

    expect(out.map((d) => d.to).sort()).toEqual(['kaito', 'rin']);
    expect((await store.getPlayer('rin'))!.squadId).toBe(squadId);
  });

  it('cannot be joined without an invite', async () => {
    const created = await svc.handle('kaito', { type: 'createSquad' });
    const squadId = (first(created) as { squadId: string }).squadId;
    expect(code(await svc.handle('rin', { type: 'acceptSquadInvite', squadId }))).toBe('notInvited');
  });

  it('only the leader may invite', async () => {
    const squadId = await formSquad(['kaito', 'rin']);
    expect(code(await svc.handle('rin', { type: 'inviteToSquad', name: 'sora' }))).toBe('notLeader');
    void squadId;
  });

  it('refuses a player who is already in a squad', async () => {
    await formSquad(['kaito', 'rin']);
    await svc.handle('sora', { type: 'createSquad' });
    expect(code(await svc.handle('kaito', { type: 'inviteToSquad', name: 'sora' }))).toBe('alreadyInSquad');
  });

  it('caps the squad size', async () => {
    await formSquad(['kaito', 'rin', 'sora', 'toma']);
    await store.createPlayer(player('fifth'));
    expect(code(await svc.handle('kaito', { type: 'inviteToSquad', name: 'fifth' }))).toBe('squadFull');
  });

  it('cannot create a second squad while in one', async () => {
    await formSquad(['kaito']);
    expect(code(await svc.handle('kaito', { type: 'createSquad' }))).toBe('alreadyInSquad');
  });
});

/* ── Eligibility ─────────────────────────────────────────────────────── */

describe('a squad is not a way to smuggle someone in', () => {
  it('refuses if any member is below the mission rank', async () => {
    await store.savePlayer(player('rin', { rank: 'genin' }));
    await formSquad(['kaito', 'rin', 'sora']);
    expect(code(await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id }))).toBe('rankLocked');
  });

  it('refuses if any member is too disreputable to be given work', async () => {
    await store.savePlayer(player('sora', { reputation: -80 }));
    await formSquad(['kaito', 'rin', 'sora']);
    expect(code(await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id }))).toBe('reputationLocked');
  });

  it('refuses a squad smaller than the mission requires', async () => {
    await formSquad(['kaito', 'rin']);
    expect(code(await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id }))).toBe('tooFewMembers');
  });

  it('refuses a solo mission taken as a party', async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    expect(code(await svc.handle('kaito', { type: 'acceptPartyMission', missionId: 'clear-the-canal' }))).toBe('notAPartyMission');
  });

  it('only the leader may commit the squad', async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    expect(code(await svc.handle('rin', { type: 'acceptPartyMission', missionId: PARTY.id }))).toBe('notLeader');
  });

  it('averages the squad rather than summing, so passengers do not carry', () => {
    const specialist = [player('a', { stats: stats({ [PARTY.stat]: 400 } as Partial<Stats>) })];
    const withPassengers = [
      ...specialist,
      player('b', { stats: stats({ [PARTY.stat]: 10 } as Partial<Stats>) }),
      player('c', { stats: stats({ [PARTY.stat]: 10 } as Partial<Stats>) }),
    ];
    expect(partySuccessChance(withPassengers, PARTY)).toBeLessThan(partySuccessChance(specialist, PARTY));
  });
});

/* ── Nobody escapes the consequences ─────────────────────────────────── */

describe('a committed squad is locked', () => {
  beforeEach(async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id });
  });

  it('a member cannot walk away once the mission has started', async () => {
    expect(code(await svc.handle('rin', { type: 'leaveSquad' }))).toBe('squadLocked');
    expect((await store.getPlayer('rin'))!.squadId).not.toBeNull();
  });

  it('the leader cannot disband to dodge a failure either', async () => {
    expect(code(await svc.handle('kaito', { type: 'leaveSquad' }))).toBe('squadLocked');
  });

  it('nobody can be invited into a running mission', async () => {
    expect(code(await svc.handle('kaito', { type: 'inviteToSquad', name: 'toma' }))).toBe('squadLocked');
  });

  it('the squad cannot take a second mission', async () => {
    expect(code(await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id }))).toBe('squadLocked');
  });

  it('cannot be reported early', async () => {
    expect(code(await svc.handle('kaito', { type: 'completePartyMission' }))).toBe('notFinished');
  });
});

/* ── Resolution ──────────────────────────────────────────────────────── */

describe('party mission resolution', () => {
  it('pays every member and dissolves the squad', async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id });
    clock += PARTY.minutes * 60_000;

    const out = await svc.handle('rin', { type: 'completePartyMission' });
    const resolved = out.filter((d) => d.message.type === 'partyMissionResolved');
    expect(resolved.map((d) => d.to).sort()).toEqual(['kaito', 'rin', 'sora']);

    for (const id of ['kaito', 'rin', 'sora']) {
      const p = await store.getPlayer(id);
      expect(p!.squadId).toBeNull();
      expect(p!.xp).toBeGreaterThan(0);
    }
  });

  it('gives the same answer however many times it is asked', async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id });
    const squad = (await store.getSquad((await store.getPlayer('kaito'))!.squadId!))!;
    const members: PlayerRecord[] = [];
    for (const id of squad.memberIds) members.push((await store.getPlayer(id))!);

    const at = squad.mission!.startedAt + PARTY.minutes * 60_000;
    const answers = Array.from({ length: 6 }, () => resolvePartyMission(squad, members, at).success);
    expect(new Set(answers).size).toBe(1);
  });

  it('splits the purse rather than paying each member in full', async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id });
    clock += PARTY.minutes * 60_000;
    const out = await svc.handle('kaito', { type: 'completePartyMission' });
    const msg = out.find((d) => d.message.type === 'partyMissionResolved')!.message as { ryo: number; success: boolean };

    // Whatever the outcome, three shares must add up to no more than the purse.
    const purse = msg.success ? PARTY.ryo : PARTY.ryo * MISSIONS.failure.ryoShare;
    expect(msg.ryo * 3).toBeLessThanOrEqual(Math.round(purse) + 3);
    expect(msg.ryo).toBeGreaterThan(0);
  });

  it('cannot be reported twice for a second payout', async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id });
    clock += PARTY.minutes * 60_000;
    await svc.handle('kaito', { type: 'completePartyMission' });
    const paid = (await store.getPlayer('kaito'))!.ryo;

    expect(code(await svc.handle('kaito', { type: 'completePartyMission' }))).toBe('notInSquad');
    expect((await store.getPlayer('kaito'))!.ryo).toBe(paid);
  });

  it('leaves everyone free to take work again afterwards', async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id });
    clock += PARTY.minutes * 60_000;
    await svc.handle('kaito', { type: 'completePartyMission' });
    const out = await svc.handle('rin', { type: 'acceptMission', missionId: 'clear-the-canal' });
    expect(first(out).type).toBe('missionAccepted');
  });
});

/* ── Interaction with solo work ──────────────────────────────────────── */

describe('squads and solo work do not overlap', () => {
  it('refuses to invite someone already away on a mission', async () => {
    await svc.handle('rin', { type: 'acceptMission', missionId: 'clear-the-canal' });
    await formSquad(['kaito']);
    expect(code(await svc.handle('kaito', { type: 'inviteToSquad', name: 'rin' }))).toBe('busy');
  });

  it('refuses to commit a squad whose member is away on a solo mission', async () => {
    await formSquad(['kaito', 'rin', 'sora']);
    const rin = (await store.getPlayer('rin'))!;
    rin.mission = { missionId: 'clear-the-canal', startedAt: clock };
    await store.savePlayer(rin);
    expect(code(await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id }))).toBe('busy');
  });

  it('leaving before the mission frees the player and can disband the squad', async () => {
    await formSquad(['kaito', 'rin']);
    await svc.handle('rin', { type: 'leaveSquad' });
    expect((await store.getPlayer('rin'))!.squadId).toBeNull();
    await svc.handle('kaito', { type: 'leaveSquad' });
    expect((await store.getPlayer('kaito'))!.squadId).toBeNull();
  });

  it('S-rank work is now reachable, where it used to be refused outright', async () => {
    const solo = await svc.handle('kaito', { type: 'acceptMission', missionId: PARTY.id });
    expect(code(solo)).toBe('needsParty');

    await formSquad(['kaito', 'rin', 'sora']);
    const party = await svc.handle('kaito', { type: 'acceptPartyMission', missionId: PARTY.id });
    expect(first(party).type).toBe('squad');
    expect(MISSION_BY_ID.get(PARTY.id)!.rank).toBe('S');
  });
});
