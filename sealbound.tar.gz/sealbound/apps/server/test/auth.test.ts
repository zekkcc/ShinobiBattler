import { beforeEach, describe, expect, it } from 'vitest';
import { Accounts, StoreSessionResolver, newPlayer } from '../src/accounts.js';
import { hashPassword, hashToken, issueSession, normaliseName, verifyPassword } from '../src/auth.js';
import { buildServer } from '../src/app.js';
import { MemoryStore } from '../src/store/index.js';

let store: MemoryStore;
let clock: number;
let accounts: Accounts;

beforeEach(() => {
  store = new MemoryStore();
  clock = 1_700_000_000_000;
  accounts = new Accounts(store, () => clock);
});

const good = { name: 'Kaito Vess', password: 'correct horse battery', villageId: 'konohagakure' };

/* ── Password storage ────────────────────────────────────────────────── */

describe('password storage', () => {
  it('never stores the password itself', async () => {
    const r = await accounts.register(good);
    expect(r.ok).toBe(true);
    const account = await store.getAccountByNameKey(normaliseName(good.name));
    expect(account!.password).not.toContain(good.password);
    expect(account!.password.startsWith('scrypt$')).toBe(true);
  });

  it('salts, so the same password hashes differently every time', async () => {
    const a = await hashPassword('the same password');
    const b = await hashPassword('the same password');
    expect(a).not.toBe(b);
    expect(await verifyPassword('the same password', a)).toBe(true);
    expect(await verifyPassword('the same password', b)).toBe(true);
  });

  it('accepts the right password and rejects a wrong one', async () => {
    const stored = await hashPassword('a real password here');
    expect(await verifyPassword('a real password here', stored)).toBe(true);
    expect(await verifyPassword('a real password heer', stored)).toBe(false);
    expect(await verifyPassword('', stored)).toBe(false);
  });

  it('rejects a malformed or tampered digest instead of throwing', async () => {
    for (const bad of ['', 'nonsense', 'scrypt$1$2$3', 'md5$1$1$1$c2FsdA==$ZA==', 'scrypt$x$x$x$!!$!!']) {
      expect(await verifyPassword('anything', bad)).toBe(false);
    }
  });

  it('records the cost parameters so they can be raised later', async () => {
    const stored = await hashPassword('a real password here');
    const [scheme, n, r, p] = stored.split('$');
    expect(scheme).toBe('scrypt');
    expect(Number(n)).toBeGreaterThanOrEqual(16384);
    expect(Number(r)).toBeGreaterThan(0);
    expect(Number(p)).toBeGreaterThan(0);
  });
});

/* ── Session tokens ──────────────────────────────────────────────────── */

describe('session tokens', () => {
  it('stores only the hash, so a database dump does not yield live sessions', async () => {
    const result = await accounts.register(good);
    if (!result.ok) throw new Error('registration failed');
    const stored = await store.getSession(hashToken(result.token));
    expect(stored).not.toBeNull();
    expect(JSON.stringify(stored)).not.toContain(result.token);
  });

  it('issues an unguessable token', () => {
    const seen = new Set<string>();
    for (let i = 0; i < 200; i++) seen.add(issueSession(0).token);
    expect(seen.size).toBe(200);
    expect([...seen][0]!.length).toBeGreaterThanOrEqual(40);
  });

  it('carries nothing the client could edit', async () => {
    const result = await accounts.register(good);
    if (!result.ok) throw new Error('registration failed');
    // The token is opaque: it is not a JWT and encodes no identity or expiry.
    expect(result.token).not.toContain('.');
    const decoded = Buffer.from(result.token, 'base64url').toString('utf8');
    expect(decoded).not.toContain(result.playerId);
    expect(decoded).not.toContain('academy');
  });

  it('resolves a live session to the right player', async () => {
    const result = await accounts.register(good);
    if (!result.ok) throw new Error('registration failed');
    const resolver = new StoreSessionResolver(store, () => clock);
    expect(await resolver.resolve(result.token)).toBe(result.playerId);
  });

  it('rejects an unknown, empty, or altered token', async () => {
    const result = await accounts.register(good);
    if (!result.ok) throw new Error('registration failed');
    const resolver = new StoreSessionResolver(store, () => clock);
    expect(await resolver.resolve(undefined)).toBeNull();
    expect(await resolver.resolve('')).toBeNull();
    expect(await resolver.resolve('not-a-token')).toBeNull();
    expect(await resolver.resolve(`${result.token}x`)).toBeNull();
  });

  it('rejects an expired session and deletes it on sight', async () => {
    const result = await accounts.register(good);
    if (!result.ok) throw new Error('registration failed');
    const resolver = new StoreSessionResolver(store, () => clock);
    clock += 31 * 24 * 60 * 60 * 1000;
    expect(await resolver.resolve(result.token)).toBeNull();
    expect(await store.getSession(hashToken(result.token))).toBeNull();
  });

  it('logout invalidates the token immediately', async () => {
    const result = await accounts.register(good);
    if (!result.ok) throw new Error('registration failed');
    const resolver = new StoreSessionResolver(store, () => clock);
    await accounts.logout(result.token);
    expect(await resolver.resolve(result.token)).toBeNull();
  });

  it('sweeping removes expired sessions and leaves live ones alone', async () => {
    const a = await accounts.register(good);
    clock += 40 * 24 * 60 * 60 * 1000;
    const b = await accounts.register({ ...good, name: 'Rin Karrow' });
    if (!a.ok || !b.ok) throw new Error('registration failed');
    expect(await accounts.sweepSessions()).toBe(1);
    const resolver = new StoreSessionResolver(store, () => clock);
    expect(await resolver.resolve(a.token)).toBeNull();
    expect(await resolver.resolve(b.token)).toBe(b.playerId);
  });
});

/* ── Login cannot be used to learn who plays here ────────────────────── */

describe('login does not leak', () => {
  it('gives the same answer for a wrong name and a wrong password', async () => {
    await accounts.register(good);
    const noSuchName = await accounts.login({ name: 'Nobody At All', password: good.password });
    const wrongPassword = await accounts.login({ name: good.name, password: 'wrong password here' });
    expect(noSuchName.ok).toBe(false);
    expect(wrongPassword.ok).toBe(false);
    if (noSuchName.ok || wrongPassword.ok) throw new Error('unreachable');
    expect(noSuchName.code).toBe(wrongPassword.code);
    expect(noSuchName.detail).toBe(wrongPassword.detail);
  });

  it('does the hashing work even when the account does not exist', async () => {
    await accounts.register(good);
    await accounts.login({ name: 'warmup', password: 'warmup password' });

    const time = async (fn: () => Promise<unknown>) => {
      const t0 = performance.now();
      await fn();
      return performance.now() - t0;
    };
    const missing = await time(() => accounts.login({ name: 'Nobody At All', password: good.password }));
    const wrong = await time(() => accounts.login({ name: good.name, password: 'wrong password here' }));

    // Skipping the hash on an unknown name would make it near-instant, which is a
    // free user-enumeration oracle. Bounds are loose because this is a timing test.
    expect(missing).toBeGreaterThan(wrong * 0.25);
  });

  it('lets a registered player log back in', async () => {
    await accounts.register(good);
    const again = await accounts.login({ name: good.name, password: good.password });
    expect(again.ok).toBe(true);
  });
});

/* ── Registration rules ──────────────────────────────────────────────── */

describe('registration', () => {
  it('creates the shinobi alongside the account', async () => {
    const result = await accounts.register(good);
    if (!result.ok) throw new Error('registration failed');
    const player = await store.getPlayer(result.playerId);
    expect(player!.name).toBe('Kaito Vess');
    expect(player!.rank).toBe('academy');
    expect(player!.level).toBe(1);
    expect(player!.known).toEqual([]);
    expect(player!.villageId).toBe('konohagakure');
  });

  it('refuses a name somebody already has, ignoring case and spacing', async () => {
    await accounts.register(good);
    for (const name of ['kaito vess', 'KAITO VESS', 'Kaito-Vess', 'Kaito_Vess']) {
      const clash = await accounts.register({ ...good, name });
      expect(clash.ok).toBe(false);
      if (!clash.ok) expect(clash.code).toBe('nameTaken');
    }
  });

  it('refuses names that are too short, too long, or full of punctuation', async () => {
    // Note: surrounding whitespace is trimmed rather than rejected, so ' Kaito '
    // is a valid way to type a valid name.
    for (const name of ['ab', 'x'.repeat(40), '!!!!', '   ', '<script>', 'trailing-']) {
      const result = await accounts.register({ ...good, name });
      expect(result.ok).toBe(false);
    }
  });

  it('refuses a weak password and says what is wrong', async () => {
    const result = await accounts.register({ ...good, password: 'short' });
    expect(result.ok).toBe(false);
    if (!result.ok) {
      expect(result.code).toBe('weakPassword');
      expect(result.detail).toContain('10');
    }
  });

  it('refuses a village that does not exist', async () => {
    const result = await accounts.register({ ...good, villageId: 'atlantis' });
    expect(result.ok).toBe(false);
  });

  it('rolls the bloodline server-side, and the client cannot ask for one', async () => {
    const withBloodline = new Set<string | null>();
    for (let i = 0; i < 60; i++) {
      const p = newPlayer(`id-${i}`, `Name ${i}`, 'konohagakure', `seed-${i}`);
      withBloodline.add(p.bloodlineId);
    }
    // Most characters have none; the roll is not something registration accepts.
    expect(withBloodline.has(null)).toBe(true);
    expect(Object.keys({} as Record<string, never>)).not.toContain('bloodlineId');
  });
});

/* ── Over HTTP ───────────────────────────────────────────────────────── */

describe('the auth endpoints', () => {
  it('registers, logs in, and rejects a bad password', async () => {
    const app = await buildServer({ store, now: () => clock });

    const created = await app.inject({
      method: 'POST', url: '/api/register',
      payload: { name: 'Rin Karrow', password: 'a good long password', villageId: 'kirigakure' },
    });
    expect(created.statusCode).toBe(201);
    const token = created.json<{ token: string }>().token;
    expect(token).toBeTruthy();

    const ok = await app.inject({
      method: 'POST', url: '/api/login',
      payload: { name: 'Rin Karrow', password: 'a good long password' },
    });
    expect(ok.statusCode).toBe(200);

    const bad = await app.inject({
      method: 'POST', url: '/api/login',
      payload: { name: 'Rin Karrow', password: 'not the password' },
    });
    expect(bad.statusCode).toBe(401);
    expect(bad.json<{ detail: string }>().detail).not.toContain('password is wrong');

    const out = await app.inject({
      method: 'POST', url: '/api/logout', headers: { authorization: `Bearer ${token}` },
    });
    expect(out.statusCode).toBe(200);
    await app.close();
  });

  it('rejects a malformed body without touching the store', async () => {
    const app = await buildServer({ store, now: () => clock });
    // Malformed requests deliberately consume rate budget — otherwise sending
    // junk would be a free way to probe the endpoint — so this stays inside the
    // registration burst.
    for (const payload of [{}, { name: 'x' }, { name: 1, password: 2 }]) {
      const res = await app.inject({ method: 'POST', url: '/api/register', payload });
      expect(res.statusCode).toBe(400);
    }
    expect(await store.getAccountByNameKey('x')).toBeNull();
    await app.close();
  });

  it('throttles password guessing', async () => {
    const app = await buildServer({ store, now: () => clock });
    await app.inject({
      method: 'POST', url: '/api/register',
      payload: { name: 'Rin Karrow', password: 'a good long password', villageId: 'kirigakure' },
    });

    let throttled = 0;
    for (let i = 0; i < 12; i++) {
      const res = await app.inject({
        method: 'POST', url: '/api/login',
        payload: { name: 'Rin Karrow', password: `guess-${i}` },
      });
      if (res.statusCode === 429) throttled++;
    }
    expect(throttled).toBeGreaterThan(0);
    await app.close();
  });

  it('does not hand out a session on a failed login', async () => {
    const app = await buildServer({ store, now: () => clock });
    const res = await app.inject({
      method: 'POST', url: '/api/login', payload: { name: 'ghost', password: 'whatever it is' },
    });
    expect(res.statusCode).toBe(401);
    expect(res.json<{ token?: string }>().token).toBeUndefined();
    await app.close();
  });
});
