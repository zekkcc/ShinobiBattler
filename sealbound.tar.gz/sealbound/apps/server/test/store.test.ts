import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { PGlite } from '@electric-sql/pglite';
import type { Stats } from '@shinobi/shared';
import { MemoryStore, type PlayerRecord, type Store } from '../src/store/index.js';
import { migrate, PostgresStore } from '../src/store/postgres.js';
import { GameService } from '../src/service.js';

/**
 * One contract, two implementations.
 *
 * Running the same suite against both is the only thing that actually proves
 * they are interchangeable — and it executes schema.sql, which had never been
 * run at all before this file existed.
 */

const stats = (o: Partial<Stats> = {}): Stats => ({
  ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60,
  strength: 60, speed: 60, stamina: 60, handSeals: 60, ...o,
});

const player = (id: string, o: Partial<PlayerRecord> = {}): PlayerRecord => ({
  id, name: id, villageId: 'konohagakure', clanId: null, clanJoinedAt: null, clanContribution: 0, bloodlineId: null,
  rank: 'genin', level: 12, xp: 3400, stats: stats(), affinity: 'water',
  loadout: ['fireball-jutsu'], known: ['fireball-jutsu', 'chidori'],
  reputation: 17, ryo: 4200, training: null, mission: null,
  missionsAtRank: 3, missionsCompleted: 9, squadId: null, rogue: false, defectedAt: null, notoriety: 0,
  titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0, sRankCompleted: 0, rating: 1080, ...o,
});

const pg = new PGlite();
afterAll(async () => { await pg.close(); });

const implementations: { name: string; make: () => Promise<Store> }[] = [
  { name: 'MemoryStore', make: async () => new MemoryStore() },
  {
    name: 'PostgresStore',
    make: async () => {
      // Fresh schema per test so cases cannot leak into one another.
      await pg.query('DROP SCHEMA public CASCADE');
      await pg.query('CREATE SCHEMA public');
      await migrate(pg);
      return new PostgresStore(pg);
    },
  },
];

/** A player is owned by an account, so the account has to exist first. */
async function seed(store: Store, p: PlayerRecord): Promise<PlayerRecord> {
  await store.createAccount({ id: p.id, nameKey: p.id.toLowerCase(), password: 'scrypt$1$1$1$c2FsdA==$ZGlnZXN0' });
  await store.createPlayer(p);
  return p;
}

for (const impl of implementations) {
  describe(`store contract — ${impl.name}`, () => {
    let store: Store;
    beforeEach(async () => { store = await impl.make(); });

    it('round-trips a player unchanged', async () => {
      const p = player('kaito');
      await seed(store, p);
      const back = await store.getPlayer('kaito');
      expect(back).toEqual(p);
    });

    it('returns null for a player who does not exist', async () => {
      expect(await store.getPlayer('nobody')).toBeNull();
    });

    it('persists every field that progression writes', async () => {
      await seed(store, player('kaito'));
      const p = (await store.getPlayer('kaito'))!;
      p.rank = 'chunin';
      p.xp = 99_000;
      p.level = 31;
      p.ryo = 250_000;
      p.reputation = -40;
      p.missionsAtRank = 0;
      p.missionsCompleted = 44;
      p.rating = 1310;
      p.known = ['fireball-jutsu', 'chidori', 'amaterasu'];
      p.loadout = ['chidori'];
      p.bloodlineId = 'sharingan';
      p.stats.ninjutsu = 143.5;
      await store.savePlayer(p);
      expect(await store.getPlayer('kaito')).toEqual(p);
    });

    it('stores a training session and clears it again', async () => {
      await seed(store, player('kaito'));
      const p = (await store.getPlayer('kaito'))!;
      p.training = { stat: 'taijutsu', tier: 3, locationId: 'dojo', startedAt: 1_700_000_000_000 };
      await store.savePlayer(p);
      expect((await store.getPlayer('kaito'))!.training).toEqual(p.training);

      p.training = null;
      await store.savePlayer(p);
      expect((await store.getPlayer('kaito'))!.training).toBeNull();
    });

    it('stores a mission session and clears it again', async () => {
      await seed(store, player('kaito'));
      const p = (await store.getPlayer('kaito'))!;
      p.mission = { missionId: 'clear-the-canal', startedAt: 1_700_000_123_000 };
      await store.savePlayer(p);
      expect((await store.getPlayer('kaito'))!.mission).toEqual(p.mission);

      p.mission = null;
      await store.savePlayer(p);
      expect((await store.getPlayer('kaito'))!.mission).toBeNull();
    });

    it('keeps at most one training session per player', async () => {
      await seed(store, player('kaito'));
      const p = (await store.getPlayer('kaito'))!;
      p.training = { stat: 'taijutsu', tier: 1, locationId: 'dojo', startedAt: 1000 };
      await store.savePlayer(p);
      p.training = { stat: 'speed', tier: 4, locationId: 'forest', startedAt: 2000 };
      await store.savePlayer(p);
      const back = await store.getPlayer('kaito');
      expect(back!.training).toEqual(p.training);
    });

    it('does not let one player read another player state', async () => {
      await seed(store, player('kaito', { ryo: 1 }));
      await seed(store, player('rin', { ryo: 999 }));
      expect((await store.getPlayer('kaito'))!.ryo).toBe(1);
      expect((await store.getPlayer('rin'))!.ryo).toBe(999);
    });

    it('round-trips a clan, its officers, and its treasury', async () => {
      await seed(store, player('kaito'));
      await seed(store, player('rin'));
      await seed(store, player('sora'));
      const clan = {
        id: 'clan-1', name: 'Iron Lotus', nameKey: 'ironlotus', leaderId: 'kaito',
        memberIds: ['kaito', 'rin'], officerIds: ['rin'], invitedIds: ['sora'],
        bank: 42_000, foundedAt: 1_700_000_000_000,
        withdrawnToday: 1500, withdrawWindowStart: 1_700_000_100_000,
      };
      await store.createClan(clan);
      const back = await store.getClan('clan-1');
      expect(back!.leaderId).toBe('kaito');
      expect(back!.memberIds.sort()).toEqual(['kaito', 'rin']);
      expect(back!.officerIds).toEqual(['rin']);
      expect(back!.invitedIds).toEqual(['sora']);
      expect(back!.bank).toBe(42_000);
      expect(back!.withdrawnToday).toBe(1500);
    });

    it('finds a clan by its normalised name', async () => {
      await seed(store, player('kaito'));
      await store.createClan({
        id: 'clan-2', name: 'Iron Lotus', nameKey: 'ironlotus', leaderId: 'kaito',
        memberIds: ['kaito'], officerIds: [], invitedIds: [], bank: 0,
        foundedAt: 0, withdrawnToday: 0, withdrawWindowStart: 0,
      });
      expect((await store.getClanByNameKey('ironlotus'))!.name).toBe('Iron Lotus');
      expect(await store.getClanByNameKey('somethingelse')).toBeNull();
    });

    it('persists clan tenure and contribution on the player', async () => {
      // clanId now means the PLAYER clan and is foreign-keyed, so tenure and
      // contribution are checked without claiming membership of a clan that
      // does not exist.
      await seed(store, player('kaito', { clanJoinedAt: 1_700_000_500_000, clanContribution: 8800 }));
      const back = await store.getPlayer('kaito');
      expect(back!.clanJoinedAt).toBe(1_700_000_500_000);
      expect(back!.clanContribution).toBe(8800);
    });

    it('round-trips a missing-nin, including when they defected', async () => {
      await seed(store, player('kaito', { rogue: true, defectedAt: 1_700_000_777_000, notoriety: 143 }));
      const back = await store.getPlayer('kaito');
      expect(back!.rogue).toBe(true);
      expect(back!.defectedAt).toBe(1_700_000_777_000);
      expect(back!.notoriety).toBe(143);
    });

    it('lists only the players who have actually defected', async () => {
      await seed(store, player('kaito'));
      await seed(store, player('rin', { rogue: true, notoriety: 40 }));
      const rogues = await store.listRogues();
      expect(rogues.map((r) => r.id)).toEqual(['rin']);
    });

    it('round-trips a bounty contract with its locked value', async () => {
      await seed(store, player('kaito'));
      await seed(store, player('rin', { rogue: true, notoriety: 40 }));
      const contract = {
        id: 'c-1', hunterId: 'kaito', targetId: 'rin', value: 9400,
        acceptedAt: 1_700_000_000_000, expiresAt: 1_700_000_900_000,
      };
      await store.saveContract(contract);
      const back = await store.listContracts(0);
      expect(back).toEqual([contract]);
      await store.deleteContract('c-1');
      expect(await store.listContracts(0)).toEqual([]);
    });

    it('round-trips a squad, including who is only invited', async () => {
      await seed(store, player('kaito'));
      await seed(store, player('rin'));
      await seed(store, player('sora'));
      const squad = {
        id: 'squad-1', leaderId: 'kaito',
        memberIds: ['kaito', 'rin'], invitedIds: ['sora'],
        mission: null,
      };
      await store.createSquad(squad);
      const back = await store.getSquad('squad-1');
      expect(back!.leaderId).toBe('kaito');
      expect(back!.memberIds.sort()).toEqual(['kaito', 'rin']);
      expect(back!.invitedIds).toEqual(['sora']);
      expect(back!.mission).toBeNull();
    });

    it('round-trips a committed squad mission', async () => {
      await seed(store, player('kaito'));
      await seed(store, player('rin'));
      await store.createSquad({
        id: 'squad-2', leaderId: 'kaito', memberIds: ['kaito', 'rin'], invitedIds: [], mission: null,
      });
      const squad = (await store.getSquad('squad-2'))!;
      squad.mission = { missionId: 'the-long-winter', startedAt: 1_700_000_500_000 };
      await store.saveSquad(squad);
      expect((await store.getSquad('squad-2'))!.mission).toEqual(squad.mission);
    });

    it('deleting a squad releases its members', async () => {
      await seed(store, player('kaito'));
      await store.createSquad({ id: 'squad-3', leaderId: 'kaito', memberIds: ['kaito'], invitedIds: [], mission: null });
      await store.deleteSquad('squad-3');
      expect(await store.getSquad('squad-3')).toBeNull();
    });

    it('round-trips a replay as seed and actions', async () => {
      await seed(store, player('kaito'));
      await seed(store, player('rin'));
      const replay = {
        matchId: 'm-1', seed: 'seed-1',
        fighterIds: ['kaito', 'rin'] as [string, string],
        actions: [
          { fighterId: 'kaito', actionId: 'fireball-jutsu', targetId: 'rin', submittedBy: 'kaito' },
          { fighterId: 'rin', actionId: 'basic-strike', targetId: 'kaito', submittedBy: 'rin' },
        ],
        winnerId: 'kaito', outcome: 'ko', rounds: 14, endedAt: 1_700_000_000_000,
      };
      await store.saveReplay(replay);
      expect(await store.getReplay('m-1')).toEqual(replay);
    });

    it('lists replays for a player, newest first', async () => {
      await seed(store, player('kaito'));
      await seed(store, player('rin'));
      const base = {
        fighterIds: ['kaito', 'rin'] as [string, string],
        actions: [], winnerId: null, outcome: 'draw', rounds: 3,
      };
      await store.saveReplay({ ...base, matchId: 'm-old', seed: 's1', endedAt: 1000 });
      await store.saveReplay({ ...base, matchId: 'm-new', seed: 's2', endedAt: 9000 });
      const list = await store.listReplaysFor('kaito', 10);
      expect(list.map((r) => r.matchId)).toEqual(['m-new', 'm-old']);
      expect(await store.listReplaysFor('someone-else', 10)).toEqual([]);
    });

    it('honours the replay list limit', async () => {
      await seed(store, player('kaito'));
      await seed(store, player('rin'));
      for (let i = 0; i < 5; i++) {
        await store.saveReplay({
          matchId: `m-${i}`, seed: `s-${i}`, fighterIds: ['kaito', 'rin'],
          actions: [], winnerId: null, outcome: 'draw', rounds: 2, endedAt: i * 1000,
        });
      }
      expect(await store.listReplaysFor('kaito', 2)).toHaveLength(2);
    });

    it('does not mutate the caller record on write', async () => {
      const p = player('kaito');
      const snapshot = JSON.stringify(p);
      await seed(store, p);
      const back = (await store.getPlayer('kaito'))!;
      back.ryo = 0;
      back.known.push('tampered');
      expect(JSON.stringify(p)).toBe(snapshot);
      expect((await store.getPlayer('kaito'))!.known).not.toContain('tampered');
    });
  });
}

/* ── Things only the SQL implementation can be asked ─────────────────── */

describe('schema guarantees', () => {
  beforeEach(async () => {
    await pg.query('DROP SCHEMA public CASCADE');
    await pg.query('CREATE SCHEMA public');
    await migrate(pg);
  });

  it('executes schema.sql cleanly', async () => {
    const { rows } = await pg.query<{ table_name: string }>(
      `SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name`,
    );
    expect(rows.map((r) => r.table_name)).toEqual([
      'accounts', 'bounty_contracts', 'clan_members', 'clans', 'ladder_history',
      'legendary_history', 'legendary_items', 'mission_sessions', 'players',
      'replays', 'sessions', 'squad_members', 'squads', 'training_sessions',
    ]);
  });

  it('has no column for elapsed training time — it is always derived', async () => {
    const { rows } = await pg.query<{ column_name: string }>(
      `SELECT column_name FROM information_schema.columns WHERE table_name='training_sessions'`,
    );
    const names = rows.map((r) => r.column_name);
    expect(names).toContain('started_at');
    for (const forbidden of ['elapsed', 'progress', 'minutes', 'completed_at', 'gain']) {
      expect(names).not.toContain(forbidden);
    }
  });

  it('has no state-snapshot column on replays', async () => {
    const { rows } = await pg.query<{ column_name: string }>(
      `SELECT column_name FROM information_schema.columns WHERE table_name='replays'`,
    );
    const names = rows.map((r) => r.column_name);
    expect(names).toContain('seed');
    expect(names).toContain('actions');
    for (const forbidden of ['state', 'snapshot', 'final_state', 'fighters']) {
      expect(names).not.toContain(forbidden);
    }
  });

  it('refuses a second live training session at the database level', async () => {
    await pg.query(`INSERT INTO accounts (id, name_key, password) VALUES ('kaito','kaito','x')`);
    await pg.query(
      `INSERT INTO players (id, name, village_id, rank, stats, affinity)
       VALUES ('kaito','Kaito','konohagakure','genin','{}'::jsonb,'fire')`,
    );
    await pg.query(`INSERT INTO training_sessions (player_id, location_id, tier, stat) VALUES ('kaito','dojo',1,'taijutsu')`);
    await expect(
      pg.query(`INSERT INTO training_sessions (player_id, location_id, tier, stat) VALUES ('kaito','forest',2,'speed')`),
    ).rejects.toThrow();
  });

  it('rejects a training tier outside the allowed range', async () => {
    await pg.query(`INSERT INTO accounts (id, name_key, password) VALUES ('kaito','kaito','x')`);
    await pg.query(
      `INSERT INTO players (id, name, village_id, rank, stats, affinity)
       VALUES ('kaito','Kaito','konohagakure','genin','{}'::jsonb,'fire')`,
    );
    await expect(
      pg.query(`INSERT INTO training_sessions (player_id, location_id, tier, stat) VALUES ('kaito','dojo',9,'taijutsu')`),
    ).rejects.toThrow();
  });

  it('removes a player sessions when the player is deleted', async () => {
    await pg.query(`INSERT INTO accounts (id, name_key, password) VALUES ('kaito','kaito','x')`);
    await pg.query(
      `INSERT INTO players (id, name, village_id, rank, stats, affinity)
       VALUES ('kaito','Kaito','konohagakure','genin','{}'::jsonb,'fire')`,
    );
    await pg.query(`INSERT INTO mission_sessions (player_id, mission_id) VALUES ('kaito','clear-the-canal')`);
    await pg.query(`DELETE FROM players WHERE id='kaito'`);
    const { rows } = await pg.query(`SELECT * FROM mission_sessions`);
    expect(rows).toHaveLength(0);
  });

  it('refuses to put one player in two clans', async () => {
    await pg.query(`INSERT INTO accounts (id, name_key, password) VALUES ('kaito','kaito','x')`);
    await pg.query(`INSERT INTO clans (id, name, name_key, leader_id) VALUES ('c1','A','a','kaito')`);
    await pg.query(`INSERT INTO clans (id, name, name_key, leader_id) VALUES ('c2','B','b','kaito')`);
    await pg.query(
      `INSERT INTO players (id, name, village_id, rank, stats, affinity)
       VALUES ('kaito','Kaito','konohagakure','chunin','{}'::jsonb,'fire')`,
    );
    await pg.query(`INSERT INTO clan_members (clan_id, player_id) VALUES ('c1','kaito')`);
    await expect(
      pg.query(`INSERT INTO clan_members (clan_id, player_id) VALUES ('c2','kaito')`),
    ).rejects.toThrow();
  });

  it('refuses a clan treasury below zero', async () => {
    await pg.query(`INSERT INTO accounts (id, name_key, password) VALUES ('kaito','kaito','x')`);
    await expect(
      pg.query(`INSERT INTO clans (id, name, name_key, leader_id, bank) VALUES ('c1','A','a','kaito',-5)`),
    ).rejects.toThrow();
  });

  it('refuses two clans with confusable names', async () => {
    await pg.query(`INSERT INTO accounts (id, name_key, password) VALUES ('kaito','kaito','x')`);
    await pg.query(`INSERT INTO clans (id, name, name_key, leader_id) VALUES ('c1','Iron Lotus','ironlotus','kaito')`);
    await expect(
      pg.query(`INSERT INTO clans (id, name, name_key, leader_id) VALUES ('c2','iron  lotus','ironlotus','kaito')`),
    ).rejects.toThrow();
  });

  it('refuses to put one player in two squads', async () => {
    await pg.query(`INSERT INTO accounts (id, name_key, password) VALUES ('kaito','kaito','x')`);
    await pg.query(
      `INSERT INTO players (id, name, village_id, rank, stats, affinity)
       VALUES ('kaito','Kaito','konohagakure','anbu','{}'::jsonb,'fire')`,
    );
    await pg.query(`INSERT INTO squads (id, leader_id) VALUES ('s1','kaito')`);
    await pg.query(`INSERT INTO squads (id, leader_id) VALUES ('s2','kaito')`);
    await pg.query(`INSERT INTO squad_members (squad_id, player_id) VALUES ('s1','kaito')`);
    await expect(
      pg.query(`INSERT INTO squad_members (squad_id, player_id) VALUES ('s2','kaito')`),
    ).rejects.toThrow();
  });

  it('keeps a legendary item unique to one holder at a time', async () => {
    await pg.query(`INSERT INTO accounts (id, name_key, password) VALUES ('kaito','kaito','x')`);
    await pg.query(
      `INSERT INTO players (id, name, village_id, rank, stats, affinity)
       VALUES ('kaito','Kaito','konohagakure','genin','{}'::jsonb,'fire')`,
    );
    await pg.query(`INSERT INTO legendary_items (item_id, holder_id) VALUES ('the-white-fang-blade','kaito')`);
    await expect(
      pg.query(`INSERT INTO legendary_items (item_id, holder_id) VALUES ('the-white-fang-blade','kaito')`),
    ).rejects.toThrow();
  });
});

/* ── The service on real SQL ─────────────────────────────────────────── */

describe('the core loop runs on Postgres, not just in memory', () => {
  it('takes a mission, is paid, buys a technique, and survives a restart', async () => {
    await pg.query('DROP SCHEMA public CASCADE');
    await pg.query('CREATE SCHEMA public');
    await migrate(pg);

    const store = new PostgresStore(pg);
    let clock = 1_700_000_000_000;
    const svc = new GameService(store, () => clock);
    await seed(store, player('kaito', { ryo: 0, xp: 0, level: 1, rank: 'genin', known: [] }));

    const board = await svc.handle('kaito', { type: 'listMissions' });
    expect(board[0]!.message.type).toBe('missionBoard');

    await svc.handle('kaito', { type: 'acceptMission', missionId: 'clear-the-canal' });
    expect((await store.getPlayer('kaito'))!.mission?.missionId).toBe('clear-the-canal');

    clock += 12 * 60_000;
    const done = await svc.handle('kaito', { type: 'completeMission' });
    expect(done[0]!.message.type).toBe('missionResolved');

    const paid = (await store.getPlayer('kaito'))!;
    expect(paid.ryo).toBeGreaterThan(0);
    expect(paid.mission).toBeNull();

    paid.ryo = 5000;
    await store.savePlayer(paid);
    await svc.handle('kaito', { type: 'learnJutsu', jutsuId: 'phoenix-flower-jutsu' });

    // A brand new service against the same database sees everything.
    const afterRestart = new GameService(new PostgresStore(pg), () => clock);
    const out = await afterRestart.handle('kaito', { type: 'setLoadout', jutsuIds: ['phoenix-flower-jutsu'] });
    expect(out[0]!.message.type).toBe('loadoutSet');
    expect((await store.getPlayer('kaito'))!.known).toContain('phoenix-flower-jutsu');
  });

  it('persists a finished match and its replay', async () => {
    await pg.query('DROP SCHEMA public CASCADE');
    await pg.query('CREATE SCHEMA public');
    await migrate(pg);

    const store = new PostgresStore(pg);
    const clock = 1_700_000_000_000;
    const svc = new GameService(store, () => clock);
    await seed(store, player('kaito', { loadout: ['fireball-jutsu'], known: ['fireball-jutsu'] }));
    await seed(store, player('rin', { loadout: ['fireball-jutsu'], known: ['fireball-jutsu'] }));

    await svc.handle('kaito', { type: 'queue', rank: 'genin' });
    await svc.handle('rin', { type: 'queue', rank: 'genin' });
    const room = svc.roomFor('kaito')!;
    const matchId = room.matchId;

    await svc.handle('rin', { type: 'forfeit', matchId });

    const replay = await store.getReplay(matchId);
    expect(replay).not.toBeNull();
    expect(replay!.seed).toBe(room.seed);
    expect((await store.getPlayer('kaito'))!.rating).toBeGreaterThan(1080);
  });
});
