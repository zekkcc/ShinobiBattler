import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { PGlite } from '@electric-sql/pglite';
import { LEGACY } from '@shinobi/content';
import type { ServerMessage, Stats } from '@shinobi/shared';
import { GameService } from '../src/service.js';
import { MemoryStore, type PlayerRecord, type Store } from '../src/store/index.js';
import { migrate, PostgresStore } from '../src/store/postgres.js';
import { awardTitles, claimLegendary, claimable, earnedTitles, LegacyError, setDisplayedTitle, transferLegendary } from '../src/legacy.js';

const stats = (): Stats => ({
  ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60,
  strength: 60, speed: 60, stamina: 60, handSeals: 60,
});

const player = (id: string, o: Partial<PlayerRecord> = {}): PlayerRecord => ({
  id, name: id, villageId: 'konohagakure', clanId: null, clanJoinedAt: null,
  clanContribution: 0, bloodlineId: null, rank: 'chunin', level: 30, xp: 0,
  stats: stats(), affinity: 'fire', loadout: [], known: [],
  reputation: 0, ryo: 0, training: null, mission: null,
  missionsAtRank: 0, missionsCompleted: 0, squadId: null,
  rogue: false, defectedAt: null, notoriety: 0,
  titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0, sRankCompleted: 0,
  rating: 1000, ...o,
});

let store: MemoryStore;
let clock: number;
let svc: GameService;

beforeEach(async () => {
  store = new MemoryStore();
  clock = 1_700_000_000_000;
  svc = new GameService(store, () => clock);
  await store.createPlayer(player('kaito'));
  await store.createPlayer(player('rin'));
});

const first = (out: { message: ServerMessage }[]) => out[0]!.message;
const code = (out: { message: ServerMessage }[]) => (first(out) as { code?: string }).code;

/* ── Titles are earned ───────────────────────────────────────────────── */

describe('titles', () => {
  it('are granted by crossing a threshold, not by asking', () => {
    const p = player('a', { missionsCompleted: 0 });
    expect(earnedTitles(p)).not.toContain('of-the-long-road');
    p.missionsCompleted = 25;
    expect(earnedTitles(p)).toContain('of-the-long-road');
  });

  it('cannot be bought — there is no price anywhere in the data', () => {
    const raw = JSON.stringify(LEGACY);
    for (const forbidden of ['"price"', '"cost"', '"ryo"', '"purchasable":true']) {
      expect(raw).not.toContain(forbidden);
    }
    expect(LEGACY.rules.purchasable).toBe(false);
  });

  it('are only awarded once, however many times we check', () => {
    const p = player('a', { missionsCompleted: 30 });
    const firstPass = awardTitles(p);
    expect(firstPass.length).toBeGreaterThan(0);
    expect(awardTitles(p)).toEqual([]);
    expect(new Set(p.titles).size).toBe(p.titles.length);
  });

  it('can only be displayed once earned', () => {
    const p = player('a');
    expect(() => setDisplayedTitle(p, 'kage-slayer')).toThrow(LegacyError);
    p.titles.push('kage-slayer');
    setDisplayedTitle(p, 'kage-slayer');
    expect(p.displayedTitle).toBe('kage-slayer');
  });

  it('rejects a title that does not exist', () => {
    const p = player('a', { titles: ['invented'] });
    expect(() => setDisplayedTitle(p, 'invented')).toThrow(LegacyError);
  });

  it('can be cleared', () => {
    const p = player('a', { titles: ['kage-slayer'], displayedTitle: 'kage-slayer' });
    setDisplayedTitle(p, null);
    expect(p.displayedTitle).toBeNull();
  });

  it('are awarded through the service when a threshold is crossed', async () => {
    await store.savePlayer(player('kaito', { pvpWins: 24, rating: 1000 }));
    await store.savePlayer(player('rin'));
    await svc.handle('kaito', { type: 'queue', rank: 'chunin' });
    await svc.handle('rin', { type: 'queue', rank: 'chunin' });
    const room = svc.roomFor('kaito');
    expect(room).toBeDefined();

    const out = await svc.handle('rin', { type: 'forfeit', matchId: room!.matchId });
    expect(out.some((d) => d.message.type === 'titlesEarned')).toBe(true);
    const p = await store.getPlayer('kaito');
    expect(p!.pvpWins).toBe(25);
    expect(p!.titles).toContain('the-silent-mist');
  });

  it('the client cannot set a title it has not earned', async () => {
    expect(code(await svc.handle('kaito', { type: 'setTitle', titleId: 'kage-slayer' }))).toBe('notEarned');
  });
});

/* ── Legendaries are unique ──────────────────────────────────────────── */

describe('legendary items', () => {
  it('are shortlisted only once the feat is done and nobody holds them', () => {
    const p = player('a', { pvpWins: 10 });
    expect(claimable(p, []).map((c) => c.itemId)).not.toContain('the-white-fang-blade');
    p.pvpWins = 50;
    expect(claimable(p, []).map((c) => c.itemId)).toContain('the-white-fang-blade');
  });

  it('disappear from the shortlist once somebody holds them', () => {
    const p = player('a', { pvpWins: 60 });
    const held = [{ itemId: 'the-white-fang-blade', holderId: 'someone', acquiredAt: 0 }];
    expect(claimable(p, held).map((c) => c.itemId)).not.toContain('the-white-fang-blade');
  });

  it('cannot be claimed without the feat', async () => {
    await expect(claimLegendary(store, player('a', { pvpWins: 1 }), 'the-white-fang-blade', 0))
      .rejects.toThrow(LegacyError);
  });

  it('can only be claimed once', async () => {
    const a = player('a', { pvpWins: 60 });
    const b = player('b', { pvpWins: 60 });
    await store.createPlayer(a);
    await store.createPlayer(b);
    await claimLegendary(store, a, 'the-white-fang-blade', 0);
    await expect(claimLegendary(store, b, 'the-white-fang-blade', 0)).rejects.toThrow();
    expect((await store.getLegendary('the-white-fang-blade'))!.holderId).toBe('a');
  });

  it('grant no combat power — that is a stated rule, not an oversight', () => {
    expect(LEGACY.rules.grantsCombatPower).toBe(false);
    const raw = JSON.stringify(LEGACY.legendaries);
    for (const forbidden of ['stat', 'damage', 'bonus', 'power', 'mult']) {
      expect(raw.toLowerCase()).not.toContain(`"${forbidden}"`);
    }
  });

  it('record their chain of custody, and nothing removes from it', async () => {
    const a = player('a', { pvpWins: 60 });
    await store.createPlayer(a);
    await claimLegendary(store, a, 'the-white-fang-blade', 1000);
    await transferLegendary(store, 'the-white-fang-blade', 'a', 'rin', 5000);

    const chain = await store.legendaryHistory('the-white-fang-blade');
    expect(chain).toHaveLength(2);
    expect(chain[0]!.holderId).toBe('a');
    expect(chain[0]!.heldUntil).toBe(5000);
    expect(chain[1]!.holderId).toBe('rin');
    expect(chain[1]!.heldUntil).toBeNull();
  });

  it('refuse a transfer from somebody who is not the holder', async () => {
    const a = player('a', { pvpWins: 60 });
    await store.createPlayer(a);
    await claimLegendary(store, a, 'the-white-fang-blade', 0);
    await expect(transferLegendary(store, 'the-white-fang-blade', 'rin', 'kaito', 1))
      .rejects.toThrow(LegacyError);
  });

  it('are claimable through the service and then held', async () => {
    await store.savePlayer(player('kaito', { pvpWins: 60 }));
    const out = await svc.handle('kaito', { type: 'claimLegendary', itemId: 'the-white-fang-blade' });
    expect(first(out).type).toBe('legendaryClaimed');

    const board = await svc.handle('rin', { type: 'listLegacy' });
    const msg = first(board) as { held: { itemId: string; holderName: string; yours: boolean }[] };
    expect(msg.held).toHaveLength(1);
    expect(msg.held[0]!.holderName).toBe('kaito');
    expect(msg.held[0]!.yours).toBe(false);
  });

  it('refuse a second claimant through the service', async () => {
    await store.savePlayer(player('kaito', { pvpWins: 60 }));
    await store.savePlayer(player('rin', { pvpWins: 60 }));
    await svc.handle('kaito', { type: 'claimLegendary', itemId: 'the-white-fang-blade' });
    expect(code(await svc.handle('rin', { type: 'claimLegendary', itemId: 'the-white-fang-blade' })))
      .toBe('alreadyHeld');
  });
});

/* ── Uniqueness must hold in the database, not just in the check ─────── */

const pg = new PGlite();
afterAll(async () => { await pg.close(); });

describe('uniqueness is enforced by the database', () => {
  let sqlStore: Store;

  beforeEach(async () => {
    await pg.query('DROP SCHEMA public CASCADE');
    await pg.query('CREATE SCHEMA public');
    await migrate(pg);
    sqlStore = new PostgresStore(pg);
    for (const id of ['a', 'b']) {
      await sqlStore.createAccount({ id, nameKey: id, password: 'x' });
      await sqlStore.createPlayer(player(id, { pvpWins: 60 }));
    }
  });

  it('rejects a second holder for the same item at the storage layer', async () => {
    await sqlStore.claimLegendary({ itemId: 'the-white-fang-blade', holderId: 'a', acquiredAt: 1000 }, 1000);
    // Deliberately bypassing the application check: the primary key is the guarantee.
    await expect(
      sqlStore.claimLegendary({ itemId: 'the-white-fang-blade', holderId: 'b', acquiredAt: 2000 }, 2000),
    ).rejects.toThrow();
    expect((await sqlStore.getLegendary('the-white-fang-blade'))!.holderId).toBe('a');
  });

  it('keeps the full chain across a transfer', async () => {
    await sqlStore.claimLegendary({ itemId: 'the-hunters-tally', holderId: 'a', acquiredAt: 1000 }, 1000);
    await sqlStore.transferLegendary('the-hunters-tally', 'b', 5000);
    const chain = await sqlStore.legendaryHistory('the-hunters-tally');
    expect(chain.map((c) => c.holderId)).toEqual(['a', 'b']);
    expect(chain[0]!.heldUntil).toBe(5000);
  });

  it('round-trips titles and the legacy counters', async () => {
    const p = (await sqlStore.getPlayer('a'))!;
    p.titles = ['the-silent-mist', 'hunter-nin'];
    p.displayedTitle = 'hunter-nin';
    p.bountiesClaimed = 7;
    p.sRankCompleted = 2;
    await sqlStore.savePlayer(p);
    expect(await sqlStore.getPlayer('a')).toEqual(p);
  });
});
