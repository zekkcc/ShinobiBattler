import { beforeEach, describe, expect, it } from 'vitest';
import { ROGUE } from '@shinobi/content';
import type { ServerMessage, Stats } from '@shinobi/shared';
import { GameService } from '../src/service.js';
import { MemoryStore, type PlayerRecord } from '../src/store/index.js';
import {
  amnestyCost, bountyOn, claimBounty, defect, isWorthHunting,
  RogueError, seekAmnesty, takeContract,
} from '../src/rogue.js';

const stats = (o: Partial<Stats> = {}): Stats => ({
  ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60,
  strength: 60, speed: 60, stamina: 60, handSeals: 200, ...o,
});

const player = (id: string, o: Partial<PlayerRecord> = {}): PlayerRecord => ({
  id, name: id, villageId: 'konohagakure', clanId: null, clanJoinedAt: null, clanContribution: 0, bloodlineId: null,
  rank: 'chunin', level: 30, xp: 0, stats: stats(), affinity: 'fire',
  loadout: ['fireball-jutsu'], known: ['fireball-jutsu'],
  reputation: 60, ryo: 50_000, training: null, mission: null,
  missionsAtRank: 0, missionsCompleted: 0, squadId: null,
  rogue: false, defectedAt: null, notoriety: 0,
  titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0, sRankCompleted: 0, rating: 1000, ...o,
});

let store: MemoryStore;
let clock: number;
let svc: GameService;

beforeEach(async () => {
  store = new MemoryStore();
  clock = 1_700_000_000_000;
  svc = new GameService(store, () => clock);
  await store.createPlayer(player('kaito'));
  await store.createPlayer(player('rin'));
});

const first = (out: { message: ServerMessage }[]) => out[0]!.message;
const code = (out: { message: ServerMessage }[]) => (first(out) as { code?: string }).code;

/* ── Leaving the village costs something ─────────────────────────────── */

describe('defection', () => {
  it('closes the village behind you', async () => {
    await svc.handle('kaito', { type: 'defect' });
    const p = (await store.getPlayer('kaito'))!;
    expect(p.rogue).toBe(true);
    expect(p.reputation).toBeLessThanOrEqual(ROGUE.defection.reputationFloor);

    // The mission desk is shut, because standing is on the floor.
    const board = await svc.handle('kaito', { type: 'listMissions' });
    expect((first(board) as { missions: unknown[] }).missions).toHaveLength(0);
    expect(code(await svc.handle('kaito', { type: 'acceptMission', missionId: 'clear-the-canal' })))
      .toBe('reputationLocked');
  });

  it('freezes rank — a missing-nin holds none', async () => {
    await store.savePlayer(player('kaito', {
      rank: 'genin', level: 40, reputation: 300, rating: 1400, missionsAtRank: 30,
    }));
    const before = await svc.handle('kaito', { type: 'requestPromotion' });
    expect(first(before).type).toBe('promotion');

    await store.savePlayer(player('rin', {
      rank: 'genin', level: 40, reputation: 300, rating: 1400, missionsAtRank: 30,
    }));
    await svc.handle('rin', { type: 'defect' });
    const after = await svc.handle('rin', { type: 'requestPromotion' });
    expect(first(after).type).toBe('promotionDenied');
    expect((await store.getPlayer('rin'))!.rank).toBe('genin');
  });

  it('cannot be done twice, or while away on a mission', () => {
    const p = player('a');
    defect(p, 0);
    expect(() => defect(p, 0)).toThrow(RogueError);

    const busy = player('b', { mission: { missionId: 'clear-the-canal', startedAt: 0 } });
    expect(() => defect(busy, 0)).toThrow(RogueError);
  });

  it('starts you at zero notoriety, so defecting alone is worth nothing', () => {
    const p = player('a', { level: 30 });
    defect(p, 0);
    expect(p.notoriety).toBe(0);
    expect(isWorthHunting(p)).toBe(false);
  });
});

/* ── Coming back ─────────────────────────────────────────────────────── */

describe('amnesty', () => {
  it('cannot be bought immediately', () => {
    const p = player('a');
    defect(p, 0);
    expect(() => seekAmnesty(p, 60_000)).toThrow(RogueError);
  });

  it('costs more the more notorious you became', () => {
    const quiet = player('a', { notoriety: 0, rogue: true });
    const infamous = player('b', { notoriety: 300, rogue: true });
    expect(amnestyCost(infamous)).toBeGreaterThan(amnestyCost(quiet));
  });

  it('is refused if you cannot pay', () => {
    const p = player('a', { ryo: 10 });
    defect(p, 0);
    expect(() => seekAmnesty(p, ROGUE.amnesty.cooldownMinutes * 60_000)).toThrow(RogueError);
  });

  it('wipes notoriety, so defecting again starts from nothing', () => {
    const p = player('a', { ryo: 500_000 });
    defect(p, 0);
    p.notoriety = 200;
    seekAmnesty(p, ROGUE.amnesty.cooldownMinutes * 60_000);
    expect(p.rogue).toBe(false);
    expect(p.notoriety).toBe(0);
    expect(p.reputation).toBe(ROGUE.amnesty.reputationOnReturn);
  });
});

/* ── Bounties are earned, never minted ───────────────────────────────── */

describe('what a head is worth', () => {
  it('is nothing for someone who has not done anything', () => {
    const fresh = player('a', { rogue: true, notoriety: 0 });
    expect(isWorthHunting(fresh)).toBe(false);
  });

  it('rises with what the rogue has actually done', () => {
    const quiet = player('a', { rogue: true, notoriety: 10 });
    const infamous = player('b', { rogue: true, notoriety: 300 });
    expect(bountyOn(infamous)).toBeGreaterThan(bountyOn(quiet));
  });

  it('is zero for anyone still in a village', () => {
    expect(bountyOn(player('a', { notoriety: 400 }))).toBe(0);
  });

  it('cannot be posted on a villager, or on yourself', () => {
    const hunter = player('a');
    const villager = player('b');
    expect(() => takeContract(hunter, villager, [], 0)).toThrow(RogueError);
    const rogue = player('c', { rogue: true, notoriety: 100 });
    expect(() => takeContract(rogue, rogue, [], 0)).toThrow(RogueError);
  });

  it('cannot be taken by a missing-nin — hunting is village work', () => {
    const rogueHunter = player('a', { rogue: true, notoriety: 50 });
    const target = player('b', { rogue: true, notoriety: 100 });
    expect(() => takeContract(rogueHunter, target, [], 0)).toThrow(RogueError);
  });

  it('locks its value when taken, so it cannot be pumped afterwards', () => {
    const hunter = player('a');
    const target = player('b', { rogue: true, notoriety: 50 });
    const contract = takeContract(hunter, target, [], 0);
    const locked = contract.value;

    target.notoriety = 500;   // the rogue goes on a spree after the contract
    const claim = claimBounty(contract, hunter, target, 1000);
    expect(claim.takenFromRogue).toBeLessThanOrEqual(locked);
  });

  it('holds a hunter to one contract at a time', () => {
    const hunter = player('a');
    const first = player('b', { rogue: true, notoriety: 100 });
    const second = player('c', { rogue: true, notoriety: 100 });
    const live = [takeContract(hunter, first, [], 0)];
    expect(() => takeContract(hunter, second, live, 0)).toThrow(RogueError);
  });

  it('expires, and an expired contract pays nothing', () => {
    const hunter = player('a');
    const target = player('b', { rogue: true, notoriety: 100 });
    const contract = takeContract(hunter, target, [], 0);
    expect(() => claimBounty(contract, hunter, target, contract.expiresAt + 1)).toThrow(RogueError);
  });
});

/* ── The interesting part: does collusion pay? ───────────────────────── */

describe('collusion is unprofitable by construction', () => {
  it('destroys value on every capture — the pair ends up poorer', () => {
    const hunter = player('a', { ryo: 0 });
    const rogue = player('b', { rogue: true, notoriety: 200, ryo: 100_000 });
    const before = hunter.ryo + rogue.ryo;

    const contract = takeContract(hunter, rogue, [], 0);
    claimBounty(contract, hunter, rogue, 1000);

    const after = hunter.ryo + rogue.ryo;
    expect(after).toBeLessThan(before);
    expect(ROGUE.bounty.hunterShare).toBeLessThan(1);
  });

  it('resets the rogue to worthless after a capture, so the next loop pays less', () => {
    const hunter = player('a');
    const rogue = player('b', { rogue: true, notoriety: 200, ryo: 100_000 });
    const contract = takeContract(hunter, rogue, [], 0);
    claimBounty(contract, hunter, rogue, 1000);

    expect(rogue.notoriety).toBe(0);
    expect(isWorthHunting(rogue)).toBe(false);
  });

  it('refuses the same pair again until the cooldown lapses', () => {
    const hunter = player('a');
    const rogue = player('b', { rogue: true, notoriety: 200 });
    const first = takeContract(hunter, rogue, [], 0);
    const settled = [{ ...first, expiresAt: 1 }];

    expect(() => takeContract(hunter, rogue, settled, 2)).toThrow(RogueError);
    const past = ROGUE.contract.cooldownMinutesSamePair * 60_000 + 1;
    expect(() => takeContract(hunter, rogue, settled, past)).not.toThrow();
  });

  it('never takes more from a rogue than they actually have', () => {
    const hunter = player('a', { ryo: 0 });
    const broke = player('b', { rogue: true, notoriety: 300, ryo: 12 });
    const contract = takeContract(hunter, broke, [], 0);
    const claim = claimBounty(contract, hunter, broke, 100);
    expect(claim.takenFromRogue).toBe(12);
    expect(broke.ryo).toBe(0);
  });
});

/* ── The black market ────────────────────────────────────────────────── */

describe('the black market', () => {
  it('sells above your rank, for considerably more money', async () => {
    await store.savePlayer(player('kaito', { rank: 'genin', ryo: 500_000 }));
    expect(code(await svc.handle('kaito', { type: 'learnJutsu', jutsuId: 'amaterasu' }))).toBe('rankLocked');

    await store.savePlayer(player('rin', { rank: 'genin', ryo: 500_000, rogue: true }));
    const out = await svc.handle('rin', { type: 'learnJutsu', jutsuId: 'amaterasu' });
    expect(first(out).type).toBe('jutsuLearned');

    const paidByRogue = 500_000 - (await store.getPlayer('rin'))!.ryo;
    await store.savePlayer(player('kaito', { rank: 'anbu', ryo: 500_000 }));
    await svc.handle('kaito', { type: 'learnJutsu', jutsuId: 'amaterasu' });
    const paidByVillager = 500_000 - (await store.getPlayer('kaito'))!.ryo;

    expect(paidByRogue).toBeGreaterThan(paidByVillager);
  });
});

/* ── End to end through the service ──────────────────────────────────── */

describe('hunting, end to end', () => {
  it('shows only rogues worth hunting on the board', async () => {
    await store.savePlayer(player('rin', { rogue: true, notoriety: 0 }));
    let board = await svc.handle('kaito', { type: 'listBounties' });
    expect((first(board) as { bounties: unknown[] }).bounties).toHaveLength(0);

    await store.savePlayer(player('rin', { rogue: true, notoriety: 120 }));
    board = await svc.handle('kaito', { type: 'listBounties' });
    const listed = (first(board) as { bounties: { targetId: string; value: number }[] }).bounties;
    expect(listed).toHaveLength(1);
    expect(listed[0]!.targetId).toBe('rin');
    expect(listed[0]!.value).toBeGreaterThan(0);
  });

  it('pays out when the hunter actually beats the rogue', async () => {
    await store.savePlayer(player('rin', { rogue: true, notoriety: 150, ryo: 80_000 }));
    const taken = await svc.handle('kaito', { type: 'takeBountyContract', targetId: 'rin' });
    expect(first(taken).type).toBe('contractTaken');

    await svc.handle('kaito', { type: 'queue', rank: 'chunin' });
    await svc.handle('rin', { type: 'queue', rank: 'chunin' });
    const room = svc.roomFor('kaito');
    expect(room).toBeDefined();   // a guarded assertion here would pass vacuously

    const out = await svc.handle('rin', { type: 'forfeit', matchId: room!.matchId });
    expect(out.some((d) => d.message.type === 'bountyClaimed')).toBe(true);
    expect((await store.getPlayer('kaito'))!.ryo).toBeGreaterThan(50_000);
    expect((await store.getPlayer('rin'))!.notoriety).toBe(0);
  });

  it('pays nothing when the hunter loses', async () => {
    await store.savePlayer(player('rin', { rogue: true, notoriety: 150, ryo: 80_000 }));
    await svc.handle('kaito', { type: 'takeBountyContract', targetId: 'rin' });

    await svc.handle('kaito', { type: 'queue', rank: 'chunin' });
    await svc.handle('rin', { type: 'queue', rank: 'chunin' });
    const room = svc.roomFor('kaito');
    expect(room).toBeDefined();

    const out = await svc.handle('kaito', { type: 'forfeit', matchId: room!.matchId });
    expect(out.some((d) => d.message.type === 'bountyClaimed')).toBe(false);
    expect((await store.getPlayer('rin'))!.ryo).toBe(80_000);
  });

  it('a rogue winning a match becomes more notorious', async () => {
    await store.savePlayer(player('rin', { rogue: true, notoriety: 20 }));
    await svc.handle('kaito', { type: 'queue', rank: 'chunin' });
    await svc.handle('rin', { type: 'queue', rank: 'chunin' });
    const room = svc.roomFor('rin');
    expect(room).toBeDefined();

    await svc.handle('kaito', { type: 'forfeit', matchId: room!.matchId });
    expect((await store.getPlayer('rin'))!.notoriety).toBeGreaterThan(20);
  });
});
