import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { mkdir, rm, writeFile } from 'node:fs/promises';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { buildServer } from '../src/app.js';
import { createMatch, makeRng, resolveTurn } from '@shinobi/engine';
import { TRAINING } from '@shinobi/content';
import type { ServerMessage, Stats } from '@shinobi/shared';
import { GameService } from '../src/service.js';
import { newMetaState, MemoryStore, type PlayerRecord } from '../src/store/index.js';
import { specFor } from '../src/matchroom.js';
import { RateLimiter } from '../src/ratelimit.js';
import { claimTraining, currentWeather, startTraining, TrainingError } from '../src/training.js';

/* ── fixtures ────────────────────────────────────────────────────────── */

const stats = (o: Partial<Stats> = {}): Stats => ({
  ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60,
  strength: 60, speed: 60, stamina: 60, handSeals: 200, ...o,
});

const player = (id: string, o: Partial<PlayerRecord> = {}): PlayerRecord => ({
  id, name: id, villageId: 'konohagakure', clanId: null, clanJoinedAt: null, clanContribution: 0, bloodlineId: null,
  rank: 'genin', level: 20, xp: 0, stats: stats(), affinity: 'fire',
  loadout: ['fireball-jutsu', 'phoenix-flower-jutsu', 'shadow-clone-jutsu'],
  known: ['fireball-jutsu', 'phoenix-flower-jutsu', 'shadow-clone-jutsu', 'amaterasu'],
  reputation: 0, ryo: 0, training: null, mission: null,
  missionsAtRank: 0, missionsCompleted: 0, squadId: null, rogue: false, defectedAt: null, notoriety: 0,
  titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0, sRankCompleted: 0, rating: 1000, ...newMetaState(0), ...o,
});

let store: MemoryStore;
let clock: number;
let svc: GameService;

beforeEach(async () => {
  store = new MemoryStore();
  clock = 1_700_000_000_000;
  svc = new GameService(store, () => clock);
  await store.createPlayer(player('alice'));
  await store.createPlayer(player('bob'));
});

const kinds = (out: { message: ServerMessage }[]) => out.map((d) => d.message.type);
const first = (out: { message: ServerMessage }[]) => out[0]!.message;

async function pairUp(): Promise<string> {
  await svc.handle('alice', { type: 'queue', rank: 'genin' });
  const out = await svc.handle('bob', { type: 'queue', rank: 'genin' });
  const found = out.find((d) => d.message.type === 'matchFound')!;
  return (found.message as { matchId: string }).matchId;
}

/* ── §5 Message validation at the boundary ───────────────────────────── */

describe('message validation (CLAUDE.md §5)', () => {
  it('rejects a malformed message before any handler runs', async () => {
    for (const bad of [null, 42, 'queue', {}, { type: 'nope' }, { type: 'queue' }, { type: 'queue', rank: 'emperor' }]) {
      const out = await svc.handle('alice', bad);
      expect(first(out).type).toBe('error');
      expect((first(out) as { code: string }).code).toBe('badMessage');
    }
  });

  it('ignores unknown fields rather than letting them through', async () => {
    const out = await svc.handle('alice', {
      type: 'queue', rank: 'genin',
      damage: 99999, hp: 1, rating: 99999, isAdmin: true,
    });
    expect(first(out).type).toBe('queued');
    const stored = await store.getPlayer('alice');
    expect(stored!.rating).toBe(1000);
  });

  it('does not accept a client-supplied rank — it uses the stored one', async () => {
    const climber = player('climber', { rank: 'academy' });
    await store.createPlayer(climber);
    const out = await svc.handle('climber', { type: 'queue', rank: 'kage' });
    expect((first(out) as { rank: string }).rank).toBe('academy');
  });

  it('rejects an oversized loadout instead of truncating silently into a bad state', async () => {
    const many = Array.from({ length: 30 }, () => 'fireball-jutsu');
    const out = await svc.handle('alice', { type: 'setLoadout', jutsuIds: many });
    expect(first(out).type).toBe('error');
  });
});

/* ── §5 + §8 Body ownership ──────────────────────────────────────────── */

describe('body ownership (CLAUDE.md §8)', () => {
  it('overrides any submittedBy the client puts in the payload', async () => {
    const matchId = await pairUp();
    const room = svc.roomFor('alice')!;
    // alice claims to be bob
    await svc.handle('alice', {
      type: 'submitAction', matchId,
      action: { fighterId: 'bob', actionId: 'fireball-jutsu', targetId: 'alice', submittedBy: 'bob' },
    });
    expect(room.hasSubmitted('bob')).toBe(false);
  });

  it('refuses an action addressed to the opponent', async () => {
    const matchId = await pairUp();
    const out = await svc.handle('alice', {
      type: 'submitAction', matchId,
      action: { fighterId: 'bob', actionId: 'fireball-jutsu', targetId: 'alice' },
    });
    expect(first(out).type).toBe('error');
    expect((first(out) as { code: string }).code).toBe('rejectedAction');
  });

  it('refuses an action for a match the player is not in', async () => {
    await pairUp();
    await store.createPlayer(player('mallory'));
    const out = await svc.handle('mallory', {
      type: 'submitAction', matchId: svc.roomFor('alice')!.matchId,
      action: { fighterId: 'alice', actionId: 'fireball-jutsu', targetId: 'bob' },
    });
    expect((first(out) as { code: string }).code).toBe('notInThisMatch');
  });

  it('takes the first submission per body, so resubmitting cannot re-roll a round', async () => {
    const matchId = await pairUp();
    const room = svc.roomFor('alice')!;
    room.submit('alice', [
      { fighterId: 'alice', actionId: 'fireball-jutsu', targetId: 'bob', submittedBy: 'alice' },
      { fighterId: 'alice', actionId: 'phoenix-flower-jutsu', targetId: 'bob', submittedBy: 'alice' },
    ]);
    expect(room.hasSubmitted('alice')).toBe(true);
  });

  it('a player cannot drive the opponent clone bodies', async () => {
    const matchId = await pairUp();
    const room = svc.roomFor('alice')!;
    // give alice a clone by resolving a split
    room.submit('alice', [{ fighterId: 'alice', actionId: 'shadow-clone-jutsu', targetId: 'bob', submittedBy: 'alice' }]);
    room.submit('bob', [{ fighterId: 'bob', actionId: 'fireball-jutsu', targetId: 'alice', submittedBy: 'bob' }]);
    room.resolve(clock);
    const view = room.viewFor('alice');
    const clone = view.fighters.find((f) => f.id === 'alice')!.clones[0];
    if (!clone) return; // seal fumble on this seed; ownership is covered by the engine suite too
    const res = room.submit('bob', [{ fighterId: clone.id, actionId: 'fireball-jutsu', targetId: 'alice', submittedBy: 'bob' }]);
    expect(res.accepted).toBe(0);
    void matchId;
  });
});

/* ── §5 Client submits intent and nothing else ───────────────────────── */

describe('the client cannot supply outcomes', () => {
  it('a submitted action carries only an id and a target after sanitising', async () => {
    const matchId = await pairUp();
    const room = svc.roomFor('alice')!;
    room.submit('alice', [{
      fighterId: 'alice', actionId: 'fireball-jutsu', targetId: 'bob', submittedBy: 'alice',
      // everything below is attacker-controlled garbage that must not survive
      damage: 99999, hit: true, roll: 1, cooldown: 0, chakra: 9999,
    } as never]);
    room.submit('bob', [{ fighterId: 'bob', actionId: 'fireball-jutsu', targetId: 'alice', submittedBy: 'bob' }]);
    room.resolve(clock);
    const replay = room.toReplay(clock);
    for (const a of replay.actions) {
      expect(Object.keys(a).sort()).toEqual(['actionId', 'fighterId', 'submittedBy', 'targetId']);
    }
  });

  it('never lets a client set its own rating or stats', async () => {
    await svc.handle('alice', { type: 'setLoadout', jutsuIds: ['fireball-jutsu'], rating: 5000, stats: { speed: 500 } });
    const stored = await store.getPlayer('alice');
    expect(stored!.rating).toBe(1000);
    expect(stored!.stats.speed).toBe(60);
  });

  it('hides the opponent loadout and skill ledger from a match view', async () => {
    await pairUp();
    const room = svc.roomFor('alice')!;
    const view = room.viewFor('alice');
    const mine = view.fighters.find((f) => f.id === 'alice')!;
    const theirs = view.fighters.find((f) => f.id === 'bob')!;
    expect(mine.loadout.length).toBeGreaterThan(0);
    expect(theirs.loadout).toEqual([]);
    expect(theirs.skillLedger).toEqual({});
  });
});

/* ── §5 Rate limiting ────────────────────────────────────────────────── */

describe('rate limiting (CLAUDE.md §5)', () => {
  it('throttles a flood of actions', async () => {
    const matchId = await pairUp();
    let limited = 0;
    for (let i = 0; i < 60; i++) {
      const out = await svc.handle('alice', {
        type: 'submitAction', matchId,
        action: { fighterId: 'alice', actionId: 'fireball-jutsu', targetId: 'bob' },
      });
      if ((first(out) as { code?: string }).code === 'rateLimited') limited++;
    }
    expect(limited).toBeGreaterThan(0);
  });

  it('refills over time rather than locking a player out permanently', () => {
    const limiter = new RateLimiter();
    let t = 0;
    while (limiter.take('alice', 'queue', t)) { /* drain the burst */ }
    expect(limiter.take('alice', 'queue', t)).toBe(false);
    t += 60_000;
    expect(limiter.take('alice', 'queue', t)).toBe(true);
  });

  it('keys buckets per player, so one client cannot starve another', () => {
    const limiter = new RateLimiter();
    while (limiter.take('alice', 'queue', 0)) { /* drain alice */ }
    expect(limiter.take('alice', 'queue', 0)).toBe(false);
    expect(limiter.take('bob', 'queue', 0)).toBe(true);
  });

  it('keys buckets per operation, so spamming one does not block another', () => {
    const limiter = new RateLimiter();
    while (limiter.take('alice', 'queue', 0)) { /* drain */ }
    expect(limiter.take('alice', 'ping', 0)).toBe(true);
  });
});

/* ── §5 Training timers are server-side ──────────────────────────────── */

describe('training timers (CLAUDE.md §5)', () => {
  it('derives elapsed time from the stored startedAt', () => {
    const p = player('t1');
    p.training = startTraining(p, 'dojo', 2, 1000);
    const tier = TRAINING.tiers.find((t) => t.tier === 2)!;
    const result = claimTraining(p, 1000 + tier.minutes * 60_000, 'clear');
    expect(result.minutesCredited).toBeCloseTo(tier.minutes, 1);
    expect(result.complete).toBe(true);
  });

  it('credits nothing for time that has not actually passed', () => {
    const p = player('t2');
    p.training = startTraining(p, 'dojo', 3, 5000);
    const result = claimTraining(p, 5000, 'clear');
    expect(result.minutesCredited).toBe(0);
    expect(Object.keys(result.gains)).toHaveLength(0);
  });

  it('never credits more than the tier allows, however long the client waits', () => {
    const p = player('t3');
    p.training = startTraining(p, 'dojo', 1, 0);
    const tier = TRAINING.tiers.find((t) => t.tier === 1)!;
    const week = 7 * 24 * 60 * 60_000;
    const result = claimTraining(p, week, 'clear');
    expect(result.minutesCredited).toBeLessThanOrEqual(tier.minutes);
  });

  it('refuses a second session while one is running', () => {
    const p = player('t4');
    p.training = startTraining(p, 'dojo', 1, 0);
    expect(() => startTraining(p, 'library', 5, 0)).toThrow(TrainingError);
  });

  it('refuses a claim with no session', () => {
    expect(() => claimTraining(player('t5'), 0, 'clear')).toThrow(TrainingError);
  });

  it('gates locations by rank', () => {
    const academy = player('t6', { rank: 'academy' });
    expect(() => startTraining(academy, 'mountain', 1, 0)).toThrow(TrainingError);
    expect(() => startTraining(academy, 'dojo', 1, 0)).not.toThrow();
  });

  it('weather is global and clock-derived, so it cannot be rerolled', () => {
    const t = 1_700_000_000_000;
    expect(currentWeather(t)).toBe(currentWeather(t));
    expect(currentWeather(t)).not.toBe(currentWeather(t + 3 * 60 * 60 * 1000));
  });

  it('the service persists a session and pays it out through the store', async () => {
    const started = await svc.handle('alice', { type: 'startTraining', locationId: 'dojo', tier: 1 });
    expect(first(started).type).toBe('trainingStarted');
    expect((await store.getPlayer('alice'))!.training).not.toBeNull();

    const before = (await store.getPlayer('alice'))!.stats.taijutsu;
    clock += 5 * 60_000;
    const claimed = await svc.handle('alice', { type: 'claimTraining' });
    expect(first(claimed).type).toBe('trainingClaimed');

    const after = await store.getPlayer('alice');
    expect(after!.stats.taijutsu).toBeGreaterThan(before);
    expect(after!.training).toBeNull();
  });
});

/* ── §12 Replays are (seed, actions[]) ───────────────────────────────── */

describe('replays (CLAUDE.md §12)', () => {
  it('store nothing but the seed and the action log', async () => {
    const matchId = await pairUp();
    const room = svc.roomFor('alice')!;
    room.submit('alice', [{ fighterId: 'alice', actionId: 'fireball-jutsu', targetId: 'bob', submittedBy: 'alice' }]);
    room.submit('bob', [{ fighterId: 'bob', actionId: 'fireball-jutsu', targetId: 'alice', submittedBy: 'bob' }]);
    room.resolve(clock);

    const replay = room.toReplay(clock);
    const serialised = JSON.stringify(replay);
    for (const forbidden of ['"hp"', '"maxHp"', '"chakra"', '"statuses"', '"fighters"', '"cooldowns"']) {
      expect(serialised).not.toContain(forbidden);
    }
    expect(replay.seed).toBe(room.seed);
    void matchId;
  });

  it('a stored replay reproduces the match exactly when re-run through the engine', async () => {
    await pairUp();
    const room = svc.roomFor('alice')!;
    const perRound: { alice: string; bob: string }[] = [
      { alice: 'fireball-jutsu', bob: 'phoenix-flower-jutsu' },
      { alice: 'phoenix-flower-jutsu', bob: 'fireball-jutsu' },
      { alice: 'fireball-jutsu', bob: 'fireball-jutsu' },
    ];
    for (const r of perRound) {
      room.submit('alice', [{ fighterId: 'alice', actionId: r.alice, targetId: 'bob', submittedBy: 'alice' }]);
      room.submit('bob', [{ fighterId: 'bob', actionId: r.bob, targetId: 'alice', submittedBy: 'bob' }]);
      room.resolve(clock);
    }
    const live = room.viewFor('alice');
    const replay = room.toReplay(clock);

    // Rebuild from (seed, actions[]) alone.
    const a = await store.getPlayer('alice');
    const b = await store.getPlayer('bob');
    let state = createMatch(replay.matchId, replay.seed, specFor(a!), specFor(b!));
    const rng = makeRng(replay.seed);
    for (let i = 0; i < replay.actions.length; i += 2) {
      state = resolveTurn(state, replay.actions.slice(i, i + 2), rng).state;
    }

    expect(state.fighters[0].hp).toBe(live.fighters[0].hp);
    expect(state.fighters[1].hp).toBe(live.fighters[1].hp);
    expect(state.round).toBe(live.round);
  });
});

/* ── §5 Skill gain is settled server-side ────────────────────────────── */

describe('progression is settled server-side', () => {
  it('writes stat gains and a new rating when a match ends', async () => {
    await pairUp();
    const room = svc.roomFor('alice')!;
    const before = await store.getPlayer('alice');

    room.forfeit('bob');
    room.timeOutMissing();
    room.resolve(clock);
    expect(room.isComplete).toBe(true);
    await room.settle(store, clock);

    const after = await store.getPlayer('alice');
    expect(after!.rating).not.toBe(before!.rating);
    expect(after!.reputation).toBeGreaterThan(before!.reputation);
    expect(await store.getReplay(room.matchId)).not.toBeNull();
  });

  it('the winner gains rating and the loser loses it', async () => {
    await pairUp();
    const room = svc.roomFor('alice')!;
    room.forfeit('bob');
    room.timeOutMissing();
    room.resolve(clock);
    await room.settle(store, clock);
    const alice = await store.getPlayer('alice');
    const bob = await store.getPlayer('bob');
    expect(alice!.rating).toBeGreaterThan(1000);
    expect(bob!.rating).toBeLessThan(1000);
  });
});

/* ── Loadouts ────────────────────────────────────────────────────────── */

describe('loadouts', () => {
  it('rejects an unknown jutsu id', async () => {
    const out = await svc.handle('alice', { type: 'setLoadout', jutsuIds: ['not-a-jutsu'] });
    expect((first(out) as { code: string }).code).toBe('unknownJutsu');
  });

  it('enforces stat requirements before persisting', async () => {
    const out = await svc.handle('alice', { type: 'setLoadout', jutsuIds: ['amaterasu'] });
    expect((first(out) as { code: string }).code).toBe('requirementNotMet');
    expect((await store.getPlayer('alice'))!.loadout).not.toContain('amaterasu');
  });

  it('refuses a change mid-match', async () => {
    await pairUp();
    const out = await svc.handle('alice', { type: 'setLoadout', jutsuIds: ['fireball-jutsu'] });
    expect((first(out) as { code: string }).code).toBe('cannotChangeLoadoutMidMatch');
  });

  it('de-duplicates', async () => {
    const out = await svc.handle('alice', { type: 'setLoadout', jutsuIds: ['fireball-jutsu', 'fireball-jutsu'] });
    expect((first(out) as { jutsuIds: string[] }).jutsuIds).toEqual(['fireball-jutsu']);
  });
});

/* ── Matchmaking and lifecycle ───────────────────────────────────────── */

describe('matchmaking', () => {
  it('pairs two queued players of the same rank', async () => {
    const out = await svc.handle('alice', { type: 'queue', rank: 'genin' });
    expect(kinds(out)).toEqual(['queued']);
    const out2 = await svc.handle('bob', { type: 'queue', rank: 'genin' });
    expect(kinds(out2).filter((k) => k === 'matchFound')).toHaveLength(2);
  });

  it('refuses to queue a player already in a match', async () => {
    await pairUp();
    const out = await svc.handle('alice', { type: 'queue', rank: 'genin' });
    expect((first(out) as { code: string }).code).toBe('alreadyInMatch');
  });

  it('does not pair a player with themselves', async () => {
    await svc.handle('alice', { type: 'queue', rank: 'genin' });
    const out = await svc.handle('alice', { type: 'queue', rank: 'genin' });
    expect(out.every((d) => d.message.type !== 'matchFound')).toBe(true);
  });

  it('a silent client loses the round rather than stalling the match', async () => {
    await pairUp();
    const room = svc.roomFor('alice')!;
    room.submit('alice', [{ fighterId: 'alice', actionId: 'fireball-jutsu', targetId: 'bob', submittedBy: 'alice' }]);
    expect(room.readyToResolve).toBe(false);
    const out = await svc.tickTimeouts();
    expect(out.some((d) => d.message.type === 'roundResolved')).toBe(true);
    expect(room.round).toBe(2);
  });

  it('cleans the room up when the match ends', async () => {
    await pairUp();
    expect(svc.activeRooms).toBe(1);
    const matchId = svc.roomFor('alice')!.matchId;
    await svc.handle('alice', { type: 'forfeit', matchId });
    expect(svc.activeRooms).toBe(0);
    expect(svc.roomFor('alice')).toBeUndefined();
  });
});

describe('rate limiter robustness', () => {
  it('falls back to a conservative policy for an operation it does not know', () => {
    const limiter = new RateLimiter();
    // An unknown operation used to throw, which meant adding a protocol message
    // and forgetting a policy could take the server down.
    expect(() => limiter.take('alice', 'brandNewThing' as never, 0)).not.toThrow();
    let allowed = 0;
    while (limiter.take('alice', 'brandNewThing' as never, 0)) allowed++;
    expect(allowed).toBeGreaterThan(0);
    expect(allowed).toBeLessThan(10);
  });

  it('has a policy for every message the protocol accepts', async () => {
    const { ZClientMessage } = await import('@shinobi/shared');
    const { POLICIES } = await import('../src/ratelimit.js');
    const types = ZClientMessage.options.map((o) => o.shape.type.value as string);
    const missing = types.filter((t) => !(t in POLICIES));
    expect(missing).toEqual([]);
  });
});

/**
 * Serving the client from the API process.
 *
 * A deployed build is one origin: the same server answers /api, /ws and the
 * static bundle. The risk in that arrangement is the catch-all — a fallback that
 * is too greedy turns every mistyped API path into an HTML page and a 200, which
 * is a miserable thing to debug against.
 */
describe('static client hosting', () => {
  const dist = join(tmpdir(), `sealbound-dist-${Math.random().toString(36).slice(2)}`);

  beforeAll(async () => {
    await mkdir(dist, { recursive: true });
    await writeFile(join(dist, 'index.html'), '<!doctype html><title>sealbound</title>');
  });
  afterAll(async () => { await rm(dist, { recursive: true, force: true }); });

  it('serves the app shell for a client route', async () => {
    const app = await buildServer({ store: new MemoryStore(), staticDir: dist });
    const res = await app.inject({ method: 'GET', url: '/some/client/route' });
    expect(res.statusCode).toBe(200);
    expect(res.body).toContain('sealbound');
    await app.close();
  });

  it('still answers an unknown API path with a 404 and not with HTML', async () => {
    const app = await buildServer({ store: new MemoryStore(), staticDir: dist });
    const res = await app.inject({ method: 'GET', url: '/api/no-such-thing' });
    expect(res.statusCode).toBe(404);
    expect(res.body).not.toContain('<!doctype html>');
    await app.close();
  });

  it('does not swallow the health check', async () => {
    const app = await buildServer({ store: new MemoryStore(), staticDir: dist });
    const res = await app.inject({ method: 'GET', url: '/health' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).ok).toBe(true);
    await app.close();
  });

  it('starts without a build present, so development is unaffected', async () => {
    const app = await buildServer({ store: new MemoryStore(), staticDir: join(dist, 'not-here') });
    const res = await app.inject({ method: 'GET', url: '/health' });
    expect(res.statusCode).toBe(200);
    await app.close();
  });
});
