import { beforeEach, describe, expect, it } from 'vitest';
import { COSMETICS, DUNGEONS, ECONOMY, MENTORSHIP, POLITICS, TERRITORY, currentSeason } from '@shinobi/content';
import type { Stats } from '@shinobi/shared';
import { MemoryStore, newMetaState, type ClanRecord, type PlayerRecord } from '../src/store/index.js';
import { GameService } from '../src/service.js';
import { cycleStart, currentWeather, electionPhase, villageEffects, warPeriod } from '../src/world.js';
import { claimGathering, creditWarScore, declareWar, resolveDueWars, startGathering, TerritoryError } from '../src/territory.js';
import { buyListing, claimCrafting, EconomyError, give, held, listForSale, startCrafting, useItem } from '../src/economy.js';
import { certify, PoliticsError, setTax, suffrageProblem } from '../src/politics.js';
import { answerRoom, enterDungeon, normaliseAnswer, verifyAnswer } from '../src/dungeons.js';
import { acceptMentorship, duePayouts, offerMentorship, MentorshipError, recordPayouts } from '../src/mentorship.js';
import { buy as buyCosmetic, CosmeticError, equip } from '../src/cosmetics.js';
import { acceptTrade, giftTo, proposeTrade, TradeError } from '../src/trading.js';

/**
 * The meta-game, tested the way it will actually be attacked.
 *
 * Most of these are not "does the feature work" — they are "can the feature be
 * turned into free money, free ground, or a free election". Each one states the
 * attack it is closing.
 */

const DAY = 24 * 60 * 60 * 1000;

const stats = (o: Partial<Stats> = {}): Stats => ({
  ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60,
  strength: 60, speed: 60, stamina: 60, handSeals: 60, ...o,
});

const player = (id: string, o: Partial<PlayerRecord> = {}): PlayerRecord => ({
  id, name: id, villageId: 'konohagakure', clanId: null, clanJoinedAt: null, clanContribution: 0,
  bloodlineId: null, rank: 'chunin', level: 30, xp: 0, stats: stats(), affinity: 'fire',
  loadout: [], known: [], reputation: 100, ryo: 100_000, training: null, mission: null,
  missionsAtRank: 0, missionsCompleted: 20, squadId: null, rogue: false, defectedAt: null,
  notoriety: 0, titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0,
  sRankCompleted: 0, rating: 1000, ...newMetaState(0), ...o,
});

const clan = (id: string, o: Partial<ClanRecord> = {}): ClanRecord => ({
  id, name: id, nameKey: id, leaderId: `${id}-leader`,
  memberIds: [`${id}-leader`, `${id}-a`, `${id}-b`], officerIds: [], invitedIds: [],
  bank: 500_000, foundedAt: 0, withdrawnToday: 0, withdrawWindowStart: 0, ...o,
});

/* ══════════════════════════════════════════════════════════════════════════
   Seasons and the world clock
   ══════════════════════════════════════════════════════════════════════ */

describe('the world clock', () => {
  it('gives every player the same season at the same instant, and stores nothing', () => {
    const t = 1_800_000_000_000;
    expect(currentSeason(t).id).toBe(currentSeason(t).id);
    const seen = new Set<string>();
    for (let d = 0; d < 28; d++) seen.add(currentSeason(d * DAY).id);
    expect(seen.size).toBe(4);
  });

  it('draws weather from the season, so winter has snow in it and summer does not', () => {
    const winterDay = [...Array(28).keys()].find((d) => currentSeason(d * DAY).id === 'winter')!;
    const summerDay = [...Array(28).keys()].find((d) => currentSeason(d * DAY).id === 'summer')!;
    const winterWeather = new Set([...Array(24).keys()].map((h) => currentWeather(winterDay * DAY + h * 3_600_000)));
    const summerWeather = new Set([...Array(24).keys()].map((h) => currentWeather(summerDay * DAY + h * 3_600_000)));
    expect(winterWeather.has('snow')).toBe(true);
    expect(summerWeather.has('snow')).toBe(false);
  });

  it('keeps the old guarantee: weather cannot be rerolled by asking again', () => {
    const t = 1_700_000_000_000;
    expect(currentWeather(t)).toBe(currentWeather(t));
    expect(currentWeather(t)).not.toBe(currentWeather(t + 3 * 3_600_000));
  });
});

/* ══════════════════════════════════════════════════════════════════════════
   Territory and clan wars
   ══════════════════════════════════════════════════════════════════════ */

describe('territory: declaring', () => {
  let store: MemoryStore;
  const now = warPeriod(1_800_000_000_000).startsAtMs + 60_000;

  beforeEach(async () => {
    store = new MemoryStore();
  });

  const seedClan = async (id: string) => {
    const c = clan(id);
    await store.createClan(c);
    for (const m of c.memberIds) await store.createPlayer(player(m, { clanId: id, clanJoinedAt: 0 }));
    return c;
  };

  it('takes the stake from the clan treasury, not from the officer who declared', async () => {
    const c = await seedClan('shadow');
    const leader = (await store.getPlayer('shadow-leader'))!;
    const before = leader.ryo;
    await declareWar(store, c, leader, 'north-forest', now);
    expect(c.bank).toBe(500_000 - TERRITORY.war.declareCost);
    expect(leader.ryo).toBe(before);
  });

  it('refuses a second declaration on the same region in the same period — at the store, not the check', async () => {
    const a = await seedClan('alpha');
    const b = await seedClan('beta');
    await declareWar(store, a, (await store.getPlayer('alpha-leader'))!, 'north-forest', now);
    await expect(declareWar(store, b, (await store.getPlayer('beta-leader'))!, 'north-forest', now))
      .rejects.toThrow();
  });

  it('closes the declaration window partway through the period', async () => {
    const c = await seedClan('late');
    const period = warPeriod(now);
    const tooLate = period.startsAtMs + (TERRITORY.war.declareWindowDays * DAY) + 1;
    await expect(declareWar(store, c, (await store.getPlayer('late-leader'))!, 'north-forest', tooLate))
      .rejects.toThrow(TerritoryError);
  });

  it('will not let a clan cross a border its village is not at war with', async () => {
    const c = await seedClan('konoha-clan');
    // The Dunes are Suna's ground and nobody has declared anything.
    await expect(declareWar(store, c, (await store.getPlayer('konoha-clan-leader'))!, 'dunes-of-glass', now))
      .rejects.toMatchObject({ code: 'notAtWar' });
  });
});

describe('territory: scoring', () => {
  let store: MemoryStore;
  const now = warPeriod(1_800_000_000_000).startsAtMs + 60_000;

  beforeEach(async () => { store = new MemoryStore(); });

  const setup = async () => {
    const c = clan('holders');
    await store.createClan(c);
    for (const m of c.memberIds) {
      await store.createPlayer(player(m, { clanId: c.id, clanJoinedAt: 0 }));
    }
    await declareWar(store, c, (await store.getPlayer('holders-leader'))!, 'north-forest', now);
    return c;
  };

  it('refuses score from a member who joined after the war started — no mercenaries', async () => {
    await setup();
    const merc = player('merc', { clanId: 'holders', clanJoinedAt: now - 60_000 });
    await store.createPlayer(merc);
    const touched = await creditWarScore(store, merc, 'pvpWin', now);
    expect(touched).toEqual([]);
  });

  it('caps what one member can contribute, so a single grinder cannot decide a war', async () => {
    await setup();
    const grinder = (await store.getPlayer('holders-a'))!;
    for (let i = 0; i < 200; i++) await creditWarScore(store, grinder, 'pvpWin', now);
    const war = (await store.listWars())[0]!;
    expect(war.contributions[grinder.id]).toBe(TERRITORY.war.score.maxPerMemberPerPeriod);
  });

  it('gives the defender an advantage in SCORE and leaves every combat stat alone', async () => {
    const attacker = clan('attacker');
    const defender = clan('defender', { leaderId: 'defender-leader', memberIds: ['defender-leader', 'defender-a', 'defender-b'] });
    await store.createClan(attacker);
    await store.createClan(defender);
    for (const m of [...attacker.memberIds, ...defender.memberIds]) {
      await store.createPlayer(player(m, { clanId: m.startsWith('attacker') ? 'attacker' : 'defender', clanJoinedAt: 0 }));
    }
    await store.saveRegion({ id: 'north-forest', controllingVillageId: 'konohagakure', garrisonClanId: 'defender', capturedAt: 0 });
    await declareWar(store, attacker, (await store.getPlayer('attacker-leader'))!, 'north-forest', now);

    await creditWarScore(store, (await store.getPlayer('attacker-a'))!, 'pvpWin', now);
    await creditWarScore(store, (await store.getPlayer('defender-a'))!, 'pvpWin', now);
    const war = (await store.listWars())[0]!;
    expect(war.defenderScore).toBeGreaterThan(war.attackerScore);
    expect(war.defenderScore).toBe(Math.round(TERRITORY.war.score.pvpWin * TERRITORY.war.defenderScoreMultiplier));

    // The stats of everyone involved are untouched — territory is not combat power.
    const fighter = (await store.getPlayer('defender-a'))!;
    expect(fighter.stats).toEqual(stats());
  });
});

describe('territory: resolution', () => {
  it('destroys part of the stake, so trading a region back and forth loses money', async () => {
    const store = new MemoryStore();
    const now = warPeriod(1_800_000_000_000).startsAtMs + 60_000;
    const c = clan('raiders');
    await store.createClan(c);
    for (const m of c.memberIds) await store.createPlayer(player(m, { clanId: c.id, clanJoinedAt: 0 }));

    const bankBefore = c.bank;
    await declareWar(store, c, (await store.getPlayer('raiders-leader'))!, 'north-forest', now);
    await store.saveClan(c);
    await creditWarScore(store, (await store.getPlayer('raiders-a'))!, 'pvpWin', now);

    const outcomes = await resolveDueWars(store, warPeriod(now).endsAtMs + 1);
    expect(outcomes[0]!.winnerClanId).toBe('raiders');

    const after = (await store.getClan('raiders'))!;
    expect(after.bank).toBeLessThan(bankBefore);

    const region = (await store.getRegion('north-forest'))!;
    expect(region.garrisonClanId).toBe('raiders');
  });

  it('leaves the garrison in place when the assault scores less', async () => {
    const store = new MemoryStore();
    const now = warPeriod(1_800_000_000_000).startsAtMs + 60_000;
    const attacker = clan('weak');
    const defender = clan('strong', { leaderId: 'strong-leader', memberIds: ['strong-leader', 'strong-a', 'strong-b'] });
    await store.createClan(attacker);
    await store.createClan(defender);
    for (const m of [...attacker.memberIds, ...defender.memberIds]) {
      await store.createPlayer(player(m, { clanId: m.startsWith('weak') ? 'weak' : 'strong', clanJoinedAt: 0 }));
    }
    await store.saveRegion({ id: 'north-forest', controllingVillageId: 'konohagakure', garrisonClanId: 'strong', capturedAt: 0 });
    await declareWar(store, attacker, (await store.getPlayer('weak-leader'))!, 'north-forest', now);
    await creditWarScore(store, (await store.getPlayer('strong-a'))!, 'pvpWin', now);

    await resolveDueWars(store, warPeriod(now).endsAtMs + 1);
    expect((await store.getRegion('north-forest'))!.garrisonClanId).toBe('strong');
  });
});

describe('territory: gathering', () => {
  const springDay = [...Array(28).keys()].find((d) => currentSeason(d * DAY).id === 'spring')!;
  const now = springDay * DAY + 3_600_000;
  const region = { id: 'rain-marshes', controllingVillageId: 'amegakure', garrisonClanId: null, capturedAt: 0 };

  it('refuses a resource that is not in season', () => {
    const p = player('p');
    // Deep kelp is a winter crop.
    expect(() => startGathering(p, region, 'deep-kelp', now)).toThrow(TerritoryError);
    expect(() => startGathering(p, region, 'blood-clover', now)).not.toThrow();
  });

  it('refuses a second occupation — you cannot train and gather at the same time', () => {
    const p = player('p', { training: { stat: 'speed', tier: 1, locationId: 'forest', startedAt: now } });
    expect(() => startGathering(p, region, 'blood-clover', now)).toThrow(TerritoryError);
  });

  it('cannot be re-rolled by claiming again — the yield is seeded from the trip', () => {
    const p = player('p', { gathering: { regionId: 'rain-marshes', itemId: 'blood-clover', startedAt: now } });
    const opts = { villageGatherBonus: 0, outsiderPenaltyWaived: false, outsiderTollFraction: 0.2 };
    const later = now + TERRITORY.yield.gatherMinutes * 60_000;
    const first = claimGathering(p, region, later, opts);
    const second = claimGathering(p, region, later, opts);
    expect(second.units).toBe(first.units);
  });

  it('pays an outsider less and takes a toll for the village that holds the ground', () => {
    const outsider = player('out', {
      villageId: 'konohagakure',
      gathering: { regionId: 'rain-marshes', itemId: 'blood-clover', startedAt: now },
    });
    const local = player('local', {
      villageId: 'amegakure',
      gathering: { regionId: 'rain-marshes', itemId: 'blood-clover', startedAt: now },
    });
    const later = now + TERRITORY.yield.gatherMinutes * 60_000;
    const opts = { villageGatherBonus: 0, outsiderPenaltyWaived: false, outsiderTollFraction: 0.2 };
    const away = claimGathering(outsider, region, later, opts);
    const home = claimGathering(local, region, later, opts);
    expect(home.units).toBeGreaterThan(away.units);
    expect(home.tollUnits).toBe(0);
  });
});

/* ══════════════════════════════════════════════════════════════════════════
   Economy
   ══════════════════════════════════════════════════════════════════════ */

describe('crafting', () => {
  const p = () => player('smith', { rank: 'chunin', stats: stats({ strength: 60, handSeals: 60, intelligence: 60 }) });

  it('consumes the inputs when the job starts, so they cannot be sold out from under it', () => {
    const smith = p();
    give(smith, 'river-iron', 4);
    give(smith, 'ore-vein', 2);
    smith.crafting = startCrafting(smith, 'fold-steel', 0);
    expect(held(smith, 'river-iron')).toBe(0);
    expect(held(smith, 'ore-vein')).toBe(0);
  });

  it('pays nothing before the job is finished', () => {
    const smith = p();
    give(smith, 'river-iron', 4);
    give(smith, 'ore-vein', 2);
    smith.crafting = startCrafting(smith, 'fold-steel', 0);
    expect(() => claimCrafting(smith, 60_000)).toThrow(EconomyError);
    const result = claimCrafting(smith, 25 * 60_000);
    expect(result.item).toBe('steel-billet');
    expect(held(smith, 'steel-billet')).toBe(1);
  });

  it('refuses to start without every input, and takes nothing on the way out', () => {
    const smith = p();
    give(smith, 'river-iron', 4);
    expect(() => startCrafting(smith, 'fold-steel', 0)).toThrow(EconomyError);
    expect(held(smith, 'river-iron')).toBe(4);
  });
});

describe('the market', () => {
  let store: MemoryStore;
  beforeEach(() => { store = new MemoryStore(); });

  const seller = () => player('seller', { ryo: 50_000 });
  const buyer = () => player('buyer', { ryo: 50_000 });

  it('escrows the goods, so the same stack cannot be listed twice', async () => {
    const s = seller();
    give(s, 'river-iron', 5);
    await listForSale(store, s, 'river-iron', 5, 60, 0);
    expect(held(s, 'river-iron')).toBe(0);
    await expect(listForSale(store, s, 'river-iron', 5, 60, 0)).rejects.toThrow(EconomyError);
  });

  it('destroys ryo on every wash trade between two accounts', async () => {
    const s = seller();
    const b = buyer();
    await store.createPlayer(s);
    await store.createPlayer(b);
    give(s, 'river-iron', 10);

    const before = s.ryo + b.ryo;
    const { listing, fee } = await listForSale(store, s, 'river-iron', 10, 100, 0);
    const bought = await buyListing(store, b, listing.id, 0.05, 0);
    const after = (s.ryo + bought.toSeller) + b.ryo;

    expect(fee).toBeGreaterThan(0);
    expect(bought.tax).toBeGreaterThan(0);
    // The pair is poorer for having done it. That is the whole defence: nobody
    // has to detect the collusion, because it loses money.
    expect(after).toBeLessThan(before);
    expect(before - after).toBe(fee + bought.tax);
  });

  it('charges the seller\'s village tax rate, not a constant — the government sets it', async () => {
    const s = seller();
    const b = buyer();
    await store.createPlayer(s);
    await store.createPlayer(b);
    give(s, 'river-iron', 10);
    const { listing } = await listForSale(store, s, 'river-iron', 10, 100, 0);
    const bought = await buyListing(store, b, listing.id, 0.11, 0);
    expect(bought.tax).toBe(Math.floor(1000 * 0.11));
    expect(bought.toSeller).toBe(1000 - bought.tax);
  });

  it('stays lossy even at the most generous tax a government may legally set', async () => {
    const s = seller();
    const b = buyer();
    await store.createPlayer(s);
    await store.createPlayer(b);
    give(s, 'river-iron', 10);
    const before = s.ryo + b.ryo;
    const { listing, fee } = await listForSale(store, s, 'river-iron', 10, 100, 0);
    // POLITICS.tax.min is the floor of the band — no Kage can go below it.
    const bought = await buyListing(store, b, listing.id, POLITICS.tax.min, 0);
    expect(fee + bought.tax).toBeGreaterThan(0);
    expect((s.ryo + bought.toSeller) + b.ryo).toBeLessThan(before);
  });

  it('refuses a price outside the band, in both directions', async () => {
    const s = seller();
    give(s, 'river-iron', 4);
    await expect(listForSale(store, s, 'river-iron', 1, 1, 0)).rejects.toMatchObject({ code: 'priceOutOfBand' });
    await expect(listForSale(store, s, 'river-iron', 1, 1_000_000, 0)).rejects.toMatchObject({ code: 'priceOutOfBand' });
  });

  it('will not sell to yourself', async () => {
    const s = seller();
    await store.createPlayer(s);
    give(s, 'river-iron', 2);
    const { listing } = await listForSale(store, s, 'river-iron', 2, 60, 0);
    await expect(buyListing(store, s, listing.id, 0.05, 0)).rejects.toMatchObject({ code: 'ownListing' });
  });

  it('lets exactly one of two racing buyers win, and the loser pays nothing', async () => {
    const s = seller();
    const b1 = buyer();
    const b2 = player('buyer2', { ryo: 50_000 });
    await store.createPlayer(s);
    give(s, 'river-iron', 2);
    const { listing } = await listForSale(store, s, 'river-iron', 2, 60, 0);

    const before2 = b2.ryo;
    await buyListing(store, b1, listing.id, 0.05, 0);
    await expect(buyListing(store, b2, listing.id, 0.05, 0)).rejects.toMatchObject({ code: 'noSuchListing' });
    expect(b2.ryo).toBe(before2);
    expect(held(b2, 'river-iron')).toBe(0);
  });

  it('refuses to list anything untradable — a mentor gift is not currency', async () => {
    const s = seller();
    s.inventory['ashwood-charm'] = 1;
    await expect(listForSale(store, s, 'ashwood-charm', 1, 100, 0)).rejects.toMatchObject({ code: 'untradable' });
  });

  it('refuses a missing-nin the village market entirely', async () => {
    const s = player('rogue-seller', { rogue: true });
    give(s, 'river-iron', 2);
    await expect(listForSale(store, s, 'river-iron', 2, 60, 0)).rejects.toMatchObject({ code: 'rogue' });
  });
});

describe('consumables', () => {
  it('never touch a combat statistic', () => {
    for (const item of ECONOMY.items) {
      if (!item.use) continue;
      expect(Object.keys(item.use).sort()).toEqual(
        Object.keys(item.use).filter((k) => ['trainingRateBonus', 'gatherYieldBonus', 'dungeonAttempts', 'uses'].includes(k)).sort(),
      );
    }
  });

  it('are spent rather than held, so a bonus cannot become permanent', () => {
    const p = player('p');
    give(p, 'training-weights', 1);
    useItem(p, 'training-weights');
    expect(p.boosts.trainingRateBonus).toBeGreaterThan(0);
    expect(held(p, 'training-weights')).toBe(0);
    expect(() => useItem(p, 'training-weights')).toThrow(EconomyError);
  });
});

/* ══════════════════════════════════════════════════════════════════════════
   Politics
   ══════════════════════════════════════════════════════════════════════ */

describe('elections', () => {
  const cycle = 4000;
  const nominationTime = cycleStart(cycle) + 3_600_000;
  const votingTime = cycleStart(cycle) + (POLITICS.nominationDays * DAY) + 3_600_000;

  let store: MemoryStore;
  beforeEach(() => { store = new MemoryStore(); });

  it('refuses a vote from an account with no play behind it', () => {
    const fresh = player('fresh', { rank: 'academy', missionsCompleted: 0, createdAt: votingTime });
    expect(suffrageProblem(fresh, votingTime)).not.toBeNull();
    const veteran = player('vet', { createdAt: 0 });
    expect(suffrageProblem(veteran, votingTime)).toBeNull();
  });

  it('counts one vote per player per office per cycle and rejects the second', async () => {
    const svc = new GameService(store, () => votingTime);
    const voter = player('voter', { createdAt: 0 });
    await store.createPlayer(voter);
    await store.addCandidacy({ villageId: 'konohagakure', officeId: 'kage', cycle, playerId: 'cand' });
    await store.createPlayer(player('cand', { rank: 'jonin', reputation: 300 }));

    const first = await svc.handle('voter', { type: 'castVote', officeId: 'kage', candidateId: 'cand' });
    expect(first[0]!.message.type).toBe('voted');
    const second = await svc.handle('voter', { type: 'castVote', officeId: 'kage', candidateId: 'cand' });
    expect(second[0]!.message).toMatchObject({ type: 'error', code: 'alreadyVoted' });
  });

  it('will not accept votes during nomination, nor nominations during voting', async () => {
    const nominating = new GameService(store, () => nominationTime);
    const candidate = player('runner', { rank: 'jonin', reputation: 300 });
    await store.createPlayer(candidate);
    const stood = await nominating.handle('runner', { type: 'standForOffice', officeId: 'kage' });
    expect(stood[0]!.message.type).toBe('nominated');

    const voting = new GameService(store, () => votingTime);
    const late = await voting.handle('runner', { type: 'standForOffice', officeId: 'kage' });
    expect(late[0]!.message).toMatchObject({ code: 'wrongPhase' });
  });

  it('breaks a tie on reputation and then on id, never on a roll', async () => {
    await store.createPlayer(player('a-candidate', { rank: 'jonin', reputation: 200 }));
    await store.createPlayer(player('b-candidate', { rank: 'jonin', reputation: 500 }));
    for (const id of ['a-candidate', 'b-candidate']) {
      await store.addCandidacy({ villageId: 'konohagakure', officeId: 'kage', cycle, playerId: id });
    }
    const seated = await certify(store, 'konohagakure', cycle + 1);
    const kage = seated.find((o) => o.officeId === 'kage')!;
    expect(kage.holderIds).toEqual(['b-candidate']);

    // Idempotent: certifying again returns the same government.
    const again = await certify(store, 'konohagakure', cycle + 1);
    expect(again.find((o) => o.officeId === 'kage')!.holderIds).toEqual(['b-candidate']);
  });
});

describe('office powers', () => {
  it('keeps tax inside its band, moving once per term and only by a step', () => {
    const now = cycleStart(5000) + 3_600_000;
    const village = { id: 'konohagakure', taxRate: 0.05, treasury: 0, laws: [], commissions: [], atWarWith: [], taxSetInCycle: -1 };
    expect(() => setTax(village, 0.9, now)).toThrow(PoliticsError);
    expect(() => setTax(village, 0.5, now)).toThrow(PoliticsError);
    setTax(village, 0.09, now);
    expect(village.taxRate).toBe(0.09);
    // A second change in the same term would let a holder ratchet in legal steps
    // until they arrived where the band was meant to stop them.
    expect(() => setTax(village, 0.12, now)).toThrow(PoliticsError);
    expect(village.taxRate).toBe(0.09);
  });

  it('refuses a decree from somebody who holds no office', async () => {
    const store = new MemoryStore();
    const now = cycleStart(5000) + (POLITICS.nominationDays + POLITICS.votingDays) * DAY + 3_600_000;
    const svc = new GameService(store, () => now);
    await store.createPlayer(player('nobody'));
    const out = await svc.handle('nobody', { type: 'setVillageTax', rate: 0.02 });
    expect(out[0]!.message).toMatchObject({ code: 'noPower' });
  });

  it('offers no path at all from the treasury to a wallet', () => {
    const raw = JSON.stringify(POLITICS);
    expect(/"(payout|salary|withdraw|toPlayer)"/i.test(raw)).toBe(false);
    for (const c of POLITICS.treasury.commissions) {
      expect(Object.keys(c.effect).every((k) => /Village$|ScoreBonus$|Reduction$/.test(k))).toBe(true);
    }
  });

  it('bounds every law effect to something outside a match', () => {
    for (const law of POLITICS.laws) {
      for (const key of Object.keys(law.effect)) {
        expect(['outsiderPenaltyWaived', 'warScoreBonus', 'outsiderTollFraction', 'menteeBonus']).toContain(key);
      }
    }
  });

  it('drops an expired commission from the effects without needing a sweep', () => {
    const now = 10 * DAY;
    const village = {
      id: 'konohagakure', taxRate: 0.05, treasury: 0, laws: [],
      commissions: [{ id: 'academy-stipend', endsAt: now - 1 }], atWarWith: [], taxSetInCycle: -1,
    };
    expect(villageEffects(village, now).trainingBonus).toBe(0);
  });
});

/* ══════════════════════════════════════════════════════════════════════════
   Dungeons
   ══════════════════════════════════════════════════════════════════════ */

describe('dungeons', () => {
  const winterDay = [...Array(28).keys()].find((d) => currentSeason(d * DAY).id === 'winter')!;
  const winter = winterDay * DAY + 3_600_000;

  it('stores only salted digests — no answer appears anywhere in the content', () => {
    const raw = JSON.stringify(DUNGEONS);
    expect(raw).not.toMatch(/"answer"\s*:/);
    const salts = DUNGEONS.dungeons.flatMap((d) => d.rooms.map((r) => r.salt));
    expect(new Set(salts).size).toBe(salts.length);
  });

  it('verifies an answer regardless of case and punctuation', () => {
    const room = DUNGEONS.dungeons.find((d) => d.id === 'terrace-vault')!.rooms.find((r) => r.id === 'gate')!;
    expect(verifyAnswer(room.salt, room.answerHash, 'The User')).toBe(true);
    expect(verifyAnswer(room.salt, room.answerHash, 'the-user')).toBe(true);
    expect(verifyAnswer(room.salt, room.answerHash, 'the opponent')).toBe(false);
    expect(normaliseAnswer('Sudden Death!')).toBe('suddendeath');
  });

  it('never sends the room the player has not reached', async () => {
    const store = new MemoryStore();
    const svc = new GameService(store, () => winter);
    const p = player('delver', { rank: 'genin' });
    give(p, 'shrine-key', 1);
    await store.createPlayer(p);

    const entered = await svc.handle('delver', { type: 'enterDungeon', dungeonId: 'sunken-shrine' });
    const room = entered[0]!.message as { type: string; prompt: string; index: number };
    expect(room.type).toBe('dungeonRoom');
    expect(room.index).toBe(1);
    const dungeon = DUNGEONS.dungeons.find((d) => d.id === 'sunken-shrine')!;
    const payload = JSON.stringify(entered);
    for (const later of dungeon.rooms.slice(1)) expect(payload).not.toContain(later.prompt);
    for (const r of dungeon.rooms) expect(payload).not.toContain(r.answerHash);
  });

  it('spends the key on the way in, so a peek at the first room is not free', async () => {
    const store = new MemoryStore();
    const svc = new GameService(store, () => winter);
    const p = player('delver', { rank: 'genin' });
    give(p, 'shrine-key', 1);
    await store.createPlayer(p);
    await svc.handle('delver', { type: 'enterDungeon', dungeonId: 'sunken-shrine' });
    expect(held((await store.getPlayer('delver'))!, 'shrine-key')).toBe(0);
  });

  it('locks the run after a wrong answer, which is what makes brute force expensive', () => {
    const p = player('delver', {
      dungeon: { dungeonId: 'terrace-vault', roomIndex: 0, attemptsLeft: 3, startedAt: 0, lockedUntil: 0 },
    });
    const first = answerRoom(p, 'four', 1000);
    expect(first).toMatchObject({ kind: 'wrong', attemptsLeft: 2 });
    expect(() => answerRoom(p, 'five', 2000)).toThrow(/locked/);
  });

  it('ends the run when the attempts are gone', () => {
    const p = player('delver', {
      dungeon: { dungeonId: 'terrace-vault', roomIndex: 0, attemptsLeft: 1, startedAt: 0, lockedUntil: 0 },
    });
    expect(answerRoom(p, 'nonsense', 1000)).toMatchObject({ kind: 'failed' });
    expect(p.dungeon).toBeNull();
  });

  it('puts a dungeon on cooldown at ENTRY, so known answers are not a ryo faucet', () => {
    const p = player('delver', { rank: 'chunin' });
    const { run } = enterDungeon(p, 'sunken-shrine', null, winter);
    p.dungeon = run;
    p.dungeon = null; // cleared it, or walked out — the cooldown does not care
    expect(() => enterDungeon(p, 'sunken-shrine', null, winter + 60_000)).toThrow(/onCooldown/);
    const dungeon = DUNGEONS.dungeons.find((d) => d.id === 'sunken-shrine')!;
    expect(() => enterDungeon(p, 'sunken-shrine', null, winter + dungeon.cooldownHours * 3_600_000 + 1))
      .not.toThrow(/onCooldown/);
  });

  it('caps runs per day across different dungeons too', () => {
    const p = player('delver', { rank: 'chunin' });
    const open = DUNGEONS.dungeons.filter((d) => d.seasons.length === 0 || d.seasons.includes('winter'));
    let now = winter;
    let entered = 0;
    for (const d of open) {
      try { enterDungeon(p, d.id, null, now); entered++; } catch { /* season or rank */ }
      now += 60_000;
    }
    expect(entered).toBeLessThanOrEqual(DUNGEONS.rules.maxRunsPerDay);
  });

  it('hands a dungeon legendary to the first clearer only', async () => {
    const store = new MemoryStore();
    await store.claimLegendary({ itemId: 'crown-of-long-winter', holderId: 'first', acquiredAt: 0 }, 0);
    await expect(store.claimLegendary({ itemId: 'crown-of-long-winter', holderId: 'second', acquiredAt: 1 }, 1))
      .rejects.toThrow();
  });
});

/* ══════════════════════════════════════════════════════════════════════════
   Mentorship
   ══════════════════════════════════════════════════════════════════════ */

describe('mentorship', () => {
  let store: MemoryStore;
  beforeEach(() => { store = new MemoryStore(); });

  const mentor = () => player('mentor', { rank: 'jonin', level: 50, reputation: 200 });
  const mentee = () => player('mentee', { rank: 'genin', level: 5, reputation: 0 });

  it('pays the mentor only in things that cannot be sold', () => {
    const reward = MENTORSHIP.mentor.rewardPerMilestone;
    expect(Object.keys(reward).sort()).toEqual(['clanContribution', 'reputation']);
    expect(JSON.stringify(reward)).not.toMatch(/ryo|item|gold/i);
  });

  it('refuses a pairing between two equals', async () => {
    const a = mentor();
    const b = player('peer', { rank: 'chunin', level: 48 });
    await expect(offerMentorship(store, a, b, 0)).rejects.toMatchObject({ code: 'levelGapTooSmall' });
  });

  it('lets a player be mentored once, ever', async () => {
    const m = mentor();
    const s = mentee();
    const offer = await offerMentorship(store, m, s, 0);
    await acceptMentorship(store, offer, s, 0);
    expect(s.mentoredBefore).toBe(true);
    await expect(offerMentorship(store, m, s, DAY)).rejects.toMatchObject({ code: 'alreadyMentored' });
  });

  it('pays nothing until the pairing has matured', async () => {
    const m = mentor();
    const s = mentee();
    const offer = await offerMentorship(store, m, s, 0);
    await acceptMentorship(store, offer, s, 0);
    s.missionsCompleted = 50;
    expect(duePayouts(offer, s, 'genin', 60_000)).toEqual([]);
    const mature = MENTORSHIP.pairing.minDurationMinutesBeforeRewards * 60_000 + 1;
    expect(duePayouts(offer, s, 'genin', mature).length).toBeGreaterThan(0);
  });

  it('pays a milestone once and caps the week', async () => {
    const m = mentor();
    const s = mentee();
    const offer = await offerMentorship(store, m, s, 0);
    await acceptMentorship(store, offer, s, 0);
    s.missionsCompleted = 50;
    s.pvpWins = 10;
    s.rank = 'chunin';

    const mature = MENTORSHIP.pairing.minDurationMinutesBeforeRewards * 60_000 + 1;
    const first = duePayouts(offer, s, 'genin', mature);
    expect(first.length).toBe(MENTORSHIP.mentor.maxRewardedMilestonesPerMenteePerWeek);
    recordPayouts(offer, first, mature);
    // The weekly ceiling is now spent, however much the student achieves.
    expect(duePayouts(offer, s, 'genin', mature + 60_000)).toEqual([]);
  });

  it('holds a mentor to a concurrent limit', async () => {
    const m = mentor();
    for (let i = 0; i < MENTORSHIP.mentor.maxConcurrentMentees; i++) {
      const s = player(`student-${i}`, { rank: 'genin', level: 5 });
      const offer = await offerMentorship(store, m, s, 0);
      await acceptMentorship(store, offer, s, 0);
    }
    const extra = player('one-too-many', { rank: 'genin', level: 5 });
    await expect(offerMentorship(store, m, extra, 0)).rejects.toMatchObject({ code: 'tooManyMentees' });
  });

  it('refuses a student who already has a mentor', async () => {
    const s = mentee();
    const first = await offerMentorship(store, mentor(), s, 0);
    await acceptMentorship(store, first, s, 0);
    const rival = player('rival-mentor', { rank: 'jonin', level: 50, reputation: 200 });
    await expect(offerMentorship(store, rival, s, 0)).rejects.toThrow(MentorshipError);
  });
});

/* ══════════════════════════════════════════════════════════════════════════
   Cosmetics
   ══════════════════════════════════════════════════════════════════════ */

describe('cosmetics', () => {
  it('carry no stat, effect, or combat field anywhere in the catalogue', () => {
    expect(COSMETICS.rules.affectsCombat).toBe(false);
    expect(JSON.stringify(COSMETICS)).not.toMatch(/"(stat|stats|power|bonus|multiplier|effect|damage)"\s*:/);
  });

  it('leaves every statistic untouched when bought and worn', () => {
    const p = player('dresser');
    const before = { ...p.stats };
    buyCosmetic(p, 'hair-long-tied', 0);
    equip(p, 'hair-long-tied');
    expect(p.stats).toEqual(before);
  });

  it('refuses to sell a seasonal item out of its season', () => {
    const p = player('dresser');
    const summerDay = [...Array(28).keys()].find((d) => currentSeason(d * DAY).id === 'summer')!;
    expect(() => buyCosmetic(p, 'cloak-winterfall', summerDay * DAY)).toThrow(CosmeticError);
    const winterDay = [...Array(28).keys()].find((d) => currentSeason(d * DAY).id === 'winter')!;
    expect(() => buyCosmetic(p, 'cloak-winterfall', winterDay * DAY)).not.toThrow();
  });

  it('will not sell what has to be earned', () => {
    const p = player('dresser');
    expect(() => buyCosmetic(p, 'victory-turn-away', 0)).toThrow(CosmeticError);
    p.titles.push('kage-slayer');
    expect(() => buyCosmetic(p, 'victory-turn-away', 0)).not.toThrow();
    expect(p.ryo).toBe(100_000);
  });

  it('refuses to equip something unowned', () => {
    const p = player('dresser');
    expect(() => equip(p, 'aura-first-frost')).toThrow(CosmeticError);
  });

  it('keeps cosmetics out of the tradable economy entirely', () => {
    const cosmeticIds = new Set(COSMETICS.items.map((c) => c.id));
    for (const item of ECONOMY.items) expect(cosmeticIds.has(item.id)).toBe(false);
  });
});


/* ══════════════════════════════════════════════════════════════════════════
   Direct trade and gifting

   Added by owner decision on 2026-08-04. Free transfer between accounts is now
   intended, so none of these test that value is destroyed — that property is
   deliberately gone. They test the three things that still have to hold:
   nothing duplicates, untradable stays untradable, and every transfer is
   attributable.
   ══════════════════════════════════════════════════════════════════════ */

describe('direct trade', () => {
  let store: MemoryStore;
  beforeEach(() => { store = new MemoryStore(); });

  const pair = async () => {
    const a = player('trader-a', { ryo: 10_000 });
    const b = player('trader-b', { ryo: 10_000 });
    give(a, 'river-iron', 10);
    give(b, 'ore-vein', 4);
    await store.createPlayer(a);
    await store.createPlayer(b);
    return { a, b };
  };

  it('swaps both sides atomically and conserves every unit', async () => {
    const { a, b } = await pair();
    const trade = await proposeTrade(store, a,
      b, { ryo: 500, items: [{ itemId: 'river-iron', qty: 10 }] },
      { ryo: 0, items: [{ itemId: 'ore-vein', qty: 4 }] }, 0);
    await acceptTrade(store, trade, a, b, 0);

    expect(held(a, 'river-iron')).toBe(0);
    expect(held(b, 'river-iron')).toBe(10);
    expect(held(b, 'ore-vein')).toBe(0);
    expect(held(a, 'ore-vein')).toBe(4);
    expect(a.ryo).toBe(9_500);
    expect(b.ryo).toBe(10_500);
  });

  it('moves nothing at all when the accepter cannot deliver their side', async () => {
    const { a, b } = await pair();
    const trade = await proposeTrade(store, a, b,
      { ryo: 0, items: [{ itemId: 'river-iron', qty: 10 }] },
      { ryo: 0, items: [{ itemId: 'ore-vein', qty: 99 }] }, 0);

    await expect(acceptTrade(store, trade, a, b, 0)).rejects.toThrow(TradeError);
    // The proposer keeps their goods; a half-applied trade would be a dupe.
    expect(held(a, 'river-iron')).toBe(10);
    expect(held(b, 'ore-vein')).toBe(4);
    expect(a.ryo).toBe(10_000);
  });

  it('lets only one of two acceptances settle, replaying the same stale record', async () => {
    const { a, b } = await pair();
    const trade = await proposeTrade(store, a, b,
      { ryo: 0, items: [{ itemId: 'river-iron', qty: 10 }] }, { ryo: 0, items: [] }, 0);

    await acceptTrade(store, trade, a, b, 0);
    // Replaying the same record must fail. It happens to fail on delivery rather
    // than on the missing row, because the goods have already gone — either way
    // nothing duplicates, which is the property under test.
    await expect(acceptTrade(store, trade, a, b, 0)).rejects.toThrow(TradeError);
    expect(held(b, 'river-iron')).toBe(10);
    expect(held(a, 'river-iron')).toBe(0);
  });

  it('lets only one of two SIMULTANEOUS acceptances settle', async () => {
    const { a, b } = await pair();
    const trade = await proposeTrade(store, a, b,
      { ryo: 0, items: [{ itemId: 'river-iron', qty: 10 }] }, { ryo: 0, items: [] }, 0);

    /* Both calls validate before either deletes, so the delete is the only thing
       standing between this and a duplicate payout. That is exactly the case the
       ordering inside acceptTrade exists for. */
    const results = await Promise.allSettled([
      acceptTrade(store, trade, a, b, 0),
      acceptTrade(store, trade, a, b, 0),
    ]);
    expect(results.filter((r) => r.status === 'fulfilled').length).toBe(1);
    expect(held(a, 'river-iron') + held(b, 'river-iron')).toBe(10);
  });

  it('reports a settled trade as gone when the service looks it up again', async () => {
    const { a, b } = await pair();
    const svc = new GameService(store, () => 0);
    const proposed = await svc.handle('trader-a', {
      type: 'proposeTrade', toName: 'trader-b',
      offerRyo: 0, offerItems: [{ itemId: 'river-iron', qty: 4 }],
      requestRyo: 0, requestItems: [],
    });
    const id = (proposed[0]!.message as { tradeId: string }).tradeId;
    await svc.handle('trader-b', { type: 'acceptTrade', tradeId: id });
    const again = await svc.handle('trader-b', { type: 'acceptTrade', tradeId: id });
    expect(again[0]!.message).toMatchObject({ type: 'error', code: 'noSuchTrade' });
  });

  it('offering the same stack to two people only ever pays out once', async () => {
    const { a, b } = await pair();
    const c = player('trader-c', { ryo: 10_000 });
    await store.createPlayer(c);

    const toB = await proposeTrade(store, a, b, { ryo: 0, items: [{ itemId: 'river-iron', qty: 10 }] }, { ryo: 0, items: [] }, 0);
    const toC = await proposeTrade(store, a, c, { ryo: 0, items: [{ itemId: 'river-iron', qty: 10 }] }, { ryo: 0, items: [] }, 0);

    await acceptTrade(store, toB, a, b, 0);
    await expect(acceptTrade(store, toC, a, c, 0)).rejects.toThrow(TradeError);
    expect(held(a, 'river-iron') + held(b, 'river-iron') + held(c, 'river-iron')).toBe(10);
  });

  it('refuses to move an untradable item by trade or by gift', async () => {
    const { a, b } = await pair();
    a.inventory['ashwood-charm'] = 1;
    await expect(proposeTrade(store, a, b,
      { ryo: 0, items: [{ itemId: 'ashwood-charm', qty: 1 }] }, { ryo: 0, items: [] }, 0))
      .rejects.toMatchObject({ code: 'untradable' });
    await expect(giftTo(store, a, b, { ryo: 0, items: [{ itemId: 'ashwood-charm', qty: 1 }] }, 0))
      .rejects.toMatchObject({ code: 'untradable' });
    expect(held(a, 'ashwood-charm')).toBe(1);
  });

  it('refuses to trade with yourself', async () => {
    const { a } = await pair();
    await expect(proposeTrade(store, a, a, { ryo: 100, items: [] }, { ryo: 0, items: [] }, 0))
      .rejects.toMatchObject({ code: 'self' });
  });

  it('refuses the same item listed twice on one side', async () => {
    const { a, b } = await pair();
    await expect(proposeTrade(store, a, b,
      { ryo: 0, items: [{ itemId: 'river-iron', qty: 6 }, { itemId: 'river-iron', qty: 6 }] },
      { ryo: 0, items: [] }, 0)).rejects.toMatchObject({ code: 'badQuantity' });
  });

  it('refuses a trade that would overflow the receiver\'s stack', async () => {
    const { a, b } = await pair();
    const item = ECONOMY.items.find((i) => i.tradable && i.stackMax < 500)!;
    a.inventory[item.id] = 5;
    b.inventory[item.id] = item.stackMax;
    const trade = await proposeTrade(store, a, b,
      { ryo: 0, items: [{ itemId: item.id, qty: 5 }] }, { ryo: 0, items: [] }, 0);
    await expect(acceptTrade(store, trade, a, b, 0)).rejects.toMatchObject({ code: 'stackFull' });
    expect(held(a, item.id)).toBe(5);
  });

  it('expires a proposal rather than letting it settle later', async () => {
    const { a, b } = await pair();
    const trade = await proposeTrade(store, a, b,
      { ryo: 0, items: [{ itemId: 'river-iron', qty: 1 }] }, { ryo: 0, items: [] }, 0);
    await expect(acceptTrade(store, trade, a, b, trade.expiresAt + 1))
      .rejects.toMatchObject({ code: 'expired' });
  });

  it('records every completed transfer with both ends and the contents', async () => {
    const { a, b } = await pair();
    const trade = await proposeTrade(store, a, b,
      { ryo: 250, items: [{ itemId: 'river-iron', qty: 3 }] },
      { ryo: 0, items: [{ itemId: 'ore-vein', qty: 1 }] }, 1000);
    await acceptTrade(store, trade, a, b, 1000);
    await giftTo(store, b, a, { ryo: 99, items: [] }, 2000);

    const log = await store.listTransfers('trader-a');
    expect(log.length).toBe(3);
    expect(log.filter((t) => t.kind === 'gift').length).toBe(1);
    const outbound = log.find((t) => t.fromId === 'trader-a' && t.kind === 'trade')!;
    expect(outbound.toId).toBe('trader-b');
    expect(outbound.ryo).toBe(250);
    expect(outbound.items).toEqual([{ itemId: 'river-iron', qty: 3 }]);
  });

  it('still refuses a missing-nin, who has no village to trade in', async () => {
    const { b } = await pair();
    const rogue = player('missing-nin', { rogue: true });
    give(rogue, 'river-iron', 5);
    await store.createPlayer(rogue);
    await expect(giftTo(store, rogue, b, { ryo: 0, items: [{ itemId: 'river-iron', qty: 5 }] }, 0))
      .rejects.toMatchObject({ code: 'rogue' });
  });

  it('gifts money in one step, with no proposal to accept', async () => {
    const { a, b } = await pair();
    await giftTo(store, a, b, { ryo: 1_000, items: [] }, 0);
    expect(a.ryo).toBe(9_000);
    expect(b.ryo).toBe(11_000);
  });
});
