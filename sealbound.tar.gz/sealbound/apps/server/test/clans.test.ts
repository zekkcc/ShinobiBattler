import { beforeEach, describe, expect, it } from 'vitest';
import { CLAN_RULES } from '@shinobi/content';
import type { ServerMessage, Stats } from '@shinobi/shared';
import { GameService } from '../src/service.js';
import { MemoryStore, type PlayerRecord } from '../src/store/index.js';
import { ClanError, deposit, foundClan, leaveClan, rankClans, roleOf, withdraw } from '../src/clans.js';

const stats = (o: Partial<Stats> = {}): Stats => ({
  ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60,
  strength: 60, speed: 60, stamina: 60, handSeals: 60, ...o,
});

const player = (id: string, o: Partial<PlayerRecord> = {}): PlayerRecord => ({
  id, name: id, villageId: 'konohagakure', clanId: null, clanJoinedAt: null,
  clanContribution: 0, bloodlineId: null, rank: 'chunin', level: 30, xp: 0,
  stats: stats(), affinity: 'fire', loadout: [], known: [],
  reputation: 100, ryo: 100_000, training: null, mission: null,
  missionsAtRank: 0, missionsCompleted: 0, squadId: null,
  rogue: false, defectedAt: null, notoriety: 0,
  titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0, sRankCompleted: 0, rating: 1000, ...o,
});

let store: MemoryStore;
let clock: number;
let svc: GameService;

beforeEach(async () => {
  store = new MemoryStore();
  clock = 1_700_000_000_000;
  svc = new GameService(store, () => clock);
  for (const id of ['kaito', 'rin', 'sora']) await store.createPlayer(player(id));
});

const first = (out: { message: ServerMessage }[]) => out[0]!.message;
const code = (out: { message: ServerMessage }[]) => (first(out) as { code?: string }).code;

async function foundWith(leader: string, name = 'Iron Lotus'): Promise<string> {
  const out = await svc.handle(leader, { type: 'foundClan', name });
  return (first(out) as { clanId: string }).clanId;
}
async function join(clanId: string, leader: string, who: string): Promise<void> {
  await svc.handle(leader, { type: 'inviteToClan', name: who });
  await svc.handle(who, { type: 'acceptClanInvite', clanId });
}

/* ── Founding ────────────────────────────────────────────────────────── */

describe('founding a clan', () => {
  it('costs money and standing, not money alone', () => {
    const f = CLAN_RULES.founding;
    expect(() => foundClan(player('a', { ryo: 0 }), 'Iron Lotus', 0)).toThrow(ClanError);
    expect(() => foundClan(player('b', { rank: 'genin' }), 'Iron Lotus', 0)).toThrow(ClanError);
    expect(() => foundClan(player('c', { reputation: 0 }), 'Iron Lotus', 0)).toThrow(ClanError);
    expect(() => foundClan(player('d'), 'Iron Lotus', 0)).not.toThrow();
    expect(f.ryoCost).toBeGreaterThan(0);
  });

  it('charges the founder and makes them leader', async () => {
    const clanId = await foundWith('kaito');
    const p = (await store.getPlayer('kaito'))!;
    expect(p.ryo).toBe(100_000 - CLAN_RULES.founding.ryoCost);
    expect(p.clanId).toBe(clanId);
    expect((await store.getClan(clanId))!.leaderId).toBe('kaito');
  });

  it('refuses a name somebody already has, ignoring case and spacing', async () => {
    await foundWith('kaito', 'Iron Lotus');
    expect(code(await svc.handle('rin', { type: 'foundClan', name: 'iron  lotus' }))).toBe('nameTaken');
  });

  it('refuses a missing-nin', () => {
    expect(() => foundClan(player('a', { rogue: true }), 'Iron Lotus', 0)).toThrow(ClanError);
  });

  it('refuses somebody already in a clan', async () => {
    await foundWith('kaito');
    expect(code(await svc.handle('kaito', { type: 'foundClan', name: 'Second Clan' }))).toBe('alreadyInClan');
  });
});

/* ── Membership ──────────────────────────────────────────────────────── */

describe('membership', () => {
  it('is opt-in — an invite alone puts nobody in', async () => {
    const clanId = await foundWith('kaito');
    await svc.handle('kaito', { type: 'inviteToClan', name: 'rin' });
    expect((await store.getPlayer('rin'))!.clanId).toBeNull();
    expect((await store.getClan(clanId))!.invitedIds).toContain('rin');
  });

  it('cannot be joined without an invite', async () => {
    const clanId = await foundWith('kaito');
    expect(code(await svc.handle('rin', { type: 'acceptClanInvite', clanId }))).toBe('notInvited');
  });

  it('a plain member cannot invite', async () => {
    const clanId = await foundWith('kaito');
    await join(clanId, 'kaito', 'rin');
    expect(code(await svc.handle('rin', { type: 'inviteToClan', name: 'sora' }))).toBe('notOfficer');
  });

  it('an officer can invite, and only the leader appoints officers', async () => {
    const clanId = await foundWith('kaito');
    await join(clanId, 'kaito', 'rin');
    expect(code(await svc.handle('rin', { type: 'setClanOfficer', playerId: 'rin', officer: true }))).toBe('notLeader');

    await svc.handle('kaito', { type: 'setClanOfficer', playerId: 'rin', officer: true });
    expect(roleOf((await store.getClan(clanId))!, 'rin')).toBe('officer');
    const out = await svc.handle('rin', { type: 'inviteToClan', name: 'sora' });
    expect(out.some((d) => d.message.type === 'clanInvite')).toBe(true);
  });

  it('an officer cannot remove another officer, but the leader can', async () => {
    const clanId = await foundWith('kaito');
    await join(clanId, 'kaito', 'rin');
    await join(clanId, 'kaito', 'sora');
    await svc.handle('kaito', { type: 'setClanOfficer', playerId: 'rin', officer: true });
    await svc.handle('kaito', { type: 'setClanOfficer', playerId: 'sora', officer: true });

    expect(code(await svc.handle('rin', { type: 'kickFromClan', playerId: 'sora' }))).toBe('notLeader');
    await svc.handle('kaito', { type: 'kickFromClan', playerId: 'sora' });
    expect((await store.getPlayer('sora'))!.clanId).toBeNull();
  });

  it('nobody can remove the leader', async () => {
    const clanId = await foundWith('kaito');
    await join(clanId, 'kaito', 'rin');
    await svc.handle('kaito', { type: 'setClanOfficer', playerId: 'rin', officer: true });
    expect(code(await svc.handle('rin', { type: 'kickFromClan', playerId: 'kaito' }))).toBe('cannotKickLeader');
  });

  it('a leader must hand over before leaving, and cannot strand the clan', async () => {
    const clanId = await foundWith('kaito');
    await join(clanId, 'kaito', 'rin');
    expect(code(await svc.handle('kaito', { type: 'leaveClan' }))).toBe('leaderCannotLeave');

    await svc.handle('kaito', { type: 'handOverClan', playerId: 'rin' });
    expect((await store.getClan(clanId))!.leaderId).toBe('rin');
    const out = await svc.handle('kaito', { type: 'leaveClan' });
    expect(out.some((d) => d.message.type === 'clanLeft')).toBe(true);
  });

  it('a sole leader leaving dissolves the clan', async () => {
    const clanId = await foundWith('kaito');
    await svc.handle('kaito', { type: 'leaveClan' });
    expect(await store.getClan(clanId)).toBeNull();
    expect((await store.getPlayer('kaito'))!.clanId).toBeNull();
  });

  it('caps the roll', () => {
    expect(CLAN_RULES.size.max).toBeGreaterThan(1);
    expect(CLAN_RULES.size.officersMax).toBeLessThan(CLAN_RULES.size.max);
  });
});

/* ── The bank is the obvious thing to loot ───────────────────────────── */

describe('the clan bank', () => {
  const veteran = (id: string, o: Partial<PlayerRecord> = {}) =>
    player(id, { clanJoinedAt: 0, ...o });

  it('takes deposits from any member and credits contribution', async () => {
    const clanId = await foundWith('kaito');
    await join(clanId, 'kaito', 'rin');
    await svc.handle('rin', { type: 'depositToClan', amount: 5000 });

    expect((await store.getClan(clanId))!.bank).toBe(5000);
    const p = (await store.getPlayer('rin'))!;
    expect(p.ryo).toBe(95_000);
    expect(p.clanContribution).toBeGreaterThan(0);
  });

  it('refuses a deposit larger than the depositor holds', async () => {
    const clanId = await foundWith('kaito');
    await join(clanId, 'kaito', 'rin');
    expect(code(await svc.handle('rin', { type: 'depositToClan', amount: 10_000_000 }))).toBe('insufficientFunds');
    expect((await store.getClan(clanId))!.bank).toBe(0);
  });

  it('refuses a withdrawal by a plain member', () => {
    const clan = foundClan(player('a'), 'Iron Lotus', 0);
    const member = veteran('b', { clanId: clan.id });
    clan.memberIds.push('b');
    clan.bank = 50_000;
    expect(() => withdraw(clan, member, 100, 999_999_999)).toThrow(ClanError);
  });

  it('refuses a withdrawal by somebody who just joined', () => {
    const leader = player('a');
    const clan = foundClan(leader, 'Iron Lotus', 0);
    clan.bank = 50_000;
    leader.clanJoinedAt = 0;
    // one minute of tenure, against a one-day gate
    expect(() => withdraw(clan, leader, 100, 60_000)).toThrow(ClanError);
  });

  it('caps how much can leave in a day, so a turned officer cannot empty it', () => {
    const leader = player('a', { clanJoinedAt: 0 });
    const clan = foundClan(leader, 'Iron Lotus', 0);
    clan.bank = 100_000;
    const day = CLAN_RULES.bank.memberTenureMinutesToWithdraw * 60_000 + 1;

    const cap = Math.floor(clan.bank * CLAN_RULES.bank.withdrawFractionPerDay);
    expect(withdraw(clan, leader, cap, day)).toBe(cap);
    expect(() => withdraw(clan, leader, 1, day)).toThrow(ClanError);
  });

  it('lets the cap refill the next day', () => {
    const leader = player('a', { clanJoinedAt: 0 });
    const clan = foundClan(leader, 'Iron Lotus', 0);
    clan.bank = 100_000;
    const day = CLAN_RULES.bank.memberTenureMinutesToWithdraw * 60_000 + 1;
    withdraw(clan, leader, Math.floor(clan.bank * CLAN_RULES.bank.withdrawFractionPerDay), day);
    expect(() => withdraw(clan, leader, 1, day + 24 * 60 * 60_000 + 1)).not.toThrow();
  });

  it('never lets the treasury go negative', () => {
    const leader = player('a', { clanJoinedAt: 0 });
    const clan = foundClan(leader, 'Iron Lotus', 0);
    clan.bank = 100;
    const day = CLAN_RULES.bank.memberTenureMinutesToWithdraw * 60_000 + 1;
    expect(() => withdraw(clan, leader, 500, day)).toThrow(ClanError);
    expect(clan.bank).toBe(100);
  });

  it('leaving does not take the treasury with you', () => {
    const leader = player('a');
    const clan = foundClan(leader, 'Iron Lotus', 0);
    const member = player('b', { clanId: clan.id });
    clan.memberIds.push('b');
    deposit(clan, member, 5000);
    const before = clan.bank;
    leaveClan(clan, member);
    expect(clan.bank).toBe(before);
    expect(member.clanContribution).toBe(0);
  });
});

/* ── Standing ────────────────────────────────────────────────────────── */

describe('clan rankings', () => {
  it('rank on what members did, not on the size of the treasury', () => {
    const rich = { id: 'a', name: 'Rich', nameKey: 'rich', leaderId: 'x', memberIds: ['x'], officerIds: [], invitedIds: [], bank: 10_000_000, foundedAt: 0, withdrawnToday: 0, withdrawWindowStart: 0 };
    const busy = { ...rich, id: 'b', name: 'Busy', nameKey: 'busy', bank: 0, memberIds: ['x', 'y', 'z'] };
    const ranked = rankClans([rich, busy], new Map([['a', 10], ['b', 5000]]));
    expect(ranked[0]!.name).toBe('Busy');
  });

  it('credits a successful mission to the clan', async () => {
    const clanId = await foundWith('kaito');
    const before = (await store.getPlayer('kaito'))!.clanContribution;
    await svc.handle('kaito', { type: 'acceptMission', missionId: 'clear-the-canal' });
    clock += 12 * 60_000;
    await svc.handle('kaito', { type: 'completeMission' });
    const after = (await store.getPlayer('kaito'))!.clanContribution;
    expect(after).toBeGreaterThanOrEqual(before);
    void clanId;
  });

  it('lists clans for anyone who asks', async () => {
    await foundWith('kaito');
    const out = await svc.handle('rin', { type: 'listClans' });
    expect(first(out).type).toBe('clanRankings');
    expect((first(out) as { clans: unknown[] }).clans).toHaveLength(1);
  });
});
