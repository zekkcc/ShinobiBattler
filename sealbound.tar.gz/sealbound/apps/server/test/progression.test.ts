import { beforeEach, describe, expect, it } from 'vitest';
import { MISSIONS, MISSION_BY_ID } from '@shinobi/content';
import type { ServerMessage, Stats } from '@shinobi/shared';
import { GameService } from '../src/service.js';
import { MemoryStore, type PlayerRecord } from '../src/store/index.js';
import {
  acceptMission, applyMission, availableMissions, canTakeWork, checkPromotion,
  levelForXp, MissionError, priceFor, promote, reputationTier, resolveMission, successChance, xpForLevel,
} from '../src/missions.js';

const stats = (o: Partial<Stats> = {}): Stats => ({
  ninjutsu: 60, taijutsu: 60, genjutsu: 60, intelligence: 60,
  strength: 60, speed: 60, stamina: 60, handSeals: 60, ...o,
});

const player = (id: string, o: Partial<PlayerRecord> = {}): PlayerRecord => ({
  id, name: id, villageId: 'konohagakure', clanId: null, clanJoinedAt: null, clanContribution: 0, bloodlineId: null,
  rank: 'genin', level: 20, xp: 0, stats: stats(), affinity: 'fire',
  loadout: [], known: [], reputation: 0, ryo: 0, training: null, mission: null,
  missionsAtRank: 0, missionsCompleted: 0, squadId: null, rogue: false, defectedAt: null, notoriety: 0,
  titles: [], displayedTitle: null, pvpWins: 0, bountiesClaimed: 0, sRankCompleted: 0, rating: 1000, ...o,
});

let store: MemoryStore;
let clock: number;
let svc: GameService;

beforeEach(async () => {
  store = new MemoryStore();
  clock = 1_700_000_000_000;
  svc = new GameService(store, () => clock);
  await store.createPlayer(player('kaito'));
});

const first = (out: { message: ServerMessage }[]) => out[0]!.message;
const code = (out: { message: ServerMessage }[]) => (first(out) as { code?: string }).code;

/* ── Mission timers and outcome fixing ───────────────────────────────── */

describe('missions', () => {
  it('refuses to complete before the mission time has actually passed', () => {
    const p = player('a');
    const m = MISSION_BY_ID.get('retrieve-the-cat')!;
    p.mission = acceptMission(p, m.id, 0);
    expect(() => resolveMission(p, m.minutes * 60_000 - 1)).toThrow(MissionError);
    expect(() => resolveMission(p, m.minutes * 60_000)).not.toThrow();
  });

  it('fixes the outcome when the mission is accepted, so it cannot be re-rolled', () => {
    const p = player('a');
    const m = MISSION_BY_ID.get('retrieve-the-cat')!;
    p.mission = acceptMission(p, m.id, 0);
    const at = m.minutes * 60_000;
    const results = Array.from({ length: 8 }, () => resolveMission(p, at).success);
    expect(new Set(results).size).toBe(1);
  });

  it('gives different players different outcomes on the same mission', () => {
    const m = MISSION_BY_ID.get('clear-the-canal')!;
    const outcomes = new Set<boolean>();
    for (let i = 0; i < 40; i++) {
      const p = player(`p${i}`, { stats: stats({ strength: 18 }) });
      p.mission = acceptMission(p, m.id, 0);
      outcomes.add(resolveMission(p, m.minutes * 60_000).success);
    }
    expect(outcomes.size).toBe(2);
  });

  it('refuses a second mission while one is running', () => {
    const p = player('a');
    p.mission = acceptMission(p, 'retrieve-the-cat', 0);
    expect(() => acceptMission(p, 'weed-the-terraces', 0)).toThrow(MissionError);
  });

  it('refuses a mission above the player rank', () => {
    const academy = player('a', { rank: 'academy' });
    expect(() => acceptMission(academy, 'escort-the-merchant', 0)).toThrow(MissionError);
    expect(() => acceptMission(academy, 'weed-the-terraces', 0)).not.toThrow();
  });

  it('refuses a party mission rather than letting one shinobi solo it', () => {
    const anbu = player('a', { rank: 'anbu' });
    const party = MISSIONS.missions.find((m) => m.party > 1)!;
    let thrown: MissionError | null = null;
    try { acceptMission(anbu, party.id, 0); } catch (e) { thrown = e as MissionError; }
    expect(thrown?.code).toBe('needsParty');
  });

  it('success odds rise with the relevant stat', () => {
    const m = MISSION_BY_ID.get('map-the-border')!;
    const weak = successChance(player('a', { stats: stats({ intelligence: 10 }) }), m);
    const strong = successChance(player('b', { stats: stats({ intelligence: 140 }) }), m);
    expect(strong).toBeGreaterThan(weak);
  });

  it('never reaches certainty in either direction', () => {
    const m = MISSION_BY_ID.get('map-the-border')!;
    const hopeless = successChance(player('a', { stats: stats({ intelligence: 1 }) }), m);
    const expert = successChance(player('b', { stats: stats({ intelligence: 500 }) }), m);
    expect(hopeless).toBeGreaterThan(0);
    expect(expert).toBeLessThan(1);
  });

  it('a failed mission still pays something but costs standing', () => {
    const p = player('a', { stats: stats({ speed: 1 }) });
    const m = MISSION_BY_ID.get('retrieve-the-cat')!;
    let failure = null;
    for (let i = 0; i < 60 && !failure; i++) {
      const q = player(`f${i}`, { stats: stats({ speed: 1 }) });
      q.mission = acceptMission(q, m.id, i);
      const o = resolveMission(q, i + m.minutes * 60_000);
      if (!o.success) failure = o;
    }
    expect(failure).not.toBeNull();
    expect(failure!.ryo).toBeGreaterThan(0);
    expect(failure!.ryo).toBeLessThan(m.ryo);
    expect(failure!.reputation).toBeLessThan(0);
    void p;
  });

  it('only a successful mission counts toward the next rank', () => {
    const p = player('a');
    const m = MISSION_BY_ID.get('retrieve-the-cat')!;
    applyMission(p, { mission: m, success: false, chance: 0.5, ryo: 10, xp: 5, reputation: -2, injured: false });
    expect(p.missionsAtRank).toBe(0);
    applyMission(p, { mission: m, success: true, chance: 0.5, ryo: 100, xp: 50, reputation: 1, injured: false });
    expect(p.missionsAtRank).toBe(1);
  });
});

/* ── Reputation consequences ─────────────────────────────────────────── */

describe('reputation', () => {
  it('closes the mission desk when a player is wanted', () => {
    expect(canTakeWork(player('a', { reputation: -60 }))).toBe(false);
    expect(availableMissions(player('a', { reputation: -60 }))).toHaveLength(0);
  });

  it('changes what a player pays', () => {
    const cheap = priceFor(1000, player('a', { reputation: 500 }));
    const normal = priceFor(1000, player('b', { reputation: 0 }));
    const dear = priceFor(1000, player('c', { reputation: -60 }));
    expect(cheap).toBeLessThan(normal);
    expect(dear).toBeGreaterThan(normal);
  });

  it('names the standing so a player knows where they are', () => {
    expect(reputationTier(-60).id).toBe('wanted');
    expect(reputationTier(0).id).toBe('unproven');
    expect(reputationTier(400).id).toBe('renowned');
  });

  it('refuses a mission outright when standing is too low', () => {
    const outcast = player('a', { reputation: -60 });
    expect(() => acceptMission(outcast, 'weed-the-terraces', 0)).toThrow(MissionError);
  });
});

/* ── Economy: learning techniques ────────────────────────────────────── */

describe('learning techniques', () => {
  it('costs ryo and adds the technique to what the player knows', async () => {
    await store.savePlayer(player('kaito', { ryo: 5000 }));
    const out = await svc.handle('kaito', { type: 'learnJutsu', jutsuId: 'phoenix-flower-jutsu' });
    expect(first(out).type).toBe('jutsuLearned');
    const after = await store.getPlayer('kaito');
    expect(after!.known).toContain('phoenix-flower-jutsu');
    expect(after!.ryo).toBeLessThan(5000);
  });

  it('refuses when the player cannot afford it', async () => {
    await store.savePlayer(player('kaito', { ryo: 5 }));
    expect(code(await svc.handle('kaito', { type: 'learnJutsu', jutsuId: 'phoenix-flower-jutsu' }))).toBe('cannotAfford');
  });

  it('refuses a technique above the player rank however much money they have', async () => {
    await store.savePlayer(player('kaito', { ryo: 10_000_000, rank: 'genin' }));
    expect(code(await svc.handle('kaito', { type: 'learnJutsu', jutsuId: 'amaterasu' }))).toBe('rankLocked');
  });

  it('refuses to sell the same technique twice', async () => {
    await store.savePlayer(player('kaito', { ryo: 50_000, known: ['phoenix-flower-jutsu'] }));
    expect(code(await svc.handle('kaito', { type: 'learnJutsu', jutsuId: 'phoenix-flower-jutsu' }))).toBe('alreadyKnown');
  });

  it('a loadout may only carry techniques the player has learned', async () => {
    await store.savePlayer(player('kaito', { known: [] }));
    expect(code(await svc.handle('kaito', { type: 'setLoadout', jutsuIds: ['phoenix-flower-jutsu'] }))).toBe('notLearned');
  });

  it('baseline moves are always available without buying them', async () => {
    await store.savePlayer(player('kaito', { known: [] }));
    const out = await svc.handle('kaito', { type: 'setLoadout', jutsuIds: ['basic-strike', 'substitute'] });
    expect(first(out).type).toBe('loadoutSet');
  });
});

/* ── Rank progression ────────────────────────────────────────────────── */

describe('rank progression', () => {
  it('derives level from xp, not from anything the client sends', () => {
    expect(levelForXp(0)).toBe(1);
    expect(levelForXp(xpForLevel(10))).toBe(10);
    expect(levelForXp(xpForLevel(10) - 1)).toBe(9);
    expect(levelForXp(xpForLevel(30))).toBe(30);
  });

  it('explains exactly what is missing rather than a flat refusal', () => {
    const check = checkPromotion(player('a', { rank: 'genin', level: 1, reputation: 0, rating: 900 }));
    expect(check.eligible).toBe(false);
    expect(check.missing.length).toBeGreaterThan(2);
    expect(check.missing.join(' ')).toContain('reputation');
  });

  it('promotes once every gate is met', () => {
    const ready = player('a', { rank: 'genin', level: 25, reputation: 60, rating: 1100, missionsAtRank: 10 });
    expect(checkPromotion(ready).eligible).toBe(true);
    expect(promote(ready)).toBe('chunin');
  });

  it('resets the mission count at the new rank, so the next gate is fresh work', () => {
    const ready = player('a', { rank: 'genin', level: 25, reputation: 60, rating: 1100, missionsAtRank: 10 });
    promote(ready);
    expect(ready.missionsAtRank).toBe(0);
  });

  it('cannot be bought — money is not one of the gates', () => {
    const rich = player('a', { rank: 'genin', level: 1, reputation: 0, rating: 900, ryo: 999_999_999 });
    expect(checkPromotion(rich).eligible).toBe(false);
    expect(() => promote(rich)).toThrow(MissionError);
  });

  it('refuses a promotion the client asks for but has not earned', async () => {
    const out = await svc.handle('kaito', { type: 'requestPromotion' });
    expect(first(out).type).toBe('promotionDenied');
    expect((await store.getPlayer('kaito'))!.rank).toBe('genin');
  });

  it('stops at the top rank', () => {
    expect(checkPromotion(player('a', { rank: 'kage' })).to).toBeNull();
  });
});

/* ── The loop, end to end ────────────────────────────────────────────── */

describe('the core loop', () => {
  it('runs take work -> earn -> learn -> carry', async () => {
    // 1. take the work
    const board = await svc.handle('kaito', { type: 'listMissions' });
    expect(first(board).type).toBe('missionBoard');
    const missions = (first(board) as { missions: { id: string }[] }).missions;
    expect(missions.length).toBeGreaterThan(0);

    const accepted = await svc.handle('kaito', { type: 'acceptMission', missionId: 'clear-the-canal' });
    expect(first(accepted).type).toBe('missionAccepted');

    // 2. it cannot be rushed
    expect(code(await svc.handle('kaito', { type: 'completeMission' }))).toBe('notFinished');

    // 3. earn
    clock += MISSION_BY_ID.get('clear-the-canal')!.minutes * 60_000;
    const done = await svc.handle('kaito', { type: 'completeMission' });
    expect(first(done).type).toBe('missionResolved');

    const paid = await store.getPlayer('kaito');
    expect(paid!.ryo).toBeGreaterThan(0);
    expect(paid!.xp).toBeGreaterThan(0);
    expect(paid!.level).toBe(levelForXp(paid!.xp));

    // 4. spend it on a teacher, then carry what was learned
    paid!.ryo = 5000;
    await store.savePlayer(paid!);
    await svc.handle('kaito', { type: 'learnJutsu', jutsuId: 'phoenix-flower-jutsu' });
    const out = await svc.handle('kaito', { type: 'setLoadout', jutsuIds: ['phoenix-flower-jutsu'] });
    expect(first(out).type).toBe('loadoutSet');
  });
});
