import type { FighterState, Jutsu, MatchEvent } from '@shinobi/shared';
import type { LogEntry } from './store.js';

/* ── Fighter card ────────────────────────────────────────────────────── */

function Gauge({ kind, label, value, max }: { kind: string; label: string; value: number; max: number }) {
  const pct = max > 0 ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  return (
    <div className={`gauge gauge-${kind}`}>
      <div className="gauge-head"><span>{label}</span><span>{Math.round(value)} / {Math.round(max)}</span></div>
      <div className="gauge-track" role="meter" aria-label={label} aria-valuenow={Math.round(value)} aria-valuemax={Math.round(max)}>
        <div className="gauge-fill" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

const INJURIES = new Set(['broken-arm', 'leg-injury', 'eye-injury']);
const BOONS = new Set(['haste', 'focus', 'regen']);

/**
 * The weave telegraph. A technique in progress is public information in this
 * game, so it is rendered as the loudest thing on the card: one box per seal,
 * filling as the caster works through them. Both players read the same meter,
 * which is what makes Counter and Substitute a real decision.
 */
function Weave({ fighter, jutsu }: { fighter: FighterState; jutsu?: Jutsu }) {
  if (!fighter.weave) return null;
  const { total, remaining } = fighter.weave;
  const done = total - remaining;
  return (
    <div className="weave">
      <div className="weave-label">Weaving — {remaining} turn{remaining === 1 ? '' : 's'} left</div>
      <div className="weave-name">{jutsu?.name ?? fighter.weave.jutsuId}</div>
      <div className="seals" aria-label={`${done} of ${total} seals formed`}>
        {Array.from({ length: total }, (_, i) => (
          <div key={i} className={`seal ${i < done ? 'seal-done' : ''}`}>{i < done ? '\u5370' : '\u30fb'}</div>
        ))}
      </div>
    </div>
  );
}

export function FighterCard({ fighter, subtitle, jutsuById }: {
  fighter: FighterState;
  subtitle: string;
  jutsuById: Map<string, Jutsu>;
}) {
  return (
    <section className="panel">
      <h3 className="fighter-name">{fighter.name}</h3>
      <div className="fighter-sub">{subtitle}</div>

      <Gauge kind="hp" label="Health" value={fighter.hp} max={fighter.maxHp} />
      <Gauge kind="physical" label="Physical" value={fighter.chakra.physical} max={fighter.maxChakra.physical} />
      <Gauge kind="mental" label="Mental" value={fighter.chakra.mental} max={fighter.maxChakra.mental} />
      <Gauge kind="natural" label="Natural" value={fighter.chakra.natural} max={fighter.maxChakra.natural} />

      <div className="chips">
        {fighter.stance !== 'none' && <span className="chip chip-good">{fighter.stance}</span>}
        {fighter.substitutions > 0 && <span className="chip">{fighter.substitutions} substitution</span>}
        {fighter.gateTier > 0 && <span className="chip chip-injury">gate {fighter.gateTier}</span>}
        {fighter.clones.length > 0 && <span className="chip chip-good">{fighter.clones.length} clones</span>}
        {fighter.statuses.map((s) => (
          <span
            key={s.status}
            className={`chip ${INJURIES.has(s.status) ? 'chip-injury' : BOONS.has(s.status) ? 'chip-good' : 'chip-bad'}`}
          >
            {s.status.replace('-', ' ')} {s.remaining}
          </span>
        ))}
      </div>

      <Weave fighter={fighter} jutsu={fighter.weave ? jutsuById.get(fighter.weave.jutsuId) : undefined} />

      <div className="statgrid">
        {Object.entries(fighter.stats).map(([k, v]) => (
          <div key={k}><span>{k}</span><b>{Math.round(v)}</b></div>
        ))}
      </div>
    </section>
  );
}

/* ── Exchange log ────────────────────────────────────────────────────── */

function describe(e: MatchEvent, names: Map<string, string>, jutsu: Map<string, Jutsu>): { text: string; cls: string } | null {
  const who = (id: string) => names.get(id) ?? id;
  switch (e.t) {
    case 'cast': return { text: `${who(e.fighterId)} casts ${jutsu.get(e.jutsuId)?.name ?? e.jutsuId}`, cls: 'log-cast' };
    case 'weaveStart': return { text: `${who(e.fighterId)} begins weaving ${jutsu.get(e.jutsuId)?.name ?? e.jutsuId} — ${e.turns} turns`, cls: 'log-seal' };
    case 'weaveBroken': return { text: `${who(e.fighterId)}'s weave breaks (${e.cause}) — ${e.refund} chakra recovered`, cls: 'log-seal' };
    case 'sealFailed': return { text: `${who(e.fighterId)} fumbles the seals for ${jutsu.get(e.jutsuId)?.name ?? e.jutsuId}`, cls: 'log-seal' };
    case 'damage': return { text: `${who(e.targetId)} takes ${e.amount}${e.shielded ? ` (${e.shielded} absorbed)` : ''}`, cls: 'log-hit' };
    case 'combo': return { text: `${e.comboId.toUpperCase()} — ${e.amount} damage`, cls: 'log-combo' };
    case 'heal': return { text: `${who(e.fighterId)} recovers ${e.amount}`, cls: 'log-heal' };
    case 'statusTick': return { text: `${who(e.fighterId)} suffers ${e.amount} from ${e.status}`, cls: 'log-hit' };
    case 'status': return e.applied ? { text: `${who(e.fighterId)} is ${e.status} for ${e.duration}`, cls: 'log-line' } : null;
    case 'injury': return { text: `${who(e.fighterId)} is injured — ${e.status.replace('-', ' ')}`, cls: 'log-hit' };
    case 'substitution': return { text: `${who(e.fighterId)} ${e.success ? 'substitutes away' : 'fails to substitute'}`, cls: 'log-line' };
    case 'counter': return { text: `${who(e.fighterId)} turns aside ${e.blocked}`, cls: 'log-heal' };
    case 'reflect': return { text: `${who(e.fighterId)} reflects ${e.amount}`, cls: 'log-heal' };
    case 'clonesSplit': return { text: `${who(e.fighterId)} splits into ${e.count} bodies`, cls: 'log-line' };
    case 'cloneDestroyed': return { text: `a clone of ${who(e.fighterId)} is destroyed`, cls: 'log-line' };
    case 'gate': return { text: `${who(e.fighterId)} opens gate ${e.tier}`, cls: 'log-seal' };
    case 'gateDrain': return { text: `the gate costs ${who(e.fighterId)} ${e.amount}`, cls: 'log-hit' };
    case 'overdraw': return { text: `${who(e.fighterId)} overdraws ${e.pool} — ${e.selfDamage} self-damage`, cls: 'log-hit' };
    case 'suddenDeath': return { text: 'Sudden death — all damage increased', cls: 'log-combo' };
    case 'defeated': return { text: `${who(e.fighterId)} falls`, cls: 'log-combo' };
    case 'blocked': return { text: `${who(e.fighterId)} cannot act (${e.reason})`, cls: 'log-line' };
    default: return null;
  }
}

export function ExchangeLog({ log, names, jutsuById }: {
  log: LogEntry[];
  names: Map<string, string>;
  jutsuById: Map<string, Jutsu>;
}) {
  if (log.length === 0) {
    return <p className="empty">No exchanges yet. Choose a move to open the round.</p>;
  }
  return (
    <div className="log">
      {[...log].reverse().map((entry) => (
        <div key={entry.round}>
          <div className="log-round">Round {entry.round}</div>
          {entry.events.map((e, i) => {
            const d = describe(e, names, jutsuById);
            if (!d) return null;
            return (
              <div key={i} className={`log-line ${d.cls}`}>
                {e.t === 'cast' && <span className="stamp">{'\u5370'}</span>}
                <b>{d.text}</b>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

/* ── Command bar ─────────────────────────────────────────────────────── */

const STANCES = new Set(['substitute', 'counter-stance-basic', 'prepare-seals']);

export function Commands({ options, disabled, onPick }: {
  options: Jutsu[];
  disabled: boolean;
  onPick(id: string): void;
}) {
  return (
    <div className="commands">
      {options.map((j) => {
        const cost = [
          j.cost.physical ? `${j.cost.physical}P` : '',
          j.cost.mental ? `${j.cost.mental}M` : '',
          j.cost.natural ? `${j.cost.natural}N` : '',
        ].filter(Boolean).join(' ') || 'free';
        return (
          <button
            key={j.id}
            className={`cmd ${STANCES.has(j.id) ? 'cmd-stance' : ''}`}
            disabled={disabled}
            onClick={() => onPick(j.id)}
          >
            <span className="cmd-name">{j.name}</span>
            <span className="cmd-meta">
              {cost}{j.seals > 0 ? ` · ${j.seals} seals` : ''}{j.cooldown > 0 ? ` · cd ${j.cooldown}` : ''}
            </span>
          </button>
        );
      })}
    </div>
  );
}
