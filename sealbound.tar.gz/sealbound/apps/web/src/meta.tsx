import { useState } from 'react';
import type { ClientMessage } from '@shinobi/shared';
import { useGame, type ElectionView } from './store.js';

/**
 * The meta-game screens.
 *
 * These live apart from App.tsx because that file is about a match, and this is
 * about everything between matches. The split also keeps one rule easy to see:
 * nothing in here calculates. Every price, yield, war score, tally and puzzle
 * prompt is a value the server sent. The client's whole job is to render it and
 * to submit intent, exactly as in the arena.
 *
 * Where a screen shows a number the player might expect to be actionable — a
 * reference price, a live vote count — it says where it came from, because a
 * figure with no provenance is one people assume the client made up.
 */

type Send = (msg: ClientMessage) => void;

const when = (ms: number): string => new Date(ms).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });

const remaining = (ms: number): string => {
  const left = ms - Date.now();
  if (left <= 0) return 'ready';
  const mins = Math.ceil(left / 60_000);
  return mins < 60 ? `${mins}m` : `${Math.floor(mins / 60)}h ${mins % 60}m`;
};

const title = (slug: string): string => slug.replace(/-/g, ' ').replace(/^./, (c) => c.toUpperCase());

/* ── World ───────────────────────────────────────────────────────────── */

export function WorldPanel({ send }: { send: Send }): JSX.Element {
  const { world, election } = useGame();

  return (
    <>
      <section className="panel">
        <p className="eyebrow">The same sky for everyone</p>
        <h2>{world ? world.seasonName : 'The world'}</h2>
        {!world ? <p className="empty">Asking the world what it looks like.</p> : (
          <>
            <p className="row-meta">
              {title(world.weather)} over {title(world.villageId)} · sale tax {(world.taxRate * 100).toFixed(1)}%
            </p>
            <p className="empty">
              Season and weather are worked out from the clock, not stored. Everyone in the world
              sees this same sky at this same moment, and nothing you do can reroll it.
            </p>

            <h3>Government</h3>
            {world.offices.length === 0 ? <p className="empty">No offices seated.</p> : (
              <div className="list">
                {world.offices.map((o) => (
                  <div key={o.officeId} className="row">
                    <div>
                      <div className="row-name">{o.name}</div>
                      <div className="row-meta">
                        {o.holders.length === 0 ? 'vacant' : o.holders.map((h) => h.name).join(', ')}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {world.laws.length > 0 && (
              <>
                <h3>Law</h3>
                <div className="list">
                  {world.laws.map((l) => (
                    <div key={l.id} className="row">
                      <div>
                        <div className="row-name">{l.name}</div>
                        <div className="row-meta">{l.blurb}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}

            {world.commissions.length > 0 && (
              <>
                <h3>Public works</h3>
                <div className="list">
                  {world.commissions.map((c) => (
                    <div key={c.id} className="row">
                      <div>
                        <div className="row-name">{c.name}</div>
                        <div className="row-meta">runs until {when(c.endsAtMs)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}

            {world.atWarWith.length > 0 && (
              <p className="chip chip-bad" style={{ marginTop: 12 }}>
                At war with {world.atWarWith.map(title).join(', ')}
              </p>
            )}
          </>
        )}
      </section>

      <ElectionPanel send={send} election={election} />
    </>
  );
}

function ElectionPanel({ send, election }: { send: Send; election: ElectionView | null }): JSX.Element {
  const [rate, setRate] = useState('0.05');

  return (
    <section className="panel">
      <p className="eyebrow">Somebody has to run the place</p>
      <h2>Election</h2>
      {!election ? (
        <button className="btn" onClick={() => send({ type: 'electionStatus' })}>Check the notice board</button>
      ) : (
        <>
          <p className="row-meta">
            Term {election.cycle} · {election.phase} until {when(election.phaseEndsAtMs)}
          </p>
          <p className="empty">
            Vote counts are public and live. A tally nobody can audit is a tally nobody should
            trust, and there is nothing secret here worth that.
          </p>

          <div className="list">
            {election.races.map((race) => (
              <div key={race.officeId} className="row" style={{ alignItems: 'flex-start' }}>
                <div style={{ flex: 1 }}>
                  <div className="row-name">{race.name} <span className="row-meta">· {race.seats} seat{race.seats > 1 ? 's' : ''}</span></div>
                  {race.candidates.length === 0 ? (
                    <div className="row-meta">Nobody is standing.</div>
                  ) : race.candidates.map((c) => (
                    <div key={c.id} className="row-meta" style={{ marginTop: 4 }}>
                      {c.name} — {c.votes} vote{c.votes === 1 ? '' : 's'}
                      {race.yourVote === c.id && <span className="chip chip-good" style={{ marginLeft: 6 }}>your vote</span>}
                      {race.youMayVote && race.yourVote === null && (
                        <button
                          className="btn"
                          style={{ marginLeft: 8 }}
                          onClick={() => send({ type: 'castVote', officeId: race.officeId, candidateId: c.id })}
                        >
                          vote
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                {race.youMayStand && (
                  <button className="btn" onClick={() => send({ type: 'standForOffice', officeId: race.officeId })}>
                    stand
                  </button>
                )}
              </div>
            ))}
          </div>

          <h3>If you hold the office</h3>
          <p className="empty">
            These are refused unless you actually hold a seat that carries the power. The server
            checks the office, not the message.
          </p>
          <div className="row">
            <div className="field">
              <label htmlFor="tax">Sale tax</label>
              <input id="tax" value={rate} onChange={(e) => setRate(e.target.value)} />
            </div>
            <button className="btn" onClick={() => send({ type: 'setVillageTax', rate: Number(rate) })}>
              Set the rate
            </button>
          </div>
          <p className="row-meta">Bounded by law, moves once a term, and only by a step.</p>
        </>
      )}
    </section>
  );
}

/* ── Land ────────────────────────────────────────────────────────────── */

export function LandPanel({ send }: { send: Send }): JSX.Element {
  const { regions, warBoard, gathering } = useGame();
  const [picked, setPicked] = useState<string | null>(null);

  return (
    <>
      <section className="panel">
        <p className="eyebrow">Ground somebody is standing on</p>
        <h2>Regions</h2>

        {gathering ? (
          <div className="row">
            <div>
              <div className="row-name">Out at {title(gathering.regionId)}</div>
              <div className="row-meta">
                Working {title(gathering.itemId)} · full haul in {remaining(gathering.endsAtMs)}
              </div>
            </div>
            <button className="btn btn-seal" onClick={() => send({ type: 'claimGathering' })}>Come back</button>
          </div>
        ) : regions.length === 0 ? (
          <button className="btn" onClick={() => send({ type: 'listRegions' })}>Look at the map</button>
        ) : (
          <div className="list">
            {regions.map((r) => (
              <div key={r.id} className="row" style={{ alignItems: 'flex-start' }}>
                <div style={{ flex: 1 }}>
                  <div className="row-name">
                    {r.name}
                    {r.yoursToGather
                      ? <span className="chip chip-good" style={{ marginLeft: 6 }}>home ground</span>
                      : <span className="chip" style={{ marginLeft: 6 }}>{title(r.controllingVillage)}</span>}
                  </div>
                  <div className="row-meta">
                    {r.country}
                    {r.garrisonClanName ? ` · garrisoned by ${r.garrisonClanName}` : ' · no garrison'}
                  </div>
                  <div className="row-meta" style={{ marginTop: 4 }}>
                    {r.resources.length === 0
                      ? 'Nothing worth cutting this season.'
                      : `In season: ${r.resources.map(title).join(', ')}`}
                  </div>
                  {picked === r.id && r.resources.map((itemId) => (
                    <button
                      key={itemId}
                      className="btn"
                      style={{ marginRight: 6, marginTop: 6 }}
                      onClick={() => { send({ type: 'startGathering', regionId: r.id, itemId }); setPicked(null); }}
                    >
                      gather {title(itemId)}
                    </button>
                  ))}
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {r.resources.length > 0 && (
                    <button className="btn" onClick={() => setPicked(picked === r.id ? null : r.id)}>
                      {picked === r.id ? 'never mind' : 'gather'}
                    </button>
                  )}
                  <button className="btn" onClick={() => send({ type: 'declareWar', regionId: r.id })}>
                    declare
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
        <p className="empty">
          Holding ground pays in yield and in war score. It grants no combat statistic — a bonus you
          could not see from the other side of a fight would decide matches invisibly.
        </p>
      </section>

      <section className="panel">
        <p className="eyebrow">Settled by what people did, not by a roll</p>
        <h2>War board</h2>
        {!warBoard ? (
          <button className="btn" onClick={() => send({ type: 'warStatus' })}>Read the board</button>
        ) : (
          <>
            <p className="row-meta">
              Period ends {when(warBoard.periodEndsAtMs)} ·{' '}
              {warBoard.declareWindowOpen ? 'declarations open' : 'declarations closed for this period'}
            </p>
            {warBoard.wars.length === 0 ? (
              <p className="empty">Nobody is contesting anything.</p>
            ) : (
              <div className="list">
                {warBoard.wars.map((w) => (
                  <div key={w.regionId + w.attackerClanId} className="row">
                    <div>
                      <div className="row-name">{w.regionName}</div>
                      <div className="row-meta">
                        {w.attackerClanName} attacking · settles {when(w.resolvesAtMs)}
                      </div>
                    </div>
                    <div className="row-meta">
                      {w.attackerScore} — {w.defenderScore}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </section>
    </>
  );
}

/* ── Workshop ────────────────────────────────────────────────────────── */

export function WorkshopPanel({ send }: { send: Send }): JSX.Element {
  const { inventory, recipes, crafting } = useGame();

  return (
    <>
      <section className="panel">
        <p className="eyebrow">What you are carrying</p>
        <h2>Pack</h2>
        {!inventory ? (
          <button className="btn" onClick={() => send({ type: 'inventory' })}>Empty your pockets</button>
        ) : inventory.items.length === 0 ? (
          <p className="empty">Nothing but lint and {inventory.ryo.toLocaleString()} ryo.</p>
        ) : (
          <div className="list">
            {inventory.items.map((i) => (
              <div key={i.itemId} className="row">
                <div>
                  <div className="row-name">{i.name} <span className="row-meta">x{i.qty}</span></div>
                  <div className="row-meta">{i.kind}</div>
                </div>
                {i.kind === 'consumable' && (
                  <button className="btn" onClick={() => send({ type: 'useItem', itemId: i.itemId })}>use</button>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="panel">
        <p className="eyebrow">Materials go in when the job starts</p>
        <h2>Workbench</h2>
        {crafting ? (
          <div className="row">
            <div>
              <div className="row-name">{title(crafting.recipeId)}</div>
              <div className="row-meta">ready in {remaining(crafting.endsAtMs)}</div>
            </div>
            <button className="btn btn-seal" onClick={() => send({ type: 'claimCrafting' })}>Take it off the bench</button>
          </div>
        ) : recipes.length === 0 ? (
          <button className="btn" onClick={() => send({ type: 'listRecipes' })}>What can I make?</button>
        ) : (
          <div className="list">
            {recipes.map((r) => (
              <div key={r.id} className="row" style={{ alignItems: 'flex-start' }}>
                <div style={{ flex: 1 }}>
                  <div className="row-name">{r.name}</div>
                  <div className="row-meta">
                    {r.inputs.map((i) => `${i.qty}x ${title(i.item)}`).join(' + ')} → {r.output.qty}x {title(r.output.item)}
                  </div>
                  <div className="row-meta">{r.station} · {r.minutes} minutes</div>
                  {!r.craftable && r.missing.length > 0 && (
                    <div className="row-meta" style={{ opacity: 0.75, marginTop: 4 }}>
                      short of {r.missing.map(title).join(', ')}
                    </div>
                  )}
                </div>
                <button
                  className="btn"
                  disabled={!r.craftable}
                  onClick={() => send({ type: 'startCrafting', recipeId: r.id })}
                >
                  start
                </button>
              </div>
            ))}
          </div>
        )}
        <p className="empty">
          The materials leave your pack the moment you start, not when you collect. A job you
          walked away from has already cost you.
        </p>
      </section>
    </>
  );
}

/* ── Market and trade ────────────────────────────────────────────────── */

export function MarketPanel({ send }: { send: Send }): JSX.Element {
  const { market, inventory, trades } = useGame();
  const [sellItem, setSellItem] = useState('');
  const [sellQty, setSellQty] = useState('1');
  const [sellPrice, setSellPrice] = useState('');
  const [giftTo, setGiftTo] = useState('');
  const [giftAmount, setGiftAmount] = useState('');

  const reference = sellItem && market ? market.referencePrices[sellItem] : undefined;

  return (
    <>
      <section className="panel">
        <p className="eyebrow">For dealing with strangers</p>
        <h2>Market</h2>
        {!market ? (
          <button className="btn" onClick={() => { send({ type: 'listMarket' }); send({ type: 'inventory' }); }}>
            Walk down to the stalls
          </button>
        ) : (
          <>
            <p className="row-meta">Sale tax here is {(market.taxRate * 100).toFixed(1)}%, set by your village.</p>
            {market.listings.length === 0 ? (
              <p className="empty">The stalls are bare.</p>
            ) : (
              <div className="list">
                {market.listings.map((l) => {
                  const ref = market.referencePrices[l.itemId];
                  return (
                    <div key={l.listingId} className="row">
                      <div>
                        <div className="row-name">{l.name} <span className="row-meta">x{l.qty}</span></div>
                        <div className="row-meta">
                          {l.unitPrice} each from {l.sellerName}
                          {ref !== undefined && ` · usually about ${ref}`}
                        </div>
                      </div>
                      {l.yours ? (
                        <button className="btn" onClick={() => send({ type: 'cancelListing', listingId: l.listingId })}>
                          withdraw
                        </button>
                      ) : (
                        <button className="btn" onClick={() => send({ type: 'buyListing', listingId: l.listingId })}>
                          buy · {(l.qty * l.unitPrice).toLocaleString()}
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            <h3>Sell something</h3>
            <div className="row">
              <div className="field">
                <label htmlFor="sell-item">Item</label>
                <select id="sell-item" value={sellItem} onChange={(e) => setSellItem(e.target.value)}>
                  <option value="">choose</option>
                  {(inventory?.items ?? []).map((i) => (
                    <option key={i.itemId} value={i.itemId}>{i.name} (x{i.qty})</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label htmlFor="sell-qty">Qty</label>
                <input id="sell-qty" value={sellQty} onChange={(e) => setSellQty(e.target.value)} />
              </div>
              <div className="field">
                <label htmlFor="sell-price">Each</label>
                <input id="sell-price" value={sellPrice} onChange={(e) => setSellPrice(e.target.value)} />
              </div>
              <button
                className="btn"
                onClick={() => send({
                  type: 'sellItem', itemId: sellItem,
                  qty: Number(sellQty), unitPrice: Number(sellPrice),
                })}
              >
                List it
              </button>
            </div>
            {reference !== undefined && (
              <p className="row-meta">
                The going rate is about {reference}. Asking far outside that will be refused —
                the band moves with what people actually pay, and drifts back on its own.
              </p>
            )}
          </>
        )}
      </section>

      <section className="panel">
        <p className="eyebrow">Straight across, no middleman</p>
        <h2>Trades and gifts</h2>
        <p className="empty">
          A direct trade costs neither side a fee. Every completed transfer is recorded
          permanently, with both names and exactly what changed hands.
        </p>

        {trades.incoming.length > 0 && (
          <>
            <h3>Offered to you</h3>
            <div className="list">
              {trades.incoming.map((t) => (
                <div key={t.tradeId} className="row">
                  <div>
                    <div className="row-name">from {t.fromName}</div>
                    <div className="row-meta">
                      they give {t.offerRyo} ryo · they want {t.requestRyo} ryo · expires {when(t.expiresAtMs)}
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-seal" onClick={() => send({ type: 'acceptTrade', tradeId: t.tradeId })}>accept</button>
                    <button className="btn" onClick={() => send({ type: 'declineTrade', tradeId: t.tradeId })}>refuse</button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {trades.outgoing.length > 0 && (
          <>
            <h3>Waiting on them</h3>
            <div className="list">
              {trades.outgoing.map((t) => (
                <div key={t.tradeId} className="row">
                  <div>
                    <div className="row-name">to {t.toName}</div>
                    <div className="row-meta">expires {when(t.expiresAtMs)}</div>
                  </div>
                  <button className="btn" onClick={() => send({ type: 'declineTrade', tradeId: t.tradeId })}>withdraw</button>
                </div>
              ))}
            </div>
          </>
        )}

        <h3>Send money</h3>
        <div className="row">
          <div className="field">
            <label htmlFor="gift-to">To</label>
            <input id="gift-to" value={giftTo} onChange={(e) => setGiftTo(e.target.value)} placeholder="their name" />
          </div>
          <div className="field">
            <label htmlFor="gift-amount">Ryo</label>
            <input id="gift-amount" value={giftAmount} onChange={(e) => setGiftAmount(e.target.value)} />
          </div>
          <button
            className="btn"
            onClick={() => send({ type: 'giftRyo', toName: giftTo, amount: Number(giftAmount) })}
          >
            Send
          </button>
        </div>
        <button className="btn" style={{ marginTop: 10 }} onClick={() => send({ type: 'listTrades' })}>
          Refresh offers
        </button>
      </section>
    </>
  );
}

/* ── Dungeons ────────────────────────────────────────────────────────── */

export function DungeonPanel({ send }: { send: Send }): JSX.Element {
  const { dungeons, room } = useGame();
  const [answer, setAnswer] = useState('');

  if (room) {
    return (
      <section className="panel">
        <p className="eyebrow">Room {room.index} of {room.total}</p>
        <h2>{title(room.dungeonId)}</h2>
        <p style={{ fontSize: '1.05rem', lineHeight: 1.5 }}>{room.prompt}</p>
        <p className="row-meta">{room.hint}</p>
        <div className="row" style={{ marginTop: 12 }}>
          <div className="field" style={{ flex: 1 }}>
            <label htmlFor="answer">Say it aloud</label>
            <input
              id="answer"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && answer.trim()) { send({ type: 'answerRoom', answer }); setAnswer(''); }
              }}
            />
          </div>
          <button
            className="btn btn-seal"
            onClick={() => { send({ type: 'answerRoom', answer }); setAnswer(''); }}
          >
            Answer
          </button>
        </div>
        <p className="row-meta">
          {room.attemptsLeft} attempt{room.attemptsLeft === 1 ? '' : 's'} left · the run closes at {when(room.expiresAtMs)}
        </p>
        <p className="empty">
          Case and punctuation do not matter. A wrong answer costs an attempt and seals the room
          for a few minutes — the answers are never sent to your machine, so there is nothing here
          to read but the riddle.
        </p>
        <button className="btn" style={{ marginTop: 10 }} onClick={() => send({ type: 'abandonDungeon' })}>
          Leave the way you came
        </button>
      </section>
    );
  }

  return (
    <section className="panel">
      <p className="eyebrow">Older than the villages</p>
      <h2>Hidden places</h2>
      {!dungeons ? (
        <button className="btn" onClick={() => send({ type: 'listDungeons' })}>Ask around</button>
      ) : (
        <div className="list">
          {dungeons.dungeons.map((d) => (
            <div key={d.id} className="row" style={{ alignItems: 'flex-start' }}>
              <div style={{ flex: 1 }}>
                <div className="row-name">{d.name}</div>
                <div className="row-meta">{title(d.regionId)} · {d.runsLeftToday} run{d.runsLeftToday === 1 ? '' : 's'} left today</div>
                <div className="row-meta" style={{ marginTop: 4, opacity: 0.8 }}>{d.blurb}</div>
                {!d.open && d.reason && <div className="row-meta" style={{ marginTop: 4 }}>closed: {d.reason}</div>}
              </div>
              <button className="btn" disabled={!d.open} onClick={() => send({ type: 'enterDungeon', dungeonId: d.id })}>
                go in
              </button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

/* ── Mentorship and wardrobe ─────────────────────────────────────────── */

export function MentorPanel({ send }: { send: Send }): JSX.Element {
  const { mentorship, cosmetics } = useGame();
  const [studentName, setStudentName] = useState('');

  return (
    <>
      <section className="panel">
        <p className="eyebrow">Somebody taught you, once</p>
        <h2>Teaching</h2>
        {!mentorship ? (
          <button className="btn" onClick={() => send({ type: 'mentorStatus' })}>Check</button>
        ) : (
          <>
            {mentorship.asMentee && (
              <div className="row">
                <div>
                  <div className="row-name">{mentorship.asMentee.mentorName} is teaching you</div>
                  <div className="row-meta">
                    +{(mentorship.asMentee.trainingBonus * 100).toFixed(0)}% on everything you train
                  </div>
                </div>
                <button className="btn" onClick={() => send({ type: 'endMentorship' })}>graduate</button>
              </div>
            )}

            {mentorship.offers.length > 0 && (
              <>
                <h3>Offers</h3>
                <div className="list">
                  {mentorship.offers.map((o) => (
                    <div key={o.mentorId} className="row">
                      <div className="row-name">{o.mentorName} offers to teach you</div>
                      <button className="btn btn-seal" onClick={() => send({ type: 'acceptMentorship', mentorId: o.mentorId })}>
                        accept
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}

            {mentorship.asMentor.length > 0 && (
              <>
                <h3>Your students</h3>
                <div className="list">
                  {mentorship.asMentor.map((m) => (
                    <div key={m.menteeId} className="row">
                      <div>
                        <div className="row-name">{m.menteeName}</div>
                        <div className="row-meta">
                          {m.milestones.length === 0 ? 'nothing to show yet' : `${m.milestones.length} milestone(s) reached`}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}

            <h3>Take a student</h3>
            <div className="row">
              <div className="field" style={{ flex: 1 }}>
                <label htmlFor="student">Their name</label>
                <input id="student" value={studentName} onChange={(e) => setStudentName(e.target.value)} />
              </div>
              <button className="btn" onClick={() => send({ type: 'offerMentorship', name: studentName })}>offer</button>
            </div>
            <p className="empty">
              Teaching pays in reputation and in standing with your clan. It never pays in money or
              in anything you could sell, which is deliberate: a reward you could hand to another
              account would be worth farming.
            </p>
          </>
        )}
      </section>

      <section className="panel">
        <p className="eyebrow">Bought with money, worth nothing in a fight</p>
        <h2>Wardrobe</h2>
        {!cosmetics ? (
          <button className="btn" onClick={() => send({ type: 'listCosmetics' })}>Open it</button>
        ) : (
          <div className="list">
            {cosmetics.catalogue.map((c) => (
              <div key={c.id} className="row">
                <div>
                  <div className="row-name">
                    {c.name}
                    {Object.values(cosmetics.equipped).includes(c.id) && (
                      <span className="chip chip-good" style={{ marginLeft: 6 }}>worn</span>
                    )}
                  </div>
                  <div className="row-meta">
                    {c.slot} · {c.source}
                    {c.price !== null && ` · ${c.price.toLocaleString()} ryo`}
                    {!c.owned && !c.available && c.reason && ` · ${c.reason}`}
                  </div>
                </div>
                {c.owned ? (
                  <button className="btn" onClick={() => send({ type: 'equipCosmetic', cosmeticId: c.id })}>wear</button>
                ) : (
                  <button className="btn" disabled={!c.available} onClick={() => send({ type: 'buyCosmetic', cosmeticId: c.id })}>
                    {c.price ? 'buy' : 'claim'}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
        <p className="empty">
          None of this touches a statistic, and none of it can be traded. A cosmetic that could be
          sold would be currency wearing a hat, and currency eventually buys power.
        </p>
      </section>
    </>
  );
}
