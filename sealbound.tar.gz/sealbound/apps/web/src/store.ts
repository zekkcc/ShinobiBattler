import { create } from 'zustand';
import type { ClientMessage, MatchEvent, MatchState, Rank, ServerMessage } from '@shinobi/shared';

export interface MissionBrief {
  id: string; name: string; rank: string; minutes: number;
  ryo: number; xp: number; reputation: number; brief: string; chance: number;
}

export interface Squad {
  squadId: string;
  leaderId: string;
  members: { id: string; name: string; rank: string }[];
  invited: string[];
  mission: { missionId: string; endsAtMs: number } | null;
  partyMissions: { id: string; name: string; minutes: number; ryo: number; party: number; brief: string; chance: number }[];
}

export interface Profile {
  rank: Rank; level: number; xp: number; xpForNext: number;
  ryo: number; reputation: number; standing: string;
  known: string[]; loadout: string[]; missionsAtRank: number;
  rogue: boolean; notoriety: number; bounty: number; amnestyCost: number;
  promotion: { eligible: boolean; missing: string[]; note: string };
}

/* ── Meta-game views ───────────────────────────────────────────────────
   Every one of these is a picture the SERVER sent. The client stores no
   prices it worked out, no yields, no war scores, and no puzzle answers —
   there is nothing here that could disagree with the server, because there is
   nothing here that was computed here. */

export interface WorldView {
  season: string; seasonName: string; weather: string; villageId: string; taxRate: number;
  laws: { id: string; name: string; blurb: string }[];
  commissions: { id: string; name: string; endsAtMs: number }[];
  offices: { officeId: string; name: string; holders: { id: string; name: string }[] }[];
  atWarWith: string[];
}

export interface RegionView {
  id: string; name: string; country: string;
  controllingVillage: string; garrisonClan: string | null; garrisonClanName: string | null;
  resources: string[]; trainingBonus: number; yoursToGather: boolean;
}

export interface WarBoard {
  periodEndsAtMs: number; declareWindowOpen: boolean;
  wars: {
    regionId: string; regionName: string; attackerClanId: string; attackerClanName: string;
    defenderClanId: string | null; attackerScore: number; defenderScore: number; resolvesAtMs: number;
  }[];
}

export interface Inventory {
  ryo: number;
  items: { itemId: string; name: string; kind: string; qty: number }[];
  cosmetics: string[];
  equipped: Record<string, string>;
}

export interface RecipeView {
  id: string; name: string; station: string; minutes: number;
  inputs: { item: string; qty: number }[];
  output: { item: string; qty: number };
  craftable: boolean; missing: string[];
}

export interface MarketView {
  referencePrices: Record<string, number>;
  taxRate: number;
  listings: {
    listingId: string; itemId: string; name: string; qty: number; unitPrice: number;
    sellerName: string; yours: boolean; expiresAtMs: number;
  }[];
}

export interface TradeView {
  incoming: { tradeId: string; fromName: string; offerRyo: number; requestRyo: number; expiresAtMs: number }[];
  outgoing: { tradeId: string; toName: string; offerRyo: number; requestRyo: number; expiresAtMs: number }[];
}

export interface ElectionView {
  villageId: string; cycle: number; phase: string; phaseEndsAtMs: number;
  races: {
    officeId: string; name: string; seats: number;
    candidates: { id: string; name: string; votes: number }[];
    yourVote: string | null; youMayStand: boolean; youMayVote: boolean;
  }[];
}

export interface DungeonList {
  season: string;
  dungeons: { id: string; name: string; regionId: string; blurb: string; open: boolean; reason: string | null; runsLeftToday: number }[];
}

export interface DungeonRoom {
  dungeonId: string; roomId: string; index: number; total: number;
  prompt: string; hint: string; attemptsLeft: number; expiresAtMs: number;
}

export interface MentorView {
  asMentor: { menteeId: string; menteeName: string; startedAt: number; milestones: string[] }[];
  asMentee: { mentorId: string; mentorName: string; startedAt: number; trainingBonus: number } | null;
  offers: { mentorId: string; mentorName: string }[];
}

export interface CosmeticsView {
  owned: string[];
  equipped: Record<string, string>;
  catalogue: {
    id: string; name: string; slot: string; source: string;
    price: number | null; owned: boolean; available: boolean; reason: string | null;
  }[];
}

/**
 * Client state.
 *
 * The client holds no authority over anything: it renders what the server sends
 * and submits intent. There is deliberately no local damage calculation here —
 * the same engine runs on the server and is the only thing that decides.
 */

export interface LogEntry { round: number; events: MatchEvent[] }

interface GameStore {
  status: 'disconnected' | 'connecting' | 'connected';
  playerId: string | null;
  weather: string;
  matchId: string | null;
  opponentName: string;
  state: MatchState | null;
  log: LogEntry[];
  notice: string | null;
  error: string | null;
  waiting: boolean;
  training: { locationId: string; tier: number; endsAtMs: number } | null;
  mission: { missionId: string; endsAtMs: number } | null;
  board: MissionBrief[];
  profile: Profile | null;
  squad: Squad | null;
  squadInvite: { squadId: string; from: string } | null;
  bounties: { targetId: string; name: string; level: number; notoriety: number; value: number }[];
  contract: { targetId: string; expiresAtMs: number; value: number } | null;

  world: WorldView | null;
  regions: RegionView[];
  warBoard: WarBoard | null;
  gathering: { regionId: string; itemId: string; endsAtMs: number } | null;
  crafting: { recipeId: string; endsAtMs: number } | null;
  inventory: Inventory | null;
  recipes: RecipeView[];
  market: MarketView | null;
  trades: TradeView;
  election: ElectionView | null;
  dungeons: DungeonList | null;
  room: DungeonRoom | null;
  mentorship: MentorView | null;
  cosmetics: CosmeticsView | null;

  connect(token: string): void;
  authenticate(mode: 'login' | 'register', name: string, password: string, villageId: string): Promise<void>;
  send(msg: ClientMessage): void;
  clearError(): void;
}

let socket: WebSocket | null = null;

/** One-line description of one side of a trade or gift, for the notice bar. */
function describeSide(ryo: number, items: { itemId: string; qty: number }[]): string {
  const parts = items.map((i) => `${i.qty}x ${i.itemId}`);
  if (ryo > 0) parts.unshift(`${ryo} ryo`);
  return parts.length > 0 ? parts.join(' and ') : 'nothing';
}

export const useGame = create<GameStore>((set, get) => ({
  status: 'disconnected',
  playerId: null,
  weather: 'clear',
  matchId: null,
  opponentName: '',
  state: null,
  log: [],
  notice: null,
  error: null,
  waiting: false,
  training: null,
  mission: null,
  board: [],
  profile: null,
  squad: null,
  squadInvite: null,
  bounties: [],
  contract: null,

  world: null,
  regions: [],
  warBoard: null,
  gathering: null,
  crafting: null,
  inventory: null,
  recipes: [],
  market: null,
  trades: { incoming: [], outgoing: [] },
  election: null,
  dungeons: null,
  room: null,
  mentorship: null,
  cosmetics: null,

  /**
   * Register or sign in over HTTP, then open the socket with the returned token.
   * The token is held in memory only — it is not written to storage, so closing
   * the tab ends the session on this device.
   */
  async authenticate(mode, name, password, villageId) {
    set({ status: 'connecting', error: null });
    try {
      const res = await fetch(`/api/${mode}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(mode === 'register' ? { name, password, villageId } : { name, password }),
      });
      const body = await res.json() as { token?: string; detail?: string; error?: string };
      if (!res.ok || !body.token) {
        set({ status: 'disconnected', error: body.detail ?? body.error ?? 'That did not work.' });
        return;
      }
      get().connect(body.token);
    } catch {
      set({ status: 'disconnected', error: 'Could not reach the server. Is it running on port 3000?' });
    }
  },

  connect(token: string) {
    if (socket) socket.close();
    set({ status: 'connecting', error: null });

    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    socket = new WebSocket(`${proto}://${location.host}/ws`, token);

    socket.onopen = () => set({ status: 'connected' });
    socket.onclose = () => set({ status: 'disconnected', playerId: null });
    socket.onerror = () => set({ error: 'Could not reach the server. Is it running on port 3000?' });

    socket.onmessage = (ev) => {
      const msg = JSON.parse(ev.data as string) as ServerMessage;
      switch (msg.type) {
        case 'welcome':
          set({ playerId: msg.playerId, weather: msg.weather, notice: null });
          break;
        case 'queued':
          set({ notice: `In the queue at ${msg.rank}. Waiting for an opponent.` });
          break;
        case 'matchFound':
          set({ matchId: msg.matchId, opponentName: msg.opponentName, state: msg.state, log: [], notice: null, waiting: false });
          break;
        case 'roundResolved':
          set((s) => ({
            state: msg.state,
            log: [...s.log, { round: msg.state.round - 1, events: msg.events }],
            waiting: false,
            notice: null,
          }));
          break;
        case 'awaitingOpponent':
          set({ waiting: true, notice: 'Move locked in. Waiting for your opponent.' });
          break;
        case 'matchEnded': {
          const me = get().playerId;
          const result = msg.winnerId === null ? 'Draw' : msg.winnerId === me ? 'Victory' : 'Defeat';
          set({ notice: `${result} — rating now ${msg.rating}.`, matchId: null, waiting: false });
          break;
        }
        case 'profile':
          set({ profile: msg });
          break;
        case 'missionBoard':
          set({ board: msg.missions, notice: null });
          break;
        case 'missionAccepted':
          set({ mission: { missionId: msg.missionId, endsAtMs: msg.endsAtMs }, notice: null });
          break;
        case 'missionResolved':
          set({
            mission: null,
            notice: `${msg.success ? 'Mission complete' : 'Mission failed'} — ` +
              `${msg.ryo} ryo, ${msg.xp} xp, ${msg.reputation >= 0 ? '+' : ''}${msg.reputation} reputation` +
              (msg.injured ? '. You came back hurt.' : '.'),
          });
          break;
        case 'jutsuLearned':
          set({ notice: `Learned it for ${msg.paid} ryo. ${msg.ryo} left.` });
          break;
        case 'promotion':
          set({ notice: `Promoted to ${msg.rank}. ${msg.note}` });
          break;
        case 'promotionDenied':
          set({ notice: `Not yet — ${msg.missing.join('; ')}.` });
          break;
        case 'squad':
          set({ squad: msg, squadInvite: null, notice: null });
          break;
        case 'squadInvite':
          set({ squadInvite: { squadId: msg.squadId, from: msg.from }, notice: `${msg.from} wants you on their squad.` });
          break;
        case 'squadDisbanded':
          set({ squad: null, notice: 'Squad disbanded.' });
          break;
        case 'partyMissionResolved':
          set({
            squad: null,
            notice: `${msg.success ? 'Party mission complete' : 'Party mission failed'} — ` +
              `${msg.ryo} ryo, ${msg.xp} xp, ${msg.reputation >= 0 ? '+' : ''}${msg.reputation} reputation (your share).`,
          });
          break;
        case 'defected':
          set({ notice: msg.note });
          break;
        case 'returned':
          set({ notice: `Amnesty bought for ${msg.paid} ryo. ${msg.note}` });
          break;
        case 'bountyBoard':
          set({ bounties: msg.bounties, contract: msg.yourContract, notice: null });
          break;
        case 'contractTaken':
          set({ contract: { targetId: msg.targetId, expiresAtMs: msg.expiresAtMs, value: msg.value },
            notice: `Contract taken. Beat them in the arena to collect ${msg.value} ryo.` });
          break;
        case 'bountyClaimed':
          set({ contract: null, notice: `Bounty collected on ${msg.targetName} — ${msg.paid} ryo.` });
          break;
        case 'bountyLost':
          set({ notice: `${msg.hunterName} collected on you. ${msg.taken} ryo gone.` });
          break;
        case 'trainingStarted':
          set({ training: { locationId: msg.locationId, tier: msg.tier, endsAtMs: msg.endsAtMs }, notice: null });
          break;
        case 'trainingClaimed':
          set({
            training: null,
            notice: `Trained ${msg.minutesCredited} min: ` +
              Object.entries(msg.gains).map(([k, v]) => `${k} +${v}`).join(', '),
          });
          break;
        case 'loadoutSet':
          set({ notice: `Loadout saved — ${msg.jutsuIds.length} technique(s).` });
          break;
        /* ── Meta-game ──────────────────────────────────────────────── */

        case 'world':
          set({ world: msg, weather: msg.weather });
          break;
        case 'regions':
          set({ regions: msg.regions });
          break;
        case 'warBoard':
          set({ warBoard: msg });
          break;
        case 'warDeclared':
          set({ notice: `War declared over ${msg.regionId}. ${msg.stake} ryo staked. It settles ${new Date(msg.resolvesAtMs).toLocaleString()}.` });
          break;
        case 'warResolved':
          set({ notice: `${msg.regionId}: ${msg.note} (${msg.attackerScore} to ${msg.defenderScore})` });
          break;
        case 'gatheringStarted':
          set({ gathering: { regionId: msg.regionId, itemId: msg.itemId, endsAtMs: msg.endsAtMs }, notice: null });
          break;
        case 'gatheringClaimed':
          set({
            gathering: null,
            notice: msg.units > 0
              ? `Brought back ${msg.units} ${msg.itemId}${msg.toll > 0 ? `, ${msg.toll} taken as toll` : ''}. ${msg.note}`
              : 'Nothing worth carrying home.',
          });
          break;
        case 'inventory':
          set({ inventory: msg });
          break;
        case 'recipes':
          set({ recipes: msg.recipes });
          break;
        case 'craftingStarted':
          set({ crafting: { recipeId: msg.recipeId, endsAtMs: msg.endsAtMs }, notice: null });
          break;
        case 'craftingClaimed':
          set({ crafting: null, notice: `Finished: ${msg.qty}x ${msg.item}.` });
          break;
        case 'itemUsed':
          set({ notice: msg.note });
          break;
        case 'market':
          set({ market: msg });
          break;
        case 'listed':
          set({ notice: `Listed ${msg.qty}x ${msg.itemId} at ${msg.unitPrice}. Fee of ${msg.feePaid} paid.` });
          break;
        case 'bought':
          set({ notice: `Bought ${msg.qty}x ${msg.itemId} for ${msg.paid}.` });
          break;
        case 'listingCancelled':
          set({ notice: 'Listing withdrawn. The fee is not refunded.' });
          break;
        case 'tradeProposed':
          set((st) => ({
            notice: `${msg.fromName} offers ${describeSide(msg.offerRyo, msg.offerItems)} for ${describeSide(msg.requestRyo, msg.requestItems)}.`,
            trades: st.trades,
          }));
          break;
        case 'tradeSettled':
          set({ notice: `Trade with ${msg.withName} settled.` });
          break;
        case 'tradeDeclined':
          set({ notice: `Trade with ${msg.withName} called off.` });
          break;
        case 'trades':
          set({ trades: { incoming: msg.incoming, outgoing: msg.outgoing } });
          break;
        case 'gifted':
          set({ notice: `Sent to ${msg.toName}.` });
          break;
        case 'giftReceived':
          set({ notice: `${msg.fromName} sent you ${describeSide(msg.ryo, msg.items)}.` });
          break;
        case 'election':
          set({ election: msg });
          break;
        case 'nominated':
          set({ notice: `Standing for ${msg.officeId}.` });
          break;
        case 'voted':
          set({ notice: 'Vote cast. One per office, per term.' });
          break;
        case 'decree':
          set({ notice: `Decree: ${msg.detail}.` });
          break;
        case 'dungeonList':
          set({ dungeons: msg });
          break;
        case 'dungeonRoom':
          set({ room: msg, notice: null });
          break;
        case 'dungeonProgress':
          set({ notice: msg.note });
          break;
        case 'dungeonCleared':
          set({
            room: null,
            notice: `Cleared. ${msg.ryo} ryo${msg.jutsu ? `, and you learned ${msg.jutsu}` : ''}${msg.legendary ? `, and took ${msg.legendary}` : ''}.`,
          });
          break;
        case 'dungeonFailed':
          set({ room: null, notice: msg.note });
          break;
        case 'mentorship':
          set({ mentorship: msg });
          break;
        case 'mentorshipOffered':
          set({ notice: `Offer sent to ${msg.menteeName}.` });
          break;
        case 'mentorshipStarted':
          set({ notice: msg.asMentor ? `You are now teaching ${msg.withName}.` : `${msg.withName} is teaching you.` });
          break;
        case 'mentorshipEnded':
          set({ notice: `The pairing with ${msg.withName} has ended. ${msg.note}` });
          break;
        case 'menteeMilestone':
          set({ notice: `${msg.menteeName} reached ${msg.milestoneId}. +${msg.reputation} reputation.` });
          break;
        case 'cosmetics':
          set({ cosmetics: msg });
          break;
        case 'cosmeticBought':
          set({ notice: msg.paid > 0 ? `Bought for ${msg.paid} ryo.` : 'Claimed — it was earned, not sold.' });
          break;
        case 'cosmeticEquipped':
          set({ notice: `Worn on the ${msg.slot}.` });
          break;

        case 'error':
          set({ error: humanise(msg.code, msg.detail), waiting: false });
          break;
        default:
          break;
      }
    };
  },

  send(msg: ClientMessage) {
    if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(msg));
  },

  clearError() { set({ error: null }); },
}));

/**
 * Errors explain what happened and what to do about it. They do not apologise
 * and they are never vague.
 */
function humanise(code: string, detail?: string): string {
  switch (code) {
    case 'rateLimited': return 'Slow down — too many actions at once. Wait a moment and try again.';
    case 'unauthenticated': return 'That token is not recognised. Try dev-alice or dev-bob.';
    case 'alreadyInMatch': return 'You are already in a match. Finish or forfeit it first.';
    case 'notInThisMatch': return 'That match is not yours.';
    case 'rejectedAction': return 'That action is not for a body you control.';
    case 'matchOver': return 'This match has already ended.';
    case 'unknownJutsu': return `No such technique: ${detail ?? 'unknown'}.`;
    case 'requirementNotMet': return `Your stats are too low for ${detail ?? 'that technique'}. Train first.`;
    case 'cannotChangeLoadoutMidMatch': return 'Loadouts are locked once a match starts.';
    case 'alreadyTraining': return 'A training session is already running. Claim it first.';
    case 'notTraining': return 'No training session to claim.';
    case 'alreadyOnMission': return 'You are already on a mission. Report back first.';
    case 'notOnMission': return 'No mission to report on.';
    case 'notFinished': return 'That mission is not finished yet.';
    case 'needsParty': return 'That one needs a squad. Solo squads are not supported yet.';
    case 'reputationLocked': return 'The mission desk will not deal with you. Rebuild your standing.';
    case 'cannotAfford': return `You cannot afford that — it costs ${detail ?? 'more'} ryo.`;
    case 'alreadyKnown': return 'You already know that technique.';
    case 'notLearned': return `You have not learned ${detail ?? 'that technique'} yet. Find a teacher.`;
    case 'alreadyInSquad': return 'That shinobi is already on a squad.';
    case 'notInSquad': return 'You are not on a squad.';
    case 'notLeader': return 'Only the squad leader can do that.';
    case 'squadFull': return 'A squad holds four.';
    case 'notInvited': return 'You were not invited to that squad.';
    case 'squadLocked': return 'The mission has started. Nobody leaves until it is done.';
    case 'tooFewMembers': return 'You need more people for that one.';
    case 'notAPartyMission': return 'That is solo work — take it from the mission board.';
    case 'busy': return 'Somebody is already away on a mission.';
    case 'alreadyRogue': return 'You have already left your village.';
    case 'notRogue': return 'You are not a missing-nin.';
    case 'amnestyCooldown': return 'Too soon. The village is not ready to hear from you.';
    case 'targetNotRogue': return 'There is no contract on a shinobi in good standing.';
    case 'notWorthHunting': return 'Nobody is paying for that one yet.';
    case 'alreadyHunting': return 'You are already working a contract.';
    case 'pairCooldown': return 'You hunted them recently. Find somebody else.';
    case 'selfContract': return 'You cannot take a contract on yourself.';
    case 'inMatch': return 'Not in the middle of a match.';
    case 'rankLocked': return 'That location is above your rank.';
    case 'badMessage': return 'The server rejected that message.';
    default: return detail ? `${code}: ${detail}` : code;
  }
}
