import { defineConfig } from 'vitest/config';
export default defineConfig({
  test: { include: ['packages/**/test/**/*.test.ts'], coverage: { provider: 'v8', include: ['packages/engine/src/**'] } },
});
